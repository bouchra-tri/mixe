/**
 * Code 128-B Barcode Generator (Pure SVG)
 * Encodes ASCII alphanumeric strings into real standard Code 128 barcodes.
 */

// Code 128 Patterns (Table B)
// Each pattern is 11 modules wide (except STOP which is 13)
const CODE128_PATTERNS: number[] = [
  0x6cc, 0x66c, 0x666, 0x498, 0x48c, 0x44c, 0x4c8, 0x4c4, 0x464, 0x648, // 0-9
  0x644, 0x624, 0x59c, 0x4dc, 0x4ce, 0x5cc, 0x4ec, 0x4ee, 0x764, 0x734, // 10-19
  0x732, 0x74c, 0x72c, 0x726, 0x768, 0x748, 0x728, 0x5ac, 0x4bc, 0x4be, // 20-29
  0x5bc, 0x4de, 0x4ee, 0x6e8, 0x6d8, 0x6d4, 0x758, 0x754, 0x72e, 0x71e, // 30-39
  0x5e8, 0x5e4, 0x5b8, 0x5b4, 0x59e, 0x4fa, 0x4f6, 0x576, 0x56a, 0x566, // 40-49
  0x55a, 0x556, 0x6da, 0x6d6, 0x76a, 0x766, 0x73a, 0x736, 0x79a, 0x796, // 50-59
  0x75a, 0x756, 0x6b8, 0x6b4, 0x69e, 0x4f8, 0x4f4, 0x574, 0x564, 0x554, // 60-69
  0x6f4, 0x6ec, 0x6dc, 0x6ce, 0x6de, 0x6ee, 0x7b4, 0x7ac, 0x79c, 0x78e, // 70-79
  0x79e, 0x7ae, 0x5f4, 0x5ec, 0x5dc, 0x5ce, 0x5de, 0x5ee, 0x7da, 0x7d6, // 80-89
  0x7ba, 0x7b6, 0x79a, 0x796, 0x75a, 0x756, 0x76a, 0x766, 0x73a, 0x736, // 90-99
  0x774, 0x76c, 0x75c, 0x74e, 0x18eb // 100-104 + START B (104), STOP (106)
];

// Specific constants for Start B and Stop
const START_B = 104; // index 104 pattern = 0x74e
const STOP = 106;

// Binary pattern string builder for Code 128
function getBinaryPattern(patternVal: number, length: number = 11): string {
  let bin = patternVal.toString(2);
  while (bin.length < length) {
    bin = '0' + bin;
  }
  return bin;
}

// Convert string to array of code values (Code 128 Subset B)
export function encodeCode128B(text: string): string {
  const codes: number[] = [START_B];
  let checksum = START_B;

  for (let i = 0; i < text.length; i++) {
    const charCode = text.charCodeAt(i);
    // Code 128 B: ASCII 32 to 127 corresponds to code 0 to 95
    let codeVal = charCode - 32;
    if (codeVal < 0 || codeVal > 95) {
      codeVal = 0; // fallback to space
    }
    codes.push(codeVal);
    checksum += codeVal * (i + 1);
  }

  const checkDigit = checksum % 103;
  codes.push(checkDigit);
  codes.push(STOP);

  // Build binary sequence
  let binary = '0000000000'; // Quiet zone (10 modules)
  
  // Patterns lookup table
  const patternList = [
    // 0 to 102
    "11011001100", "11001101100", "11001100110", "10010011000", "10010001100", "10001001100",
    "10011001000", "10011000100", "10001100100", "11001001000", "11001000100", "11000100100",
    "10110011100", "10011011100", "10011001110", "10111001100", "10011101100", "10011100110",
    "11001110010", "11001011100", "11001001110", "11011100100", "11001110100", "11101101110",
    "11101001100", "11100101100", "11100100110", "11101100100", "11100110100", "11100110010",
    "11011011000", "11011000110", "11000110110", "10100011000", "10001011000", "10001000110",
    "10110001000", "10001101000", "10001100010", "11010001000", "11000101000", "11000100010",
    "10110111000", "10110001110", "10001101110", "10111011000", "10111000110", "10001110110",
    "11101110110", "11010001110", "11000101110", "11011101000", "11011100010", "11011101110",
    "11101011000", "11101000110", "11100010110", "11101101000", "11101100010", "11100011010",
    "11101111010", "11001000010", "11110001010", "10100110000", "10100001100", "10010110000",
    "10010000110", "10000101100", "10000100110", "10110010000", "10110000100", "10011010000",
    "10011000010", "10000110100", "10000110010", "11000010010", "11001010000", "11110111010",
    "11000010100", "10001111010", "10100111100", "10010111100", "10010011110", "10111100100",
    "10011110100", "10011110010", "11110100100", "11110010100", "11110010010", "11011011110",
    "11011110110", "11110110110", "10101111000", "10100011110", "10001011110", "10111101000",
    "10111100010", "11110101000", "11110100010", "10111011110", "10111101110", "11101011110",
    "11110101110", "11010000100", "11010010000", "11010011100", "1100011101011" // 106 Stop
  ];

  for (const c of codes) {
    binary += patternList[c] || '10101010101';
  }

  binary += '0000000000'; // Quiet zone (10 modules)
  return binary;
}

/**
 * Generate a clean standalone SVG barcode string
 */
export function generateBarcodeSVG(
  text: string,
  options: {
    height?: number;
    moduleWidth?: number;
    includeText?: boolean;
    color?: string;
    bgColor?: string;
  } = {}
): string {
  const height = options.height || 50;
  const moduleWidth = options.moduleWidth || 2;
  const includeText = options.includeText !== false;
  const color = options.color || '#0f172a';
  const bgColor = options.bgColor || 'transparent';

  const cleanText = (text || '000000').toUpperCase().replace(/[^ -~]/g, '');
  const binary = encodeCode128B(cleanText);
  const totalWidth = binary.length * moduleWidth;
  const totalHeight = includeText ? height + 18 : height;

  let rects = '';
  let inBar = false;
  let barStart = 0;

  for (let i = 0; i < binary.length; i++) {
    const isBar = binary[i] === '1';
    if (isBar && !inBar) {
      inBar = true;
      barStart = i;
    } else if (!isBar && inBar) {
      inBar = false;
      const barWidth = (i - barStart) * moduleWidth;
      rects += `<rect x="${barStart * moduleWidth}" y="0" width="${barWidth}" height="${height}" fill="${color}" />`;
    }
  }

  if (inBar) {
    const barWidth = (binary.length - barStart) * moduleWidth;
    rects += `<rect x="${barStart * moduleWidth}" y="0" width="${barWidth}" height="${height}" fill="${color}" />`;
  }

  const textElement = includeText
    ? `<text x="${totalWidth / 2}" y="${height + 14}" font-family="'JetBrains Mono', monospace" font-size="11" font-weight="600" text-anchor="middle" fill="${color}" letter-spacing="2">${cleanText}</text>`
    : '';

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${totalWidth} ${totalHeight}" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" style="background: ${bgColor};">
    ${rects}
    ${textElement}
  </svg>`;
}

/**
 * Audio synthesis for instant check-in feedback
 */
class SoundService {
  private ctx: AudioContext | null = null;

  private getContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  // Play pleasant check-in chime (Success)
  playSuccess() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gain = ctx.createGain();

    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(880, now); // A5
    osc1.frequency.exponentialRampToValueAtTime(1318.51, now + 0.12); // E6

    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(440, now);
    osc2.frequency.setValueAtTime(659.25, now + 0.12);

    gain.gain.setValueAtTime(0.15, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(ctx.destination);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + 0.35);
    osc2.stop(now + 0.35);
  }

  // Play late arrival sound (Amber warning note)
  playLate() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(587.33, now); // D5
    osc.frequency.setValueAtTime(440, now + 0.15); // A4

    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.45);
  }

  // Play duplicate / already scanned warning sound
  playDuplicate() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(320, now);
    osc.frequency.setValueAtTime(260, now + 0.1);

    gain.gain.setValueAtTime(0.12, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.3);
  }

  // Play error sound (Unregistered barcode)
  playError() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(180, now);
    osc.frequency.setValueAtTime(140, now + 0.18);

    gain.gain.setValueAtTime(0.25, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.4);
  }

  // Speak Arabic announcement via SpeechSynthesis
  speakArabic(text: string) {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'ar-SA';
      utterance.rate = 1.05;
      utterance.pitch = 1.0;
      const voices = window.speechSynthesis.getVoices();
      const arVoice = voices.find((v) => v.lang.startsWith('ar'));
      if (arVoice) {
        utterance.voice = arVoice;
      }
      window.speechSynthesis.speak(utterance);
    } catch {
      // ignore speech errors
    }
  }
}

export const soundEffects = new SoundService();
