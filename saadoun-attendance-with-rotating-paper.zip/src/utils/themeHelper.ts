import { ThemeColor } from '../types';

export interface ThemeConfig {
  id: ThemeColor;
  name: string;
  circleColor: string; // Swatch dot hex
  // Sidebar outer styling
  sidebarBg: string;
  sidebarHeaderBg: string;
  sidebarBorder: string;
  sidebarTextColor: string;
  sidebarMutedText: string;
  sidebarActiveBg: string;
  sidebarActiveText: string;
  sidebarActiveBorder: string;
  sidebarHoverBg: string;
  sidebarCategoryText: string;
  sidebarBadgeBg: string;
  sidebarFooterBg: string;
  // App Shell styling
  appBg: string;
  appBgDark: string;
  cardBorder: string;
  accentText: string;
  primaryBg: string;
  primaryHoverBg: string;
  primaryText: string;
  badgeBg: string;
  badgeText: string;
  badgeBorder: string;
  ringColor: string;
  // Quick Scan F2 button
  quickScanBtn: string;
  quickScanBtnHover: string;
  // TopBar active accents
  topBarBadgeBg: string;
  topBarBadgeText: string;
  topBarBadgeBorder: string;
}

export const THEME_CONFIGS: Record<string, ThemeConfig> = {
  emerald: {
    id: 'emerald',
    name: 'زمردي',
    circleColor: '#10b981',
    sidebarBg: 'bg-[#102419]',
    sidebarHeaderBg: 'from-[#173525] to-[#0c1a12]',
    sidebarBorder: 'border-emerald-900/60',
    sidebarTextColor: 'text-emerald-100',
    sidebarMutedText: 'text-emerald-200/60',
    sidebarActiveBg: 'bg-emerald-600/25',
    sidebarActiveText: 'text-emerald-200',
    sidebarActiveBorder: 'border-r-4 border-emerald-400',
    sidebarHoverBg: 'hover:bg-emerald-800/20 hover:text-white',
    sidebarCategoryText: 'text-emerald-400/80',
    sidebarBadgeBg: 'bg-emerald-500 text-white',
    sidebarFooterBg: 'bg-[#0b1710]/70 border-emerald-900/40',
    appBg: 'bg-[#f4f8f5]',
    appBgDark: 'bg-[#0b1410]',
    cardBorder: 'border-emerald-200/70',
    accentText: 'text-emerald-700',
    primaryBg: 'bg-[#1e4620]',
    primaryHoverBg: 'hover:bg-[#173719]',
    primaryText: 'text-white',
    badgeBg: 'bg-emerald-50',
    badgeText: 'text-emerald-800',
    badgeBorder: 'border-emerald-200',
    ringColor: 'focus:ring-emerald-500/20 focus:border-emerald-600',
    quickScanBtn: 'bg-[#1e4620] hover:bg-[#173719] text-white',
    quickScanBtnHover: 'hover:bg-[#173719]',
    topBarBadgeBg: 'bg-emerald-50',
    topBarBadgeText: 'text-emerald-900',
    topBarBadgeBorder: 'border-emerald-200/70',
  },
  blue: {
    id: 'blue',
    name: 'أزرق',
    circleColor: '#3b82f6',
    sidebarBg: 'bg-[#0f1d33]',
    sidebarHeaderBg: 'from-[#142848] to-[#0a1424]',
    sidebarBorder: 'border-blue-900/60',
    sidebarTextColor: 'text-blue-100',
    sidebarMutedText: 'text-blue-200/60',
    sidebarActiveBg: 'bg-blue-600/25',
    sidebarActiveText: 'text-blue-200',
    sidebarActiveBorder: 'border-r-4 border-blue-400',
    sidebarHoverBg: 'hover:bg-blue-800/20 hover:text-white',
    sidebarCategoryText: 'text-blue-400/80',
    sidebarBadgeBg: 'bg-blue-500 text-white',
    sidebarFooterBg: 'bg-[#080f1b]/70 border-blue-900/40',
    appBg: 'bg-[#f4f7fb]',
    appBgDark: 'bg-[#0a121e]',
    cardBorder: 'border-blue-200/70',
    accentText: 'text-blue-700',
    primaryBg: 'bg-[#1d4ed8]',
    primaryHoverBg: 'hover:bg-[#1e40af]',
    primaryText: 'text-white',
    badgeBg: 'bg-blue-50',
    badgeText: 'text-blue-800',
    badgeBorder: 'border-blue-200',
    ringColor: 'focus:ring-blue-500/20 focus:border-blue-600',
    quickScanBtn: 'bg-[#1d4ed8] hover:bg-[#1e40af] text-white',
    quickScanBtnHover: 'hover:bg-[#1e40af]',
    topBarBadgeBg: 'bg-blue-50',
    topBarBadgeText: 'text-blue-900',
    topBarBadgeBorder: 'border-blue-200/70',
  },
  red: {
    id: 'red',
    name: 'أحمر',
    circleColor: '#ef4444',
    sidebarBg: 'bg-[#251014]',
    sidebarHeaderBg: 'from-[#38161e] to-[#18090c]',
    sidebarBorder: 'border-red-900/60',
    sidebarTextColor: 'text-red-100',
    sidebarMutedText: 'text-red-200/60',
    sidebarActiveBg: 'bg-red-600/25',
    sidebarActiveText: 'text-red-200',
    sidebarActiveBorder: 'border-r-4 border-red-400',
    sidebarHoverBg: 'hover:bg-red-800/20 hover:text-white',
    sidebarCategoryText: 'text-red-400/80',
    sidebarBadgeBg: 'bg-red-500 text-white',
    sidebarFooterBg: 'bg-[#14080a]/70 border-red-900/40',
    appBg: 'bg-[#fcf5f5]',
    appBgDark: 'bg-[#160a0c]',
    cardBorder: 'border-red-200/70',
    accentText: 'text-red-700',
    primaryBg: 'bg-[#b91c1c]',
    primaryHoverBg: 'hover:bg-[#991b1b]',
    primaryText: 'text-white',
    badgeBg: 'bg-red-50',
    badgeText: 'text-red-800',
    badgeBorder: 'border-red-200',
    ringColor: 'focus:ring-red-500/20 focus:border-red-600',
    quickScanBtn: 'bg-[#b91c1c] hover:bg-[#991b1b] text-white',
    quickScanBtnHover: 'hover:bg-[#991b1b]',
    topBarBadgeBg: 'bg-red-50',
    topBarBadgeText: 'text-red-900',
    topBarBadgeBorder: 'border-red-200/70',
  },
  orange: {
    id: 'orange',
    name: 'برتقالي',
    circleColor: '#f97316',
    sidebarBg: 'bg-[#25160d]',
    sidebarHeaderBg: 'from-[#3a2113] to-[#170c07]',
    sidebarBorder: 'border-orange-900/60',
    sidebarTextColor: 'text-orange-100',
    sidebarMutedText: 'text-orange-200/60',
    sidebarActiveBg: 'bg-orange-600/25',
    sidebarActiveText: 'text-orange-200',
    sidebarActiveBorder: 'border-r-4 border-orange-400',
    sidebarHoverBg: 'hover:bg-orange-800/20 hover:text-white',
    sidebarCategoryText: 'text-orange-400/80',
    sidebarBadgeBg: 'bg-orange-500 text-white',
    sidebarFooterBg: 'bg-[#140a05]/70 border-orange-900/40',
    appBg: 'bg-[#fdf6f0]',
    appBgDark: 'bg-[#160d07]',
    cardBorder: 'border-orange-200/70',
    accentText: 'text-orange-700',
    primaryBg: 'bg-[#c2410c]',
    primaryHoverBg: 'hover:bg-[#9a3412]',
    primaryText: 'text-white',
    badgeBg: 'bg-orange-50',
    badgeText: 'text-orange-800',
    badgeBorder: 'border-orange-200',
    ringColor: 'focus:ring-orange-500/20 focus:border-orange-600',
    quickScanBtn: 'bg-[#c2410c] hover:bg-[#9a3412] text-white',
    quickScanBtnHover: 'hover:bg-[#9a3412]',
    topBarBadgeBg: 'bg-orange-50',
    topBarBadgeText: 'text-orange-900',
    topBarBadgeBorder: 'border-orange-200/70',
  },
  amber: {
    id: 'amber',
    name: 'أصفر',
    circleColor: '#d97706',
    sidebarBg: 'bg-[#201c10]',
    sidebarHeaderBg: 'from-[#332b17] to-[#161208]',
    sidebarBorder: 'border-amber-900/50',
    sidebarTextColor: 'text-amber-100',
    sidebarMutedText: 'text-amber-200/60',
    sidebarActiveBg: 'bg-amber-600/25',
    sidebarActiveText: 'text-amber-200',
    sidebarActiveBorder: 'border-r-4 border-amber-400',
    sidebarHoverBg: 'hover:bg-amber-800/20 hover:text-white',
    sidebarCategoryText: 'text-amber-400/80',
    sidebarBadgeBg: 'bg-amber-500 text-white',
    sidebarFooterBg: 'bg-[#131008]/70 border-amber-900/40',
    appBg: 'bg-[#faf8f0]',
    appBgDark: 'bg-[#141209]',
    cardBorder: 'border-amber-200/70',
    accentText: 'text-amber-800',
    primaryBg: 'bg-[#78350f]',
    primaryHoverBg: 'hover:bg-[#602a0c]',
    primaryText: 'text-white',
    badgeBg: 'bg-amber-50',
    badgeText: 'text-amber-900',
    badgeBorder: 'border-amber-200',
    ringColor: 'focus:ring-amber-500/20 focus:border-amber-600',
    quickScanBtn: 'bg-[#854d0e] hover:bg-[#713f12] text-white',
    quickScanBtnHover: 'hover:bg-[#713f12]',
    topBarBadgeBg: 'bg-amber-100/80',
    topBarBadgeText: 'text-amber-950',
    topBarBadgeBorder: 'border-amber-300/70',
  },
  purple: {
    id: 'purple',
    name: 'بنفسجي',
    circleColor: '#8b5cf6',
    sidebarBg: 'bg-[#1a1228]',
    sidebarHeaderBg: 'from-[#2a1b3f] to-[#110a1b]',
    sidebarBorder: 'border-purple-900/60',
    sidebarTextColor: 'text-purple-100',
    sidebarMutedText: 'text-purple-200/60',
    sidebarActiveBg: 'bg-purple-600/25',
    sidebarActiveText: 'text-purple-200',
    sidebarActiveBorder: 'border-r-4 border-purple-400',
    sidebarHoverBg: 'hover:bg-purple-800/20 hover:text-white',
    sidebarCategoryText: 'text-purple-400/80',
    sidebarBadgeBg: 'bg-purple-500 text-white',
    sidebarFooterBg: 'bg-[#0f0a17]/70 border-purple-900/40',
    appBg: 'bg-[#f9f5fd]',
    appBgDark: 'bg-[#120b1b]',
    cardBorder: 'border-purple-200/70',
    accentText: 'text-purple-700',
    primaryBg: 'bg-[#6d28d9]',
    primaryHoverBg: 'hover:bg-[#5b21b6]',
    primaryText: 'text-white',
    badgeBg: 'bg-purple-50',
    badgeText: 'text-purple-800',
    badgeBorder: 'border-purple-200',
    ringColor: 'focus:ring-purple-500/20 focus:border-purple-600',
    quickScanBtn: 'bg-[#6d28d9] hover:bg-[#5b21b6] text-white',
    quickScanBtnHover: 'hover:bg-[#5b21b6]',
    topBarBadgeBg: 'bg-purple-50',
    topBarBadgeText: 'text-purple-900',
    topBarBadgeBorder: 'border-purple-200/70',
  },
  rose: {
    id: 'rose',
    name: 'وردي',
    circleColor: '#ec4899',
    sidebarBg: 'bg-[#24101c]',
    sidebarHeaderBg: 'from-[#3a162d] to-[#170912]',
    sidebarBorder: 'border-pink-900/60',
    sidebarTextColor: 'text-pink-100',
    sidebarMutedText: 'text-pink-200/60',
    sidebarActiveBg: 'bg-pink-600/25',
    sidebarActiveText: 'text-pink-200',
    sidebarActiveBorder: 'border-r-4 border-pink-400',
    sidebarHoverBg: 'hover:bg-pink-800/20 hover:text-white',
    sidebarCategoryText: 'text-pink-400/80',
    sidebarBadgeBg: 'bg-pink-500 text-white',
    sidebarFooterBg: 'bg-[#13080f]/70 border-pink-900/40',
    appBg: 'bg-[#fdf4f8]',
    appBgDark: 'bg-[#160912]',
    cardBorder: 'border-pink-200/70',
    accentText: 'text-pink-700',
    primaryBg: 'bg-[#be185d]',
    primaryHoverBg: 'hover:bg-[#9d174d]',
    primaryText: 'text-white',
    badgeBg: 'bg-pink-50',
    badgeText: 'text-pink-800',
    badgeBorder: 'border-pink-200',
    ringColor: 'focus:ring-pink-500/20 focus:border-pink-600',
    quickScanBtn: 'bg-[#be185d] hover:bg-[#9d174d] text-white',
    quickScanBtnHover: 'hover:bg-[#9d174d]',
    topBarBadgeBg: 'bg-pink-50',
    topBarBadgeText: 'text-pink-900',
    topBarBadgeBorder: 'border-pink-200/70',
  },
  slate: {
    id: 'slate',
    name: 'رمادي',
    circleColor: '#64748b',
    sidebarBg: 'bg-[#161c24]',
    sidebarHeaderBg: 'from-[#232d3a] to-[#0f1319]',
    sidebarBorder: 'border-slate-800/60',
    sidebarTextColor: 'text-slate-100',
    sidebarMutedText: 'text-slate-300/60',
    sidebarActiveBg: 'bg-slate-700/40',
    sidebarActiveText: 'text-slate-200',
    sidebarActiveBorder: 'border-r-4 border-slate-400',
    sidebarHoverBg: 'hover:bg-slate-800/30 hover:text-white',
    sidebarCategoryText: 'text-slate-400/80',
    sidebarBadgeBg: 'bg-slate-600 text-white',
    sidebarFooterBg: 'bg-[#0f1319]/70 border-slate-800/40',
    appBg: 'bg-[#f6f8fa]',
    appBgDark: 'bg-[#0e1217]',
    cardBorder: 'border-slate-200/80',
    accentText: 'text-slate-700',
    primaryBg: 'bg-[#334155]',
    primaryHoverBg: 'hover:bg-[#1e293b]',
    primaryText: 'text-white',
    badgeBg: 'bg-slate-100',
    badgeText: 'text-slate-800',
    badgeBorder: 'border-slate-200',
    ringColor: 'focus:ring-slate-500/20 focus:border-slate-600',
    quickScanBtn: 'bg-[#334155] hover:bg-[#1e293b] text-white',
    quickScanBtnHover: 'hover:bg-[#1e293b]',
    topBarBadgeBg: 'bg-slate-100',
    topBarBadgeText: 'text-slate-900',
    topBarBadgeBorder: 'border-slate-200',
  },
};

// Normalized list of 8 colors for the palette picker
export const THEME_COLOR_LIST: { id: ThemeColor; name: string; circleColor: string }[] = [
  { id: 'emerald', name: 'زمردي', circleColor: '#10b981' },
  { id: 'blue', name: 'أزرق', circleColor: '#3b82f6' },
  { id: 'red', name: 'أحمر', circleColor: '#ef4444' },
  { id: 'orange', name: 'برتقالي', circleColor: '#f97316' },
  { id: 'amber', name: 'أصفر', circleColor: '#d97706' },
  { id: 'purple', name: 'بنفسجي', circleColor: '#8b5cf6' },
  { id: 'rose', name: 'وردي', circleColor: '#ec4899' },
  { id: 'slate', name: 'رمادي', circleColor: '#64748b' },
];

export function getThemeConfig(theme?: ThemeColor): ThemeConfig {
  if (!theme || (theme as string) === 'light' || (theme as string) === 'dark') {
    return THEME_CONFIGS.amber; // Default to amber matching the reference screenshot!
  }
  return THEME_CONFIGS[theme] || THEME_CONFIGS.amber;
}

export function applyThemeVariables(theme?: ThemeColor, isDark: boolean = false): void {
  const cfg = getThemeConfig(theme);
  const root = document.documentElement;

  // Set CSS variables so any component can reference theme colors easily
  root.style.setProperty('--theme-circle', cfg.circleColor);
  root.style.setProperty('--theme-accent', cfg.accentText);
  if (isDark) {
    root.classList.add('dark');
  } else {
    root.classList.remove('dark');
  }
}
