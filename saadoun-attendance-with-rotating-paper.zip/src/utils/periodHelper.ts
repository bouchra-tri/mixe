import { SchoolPeriod, SchoolSettings, PeriodId } from '../types';

export const DEFAULT_PERIODS: SchoolPeriod[] = [
  // 3 فترات صباحية
  {
    id: 'm1',
    name: 'الفترة الصباحية 1 (فوج 08:00)',
    shortName: 'ص 1 (08:00)',
    type: 'morning',
    startTime: '08:00',
    lateThreshold: '08:05',
    cutoffTime: '08:45',
    active: true,
  },
  {
    id: 'm2',
    name: 'الفترة الصباحية 2 (فوج 09:00)',
    shortName: 'ص 2 (09:00)',
    type: 'morning',
    startTime: '09:00',
    lateThreshold: '09:05',
    cutoffTime: '09:45',
    active: true,
  },
  {
    id: 'm3',
    name: 'الفترة الصباحية 3 (فوج 10:00)',
    shortName: 'ص 3 (10:00)',
    type: 'morning',
    startTime: '10:00',
    lateThreshold: '10:05',
    cutoffTime: '10:45',
    active: true,
  },
  // 3 فترات مسائية
  {
    id: 'a1',
    name: 'الفترة المسائية 1 (فوج 13:00)',
    shortName: 'م 1 (13:00)',
    type: 'afternoon',
    startTime: '13:00',
    lateThreshold: '13:05',
    cutoffTime: '13:45',
    active: true,
  },
  {
    id: 'a2',
    name: 'الفترة المسائية 2 (فوج 14:00)',
    shortName: 'م 2 (14:00)',
    type: 'afternoon',
    startTime: '14:00',
    lateThreshold: '14:05',
    cutoffTime: '14:45',
    active: true,
  },
  {
    id: 'a3',
    name: 'الفترة المسائية 3 (فوج 15:00)',
    shortName: 'م 3 (15:00)',
    type: 'afternoon',
    startTime: '15:00',
    lateThreshold: '15:05',
    cutoffTime: '15:45',
    active: true,
  },
];

/**
 * Ensures settings has a valid, non-empty periods array
 */
export function getSettingsPeriods(settings?: SchoolSettings): SchoolPeriod[] {
  if (settings?.periods && Array.isArray(settings.periods) && settings.periods.length >= 6) {
    return settings.periods;
  }
  return DEFAULT_PERIODS;
}

/**
 * Find period by its ID (m1, m2, m3, a1, a2, a3)
 */
export function getPeriodById(settings: SchoolSettings | undefined, id: string): SchoolPeriod {
  const periods = getSettingsPeriods(settings);
  const found = periods.find((p) => p.id === id);
  if (found) return found;

  // Fallback for legacy 'morning' / 'afternoon'
  if (id === 'afternoon') {
    return periods.find((p) => p.type === 'afternoon') || DEFAULT_PERIODS[3];
  }
  return periods.find((p) => p.type === 'morning') || DEFAULT_PERIODS[0];
}

/**
 * Get all morning periods (3 periods)
 */
export function getMorningPeriods(settings?: SchoolSettings): SchoolPeriod[] {
  const periods = getSettingsPeriods(settings);
  return periods.filter((p) => p.type === 'morning');
}

/**
 * Get all afternoon periods (3 periods)
 */
export function getAfternoonPeriods(settings?: SchoolSettings): SchoolPeriod[] {
  const periods = getSettingsPeriods(settings);
  return periods.filter((p) => p.type === 'afternoon');
}

/**
 * Auto-detect the closest active period based on the current wall clock time
 */
export function getAutoDetectedPeriod(settings?: SchoolSettings): PeriodId {
  const now = new Date();
  const currentMinutes = now.getHours() * 60 + now.getMinutes();

  // 00:00 - 08:45 -> m1 (08:00)
  if (currentMinutes < 8 * 60 + 45) return 'm1';
  // 08:45 - 09:45 -> m2 (09:00)
  if (currentMinutes < 9 * 60 + 45) return 'm2';
  // 09:45 - 12:30 -> m3 (10:00)
  if (currentMinutes < 12 * 60 + 30) return 'm3';
  // 12:30 - 13:45 -> a1 (13:00)
  if (currentMinutes < 13 * 60 + 45) return 'a1';
  // 13:45 - 14:45 -> a2 (14:00)
  if (currentMinutes < 14 * 60 + 45) return 'a2';
  // >= 14:45 -> a3 (15:00)
  return 'a3';
}

/**
 * Check if a period ID corresponds to morning or afternoon
 */
export function getPeriodSessionType(periodId: string): 'morning' | 'afternoon' {
  if (periodId.startsWith('m') || periodId === 'morning') return 'morning';
  return 'afternoon';
}

/**
 * Formats period name for display
 */
export function getPeriodDisplayName(settings: SchoolSettings | undefined, periodId: string): string {
  const period = getPeriodById(settings, periodId);
  return period.name;
}

/**
 * Check if an attendance record matches a session or specific period filter
 */
export function matchRecordPeriod(
  recordSession: string,
  filterPeriodIdOrType: string // 'all' | 'morning' | 'afternoon' | 'm1' | 'm2' | 'm3' | 'a1' | 'a2' | 'a3'
): boolean {
  if (filterPeriodIdOrType === 'all') return true;

  if (filterPeriodIdOrType === 'morning') {
    return recordSession === 'morning' || recordSession.startsWith('m');
  }

  if (filterPeriodIdOrType === 'afternoon') {
    return recordSession === 'afternoon' || recordSession.startsWith('a');
  }

  // Exact period match
  if (recordSession === filterPeriodIdOrType) return true;

  // Legacy fallback if record was saved as 'morning' and filter is 'm1'
  if (recordSession === 'morning' && filterPeriodIdOrType === 'm1') return true;
  if (recordSession === 'afternoon' && filterPeriodIdOrType === 'a1') return true;

  return false;
}

/**
 * Detects the matching active period for a given scan time. Returns null if outside school periods.
 */
export function detectPeriodForScanTime(settings?: SchoolSettings, now = new Date()): SchoolPeriod | null {
  const periods = getSettingsPeriods(settings).filter((p) => p.active !== false);
  const currentMinutes = now.getHours() * 60 + now.getMinutes();

  for (const period of periods) {
    const [startH, startM] = (period.startTime || '08:00').split(':').map(Number);
    const [endH, endM] = (period.cutoffTime || period.startTime || '08:45').split(':').map(Number);
    const startMins = startH * 60 + startM - 35; // allow scanning 35 mins before period start
    const endMins = endH * 60 + endM + 20; // allow scanning 20 mins after cutoff

    if (currentMinutes >= startMins && currentMinutes <= endMins) {
      return period;
    }
  }

  return null;
}

