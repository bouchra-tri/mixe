import { ThemeColorId, ThemeMode, ThemePalette, ThemeConfig } from '../types/theme';

export const THEME_STORAGE_KEY = 'saadoun_theme_config_v2';
export const DEFAULT_THEME_COLOR: ThemeColorId = 'burgundy';
export const DEFAULT_THEME_MODE: ThemeMode = 'dark';

export const THEME_PRESETS: Record<Exclude<ThemeColorId, 'custom'>, ThemePalette> = {
  burgundy: {
    id: 'burgundy',
    name: 'Burgundy Gold',
    nameAr: 'العنابي والذهبي الملكي',
    primary: '#590B35',
    hover: '#420827',
    active: '#2d051a',
    light: '#321323',
    border: '#54203C',
    ring: 'rgba(239, 88, 181, 0.35)',
    foreground: '#F4E8C1',
    gradientFrom: '#590B35',
    gradientTo: '#321323',
    laser: '#AD965B',
    darkLight: 'rgba(50, 19, 35, 0.85)',
    darkBorder: '#54203C',
  },
  emerald: {
    id: 'emerald',
    name: 'Emerald',
    nameAr: 'الزمردي',
    primary: '#059669',
    hover: '#047857',
    active: '#065f46',
    light: '#ecfdf5',
    border: '#a7f3d0',
    ring: 'rgba(5, 150, 105, 0.35)',
    foreground: '#ffffff',
    gradientFrom: '#059669',
    gradientTo: '#047857',
    laser: '#10b981',
    darkLight: 'rgba(5, 150, 105, 0.18)',
    darkBorder: 'rgba(16, 185, 129, 0.35)',
  },
  blue: {
    id: 'blue',
    name: 'Royal Blue',
    nameAr: 'الأزرق الملكي',
    primary: '#2563eb',
    hover: '#1d4ed8',
    active: '#1e40af',
    light: '#eff6ff',
    border: '#bfdbfe',
    ring: 'rgba(37, 99, 235, 0.35)',
    foreground: '#ffffff',
    gradientFrom: '#2563eb',
    gradientTo: '#1d4ed8',
    laser: '#3b82f6',
    darkLight: 'rgba(37, 99, 235, 0.18)',
    darkBorder: 'rgba(59, 130, 246, 0.35)',
  },
  red: {
    id: 'red',
    name: 'Crimson Red',
    nameAr: 'الأحمر العنابي',
    primary: '#dc2626',
    hover: '#b91c1c',
    active: '#991b1b',
    light: '#fef2f2',
    border: '#fecaca',
    ring: 'rgba(220, 38, 38, 0.35)',
    foreground: '#ffffff',
    gradientFrom: '#dc2626',
    gradientTo: '#b91c1c',
    laser: '#ef4444',
    darkLight: 'rgba(220, 38, 38, 0.18)',
    darkBorder: 'rgba(239, 68, 68, 0.35)',
  },
  orange: {
    id: 'orange',
    name: 'Vibrant Orange',
    nameAr: 'البرتقالي الحيوي',
    primary: '#ea580c',
    hover: '#c2410c',
    active: '#9a3412',
    light: '#fff7ed',
    border: '#fed7aa',
    ring: 'rgba(234, 88, 12, 0.35)',
    foreground: '#ffffff',
    gradientFrom: '#ea580c',
    gradientTo: '#c2410c',
    laser: '#f97316',
    darkLight: 'rgba(234, 88, 12, 0.18)',
    darkBorder: 'rgba(249, 115, 22, 0.35)',
  },
  yellow: {
    id: 'yellow',
    name: 'Golden Amber',
    nameAr: 'الأصفر الذهبي',
    primary: '#eab308',
    hover: '#ca8a04',
    active: '#a16207',
    light: '#fefce8',
    border: '#fef08a',
    ring: 'rgba(234, 179, 8, 0.35)',
    foreground: '#0f172a',
    gradientFrom: '#eab308',
    gradientTo: '#ca8a04',
    laser: '#facc15',
    darkLight: 'rgba(234, 179, 8, 0.18)',
    darkBorder: 'rgba(250, 204, 21, 0.35)',
  },
  purple: {
    id: 'purple',
    name: 'Imperial Purple',
    nameAr: 'البنفسجي الأنيق',
    primary: '#7c3aed',
    hover: '#6d28d9',
    active: '#5b21b6',
    light: '#f5f3ff',
    border: '#ddd6fe',
    ring: 'rgba(124, 58, 237, 0.35)',
    foreground: '#ffffff',
    gradientFrom: '#7c3aed',
    gradientTo: '#6d28d9',
    laser: '#a855f7',
    darkLight: 'rgba(124, 58, 237, 0.18)',
    darkBorder: 'rgba(168, 85, 247, 0.35)',
  },
  pink: {
    id: 'pink',
    name: 'Modern Rose',
    nameAr: 'الوردي العصري',
    primary: '#db2777',
    hover: '#be185d',
    active: '#9d174d',
    light: '#fdf2f8',
    border: '#fbcfe8',
    ring: 'rgba(219, 39, 119, 0.35)',
    foreground: '#ffffff',
    gradientFrom: '#db2777',
    gradientTo: '#be185d',
    laser: '#ec4899',
    darkLight: 'rgba(219, 39, 119, 0.18)',
    darkBorder: 'rgba(236, 72, 153, 0.35)',
  },
  gray: {
    id: 'gray',
    name: 'Slate Gray',
    nameAr: 'الرمادي الاحترافي',
    primary: '#475569',
    hover: '#334155',
    active: '#1e293b',
    light: '#f8fafc',
    border: '#cbd5e1',
    ring: 'rgba(71, 85, 105, 0.35)',
    foreground: '#ffffff',
    gradientFrom: '#475569',
    gradientTo: '#334155',
    laser: '#64748b',
    darkLight: 'rgba(71, 85, 105, 0.22)',
    darkBorder: 'rgba(148, 163, 184, 0.35)',
  },
  amber: {
    id: 'amber',
    name: 'Amber Gold',
    nameAr: 'العنبري الذهبي',
    primary: '#d97706',
    hover: '#b45309',
    active: '#92400e',
    light: '#fffbeb',
    border: '#fde68a',
    ring: 'rgba(217, 119, 6, 0.35)',
    foreground: '#ffffff',
    gradientFrom: '#d97706',
    gradientTo: '#b45309',
    laser: '#f59e0b',
    darkLight: 'rgba(217, 119, 6, 0.18)',
    darkBorder: 'rgba(245, 158, 11, 0.35)',
  },
  rose: {
    id: 'rose',
    name: 'Rose Pink',
    nameAr: 'الوردي الزهري',
    primary: '#e11d48',
    hover: '#be123c',
    active: '#9f1239',
    light: '#fff1f2',
    border: '#fecdd3',
    ring: 'rgba(225, 29, 72, 0.35)',
    foreground: '#ffffff',
    gradientFrom: '#e11d48',
    gradientTo: '#be123c',
    laser: '#f43f5e',
    darkLight: 'rgba(225, 29, 72, 0.18)',
    darkBorder: 'rgba(244, 63, 94, 0.35)',
  },
  slate: {
    id: 'slate',
    name: 'Slate Dark',
    nameAr: 'الرمادي الصخري',
    primary: '#334155',
    hover: '#1e293b',
    active: '#0f172a',
    light: '#f1f5f9',
    border: '#cbd5e1',
    ring: 'rgba(51, 65, 85, 0.35)',
    foreground: '#ffffff',
    gradientFrom: '#334155',
    gradientTo: '#1e293b',
    laser: '#475569',
    darkLight: 'rgba(51, 65, 85, 0.22)',
    darkBorder: 'rgba(100, 116, 139, 0.35)',
  },
};

// Helper: Hex color manipulation & relative luminance calculation
function hexToRgb(hex: string): { r: number; g: number; b: number } {
  let cleanHex = hex.replace('#', '').trim();
  if (cleanHex.length === 3) {
    cleanHex = cleanHex
      .split('')
      .map((c) => c + c)
      .join('');
  }
  const num = parseInt(cleanHex, 16);
  return {
    r: (num >> 16) & 255,
    g: (num >> 8) & 255,
    b: num & 255,
  };
}

function rgbToHex(r: number, g: number, b: number): string {
  const clamp = (v: number) => Math.max(0, Math.min(255, Math.round(v)));
  const toHex = (v: number) => clamp(v).toString(16).padStart(2, '0');
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}

function adjustColorBrightness(hex: string, percent: number): string {
  const { r, g, b } = hexToRgb(hex);
  const factor = 1 + percent / 100;
  return rgbToHex(r * factor, g * factor, b * factor);
}

function calculateLuminance(r: number, g: number, b: number): number {
  const a = [r, g, b].map((v) => {
    v /= 255;
    return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * a[0] + 0.7152 * a[1] + 0.0722 * a[2];
}

export function generateCustomPalette(hex: string): ThemePalette {
  let cleanHex = hex.startsWith('#') ? hex : `#${hex}`;
  if (!/^#[0-9A-Fa-f]{6}$/.test(cleanHex)) {
    cleanHex = '#590B35';
  }

  const { r, g, b } = hexToRgb(cleanHex);
  const luminance = calculateLuminance(r, g, b);

  const foreground = luminance > 0.55 ? '#0f172a' : '#F4E8C1';
  const hover = adjustColorBrightness(cleanHex, -14);
  const active = adjustColorBrightness(cleanHex, -25);
  const light = `rgba(${r}, ${g}, ${b}, 0.15)`;
  const border = `rgba(${r}, ${g}, ${b}, 0.35)`;
  const ring = `rgba(239, 88, 181, 0.35)`;
  const darkLight = `rgba(${r}, ${g}, ${b}, 0.25)`;
  const darkBorder = `rgba(${r}, ${g}, ${b}, 0.5)`;

  return {
    id: 'custom',
    name: 'Custom',
    nameAr: 'لون مخصص',
    primary: cleanHex,
    hover,
    active,
    light,
    border,
    ring,
    foreground,
    gradientFrom: cleanHex,
    gradientTo: hover,
    laser: '#AD965B',
    darkLight,
    darkBorder,
  };
}

export function getPalette(colorId: ThemeColorId, customHex?: string): ThemePalette {
  if (colorId === 'custom' && customHex) {
    return generateCustomPalette(customHex);
  }
  return THEME_PRESETS[colorId as Exclude<ThemeColorId, 'custom'>] || THEME_PRESETS.burgundy;
}

export function getStoredThemeConfig(): ThemeConfig {
  try {
    const raw = localStorage.getItem(THEME_STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
    const legacy = localStorage.getItem('saadoun_achour_settings_v1');
    if (legacy) {
      const parsed = JSON.parse(legacy);
      if (parsed.themeColor) {
        return {
          color: parsed.themeColor,
          customHex: parsed.customHexColor,
          mode: parsed.themeMode || 'dark',
        };
      }
    }
  } catch (e) {
    console.warn('Error reading stored theme:', e);
  }
  return {
    color: DEFAULT_THEME_COLOR,
    mode: DEFAULT_THEME_MODE,
  };
}

export function saveStoredThemeConfig(config: ThemeConfig): void {
  try {
    localStorage.setItem(THEME_STORAGE_KEY, JSON.stringify(config));
  } catch (e) {
    console.warn('Error saving theme config:', e);
  }
}

export function applyThemeToDOM(config: ThemeConfig): void {
  if (typeof document === 'undefined') return;

  const root = document.documentElement;
  const isDark =
    config.mode === 'dark' ||
    (config.mode === 'system' &&
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-color-scheme: dark)').matches);

  if (isDark || config.color === 'burgundy') {
    root.classList.add('dark');
  } else {
    root.classList.remove('dark');
  }

  const palette = getPalette(config.color, config.customHex);

  root.style.setProperty('--theme-primary', palette.primary);
  root.style.setProperty('--theme-primary-hover', palette.hover);
  root.style.setProperty('--theme-primary-active', palette.active);
  root.style.setProperty('--theme-primary-light', isDark || config.color === 'burgundy' ? (palette.darkLight || palette.light) : palette.light);
  root.style.setProperty('--theme-primary-border', isDark || config.color === 'burgundy' ? (palette.darkBorder || palette.border) : palette.border);
  root.style.setProperty('--theme-primary-ring', palette.ring);
  root.style.setProperty('--theme-primary-fg', palette.foreground);
  root.style.setProperty('--theme-primary-gradient-from', palette.gradientFrom);
  root.style.setProperty('--theme-primary-gradient-to', palette.gradientTo);
  root.style.setProperty('--theme-laser', palette.laser);

  // Luxurious Burgundy & Gold & Cream palette variables
  if (isDark || config.color === 'burgundy') {
    root.style.setProperty('--app-bg', '#25101E');
    root.style.setProperty('--app-surface', '#321323');
    root.style.setProperty('--app-surface-subtle', '#2f1120');
    root.style.setProperty('--app-card', '#321323');
    root.style.setProperty('--app-border', '#54203C');
    root.style.setProperty('--app-border-subtle', '#321323');
    root.style.setProperty('--app-text', '#F4E8C1');
    root.style.setProperty('--app-text-muted', '#BCAF91');
    root.style.setProperty('--app-text-subtle', '#9e8f6f');
    root.style.setProperty('--theme-sidebar-bg', '#25101E');
  } else {
    root.style.setProperty('--app-bg', '#f8fafc');
    root.style.setProperty('--app-surface', '#ffffff');
    root.style.setProperty('--app-surface-subtle', '#f8fafc');
    root.style.setProperty('--app-card', '#ffffff');
    root.style.setProperty('--app-border', '#e2e8f0');
    root.style.setProperty('--app-border-subtle', '#f1f5f9');
    root.style.setProperty('--app-text', '#0f172a');
    root.style.setProperty('--app-text-muted', '#64748b');
    root.style.setProperty('--app-text-subtle', '#94a3b8');
    root.style.setProperty('--theme-sidebar-bg', '#ffffff');
  }

  const metaTheme = document.querySelector('meta[name="theme-color"]');
  if (metaTheme) {
    metaTheme.setAttribute('content', isDark || config.color === 'burgundy' ? '#25101E' : palette.primary);
  }

  window.dispatchEvent(new CustomEvent('saadoun_theme_change', { detail: config }));
}
