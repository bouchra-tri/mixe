/**
 * Intelligent Barcode Normalizer & Keyboard Layout Translator
 * Specifically designed for school environments where computers may have
 * Arabic, French AZERTY, or English QWERTY keyboard layouts.
 */

// Arabic-Indic digits to Latin digits
const ARABIC_INDIC_DIGITS: Record<string, string> = {
  '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4',
  '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9',
  // Eastern Arabic / Persian digits
  '۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4',
  '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9',
};

// French AZERTY unshifted number row keys (e.g. barcode scanner typing without Shift/CapsLock on French Windows)
// & = 1, é = 2, " = 3, ' = 4, ( = 5, - = 6, è = 7, _ = 8, ç = 9, à = 0
const AZERTY_TO_DIGITS: Record<string, string> = {
  '&': '1',
  'é': '2',
  'É': '2',
  '"': '3',
  "'": '4',
  '(': '5',
  '-': '6',
  'è': '7',
  'È': '7',
  '_': '8',
  'ç': '9',
  'Ç': '9',
  'à': '0',
  'À': '0',
  '§': '6',
};

// Arabic Keyboard layout letters to English QWERTY (for barcodes like "SA-2026-101" typed under Arabic keyboard)
const ARABIC_KEY_TO_ENGLISH: Record<string, string> = {
  'ض': 'q', 'ص': 'w', 'ث': 'e', 'ق': 'r', 'ف': 't', 'غ': 'y', 'ع': 'u', 'ه': 'i', 'خ': 'o', 'ح': 'p', 'ج': '[', 'د': ']',
  'ش': 'a', 'س': 's', 'ي': 'd', 'ب': 'f', 'ل': 'g', 'ا': 'h', 'ت': 'j', 'ن': 'k', 'م': 'l', 'ك': ';', 'ط': "'",
  'ئ': 'z', 'ء': 'x', 'ؤ': 'c', 'ر': 'v', 'لا': 'b', 'ى': 'n', 'ة': 'm', 'و': ',', 'ز': '.', 'ظ': '/',
  // Caps / Shift equivalents
  'إ': 'Y', 'أ': 'H', 'آ': 'N',
};

/**
 * Clean control codes and non-printable characters common in barcode hardware
 */
export function stripBarcodeControlChars(raw: string): string {
  if (!raw) return '';
  return raw
    .replace(/^\][A-Za-z0-9]{2}/, '') // Strip GS1 AIM identifier prefix like ]C1, ]e0, etc.
    .replace(/[\x00-\x1F\x7F-\x9F\u200B-\u200D\uFEFF]/g, '') // Strip control chars and zero-width spaces
    .trim();
}

/**
 * Convert Eastern Arabic / Persian digits to Latin (0-9)
 */
export function normalizeDigits(input: string): string {
  return input.replace(/[٠-٩۰-۹]/g, (match) => ARABIC_INDIC_DIGITS[match] || match);
}

/**
 * Detect and convert French AZERTY unshifted number row characters
 * e.g. "éàé-&à&àà&" -> "2026101001"
 */
export function convertAzertyNumbers(input: string): string {
  // If the string contains AZERTY characters that typically substitute digits
  let converted = '';
  let containsAzertyChars = false;

  for (let i = 0; i < input.length; i++) {
    const ch = input[i];
    if (AZERTY_TO_DIGITS[ch] !== undefined) {
      converted += AZERTY_TO_DIGITS[ch];
      containsAzertyChars = true;
    } else {
      converted += ch;
    }
  }

  return containsAzertyChars ? converted : input;
}

/**
 * Convert Arabic layout typed letters back to English QWERTY
 * e.g. "سش-2026-101" -> "SA-2026-101"
 */
export function convertArabicLettersToEnglish(input: string): string {
  let converted = '';
  let hasArabicLetter = false;

  for (let i = 0; i < input.length; i++) {
    const ch = input[i];
    if (ARABIC_KEY_TO_ENGLISH[ch] !== undefined) {
      converted += ARABIC_KEY_TO_ENGLISH[ch];
      hasArabicLetter = true;
    } else {
      converted += ch;
    }
  }

  return hasArabicLetter ? converted.toUpperCase() : input;
}

/**
 * Clean alphanumeric token (strips hyphens, underscores, spaces)
 */
export function stripPunctuation(str: string): string {
  return str.replace(/[\s\-_/\\.:]/g, '').toUpperCase();
}

/**
 * Generate a list of candidate strings from a raw barcode scan.
 * This guarantees that whether the user scanned on Arabic layout, French AZERTY,
 * with leading zeros, with hyphens, or with raw control characters,
 * the matching engine finds the correct student.
 */
export function getBarcodeCandidates(rawInput: string): string[] {
  const cleaned = stripBarcodeControlChars(rawInput);
  if (!cleaned) return [];

  const candidates = new Set<string>();

  // 1. Raw cleaned uppercase
  candidates.add(cleaned.toUpperCase());

  // 2. Arabic digits converted
  const withLatinDigits = normalizeDigits(cleaned).toUpperCase();
  candidates.add(withLatinDigits);

  // 3. French AZERTY numbers converted
  const withAzertyFixed = convertAzertyNumbers(withLatinDigits).toUpperCase();
  candidates.add(withAzertyFixed);

  // 4. Arabic keyboard letters translated to English QWERTY
  const withEnglishLetters = convertArabicLettersToEnglish(withAzertyFixed).toUpperCase();
  candidates.add(withEnglishLetters);

  // 5. Stripped punctuation / hyphens versions
  candidates.add(stripPunctuation(cleaned));
  candidates.add(stripPunctuation(withLatinDigits));
  candidates.add(stripPunctuation(withAzertyFixed));
  candidates.add(stripPunctuation(withEnglishLetters));

  // 6. Without leading zeros
  const withoutLeadingZeros = withAzertyFixed.replace(/^0+/, '');
  if (withoutLeadingZeros) {
    candidates.add(withoutLeadingZeros);
  }

  return Array.from(candidates).filter((c) => c.length > 0);
}

/**
 * Find matching student with multi-candidate tolerant matching
 */
export function matchStudentByBarcode<T extends { barcode: string; id: string; nationalId?: string }>(
  students: T[],
  scannedCode: string
): { student: T | null; matchedCandidate: string; candidatesTested: string[] } {
  const candidates = getBarcodeCandidates(scannedCode);

  for (const candidate of candidates) {
    // 1. Direct match with barcode, id, or nationalId
    const found = students.find((s) => {
      const sBarcode = (s.barcode || '').trim().toUpperCase();
      const sId = (s.id || '').trim().toUpperCase();
      const sNat = (s.nationalId || '').trim().toUpperCase();

      return (
        sBarcode === candidate ||
        sId === candidate ||
        (sNat && sNat === candidate)
      );
    });

    if (found) {
      return { student: found, matchedCandidate: candidate, candidatesTested: candidates };
    }

    // 2. Loose match ignoring hyphens/spaces
    const foundLoose = students.find((s) => {
      const sBarcodeClean = stripPunctuation(s.barcode || '');
      const sIdClean = stripPunctuation(s.id || '');
      const sNatClean = stripPunctuation(s.nationalId || '');
      const candClean = stripPunctuation(candidate);

      return (
        (sBarcodeClean && sBarcodeClean === candClean) ||
        (sIdClean && sIdClean === candClean) ||
        (sNatClean && sNatClean === candClean)
      );
    });

    if (foundLoose) {
      return { student: foundLoose, matchedCandidate: candidate, candidatesTested: candidates };
    }

    // 3. Match without leading zeros (e.g. 00123 -> 123)
    const candNoZero = candidate.replace(/^0+/, '');
    if (candNoZero) {
      const foundNoZero = students.find((s) => {
        const sBarcodeNoZero = (s.barcode || '').replace(/^0+/, '').toUpperCase();
        const sNatNoZero = (s.nationalId || '').replace(/^0+/, '').toUpperCase();
        return (
          (sBarcodeNoZero && sBarcodeNoZero === candNoZero) ||
          (sNatNoZero && sNatNoZero === candNoZero)
        );
      });

      if (foundNoZero) {
        return { student: foundNoZero, matchedCandidate: candidate, candidatesTested: candidates };
      }
    }
  }

  return { student: null, matchedCandidate: '', candidatesTested: candidates };
}

/**
 * Quick single-string normalizer for form inputs and barcode values
 */
export function normalizeBarcode(raw: string): string {
  if (!raw) return '';
  const cleaned = stripBarcodeControlChars(raw);
  const latinDigits = normalizeDigits(cleaned);
  const azertyFixed = convertAzertyNumbers(latinDigits);
  return convertArabicLettersToEnglish(azertyFixed).trim();
}
