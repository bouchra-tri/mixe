import { BrowserMultiFormatReader, IScannerControls } from '@zxing/browser';
import { BarcodeFormat, DecodeHintType } from '@zxing/library';

// Check if native BarcodeDetector API is supported
export const isNativeBarcodeDetectorSupported = (): boolean => {
  return typeof window !== 'undefined' && 'BarcodeDetector' in window;
};

// Create hints for ZXing to support standard Algerian student cards (Code 128, Code 39, QR, EAN-13)
const hints = new Map<DecodeHintType, any>();
hints.set(DecodeHintType.POSSIBLE_FORMATS, [
  BarcodeFormat.CODE_128,
  BarcodeFormat.CODE_39,
  BarcodeFormat.QR_CODE,
  BarcodeFormat.EAN_13,
  BarcodeFormat.EAN_8,
  BarcodeFormat.UPC_A,
  BarcodeFormat.UPC_E,
  BarcodeFormat.ITF,
]);
hints.set(DecodeHintType.TRY_HARDER, true);

export class DualBarcodeScanner {
  private zxingReader: BrowserMultiFormatReader | null = null;
  private zxingControls: IScannerControls | null = null;
  private nativeDetector: any = null;
  private nativeLoopActive: boolean = false;
  private lastScannedCode: string = '';
  private lastScannedTime: number = 0;

  constructor() {
    this.zxingReader = new BrowserMultiFormatReader(hints, {
      delayBetweenScanAttempts: 150,
      delayBetweenScanSuccess: 1200,
    });

    if (isNativeBarcodeDetectorSupported()) {
      try {
        this.nativeDetector = new (window as any).BarcodeDetector({
          formats: ['code_128', 'code_39', 'qr_code', 'ean_13', 'ean_8', 'itf'],
        });
      } catch (e) {
        console.warn('Native BarcodeDetector init failed, using ZXing:', e);
        this.nativeDetector = null;
      }
    }
  }

  // Get available video input cameras
  static async getVideoDevices(): Promise<MediaDeviceInfo[]> {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) {
        return [];
      }
      const devices = await navigator.mediaDevices.enumerateDevices();
      return devices.filter((d) => d.kind === 'videoinput');
    } catch {
      return [];
    }
  }

  // Start scanning from a video element with a given stream
  async startScanning(
    videoElement: HTMLVideoElement,
    stream: MediaStream,
    onResult: (text: string) => void,
    onError?: (err: any) => void
  ) {
    this.stop();

    // Prefer native BarcodeDetector if available for performance
    if (this.nativeDetector) {
      this.nativeLoopActive = true;
      const detectFrame = async () => {
        if (!this.nativeLoopActive) return;

        if (
          videoElement.readyState === videoElement.HAVE_ENOUGH_DATA &&
          !videoElement.paused &&
          !videoElement.ended
        ) {
          try {
            const barcodes = await this.nativeDetector.detect(videoElement);
            if (barcodes && barcodes.length > 0) {
              const rawValue = barcodes[0].rawValue?.trim();
              if (rawValue) {
                const now = Date.now();
                // Debounce duplicate scans within 1.5 seconds
                if (rawValue !== this.lastScannedCode || now - this.lastScannedTime > 1500) {
                  this.lastScannedCode = rawValue;
                  this.lastScannedTime = now;
                  onResult(rawValue);
                }
              }
            }
          } catch (e) {
            // Some frames might fail or be empty, normal in continuous camera loop
          }
        }

        if (this.nativeLoopActive) {
          requestAnimationFrame(detectFrame);
        }
      };

      requestAnimationFrame(detectFrame);
      return;
    }

    // Fallback to ZXing BrowserMultiFormatReader
    if (this.zxingReader) {
      try {
        this.zxingControls = await this.zxingReader.decodeFromVideoElement(
          videoElement,
          (result, error) => {
            if (result) {
              const rawText = result.getText()?.trim();
              if (rawText) {
                const now = Date.now();
                if (rawText !== this.lastScannedCode || now - this.lastScannedTime > 1500) {
                  this.lastScannedCode = rawText;
                  this.lastScannedTime = now;
                  onResult(rawText);
                }
              }
            }
            if (error && onError) {
              // Non-fatal per-frame error, ignored
            }
          }
        );
      } catch (err) {
        console.error('ZXing stream error:', err);
        if (onError) onError(err);
      }
    }
  }

  // Stop scanning
  stop() {
    this.nativeLoopActive = false;
    if (this.zxingControls) {
      try {
        this.zxingControls.stop();
      } catch {}
      this.zxingControls = null;
    }
  }
}

// Check if torch (flashlight) is supported by current camera track
export function isTorchSupported(stream: MediaStream | null): boolean {
  if (!stream) return false;
  const track = stream.getVideoTracks()[0];
  if (!track) return false;
  try {
    const capabilities = (track.getCapabilities ? track.getCapabilities() : {}) as any;
    return Boolean(capabilities?.torch);
  } catch {
    return false;
  }
}

// Toggle torch (flashlight)
export async function toggleTorch(stream: MediaStream | null, enabled: boolean): Promise<boolean> {
  if (!stream) return false;
  const track = stream.getVideoTracks()[0];
  if (!track) return false;
  try {
    const capabilities = (track.getCapabilities ? track.getCapabilities() : {}) as any;
    if (capabilities.torch) {
      await (track as any).applyConstraints({
        advanced: [{ torch: enabled }],
      });
      return true;
    }
  } catch (err) {
    console.warn('Torch constraint error:', err);
  }
  return false;
}

// Zoom capabilities
export function getZoomCapabilities(stream: MediaStream | null): { min: number; max: number; step: number; current?: number } | null {
  if (!stream) return null;
  const track = stream.getVideoTracks()[0];
  if (!track) return null;
  try {
    const capabilities = (track.getCapabilities ? track.getCapabilities() : {}) as any;
    if (capabilities.zoom) {
      const settings = (track.getSettings ? track.getSettings() : {}) as any;
      return {
        min: capabilities.zoom.min || 1,
        max: capabilities.zoom.max || 3,
        step: capabilities.zoom.step || 0.1,
        current: settings.zoom || 1,
      };
    }
  } catch {
    return null;
  }
  return null;
}

// Set zoom
export async function setZoom(stream: MediaStream | null, zoomValue: number): Promise<boolean> {
  if (!stream) return false;
  const track = stream.getVideoTracks()[0];
  if (!track) return false;
  try {
    await (track as any).applyConstraints({
      advanced: [{ zoom: zoomValue }],
    });
    return true;
  } catch {
    return false;
  }
}

// Mobile haptic vibration feedback
export function triggerHapticFeedback(pattern: number[] = [70, 40, 70]) {
  if (typeof window !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate(pattern);
    } catch {}
  }
}
