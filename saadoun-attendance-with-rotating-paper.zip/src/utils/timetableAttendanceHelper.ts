import {
  TimetableSession,
  TimetableSlotId,
  SchoolDay,
  Student,
  PeriodId,
  SchoolSettings,
} from '../types';
import { getSchoolDay, TIMETABLE_SLOTS } from '../data/timetableData';

/**
 * Filter sessions for a specific classroom on a given day
 */
export function getClassroomSessions(
  classroom: string,
  day: SchoolDay,
  sessions: TimetableSession[]
): TimetableSession[] {
  return sessions.filter((s) => s.classroom === classroom && s.day === day);
}

/**
 * Filter sessions for a specific teacher on a given day
 */
export function getTeacherDaySessions(
  teacherIdOrName: string,
  day: SchoolDay,
  sessions: TimetableSession[]
): TimetableSession[] {
  return sessions.filter(
    (s) =>
      (s.teacherId === teacherIdOrName || s.teacherName.includes(teacherIdOrName)) &&
      s.day === day
  );
}

/**
 * Find the earliest (first) scheduled session for a student's classroom on a day and period type (morning/afternoon)
 */
export function getStudentFirstSession(
  classroom: string,
  day: SchoolDay,
  halfDay: 'morning' | 'afternoon',
  sessions: TimetableSession[]
): TimetableSession | null {
  const morningSlots: TimetableSlotId[] = ['p1', 'p2', 'p3', 'p4'];
  const afternoonSlots: TimetableSlotId[] = ['p5', 'p6', 'p7', 'p8'];
  const targetSlots = halfDay === 'morning' ? morningSlots : afternoonSlots;

  const daySessions = getClassroomSessions(classroom, day, sessions);
  for (const slotId of targetSlots) {
    const found = daySessions.find((s) => s.slotId === slotId);
    if (found) return found;
  }
  return null;
}

/**
 * Find the earliest (first) scheduled session for a teacher on a day and period type (morning/afternoon)
 */
export function getTeacherFirstSession(
  teacherIdOrName: string,
  day: SchoolDay,
  halfDay: 'morning' | 'afternoon',
  sessions: TimetableSession[]
): TimetableSession | null {
  const morningSlots: TimetableSlotId[] = ['p1', 'p2', 'p3', 'p4'];
  const afternoonSlots: TimetableSlotId[] = ['p5', 'p6', 'p7', 'p8'];
  const targetSlots = halfDay === 'morning' ? morningSlots : afternoonSlots;

  const daySessions = getTeacherDaySessions(teacherIdOrName, day, sessions);
  for (const slotId of targetSlots) {
    const found = daySessions.find((s) => s.slotId === slotId);
    if (found) return found;
  }
  return null;
}

/**
 * Check if student has ANY class in a given half-day (morning or afternoon)
 */
export function isStudentScheduledForHalfDay(
  classroom: string,
  day: SchoolDay,
  halfDay: 'morning' | 'afternoon',
  sessions: TimetableSession[]
): boolean {
  return getStudentFirstSession(classroom, day, halfDay, sessions) !== null;
}

/**
 * Check if student has a scheduled class during a specific period (e.g. m1, m2, a1, a2)
 */
export function isStudentScheduledForPeriod(
  studentOrClassroom: Student | string,
  dateOrDay: string | Date | SchoolDay,
  periodId: string,
  sessions: TimetableSession[] = []
): boolean {
  if (!sessions || sessions.length === 0) return true; // Fallback if no timetable loaded

  const classroom = typeof studentOrClassroom === 'string' ? studentOrClassroom : studentOrClassroom.classroom;
  let day: SchoolDay;
  if (typeof dateOrDay === 'string' && ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday'].includes(dateOrDay)) {
    day = dateOrDay as SchoolDay;
  } else {
    day = getSchoolDay(dateOrDay);
  }

  // If general morning / afternoon
  if (periodId === 'morning') {
    return isStudentScheduledForHalfDay(classroom, day, 'morning', sessions);
  }
  if (periodId === 'afternoon') {
    return isStudentScheduledForHalfDay(classroom, day, 'afternoon', sessions);
  }

  // Map periodId (m1..m3, a1..a3) to slotId (p1..p8)
  const slotMap: Record<string, TimetableSlotId[]> = {
    m1: ['p1', 'p2'],
    m2: ['p2', 'p3'],
    m3: ['p3', 'p4'],
    a1: ['p5', 'p6'],
    a2: ['p6', 'p7'],
    a3: ['p7', 'p8'],
  };

  const candidateSlots = slotMap[periodId];
  if (!candidateSlots) return true;

  const daySessions = getClassroomSessions(classroom, day, sessions);
  return candidateSlots.some((slotId) => daySessions.some((s) => s.slotId === slotId));
}

/**
 * Get dynamic expected arrival time for student based on timetable
 */
export function getStudentExpectedArrival(
  student: Student,
  dateOrDay: string | Date | SchoolDay,
  halfDay: 'morning' | 'afternoon',
  sessions: TimetableSession[] = [],
  settings?: SchoolSettings
): {
  isScheduled: boolean;
  scheduled: boolean;
  expectedStartTime: string;
  expectedEndTime?: string;
  firstSession: TimetableSession | null;
  message: string;
} {
  let day: SchoolDay;
  if (typeof dateOrDay === 'string' && ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday'].includes(dateOrDay)) {
    day = dateOrDay as SchoolDay;
  } else {
    day = getSchoolDay(dateOrDay);
  }

  const firstSession = getStudentFirstSession(student.classroom, day, halfDay, sessions || []);

  if (!firstSession) {
    return {
      isScheduled: false,
      scheduled: false,
      expectedStartTime: '',
      expectedEndTime: '',
      firstSession: null,
      message: `القسم (${student.classroom}) ليس لديه حصص دراسية مبرمجة في الفترة ${halfDay === 'morning' ? 'الصباحية' : 'المسائية'} ليوم ${day}.`,
    };
  }

  const startTime = firstSession.startTime || (firstSession.slotId === 'p1' ? '08:00' : firstSession.slotId === 'p2' ? '09:00' : firstSession.slotId === 'p5' ? '13:30' : '14:30');
  const endTime = firstSession.endTime || (firstSession.slotId === 'p1' ? '09:00' : firstSession.slotId === 'p2' ? '10:00' : firstSession.slotId === 'p5' ? '14:30' : '15:30');

  return {
    isScheduled: true,
    scheduled: true,
    expectedStartTime: startTime,
    expectedEndTime: endTime,
    firstSession,
    message: `الحصة الأولى المبرمجة للقسم (${student.classroom}) تبدأ في الساعة ${startTime} (${firstSession.subject} مع ${firstSession.teacherName} في ${firstSession.room}).`,
  };
}
