import { Student, AttendanceRecord, AbsenceNotice, AbsenceNoticeStage, SchoolSettings } from '../types';

/**
 * Calculates absence days for a student based on attendance records.
 * In a middle school, a student missing check-in on a school day is marked absent or lacks a record.
 */
export function calculateStudentAbsenceStats(
  studentId: string,
  records: AttendanceRecord[]
): {
  totalAbsenceDays: number;
  consecutiveAbsenceDays: number;
  absenceDates: string[];
  lastAbsenceDate: string;
  excusedDays: number;
} {
  // Find all records where student is explicitly marked 'absent'
  const studentRecords = records
    .filter((r) => r.studentId === studentId)
    .sort((a, b) => a.date.localeCompare(b.date));

  const explicitAbsentDates = studentRecords
    .filter((r) => r.status === 'absent')
    .map((r) => r.date);

  const excusedDates = studentRecords
    .filter((r) => r.status === 'excused')
    .map((r) => r.date);

  // Remove duplicates
  const uniqueAbsentDates = Array.from(new Set(explicitAbsentDates));
  const uniqueExcusedDates = Array.from(new Set(excusedDates));

  const lastAbsenceDate = uniqueAbsentDates.length > 0 
    ? uniqueAbsentDates[uniqueAbsentDates.length - 1] 
    : new Date().toISOString().split('T')[0];

  return {
    totalAbsenceDays: uniqueAbsentDates.length,
    consecutiveAbsenceDays: uniqueAbsentDates.length,
    absenceDates: uniqueAbsentDates,
    lastAbsenceDate,
    excusedDays: uniqueExcusedDates.length,
  };
}

/**
 * Stage Metadata and labels
 */
export const STAGE_CONFIG: Record<
  AbsenceNoticeStage,
  {
    stageNumber: number;
    title: string;
    subtitle: string;
    daysRule: string;
    color: string;
    badgeBg: string;
    borderColor: string;
    urgencyText: string;
  }
> = {
  notice_1: {
    stageNumber: 1,
    title: 'الإشعار الأول بالغياب (اليوم الرابع)',
    subtitle: 'يوجه لولي الأمر في اليوم الرابع من الغياب دون عذر',
    daysRule: '4 أيام غياب',
    color: 'text-amber-800',
    badgeBg: 'bg-amber-100 text-amber-900 border-amber-300',
    borderColor: 'border-amber-300',
    urgencyText: 'تنبيه أولي وطلب الحضور لتبرير الغياب',
  },
  notice_2: {
    stageNumber: 2,
    title: 'إشعار 2 بالغياب (بعد أسبوع)',
    subtitle: 'المرحلة الثانية تعتبر إشعار 2، يوجه لولي الأمر بعد أسبوع (7 أيام) في حال استمرار الغياب',
    daysRule: 'إشعار 2 (بعد أسبوع / 7 أيام)',
    color: 'text-orange-800',
    badgeBg: 'bg-orange-100 text-orange-900 border-orange-300',
    borderColor: 'border-orange-300',
    urgencyText: 'المرحلة الثانية: إشعار 2 بعد أسبوع وتنبيه للمسؤولية التربوية',
  },
  formal_warning: {
    stageNumber: 3,
    title: 'إعذار رسمي باستئناف الدراسة (15 يوماً من أول يوم غياب)',
    subtitle: 'يوجه بعد 15 يوماً من أول يوم غياب كإعذار نهائي قبل الشطب',
    daysRule: '15 يوماً من أول يوم غياب',
    color: 'text-slate-800',
    badgeBg: 'bg-slate-100 text-slate-900 border-slate-300',
    borderColor: 'border-slate-400',
    urgencyText: 'إعذار قانوني نهائي بعد 15 يوماً من أول غياب',
  },
};

/**
 * Evaluates whether a student is eligible for a new notice or upgraded stage.
 * Rule:
 * 1. Notice 1: Day 4 of absence (اليوم الرابع من الغياب)
 * 2. Notice 2: After 1 week of absence (بعد أسبوع - 7 أيام غياب)
 * 3. Formal Warning: 15 days from the first day of absence (15 يوماً من أول يوم غياب)
 */
export function evaluateNoticeEligibility(
  student: Student,
  records: AttendanceRecord[],
  studentNotices: AbsenceNotice[]
): {
  eligibleStage: AbsenceNoticeStage | null;
  currentAbsenceDays: number;
  reason: string;
} {
  const stats = calculateStudentAbsenceStats(student.id, records);
  const notices = studentNotices.filter((n) => n.studentId === student.id && n.status !== 'cancelled');

  const hasNotice1 = notices.find((n) => n.stage === 'notice_1');
  const hasNotice2 = notices.find((n) => n.stage === 'notice_2');
  const hasFormalWarning = notices.find((n) => n.stage === 'formal_warning');

  // If already reached formal warning and not justified
  if (hasFormalWarning) {
    return {
      eligibleStage: null,
      currentAbsenceDays: Math.max(stats.totalAbsenceDays, hasFormalWarning.absenceDaysCount),
      reason: 'بلغ مرحلة الإعذار القانوني النهائي (15 يوماً من أول يوم غياب)',
    };
  }

  // Calculate days elapsed from first day of absence
  const firstAbsenceDateStr = notices.length > 0 && notices[notices.length - 1].startDate
    ? notices[notices.length - 1].startDate
    : (stats.absenceDates[0] || new Date().toISOString().split('T')[0]);
  const firstAbsenceDate = new Date(firstAbsenceDateStr);
  const today = new Date();
  const diffDaysFromFirstDay = Math.floor((today.getTime() - firstAbsenceDate.getTime()) / (1000 * 60 * 60 * 24));

  // Check if eligible for Formal Warning (Stage 3):
  // 15 days from first day of absence (total absence >= 15 days or 15 days elapsed from start of absence)
  if (stats.totalAbsenceDays >= 15 || diffDaysFromFirstDay >= 15) {
    if (hasNotice2) {
      return {
        eligibleStage: 'formal_warning',
        currentAbsenceDays: Math.max(stats.totalAbsenceDays, 15),
        reason: 'انقضاء 15 يوماً كاملة من أول يوم غياب دون استئناف',
      };
    }
  }

  // Check if eligible for Notice 2 (Stage 2):
  // After 1 week (7 days) of absence or 7 days after Notice 1
  if (hasNotice1 && !hasNotice2) {
    const notice1Date = new Date(hasNotice1.sentDate || hasNotice1.dueDate);
    const diffDaysFromNotice1 = Math.floor((today.getTime() - notice1Date.getTime()) / (1000 * 60 * 60 * 24));

    if (diffDaysFromNotice1 >= 7 || stats.totalAbsenceDays >= 7 || diffDaysFromFirstDay >= 7) {
      return {
        eligibleStage: 'notice_2',
        currentAbsenceDays: Math.max(stats.totalAbsenceDays, 7),
        reason: 'استحقاق المرحلة 2 (إشعار 2): انقضاء أسبوع كامل (7 أيام) على الغياب دون مبرر',
      };
    }
    return {
      eligibleStage: null,
      currentAbsenceDays: Math.max(stats.totalAbsenceDays, 4),
      reason: `في انتظار استكمال مهلة الأسبوع (7 أيام) لإشعار 2 (مضى ${Math.max(diffDaysFromNotice1, stats.totalAbsenceDays)} أيام)`,
    };
  }

  // Check if eligible for Notice 1 (Stage 1):
  // Day 4 of absence (total absence >= 4 days)
  if (!hasNotice1 && stats.totalAbsenceDays >= 4) {
    return {
      eligibleStage: 'notice_1',
      currentAbsenceDays: stats.totalAbsenceDays,
      reason: 'بلوغ اليوم الرابع (04) من الغياب دون عذر مقبول',
    };
  }



  return {
    eligibleStage: null,
    currentAbsenceDays: stats.totalAbsenceDays,
    reason: 'غياب أقل من 4 أيام (المواظبة عادية)',
  };
}

/**
 * Create a new notice object
 */
export function createNewNotice(
  student: Student,
  stage: AbsenceNoticeStage,
  absenceDaysCount: number,
  settings: SchoolSettings,
  existingCount: number = 0
): AbsenceNotice {
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];
  const yearStr = settings.academicYear ? settings.academicYear.split('-')[0] : '2026';
  const seqNum = String(existingCount + 1).padStart(3, '0');

  const refSuffix = stage === 'notice_1' ? 'إ1' : stage === 'notice_2' ? 'إ2' : 'إعذار';
  const referenceNumber = `${yearStr}/${seqNum}/${refSuffix}`;

  return {
    id: `NOTIF-${Date.now()}-${student.id}`,
    studentId: student.id,
    studentName: `${student.lastName} ${student.firstName}`,
    nationalId: student.nationalId,
    grade: student.grade,
    classroom: student.classroom,
    guardianName: student.guardianName,
    guardianPhone: student.guardianPhone,
    stage,
    absenceDaysCount: Math.max(absenceDaysCount, stage === 'notice_1' ? 4 : stage === 'notice_2' ? 7 : 15),
    startDate: todayStr,
    lastAbsenceDate: todayStr,
    dueDate: todayStr,
    status: 'pending',
    channel: 'whatsapp',
    referenceNumber,
    notes: `تم إنشاء الإشعار آلياً وفقاً لقانون الانضباط والمواظبة المدرسية (${STAGE_CONFIG[stage].daysRule})`,
    createdAt: now.toISOString(),
    updatedAt: now.toISOString(),
  };
}

/**
 * Generate official SMS message text
 */
export function generateNoticeSmsText(
  notice: AbsenceNotice,
  settings: SchoolSettings
): string {
  const school = settings.schoolName || 'متوسطة سعدون عاشور';
  const wilaya = settings.wilaya || 'عنابة';

  if (notice.stage === 'notice_1') {
    return `إشعار غياب رقم 1: من إدارة ${school} (${wilaya})، نحيطكم علماً بأن التلميذ(ة) ${notice.studentName} (${notice.classroom}) وصل اليوم الرابع من الغياب دون مبرر. يرجى من الولي الحضور فوراً للاستشارة التربوية لتسوية الوضعية.`;
  }

  if (notice.stage === 'notice_2') {
    return `إشعار 2 بالغياب (المرحلة 2): من إدارة ${school} (${wilaya})، بعد انقضاء أسبوع على الغياب وتواصل انقطاع التلميذ(ة) ${notice.studentName} (${notice.classroom})، نوجه إليكم إشعار 2 للتنبيه بضرورة الحضور العاجل للاستشارة التربوية قبل إحالة الملف للإعذار القانوني.`;
  }

  return `إعذار رسمي أخير: من ${school}، بعد انقضاء 15 يوماً من أول يوم غياب، يعتبر هذا إعذاراً رسمياً لاستئناف التلميذ(ة) ${notice.studentName} للدراسة خلال 48 ساعة وإلا سيتم الشطب النهائي من سجلات التمدرس.`;
}


/**
 * Generate official WhatsApp message text with full markdown formatting
 */
export function generateNoticeWhatsAppText(
  notice: AbsenceNotice,
  settings: SchoolSettings
): string {
  const school = settings.schoolName || 'متوسطة سعدون عاشور';
  const wilaya = settings.wilaya || 'عنابة';
  const year = settings.academicYear || '2026-2027';

  if (notice.stage === 'notice_1') {
    return `*الجمهورية الجزائرية الديمقراطية الشعبية*
*وزارة التربية الوطنية · مديرية التربية لولاية ${wilaya}*
*${school}*
*مصلحة الاستشارة التربوية*
──────────────
📌 *إشعار بالغياب رقم 01 (اليوم الرابع)*
رقم المرجع: ${notice.referenceNumber}
تاريخ الإصدار: ${notice.dueDate}

إلى السيد(ة) ولي أمر التلميذ(ة): *${notice.studentName}*
القسم: *${notice.classroom}* | المستوى: *${notice.grade}*

تحية طيبة وبعد،
نحيطكم علماً بأن ابنكم/ابنتكم قد سجل غياباً عن مقاعد الدراسة لمدة *أربعة (04) أيام* دون تقديم أي مبرر قانوني أو شهادة طبية.

عملاً بأحكام النظام الداخلي للمؤسسات التربوية، نلتمس منكم الحضور إلى مقر المؤسسة (مكتب مستشارة التربية) لتبرير هذا الانقطاع تفادياً للإجراءات اللاحقة وحرصاً على تمدرس التلميذ.

*مديرة المؤسسة: ${settings.principalName}*
*مستشارة التربية: ${settings.counselorName}*`;
  }

  if (notice.stage === 'notice_2') {
    return `*الجمهورية الجزائرية الديمقراطية الشعبية*
*وزارة التربية الوطنية · مديرية التربية لولاية ${wilaya}*
*${school}*
──────────────
⚠️ *إشعار 2 بالغياب (المرحلة الثانية - بعد أسبوع)*
رقم المرجع: ${notice.referenceNumber}
تاريخ الإصدار: ${notice.dueDate}

إلى السيد(ة) ولي أمر التلميذ(ة): *${notice.studentName}* (${notice.classroom})

تحية طيبة وبعد،
نظراً لعدم استجابتكم للإشعار الأول الصادر عن مؤسستنا، وتواصل غياب التلميذ لمدة *أسبوع كامل (07 أيام)* دون مبرر مقبول، نوجه إليكم *إشعار 2 بالغياب (المرحلة الثانية)*.

نذكركم بمسؤوليتكم التربوية والأسرية وضرورة التحاق التلميذ فوراً بمقاعد الدراسة، وإحضار تبرير كتابي خلال 48 ساعة لتفادي توجيه الإعذار القانوني النهائي.

*إدارة ${school}*`;
  }

  return `*الجمهورية الجزائرية الديمقراطية الشعبية*
*وزارة التربية الوطنية · مديرية التربية لولاية ${wilaya}*
*${school}*
──────────────
🚨 *إعذار رسمي أخير باستئناف الدراسة (بعد 15 يوماً من أول يوم غياب)*
رقم المرجع الإداري: ${notice.referenceNumber}
تاريخ الإعذار: ${notice.dueDate}

إلى السيد ولي أمر التلميذ(ة): *${notice.studentName}*
رقم التعريف المدرسي: *${notice.nationalId || '-'}*
القسم: *${notice.classroom}* | السنة الدراسية: *${year}*

بموجب المنشور الوزاري المنظم للمواظبة والانضباط المدرسي، ونظراً لانقضاء مهلة *خمسة عشر (15) يوماً كاملة من تاريخ أول يوم غياب* دون أي رد أو تبرير قانوني من طرفكم:

*نوجه إليكم هذا الإعذار الرسمي الأخير*
نلزمكم بإعادة التلميذ إلى مقاعد الدراسة في أجل أقصاه *48 ساعة* من تاريخ هذا الإعذار.
وفي حال عدم الامتثال، سيتم *الشطب النهائي* للتلميذ من سجلات التمدرس بمؤسستنا، واعتباره متخلياً عن الدراسة بصفة رسمية ونهائية.

*مديرة المتوسطة: ${settings.principalName}*
*مستشارة التربية: ${settings.counselorName}*`;
}

