import * as XLSX from 'xlsx';
import { Student, AttendanceRecord, SchoolSettings, AttendanceStatus, GradeLevel } from '../types';
import { getPeriodById, matchRecordPeriod } from './periodHelper';

/**
 * Configure RTL (Right-to-Left) worksheet view for Microsoft Excel & LibreOffice
 */
function applyRTL(worksheet: XLSX.WorkSheet, workbook: XLSX.WorkBook) {
  worksheet['!views'] = [{ RTL: true }];
  if (!workbook.Workbook) {
    workbook.Workbook = {};
  }
  workbook.Workbook.Views = [{ RTL: true }];
}

/**
 * Auto-calculate column widths based on content length with padding
 */
function autoFitColumns(data: (string | number)[][], minWidth = 12, maxWidth = 45): { wch: number }[] {
  const colWidths: number[] = [];

  for (const row of data) {
    row.forEach((cell, colIndex) => {
      const cellText = cell !== null && cell !== undefined ? String(cell) : '';
      const charLength = cellText.length;
      colWidths[colIndex] = Math.max(colWidths[colIndex] || minWidth, charLength + 3);
    });
  }

  return colWidths.map((w) => ({
    wch: Math.min(Math.max(w, minWidth), maxWidth),
  }));
}

/**
 * 1. Export Student Roster matching the exact table columns of StudentManagement UI:
 * [الرقم] -> [رقم التسجيل] -> [اللقب والاسم] -> [المستوى والقسم] -> [الجنس] -> [تاريخ الميلاد] -> [رمز الباركود] -> [ولي الأمر والهاتف] -> [رقم التعريف المدرسي] -> [مكان الميلاد] -> [العنوان] -> [الملاحظات]
 */
export function exportStudentsToExcel(
  students: Student[],
  settings: SchoolSettings,
  options?: {
    filterClassroom?: string;
    filterGrade?: string;
    isFiltered?: boolean;
  }
) {
  const todayStr = new Date().toISOString().split('T')[0];
  const timeStr = new Date().toLocaleTimeString('ar-DZ', { hour: '2-digit', minute: '2-digit' });

  let subtitleClass = 'جميع الأقسام والمستويات';
  if (options?.filterClassroom && options.filterClassroom !== 'all') {
    subtitleClass = `قسم: ${options.filterClassroom}`;
  } else if (options?.filterGrade && options.filterGrade !== 'all') {
    subtitleClass = `المستوى: ${options.filterGrade}`;
  }

  // Institutional Header rows
  const rows: (string | number)[][] = [
    ['الجمهورية الجزائرية الديمقراطية الشعبية'],
    [`وزارة التربية الوطنية · مديرية التربية لولاية ${settings.wilaya || 'عنابة'}`],
    [`${settings.schoolName || 'متوسطة سعدون عاشور'} (${settings.schoolType || 'التعليم المتوسط'})`, '', '', '', '', '', '', `السنة الدراسية: ${settings.academicYear || '2026-2027'}`],
    ['قائمة التلاميذ المسجلين في النظام المدرسي الرقمي'],
    [`النطاق: ${subtitleClass}`, '', `تاريخ الاستخراج: ${todayStr} ${timeStr}`, '', '', '', '', `إجمالي المقيدين: ${students.length} تلميذ`],
    [], // Blank separator row
    [
      'الرقم',
      'رقم التسجيل',
      'اللقب والاسم',
      'المستوى والقسم',
      'الجنس',
      'تاريخ الميلاد',
      'رمز الباركود',
      'ولي الأمر والهاتف',
      'رقم التعريف المدرسي',
      'مكان الميلاد',
      'العنوان',
      'الملاحظات',
    ],
  ];

  // Data rows in exact UI column order
  students.forEach((s, idx) => {
    rows.push([
      idx + 1,
      s.id,
      `${s.lastName} ${s.firstName}`,
      `${s.classroom} (${s.grade})`,
      s.gender === 'M' ? 'ذكر' : 'أنثى',
      s.birthDate || '-',
      s.barcode,
      s.guardianName && s.guardianPhone ? `${s.guardianName} (${s.guardianPhone})` : s.guardianPhone || s.guardianName || '-',
      s.nationalId || '-',
      s.birthPlace || '-',
      s.address || '-',
      s.notes || '-',
    ]);
  });

  // Summary row
  rows.push([]);
  rows.push([
    'الحصيلة الإجمالية',
    `المجموع: ${students.length} تلميذ`,
    '',
    '',
    `ذكور: ${students.filter((s) => s.gender === 'M').length} · إناث: ${students.filter((s) => s.gender === 'F').length}`,
  ]);

  const worksheet = XLSX.utils.aoa_to_sheet(rows);
  const workbook = XLSX.utils.book_new();

  applyRTL(worksheet, workbook);
  worksheet['!cols'] = autoFitColumns(rows);

  XLSX.utils.book_append_sheet(workbook, worksheet, 'قائمة التلاميذ');

  const cleanFileName = `قائمة_تلاميذ_${(settings.schoolName || 'سعدون_عاشور').replace(/\s+/g, '_')}_${subtitleClass.replace(/[:\s]+/g, '_')}_${todayStr}.xlsx`;
  XLSX.writeFile(workbook, cleanFileName);
}

/**
 * 2. Export Daily Attendance Record matching the exact table columns of DailyAttendance UI:
 * [الرقم] -> [رقم التسجيل] -> [اللقب والاسم] -> [المستوى والقسم] -> [رمز الباركود] -> [حالة الحضور] -> [وقت الدخول] -> [ولي الأمر والهاتف] -> [وسيلة التسجيل] -> [الملاحظات / سبب الغياب]
 */
export function exportAttendanceToExcel(
  items: { student: Student; record?: AttendanceRecord; status: AttendanceStatus }[],
  settings: SchoolSettings,
  options: {
    selectedDate: string;
    selectedSession?: string;
    selectedPeriod?: string;
    filterClassroom?: string;
    filterGrade?: string;
    filterStatus?: string;
  }
) {
  const periodOrSession = options.selectedPeriod || options.selectedSession || 'morning';
  let sessionText = 'الفترة الصباحية';
  if (periodOrSession === 'all') {
    sessionText = 'كامل اليوم (جميع الفترات والأفواج)';
  } else if (periodOrSession === 'morning') {
    sessionText = 'الفترة الصباحية (جميع الأفواج)';
  } else if (periodOrSession === 'afternoon') {
    sessionText = 'الفترة المسائية (جميع الأفواج)';
  } else {
    const p = getPeriodById(settings, periodOrSession);
    sessionText = `${p.name} [توقيت الدخول: ${p.startTime}]`;
  }

  let scopeText = 'كل الأقسام';
  if (options.filterClassroom && options.filterClassroom !== 'all') {
    scopeText = `قسم ${options.filterClassroom}`;
  } else if (options.filterGrade && options.filterGrade !== 'all') {
    scopeText = `مستوى ${options.filterGrade}`;
  }

  const presentCount = items.filter((i) => i.status === 'present').length;
  const lateCount = items.filter((i) => i.status === 'late').length;
  const absentCount = items.filter((i) => i.status === 'absent').length;
  const excusedCount = items.filter((i) => i.status === 'excused').length;
  const totalCount = items.length;
  const attendanceRate = totalCount > 0 ? Math.round(((presentCount + lateCount) / totalCount) * 100) : 0;

  const rows: (string | number)[][] = [
    ['الجمهورية الجزائرية الديمقراطية الشعبية'],
    [`وزارة التربية الوطنية · مديرية التربية لولاية ${settings.wilaya || 'عنابة'}`],
    [`${settings.schoolName || 'متوسطة سعدون عاشور'} (${settings.schoolType || 'التعليم المتوسط'})`, '', '', '', '', '', '', `السنة الدراسية: ${settings.academicYear || '2026-2027'}`],
    [`سجل الحضور والغيابات اليومي - ${sessionText}`],
    [
      `تاريخ اليوم: ${options.selectedDate}`,
      `الفترة / الفوج: ${sessionText}`,
      `النطاق: ${scopeText}`,
      `التعداد الإجمالي: ${totalCount}`,
      `حاضر: ${presentCount}`,
      `متأخر: ${lateCount}`,
      `غائب: ${absentCount}`,
      `مبرر: ${excusedCount}`,
      `نسبة الحضور: ${attendanceRate}%`,
    ],
    [], // Blank separator row
    [
      'الرقم',
      'رقم التسجيل',
      'اللقب والاسم',
      'المستوى والقسم',
      'رمز الباركود',
      'حالة الحضور',
      'وقت الدخول',
      'ولي الأمر والهاتف',
      'وسيلة التسجيل',
      'الملاحظات / سبب الغياب',
    ],
  ];

  items.forEach((item, idx) => {
    const statusLabel =
      item.status === 'present'
        ? 'حاضر في الموعد'
        : item.status === 'late'
        ? `متأخر (+${item.record?.lateMinutes || 0} د)`
        : item.status === 'excused'
        ? 'غياب مبرر'
        : 'غائب';

    const deviceLabel =
      item.record?.device === 'scanner_gun'
        ? 'مسدس الباركود'
        : item.record?.device === 'camera'
        ? 'كاميرا الجهاز'
        : item.record?.device === 'manual'
        ? 'تسجيل يدوي'
        : '-';

    const guardianInfo =
      item.student.guardianName && item.student.guardianPhone
        ? `${item.student.guardianName} (${item.student.guardianPhone})`
        : item.student.guardianPhone || item.student.guardianName || '-';

    rows.push([
      idx + 1,
      item.student.id,
      `${item.student.lastName} ${item.student.firstName}`,
      `${item.student.classroom} (${item.student.grade})`,
      item.student.barcode,
      statusLabel,
      item.record?.timestamp || '-',
      guardianInfo,
      deviceLabel,
      item.record?.excuseReason || item.record?.notes || '-',
    ]);
  });

  // Summary row at bottom
  rows.push([]);
  rows.push([
    'الحصيلة الإجمالية',
    `إجمالي التلاميذ: ${totalCount}`,
    '',
    '',
    '',
    `حاضر: ${presentCount} · متأخر: ${lateCount} · غائب: ${absentCount}`,
    '',
    `نسبة الحضور: ${attendanceRate}%`,
  ]);

  const worksheet = XLSX.utils.aoa_to_sheet(rows);
  const workbook = XLSX.utils.book_new();

  applyRTL(worksheet, workbook);
  worksheet['!cols'] = autoFitColumns(rows);

  XLSX.utils.book_append_sheet(workbook, worksheet, 'سجل الحضور');

  const cleanFileName = `سجل_حضور_${(settings.schoolName || 'سعدون_عاشور').replace(/\s+/g, '_')}_${options.selectedDate}_${periodOrSession}.xlsx`;
  XLSX.writeFile(workbook, cleanFileName);
}

/**
 * 3. Export Statistical Reports & Absentees matching the exact table columns of AnalyticsReports UI:
 * Sheet 1 (توزيع الحضور والغيابات حسب المستويات):
 * [المستوى الدراسي] -> [التعداد الإجمالي] -> [حاضرون في الوقت] -> [متأخرون] -> [غائبون] -> [نسبة الحضور]
 *
 * Sheet 2 (قائمة التلاميذ الغائبين):
 * [الرقم] -> [رقم التسجيل] -> [اسم ولقب التلميذ] -> [القسم] -> [ولي الأمر] -> [هاتف الاتصال]
 *
 * Sheet 3 (قائمة التلاميذ المتأخرين):
 * [الرقم] -> [اسم ولقب التلميذ] -> [القسم] -> [وقت المسح بالبوابة] -> [مدة التأخر] -> [ملاحظة مستشار التربية]
 */
export function exportAnalyticsReportToExcel(params: {
  students: Student[];
  records: AttendanceRecord[];
  settings: SchoolSettings;
  session: string;
  date: string;
}) {
  const { students, records, settings, session, date } = params;
  const sessionRecords = records.filter(
    (r) => r.date === date && matchRecordPeriod(r.session || r.periodId || 'm1', session)
  );

  let sessionText = 'الفترة الصباحية';
  if (session === 'all') {
    sessionText = 'كامل اليوم (جميع الفترات والأفواج)';
  } else if (session === 'morning') {
    sessionText = 'الفترة الصباحية (جميع الأفواج)';
  } else if (session === 'afternoon') {
    sessionText = 'الفترة المسائية (جميع الأفواج)';
  } else {
    const p = getPeriodById(settings, session);
    sessionText = `${p.name} [توقيت الدخول: ${p.startTime}]`;
  }

  const workbook = XLSX.utils.book_new();

  // SHEET 1: جدول توزيع الحضور والغيابات حسب المستويات الدراسية (مطابق تماماً لجدول المنصة)
  const gradeLevels: GradeLevel[] = ['1AM', '2AM', '3AM', '4AM'];
  const gradeLabels: Record<GradeLevel, string> = {
    '1AM': 'الأولى متوسط (1AM)',
    '2AM': 'الثانية متوسط (2AM)',
    '3AM': 'الثالثة متوسط (3AM)',
    '4AM': 'الرابعة متوسط (4AM - BEM)',
  };

  const summaryRows: (string | number)[][] = [
    ['الجمهورية الجزائرية الديمقراطية الشعبية'],
    [`وزارة التربية الوطنية · مديرية التربية لولاية ${settings.wilaya || 'عنابة'}`],
    [`${settings.schoolName || 'متوسطة سعدون عاشور'} - التقرير الإحصائي اليومي للحضور`],
    [`تاريخ التقرير: ${date}`, `الفترة: ${sessionText}`, `السنة الدراسية: ${settings.academicYear || '2026-2027'}`],
    [], // Blank separator
    [
      'المستوى الدراسي',
      'التعداد الإجمالي',
      'حاضرون في الوقت',
      'متأخرون',
      'غائبون',
      'نسبة الحضور',
    ],
  ];

  let sumTotal = 0;
  let sumPresent = 0;
  let sumLate = 0;
  let sumAbsent = 0;

  gradeLevels.forEach((g) => {
    const gStudents = students.filter((s) => s.grade === g);
    const gRecords = sessionRecords.filter((r) => r.grade === g);
    const gPresent = gRecords.filter((r) => r.status === 'present').length;
    const gLate = gRecords.filter((r) => r.status === 'late').length;
    const gTotalCheckedIn = gRecords.length;
    const gAbsent = Math.max(0, gStudents.length - gTotalCheckedIn);
    const gRate = gStudents.length > 0 ? Math.round((gTotalCheckedIn / gStudents.length) * 100) : 0;

    sumTotal += gStudents.length;
    sumPresent += gPresent;
    sumLate += gLate;
    sumAbsent += gAbsent;

    summaryRows.push([
      gradeLabels[g],
      gStudents.length,
      gPresent,
      gLate,
      gAbsent,
      `${gRate}%`,
    ]);
  });

  const totalRate = sumTotal > 0 ? Math.round(((sumPresent + sumLate) / sumTotal) * 100) : 0;
  summaryRows.push([]);
  summaryRows.push([
    'المجموع الإجمالي للمؤسسة',
    sumTotal,
    sumPresent,
    sumLate,
    sumAbsent,
    `${totalRate}%`,
  ]);

  const summarySheet = XLSX.utils.aoa_to_sheet(summaryRows);
  applyRTL(summarySheet, workbook);
  summarySheet['!cols'] = autoFitColumns(summaryRows);
  XLSX.utils.book_append_sheet(workbook, summarySheet, 'توزيع الحضور حسب المستويات');

  // SHEET 2: جدول قائمة التلاميذ الغائبين (مطابق تماماً لجدول كشف الغائبين في المنصة)
  const checkedInIds = new Set(sessionRecords.map((r) => r.studentId));
  const absentees = students.filter((st) => !checkedInIds.has(st.id));

  const absenteesRows: (string | number)[][] = [
    ['قائمة التلاميذ الغائبين رسمياً'],
    [`المؤسسة: ${settings.schoolName}`, `التاريخ: ${date}`, `الفترة: ${sessionText}`, `العدد: ${absentees.length} تلميذ`],
    [],
    [
      'الرقم',
      'رقم التسجيل',
      'اسم ولقب التلميذ',
      'القسم',
      'المستوى',
      'ولي الأمر',
      'هاتف الاتصال',
    ],
  ];

  absentees.forEach((st, idx) => {
    absenteesRows.push([
      idx + 1,
      st.id,
      `${st.lastName} ${st.firstName}`,
      st.classroom,
      st.grade,
      st.guardianName || '-',
      st.guardianPhone || '-',
    ]);
  });

  const absenteesSheet = XLSX.utils.aoa_to_sheet(absenteesRows);
  applyRTL(absenteesSheet, workbook);
  absenteesSheet['!cols'] = autoFitColumns(absenteesRows);
  XLSX.utils.book_append_sheet(workbook, absenteesSheet, 'قائمة الغائبين');

  // SHEET 3: جدول قائمة التلاميذ المتأخرين (مطابق تماماً لجدول المتأخرين في المنصة)
  const lateRecords = sessionRecords.filter((r) => r.status === 'late');
  const lateRows: (string | number)[][] = [
    ['قائمة التلاميذ المتأخرين'],
    [`المؤسسة: ${settings.schoolName}`, `التاريخ: ${date}`, `الفترة: ${sessionText}`, `العدد: ${lateRecords.length} تلميذ`],
    [],
    [
      'الرقم',
      'اسم ولقب التلميذ',
      'القسم',
      'المستوى',
      'وقت المسح بالبوابة',
      'مدة التأخر',
      'وسيلة التسجيل',
      'ملاحظة مستشار التربية',
    ],
  ];

  lateRecords.forEach((r, idx) => {
    lateRows.push([
      idx + 1,
      r.studentName,
      r.classroom,
      r.grade,
      r.timestamp,
      `+${r.lateMinutes || 0} دقيقة`,
      r.device === 'scanner_gun' ? 'مسدس الباركود' : r.device === 'camera' ? 'كاميرا' : 'يدوي',
      r.notes || r.excuseReason || '-',
    ]);
  });

  const lateSheet = XLSX.utils.aoa_to_sheet(lateRows);
  applyRTL(lateSheet, workbook);
  lateSheet['!cols'] = autoFitColumns(lateRows);
  XLSX.utils.book_append_sheet(workbook, lateSheet, 'قائمة المتأخرين');

  const fileName = `تقرير_إحصائيات_الحضور_${(settings.schoolName || 'سعدون_عاشور').replace(/\s+/g, '_')}_${date}.xlsx`;
  XLSX.writeFile(workbook, fileName);
}

/**
 * 4. Export Monthly Attendance Matrix & Statistics to Excel (سجل الحضور الشهري الرسمي)
 */
export function exportMonthlyAttendanceToExcel(params: {
  students: Student[];
  records: AttendanceRecord[];
  settings: SchoolSettings;
  year: number;
  month: number; // 1 to 12
  filterClassroom?: string;
  filterGrade?: string;
}) {
  const { students, records, settings, year, month, filterClassroom, filterGrade } = params;
  const workbook = XLSX.utils.book_new();

  // Arabic Month Names
  const arabicMonths = [
    'جانفي (يناير)',
    'فيفري (فبراير)',
    'مارس',
    'أفريل (أبريل)',
    'ماي (مايو)',
    'جوان (يونيو)',
    'جويلية (يوليو)',
    'أوت (أغسطس)',
    'سبتمبر',
    'أكتوبر',
    'نوفمبر',
    'ديسمبر',
  ];
  const monthName = arabicMonths[month - 1] || `شهر ${month}`;

  // Days in month
  const totalDaysInMonth = new Date(year, month, 0).getDate();
  const daysArray = Array.from({ length: totalDaysInMonth }, (_, i) => i + 1);

  // Filter students
  const filteredStudents = students.filter((s) => {
    if (filterClassroom && filterClassroom !== 'all' && s.classroom !== filterClassroom) return false;
    if (filterGrade && filterGrade !== 'all' && s.grade !== filterGrade) return false;
    return true;
  });

  // Month prefix string YYYY-MM
  const monthPrefix = `${year}-${String(month).padStart(2, '0')}`;
  const monthRecords = records.filter((r) => r.date.startsWith(monthPrefix));

  // Build matrix header
  const headerRow1 = [
    'الجمهورية الجزائرية الديمقراطية الشعبية · وزارة التربية الوطنية',
  ];
  const headerRow2 = [
    `${settings.schoolName || 'متوسطة سعدون عاشور'} · مديرية التربية لولاية ${settings.wilaya || 'عنابة'}`,
    '',
    '',
    '',
    `السنة الدراسية: ${settings.academicYear || '2026-2027'}`,
  ];
  const headerRow3 = [
    `سجل المتابعة الشهرية للحضور والغياب - ${monthName} ${year}`,
    '',
    '',
    '',
    `الفئة: ${filterClassroom && filterClassroom !== 'all' ? `قسم ${filterClassroom}` : filterGrade && filterGrade !== 'all' ? `مستوى ${filterGrade}` : 'جميع المستويات والأقسام'}`,
  ];

  const colHeaders: (string | number)[] = [
    'الرقم',
    'رقم التسجيل',
    'اللقب والاسم',
    'القسم',
    ...daysArray.map((d) => `يوم ${d}`),
    'مجموع الحضور',
    'تأخرات',
    'غياب غير مبرر',
    'غياب مبرر',
    'نسبة الحضور %',
  ];

  const matrixRows: (string | number)[][] = [
    headerRow1,
    headerRow2,
    headerRow3,
    [],
    colHeaders,
  ];

  filteredStudents.forEach((st, idx) => {
    let presentCount = 0;
    let lateCount = 0;
    let unexcusedAbsentCount = 0;
    let excusedCount = 0;

    const dayCells: string[] = daysArray.map((d) => {
      const dayDateStr = `${monthPrefix}-${String(d).padStart(2, '0')}`;
      const dayRecords = monthRecords.filter((r) => r.studentId === st.id && r.date === dayDateStr);

      if (dayRecords.length === 0) {
        // If it's a weekday (in Algeria: Fri 5, Sat 6 are weekend)
        const dayOfWeek = new Date(year, month - 1, d).getDay();
        if (dayOfWeek === 5 || dayOfWeek === 6) {
          return 'عطلة';
        }
        return '-';
      }

      // Check status
      const hasPresent = dayRecords.some((r) => r.status === 'present');
      const hasLate = dayRecords.some((r) => r.status === 'late');
      const hasExcused = dayRecords.some((r) => r.status === 'excused');
      const hasAbsent = dayRecords.some((r) => r.status === 'absent');

      if (hasPresent) {
        presentCount++;
        return 'ح';
      } else if (hasLate) {
        lateCount++;
        presentCount++;
        return 'ت';
      } else if (hasExcused) {
        excusedCount++;
        return 'م';
      } else if (hasAbsent) {
        unexcusedAbsentCount++;
        return 'غ';
      }
      return '-';
    });

    const totalCalculated = presentCount + unexcusedAbsentCount + excusedCount;
    const rate = totalCalculated > 0 ? Math.round((presentCount / totalCalculated) * 100) : 100;

    matrixRows.push([
      idx + 1,
      st.id,
      `${st.lastName} ${st.firstName}`,
      st.classroom,
      ...dayCells,
      presentCount,
      lateCount,
      unexcusedAbsentCount,
      excusedCount,
      `${rate}%`,
    ]);
  });

  const matrixSheet = XLSX.utils.aoa_to_sheet(matrixRows);
  applyRTL(matrixSheet, workbook);
  matrixSheet['!cols'] = autoFitColumns(matrixRows, 8, 30);
  XLSX.utils.book_append_sheet(workbook, matrixSheet, 'مصفوفة الحضور الشهرية');

  // SHEET 2: Summary Stats Sheet
  const totalSchoolStudents = filteredStudents.length;
  const totalMonthRecords = monthRecords.length;
  const totalLateMonth = monthRecords.filter((r) => r.status === 'late').length;

  const statsRows: (string | number)[][] = [
    [`ملخص المؤشرات الشهرية - ${monthName} ${year}`],
    [`المؤسسة: ${settings.schoolName}`, '', `الولاية: ${settings.wilaya}`],
    [],
    ['المؤشر الإداري والتربوي', 'القيمة'],
    ['إجمالي التلاميذ المسجلين في النطاق', totalSchoolStudents],
    ['إجمالي عمليات تسجيل الدخول بالشهر', totalMonthRecords],
    ['إجمالي حالات التأخر المسجلة', totalLateMonth],
    ['رمز الاختصارات في المصفوفة:', ''],
    ['ح', 'حاضر (Present)'],
    ['ت', 'متأخر (Late)'],
    ['غ', 'غائب غير مبرر (Absent)'],
    ['م', 'غياب مبرر بشهادة طبية (Excused)'],
    ['عطلة', 'عطلة أسبوعية (جمعة / سبت)'],
  ];

  const statsSheet = XLSX.utils.aoa_to_sheet(statsRows);
  applyRTL(statsSheet, workbook);
  statsSheet['!cols'] = autoFitColumns(statsRows, 15, 45);
  XLSX.utils.book_append_sheet(workbook, statsSheet, 'المؤشرات والرموز');

  const fileName = `التقرير_الشهري_للحضور_${monthPrefix}_${(settings.schoolName || 'سعدون_عاشور').replace(/\s+/g, '_')}.xlsx`;
  XLSX.writeFile(workbook, fileName);
}

/**
 * 5. Export Absence Notices & Disciplinary Warnings to Excel
 */
export function exportAbsenceNoticesToExcel(params: {
  notices: any[];
  settings: SchoolSettings;
}) {
  const { notices, settings } = params;
  const workbook = XLSX.utils.book_new();
  const todayStr = new Date().toISOString().split('T')[0];

  const rows: (string | number)[][] = [
    ['الجمهورية الجزائرية الديمقراطية الشعبية · وزارة التربية الوطنية'],
    [`مديرية التربية لولاية ${settings.wilaya || 'عنابة'} · ${settings.schoolName || 'متوسطة سعدون عاشور'}`],
    ['سجل إشعارات وإعذارات الغياب المتدرجة (اليوم الرابع / إشعار 2 بعد أسبوع / إعذار رسمي بعد 15 يوماً)'],
    [`تاريخ الاستخراج: ${todayStr}`, '', '', `إجمالي الإشعارات: ${notices.length}`],
    [],
    [
      'الرقم',
      'رقم المرجع الإداري',
      'المرحلة القانونية',
      'اسم ولقب التلميذ',
      'القسم',
      'المستوى',
      'اسم ولي الأمر',
      'رقم هاتف الولي',
      'عدد أيام الغياب',
      'تاريخ الاستحقاق',
      'تاريخ الإرسال',
      'حالة الإشعار',
      'وسيلة التبليغ',
      'الملاحظات الإدارية',
    ],
  ];

  notices.forEach((n, idx) => {
    const stageLabel =
      n.stage === 'notice_1'
        ? 'المرحلة 1: إشعار اليوم الرابع'
        : n.stage === 'notice_2'
        ? 'المرحلة 2: إشعار 2 (بعد أسبوع)'
        : 'المرحلة 3: إعذار رسمي (بعد 15 يوماً من أول غياب)';


    const statusLabel =
      n.status === 'sent'
        ? 'تم التبليغ والإرسال'
        : n.status === 'justified'
        ? 'تمت التسوية والتبرير'
        : n.status === 'cancelled'
        ? 'ملغى'
        : 'قيد الانتظار';

    const channelLabel =
      n.channel === 'whatsapp'
        ? 'واتساب WhatsApp'
        : n.channel === 'sms'
        ? 'رسالة نصية SMS'
        : n.channel === 'official_letter'
        ? 'خطاب رسمي بالبريد'
        : 'تسليم يدوي بالاستدعاء';

    rows.push([
      idx + 1,
      n.referenceNumber || '-',
      stageLabel,
      n.studentName,
      n.classroom,
      n.grade,
      n.guardianName || '-',
      n.guardianPhone || '-',
      `${n.absenceDaysCount || 0} أيام`,
      n.dueDate || '-',
      n.sentDate || '-',
      statusLabel,
      channelLabel,
      n.notes || n.excuseReason || '-',
    ]);
  });

  const sheet = XLSX.utils.aoa_to_sheet(rows);
  applyRTL(sheet, workbook);
  sheet['!cols'] = autoFitColumns(rows, 12, 40);
  XLSX.utils.book_append_sheet(workbook, sheet, 'سجل الإشعارات والإعذارات');

  const fileName = `سجل_إشعارات_وإعذارات_الغياب_${(settings.schoolName || 'سعدون_عاشور').replace(/\s+/g, '_')}_${todayStr}.xlsx`;
  XLSX.writeFile(workbook, fileName);
}

