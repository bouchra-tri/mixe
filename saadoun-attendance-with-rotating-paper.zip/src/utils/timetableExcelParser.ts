import * as XLSX from 'xlsx';
import {
  TimetableSession,
  TimetableSlotId,
  SchoolDay,
  GradeLevel,
  Teacher,
  ImportComparisonReport,
  SchoolSettings,
} from '../types';
import { DAYS_OF_WEEK, TIMETABLE_SLOTS, TEACHERS, SUBJECT_INFO } from '../data/timetableData';

/**
 * Standard slot mapping for CEM Saadoun Achour
 */
export const OFFICIAL_SLOTS_MAP: Record<
  TimetableSlotId,
  { label: string; startTime: string; endTime: string; periodType: 'morning' | 'afternoon' }
> = {
  p1: { label: 'الحصة 1', startTime: '08:00', endTime: '09:00', periodType: 'morning' },
  p2: { label: 'الحصة 2', startTime: '09:00', endTime: '10:00', periodType: 'morning' },
  p3: { label: 'الحصة 3', startTime: '10:00', endTime: '11:00', periodType: 'morning' },
  p4: { label: 'الحصة 4', startTime: '11:00', endTime: '12:00', periodType: 'morning' },
  p5: { label: 'الحصة 5', startTime: '13:30', endTime: '14:30', periodType: 'afternoon' },
  p6: { label: 'الحصة 6', startTime: '14:30', endTime: '15:30', periodType: 'afternoon' },
  p7: { label: 'الحصة 7', startTime: '15:30', endTime: '16:30', periodType: 'afternoon' },
  p8: { label: 'الحصة 8', startTime: '16:30', endTime: '17:30', periodType: 'afternoon' },
};

/**
 * Normalize Arabic text for reliable matching (removes diacritics, prefixes, harmonizes hamza/taa)
 */
export function normalizeArabic(text: string): string {
  if (!text) return '';
  return text
    .trim()
    .replace(/[\u064B-\u065F\u0670]/g, '') // remove tashkeel
    .replace(/[أإآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/[ىي]/g, 'ي')
    .replace(/ئ/g, 'ي')
    .replace(/ء/g, '')
    .replace(/ؤ/g, 'و')
    .replace(/^(أستاذة|أستاذ|الاستاذة|الاستاذ|أ\.|د\.|الشيخ|السيد|السيدة)\s+/gi, '')
    .replace(/\s+/g, ' ')
    .toLowerCase();
}

/**
 * Calculate token-based similarity between two names (0 to 1)
 */
export function calculateNameSimilarity(nameA: string, nameB: string): number {
  const normA = normalizeArabic(nameA);
  const normB = normalizeArabic(nameB);
  if (normA === normB) return 1.0;
  if (!normA || !normB) return 0.0;

  const wordsA = normA.split(' ').filter(Boolean);
  const wordsB = normB.split(' ').filter(Boolean);

  let commonCount = 0;
  wordsA.forEach((wA) => {
    if (wordsB.some((wB) => wB === wA || wB.includes(wA) || wA.includes(wB))) {
      commonCount++;
    }
  });

  const precision = commonCount / Math.max(wordsA.length, wordsB.length);
  return precision;
}

/**
 * Normalize classroom name to standard Algerian middle school notation (e.g. "1م1", "2م3")
 */
export function normalizeClassroom(raw: string): string {
  if (!raw) return '1م1';
  const clean = raw.trim().replace(/\s+/g, '');

  // Patterns like 1م1, 1م 1, 1 م 1
  const mMatch = clean.match(/([1-4])\s*(?:م|متوسط)\s*([1-5])/);
  if (mMatch) {
    return `${mMatch[1]}م${mMatch[2]}`;
  }

  // Patterns like 1AM1, 2AM3, 4AM2
  const amMatch = clean.match(/([1-4])\s*(?:AM|am)\s*([1-5])/i);
  if (amMatch) {
    return `${amMatch[1]}م${amMatch[2]}`;
  }

  // Already 1م1
  if (/^[1-4]م[1-5]$/.test(clean)) {
    return clean;
  }

  return clean;
}

/**
 * Infer grade level from classroom name
 */
export function inferGrade(classroom: string): GradeLevel {
  const norm = normalizeClassroom(classroom);
  if (norm.startsWith('1')) return '1AM';
  if (norm.startsWith('2')) return '2AM';
  if (norm.startsWith('3')) return '3AM';
  if (norm.startsWith('4')) return '4AM';
  return '1AM';
}

/**
 * Parse Day of week from Arabic text
 */
export function parseSchoolDay(text: string): SchoolDay | null {
  if (!text) return null;
  const raw = text.trim();
  const norm = normalizeArabic(text);
  if (/احد|الأحد|الاحد/i.test(raw) || norm.includes('احد')) return 'sunday';
  if (/اثنين|الإثنين|الاثنين/i.test(raw) || norm.includes('اثنين')) return 'monday';
  if (/ثلاثاء|الثلاثاء|لاثا/i.test(raw) || norm.includes('ثلاث') || norm.includes('لاثا')) return 'tuesday';
  if (/اربعاء|الأربعاء|الاربعاء|اربع/i.test(raw) || norm.includes('اربع') || norm.includes('لأربع')) return 'wednesday';
  if (/خميس|الخميس/i.test(raw) || norm.includes('خميس')) return 'thursday';
  return null;
}

/**
 * Parse and normalize time range string, correctly handling RTL reversed strings like "09:00-08:00"
 */
export function parseTimeRange(timeStr: string): {
  startTime: string;
  endTime: string;
  slotId: TimetableSlotId | null;
} {
  const cleaned = timeStr.trim().replace(/[–—_]/g, '-').replace(/\s+/g, '');
  const matches = cleaned.match(/(\d{1,2})[:hH](\d{2})\s*-\s*(\d{1,2})[:hH](\d{2})/);

  if (matches) {
    const h1 = parseInt(matches[1], 10);
    const m1 = parseInt(matches[2], 10);
    const h2 = parseInt(matches[3], 10);
    const m2 = parseInt(matches[4], 10);

    const minutes1 = h1 * 60 + m1;
    const minutes2 = h2 * 60 + m2;

    let startMins = minutes1;
    let endMins = minutes2;

    // RTL flip fix: if "09:00 - 08:00" -> start is 08:00, end is 09:00
    if (minutes1 > minutes2) {
      startMins = minutes2;
      endMins = minutes1;
    }

    const sH = String(Math.floor(startMins / 60)).padStart(2, '0');
    const sM = String(startMins % 60).padStart(2, '0');
    const eH = String(Math.floor(endMins / 60)).padStart(2, '0');
    const eM = String(endMins % 60).padStart(2, '0');

    const startTime = `${sH}:${sM}`;
    const endTime = `${eH}:${eM}`;

    // Map to slot ID
    let slotId: TimetableSlotId | null = null;
    if (startMins <= 8 * 60 + 15) slotId = 'p1'; // 08:00
    else if (startMins <= 9 * 60 + 15) slotId = 'p2'; // 09:00
    else if (startMins <= 10 * 60 + 15) slotId = 'p3'; // 10:00
    else if (startMins <= 11 * 60 + 15) slotId = 'p4'; // 11:00
    else if (startMins <= 13 * 60 + 45) slotId = 'p5'; // 13:00 or 13:30
    else if (startMins <= 14 * 60 + 45) slotId = 'p6'; // 14:30
    else if (startMins <= 15 * 60 + 45) slotId = 'p7'; // 15:30
    else slotId = 'p8'; // 16:30

    return { startTime, endTime, slotId };
  }

  return { startTime: '08:00', endTime: '09:00', slotId: null };
}

/**
 * Standardize subject name according to Algerian curriculum
 */
export function normalizeSubject(raw: string): string {
  if (!raw) return 'دراسة موجهة';
  const norm = normalizeArabic(raw);

  if (norm.includes('رياضيات')) return 'الرياضيات';
  if (norm.includes('عربيه') || norm.includes('عربي')) return 'اللغة العربية';
  if (norm.includes('فرنسيه') || norm.includes('فرنسي')) return 'اللغة الفرنسية';
  if (norm.includes('انجليزيه') || norm.includes('انجليزي') || norm.includes('انقليز')) return 'اللغة الإنجليزية';
  if (norm.includes('فيزياء') || norm.includes('فيزيائيه') || norm.includes('فيزيائي')) return 'العلوم الفيزيائية والتكنولوجيا';
  if (norm.includes('علوم') || norm.includes('طبيعه') || norm.includes('طبيعيه') || norm.includes('ط ح')) return 'علوم الطبيعة والحياة';
  if (norm.includes('تاريخ') || norm.includes('جغرافيا') || norm.includes('اجتماعيات')) return 'التاريخ والجغرافيا';
  if (norm.includes('اسلاميه') || norm.includes('تربيه دينيه')) return 'التربية الإسلامية';
  if (norm.includes('مدنيه')) return 'التربية المدنية';
  if (norm.includes('بدنيه') || norm.includes('رياضه') || norm.includes('تربيه رياضيه')) return 'التربية البدنية والرياضية';
  if (norm.includes('اعلام') || norm.includes('معلوماتيه') || norm.includes('كمبيوتر')) return 'الإعلام الآلي';
  if (norm.includes('فنيه') || norm.includes('رسم') || norm.includes('تشكيليه')) return 'التربية الفنية';
  if (norm.includes('موسيقيه') || norm.includes('موسيقى')) return 'التربية الموسيقية';
  if (norm.includes('امازيغيه')) return 'اللغة الأمازيغية';

  return raw.trim();
}

/**
 * Match a raw teacher name string against existing teachers database
 */
export function matchTeacher(
  rawName: string,
  existingTeachers: Teacher[]
): {
  matchedTeacher: Teacher | null;
  matchType: 'exact' | 'fuzzy' | 'unmatched';
  similarity: number;
} {
  if (!rawName || !rawName.trim()) {
    return { matchedTeacher: null, matchType: 'unmatched', similarity: 0 };
  }

  const normTarget = normalizeArabic(rawName);

  // 1. Exact match
  for (const t of existingTeachers) {
    if (normalizeArabic(t.name) === normTarget) {
      return { matchedTeacher: t, matchType: 'exact', similarity: 1.0 };
    }
  }

  const isBahloulTarget = normTarget.includes('بهلول');
  const isBenNouiTarget = normTarget.includes('نوي') || normTarget.includes('بن نوي');

  // 2. High-confidence token similarity (>= 0.70) with strict family separation
  let bestTeacher: Teacher | null = null;
  let highestSim = 0;

  for (const t of existingTeachers) {
    const normTeacherName = normalizeArabic(t.name);
    const isBahloulTeacher = normTeacherName.includes('بهلول');
    const isBenNouiTeacher = normTeacherName.includes('نوي') || normTeacherName.includes('بن نوي');

    if (isBahloulTarget && !isBahloulTeacher) continue;
    if (isBenNouiTarget && !isBenNouiTeacher) continue;
    if (!isBahloulTarget && isBahloulTeacher) continue;
    if (!isBenNouiTarget && isBenNouiTeacher) continue;

    const sim = calculateNameSimilarity(rawName, t.name);
    if (sim > highestSim) {
      highestSim = sim;
      bestTeacher = t;
    }
  }

  if (bestTeacher && highestSim >= 0.70) {
    return { matchedTeacher: bestTeacher, matchType: 'fuzzy', similarity: highestSim };
  }

  return { matchedTeacher: null, matchType: 'unmatched', similarity: highestSim };
}

/**
 * Helper to add a session and automatically expand double-hour sessions (like PE / التربية البدنية)
 * across consecutive slots (e.g., p1-p2 or p3-p4) without duplication.
 */
function addSessionWithDoubleHourExpansion(
  parsedSession: TimetableSession,
  extractedSessions: TimetableSession[],
  rawClassroomsFound: Set<string>,
  rawTeachersFound: Set<string>,
  rawRoomsFound: Set<string>
) {
  if (parsedSession.classroom) rawClassroomsFound.add(parsedSession.classroom);
  if (parsedSession.teacherName) rawTeachersFound.add(parsedSession.teacherName);
  if (parsedSession.room) rawRoomsFound.add(parsedSession.room);

  const isPE = /بدنية|رياضية|رياضة/i.test(parsedSession.subject);

  if (isPE) {
    const slotOrder: TimetableSlotId[] = ['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8'];
    const sIdx = slotOrder.indexOf(parsedSession.slotId);

    if (!extractedSessions.some(s =>
      s.day === parsedSession.day &&
      s.classroom === parsedSession.classroom &&
      s.slotId === parsedSession.slotId &&
      s.subject === parsedSession.subject
    )) {
      extractedSessions.push(parsedSession);
    }

    if (sIdx >= 0 && sIdx < slotOrder.length - 1 && sIdx % 2 === 0) {
      const nextSlotId = slotOrder[sIdx + 1];
      const nextSlotMap = OFFICIAL_SLOTS_MAP[nextSlotId];
      if (nextSlotMap) {
        const secondSession: TimetableSession = {
          ...parsedSession,
          id: `${parsedSession.id}-h2`,
          slotId: nextSlotId,
          startTime: nextSlotMap.startTime,
          endTime: nextSlotMap.endTime,
        };
        if (!extractedSessions.some(s =>
          s.day === secondSession.day &&
          s.classroom === secondSession.classroom &&
          s.slotId === secondSession.slotId &&
          s.subject === secondSession.subject
        )) {
          extractedSessions.push(secondSession);
        }
      }
    }
  } else {
    if (!extractedSessions.some(s =>
      s.day === parsedSession.day &&
      s.classroom === parsedSession.classroom &&
      s.slotId === parsedSession.slotId &&
      s.subject === parsedSession.subject &&
      s.teacherName === parsedSession.teacherName
    )) {
      extractedSessions.push(parsedSession);
    }
  }
}

export interface ParseResult {
  sessions: TimetableSession[];
  report: ImportComparisonReport;
  workbookSheets: string[];
  selectedSheet: string;
  academicYear: string;
}

/**
 * Core Parser: Reads Excel file and extracts timetable sessions
 */
export async function parseTimetableWorkbook(
  dataBuffer: ArrayBuffer,
  existingTeachers: Teacher[] = TEACHERS,
  existingClassrooms: string[] = [
    '1م1', '1م2', '1م3', '1م4', '1م5',
    '2م1', '2م2', '2م3', '2م4',
    '3م1', '3م2', '3م3', '3م4',
    '4م1', '4م2', '4م3', '4م4'
  ]
): Promise<ParseResult> {
  const workbook = XLSX.read(dataBuffer, { type: 'array' });
  const sheetNames = workbook.SheetNames;

  if (!sheetNames || sheetNames.length === 0) {
    throw new Error('الملف لا يحتوي على أي ورقة عمل.');
  }

  // Priority sheet detection:
  // 1. "أقسام - أفقي"
  // 2. "أساتذة - أفقي"
  // 3. "أقسام"
  // 4. "أساتذة"
  // 5. first sheet
  let targetSheetName = sheetNames[0];
  const classesHorizSheet = sheetNames.find((s) => /أقسام.*أفقي|classes.*horiz|أقسام-أفقي/i.test(s));
  const teachersHorizSheet = sheetNames.find((s) => /أساتذة.*أفقي|teachers.*horiz|أساتذة-أفقي/i.test(s));
  const roomsHorizSheet = sheetNames.find((s) => /قاعات.*أفقي|rooms.*horiz|قاعات-أفقي/i.test(s));
  const classesSheet = sheetNames.find((s) => /أقسام|classes/i.test(s));
  const teachersSheet = sheetNames.find((s) => /أساتذة|teachers/i.test(s));
  const roomsSheet = sheetNames.find((s) => /قاعات|rooms/i.test(s));

  if (classesHorizSheet) targetSheetName = classesHorizSheet;
  else if (teachersHorizSheet) targetSheetName = teachersHorizSheet;
  else if (roomsHorizSheet) targetSheetName = roomsHorizSheet;
  else if (classesSheet) targetSheetName = classesSheet;
  else if (teachersSheet) targetSheetName = teachersSheet;
  else if (roomsSheet) targetSheetName = roomsSheet;

  const worksheet = workbook.Sheets[targetSheetName];
  if (!worksheet) {
    throw new Error(`تعذر قراءة الورقة ${targetSheetName}`);
  }

  // Convert sheet to 2D array of strings
  const matrix: string[][] = XLSX.utils.sheet_to_json(worksheet, {
    header: 1,
    defval: '',
    raw: false,
  });

  // Extract academic year if present in top rows
  let detectedYear = '2024/2025';
  for (let r = 0; r < Math.min(10, matrix.length); r++) {
    const rowStr = matrix[r]?.join(' ') || '';
    const yrMatch = rowStr.match(/202[0-9]\s*[-/]\s*202[0-9]/);
    if (yrMatch) {
      detectedYear = yrMatch[0].replace(/\s+/g, '');
      break;
    }
  }

  const isTeachersSheet = /أساتذة/i.test(targetSheetName);

  // Extracted sessions accumulator
  const extractedSessions: TimetableSession[] = [];
  const rawTeachersFound = new Set<string>();
  const rawClassroomsFound = new Set<string>();
  const rawRoomsFound = new Set<string>();

  // Slot definitions to map columns
  const slotOrder: TimetableSlotId[] = ['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8'];

  // Parse Horizontal Matrix (either Classes-Horizontal or Teachers-Horizontal)
  // Algerian timetable sheets contain multiple tables separated by class/teacher titles
  let currentEntity = ''; // classroom or teacher name
  let dayColumnIndex = 0;
  let slotColumnsMap: { col: number; slotId: TimetableSlotId; startTime: string; endTime: string }[] = [];

  for (let r = 0; r < matrix.length; r++) {
    const row = matrix[r] || [];
    const rowText = row.join(' ').trim();

    if (!rowText) continue;

    // Check if this row is an Entity header (Class or Teacher)
    if (!isTeachersSheet) {
      // Classes sheet: look for "القسم: 1م1" or "1م1" or "1AM1"
      const classMatch = rowText.match(/(?:القسم\s*[:\-]?\s*)?([1-4]\s*(?:م|AM|متوسط)\s*[1-5])/i);
      if (classMatch) {
        currentEntity = normalizeClassroom(classMatch[1]);
        rawClassroomsFound.add(currentEntity);
        slotColumnsMap = [];
        continue;
      }
    } else {
      // Teachers sheet: look for "الأستاذ: بن صالح رشيد" or "أ. دريدي"
      const teacherMatch = rowText.match(/(?:الأستاذ|الاستاذ|الأستاذة|الاستاذة|أ\.)\s*[:\-]?\s*([^\s\-(\d]+(?:\s+[^\s\-(\d]+){1,3})/i);
      if (teacherMatch) {
        currentEntity = teacherMatch[1].trim();
        rawTeachersFound.add(currentEntity);
        slotColumnsMap = [];
        continue;
      }
    }

    // Check if this row is a Time Slots Header Row (e.g. contains 08:00, 09:00, 10:00, etc.)
    const hasTimes = row.some((cell) => /\d{1,2}[:hH]\d{2}/.test(String(cell)));
    if (hasTimes) {
      slotColumnsMap = [];
      dayColumnIndex = 0;

      row.forEach((cell, cIdx) => {
        const cellStr = String(cell || '').trim();
        const normDay = parseSchoolDay(cellStr);
        if (normDay || /اليوم|التاريخ/i.test(cellStr)) {
          dayColumnIndex = cIdx;
        }

        const parsedTime = parseTimeRange(cellStr);
        if (parsedTime.slotId) {
          slotColumnsMap.push({
            col: cIdx,
            slotId: parsedTime.slotId,
            startTime: parsedTime.startTime,
            endTime: parsedTime.endTime,
          });
        }
      });

      // If columns were not matched by explicit text, fallback to positional slot columns
      if (slotColumnsMap.length < 4) {
        slotColumnsMap = [];
        let slotIndex = 0;
        row.forEach((cell, cIdx) => {
          if (cIdx !== dayColumnIndex && String(cell || '').trim().length > 0 && slotIndex < slotOrder.length) {
            const sid = slotOrder[slotIndex];
            slotColumnsMap.push({
              col: cIdx,
              slotId: sid,
              startTime: OFFICIAL_SLOTS_MAP[sid].startTime,
              endTime: OFFICIAL_SLOTS_MAP[sid].endTime,
            });
            slotIndex++;
          }
        });
      }
      continue;
    }

    // Check if this row is a Day Row (starts with Sunday, Monday, etc.)
    const dayCell = String(row[dayColumnIndex] || row[0] || '').trim();
    const matchedDay = parseSchoolDay(dayCell);

    if (matchedDay && slotColumnsMap.length > 0) {
      // Iterate through the slot columns for this day
      slotColumnsMap.forEach((slotMap) => {
        const cellContent = String(row[slotMap.col] || '').trim();
        if (!cellContent || cellContent === '-' || cellContent === 'فراغ') return;

        // Split cell content by double newlines or blank lines to separate parallel activities
        const blocks = cellContent.split(/\r?\n\s*\r?\n/).map((b) => b.trim()).filter(Boolean);

        if (blocks.length > 1) {
          blocks.forEach((block, bIdx) => {
            const groupTag = /td|tp|فوج|مجموعة/i.test(block) ? (block.match(/td|tp|فوج\s*\d|مجموعة\s*\d/i)?.[0] || `فوج ${bIdx + 1}`) : `فوج ${bIdx + 1}`;
            const parsedSession = parseCellText(
              block,
              isTeachersSheet ? '' : currentEntity,
              isTeachersSheet ? currentEntity : '',
              matchedDay,
              slotMap.slotId,
              slotMap.startTime,
              slotMap.endTime,
              detectedYear,
              existingTeachers,
              groupTag
            );
            if (parsedSession) {
              addSessionWithDoubleHourExpansion(parsedSession, extractedSessions, rawClassroomsFound, rawTeachersFound, rawRoomsFound);
            }
          });
        } else {
          // Check if single cell string contains multiple lines that form 2 separate blocks (e.g., 6 lines = 2 blocks of 3 lines)
          const lines = cellContent.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
          if (lines.length >= 6 && lines.length % 3 === 0) {
            for (let i = 0; i < lines.length; i += 3) {
              const subBlock = lines.slice(i, i + 3).join('\n');
              const groupTag = /td|tp/i.test(subBlock) ? (subBlock.match(/td|tp/i)?.[0] || '') : `فوج ${Math.floor(i / 3) + 1}`;
              const parsedSession = parseCellText(
                subBlock,
                isTeachersSheet ? '' : currentEntity,
                isTeachersSheet ? currentEntity : '',
                matchedDay,
                slotMap.slotId,
                slotMap.startTime,
                slotMap.endTime,
                detectedYear,
                existingTeachers,
                groupTag
              );
              if (parsedSession) {
                addSessionWithDoubleHourExpansion(parsedSession, extractedSessions, rawClassroomsFound, rawTeachersFound, rawRoomsFound);
              }
            }
          } else {
            const parsedSession = parseCellText(
              cellContent,
              isTeachersSheet ? '' : currentEntity,
              isTeachersSheet ? currentEntity : '',
              matchedDay,
              slotMap.slotId,
              slotMap.startTime,
              slotMap.endTime,
              detectedYear,
              existingTeachers
            );
            if (parsedSession) {
              addSessionWithDoubleHourExpansion(parsedSession, extractedSessions, rawClassroomsFound, rawTeachersFound, rawRoomsFound);
            }
          }
        }
      });
    }
  }

  // Fallback: If horizontal matrix parser found 0 sessions (e.g. tabular format with columns: اليوم، الحصة، القسم...)
  if (extractedSessions.length === 0 && matrix.length > 1) {
    parseTabularSheet(
      matrix,
      extractedSessions,
      rawTeachersFound,
      rawClassroomsFound,
      rawRoomsFound,
      detectedYear,
      existingTeachers
    );
  }

  // Generate Comparison & Validation Report
  const report = generateComparisonReport(
    extractedSessions,
    targetSheetName,
    detectedYear,
    rawTeachersFound,
    rawClassroomsFound,
    rawRoomsFound,
    existingTeachers,
    existingClassrooms
  );

  return {
    sessions: extractedSessions,
    report,
    workbookSheets: sheetNames,
    selectedSheet: targetSheetName,
    academicYear: detectedYear,
  };
}

/**
 * Helper to parse text within a single timetable cell
 */
function parseCellText(
  cellText: string,
  contextClassroom: string,
  contextTeacher: string,
  day: SchoolDay,
  slotId: TimetableSlotId,
  startTime: string,
  endTime: string,
  academicYear: string,
  existingTeachers: Teacher[],
  explicitGroup?: string
): TimetableSession | null {
  const lines = cellText.split(/[\n\r/|]+/).map((s) => s.trim()).filter(Boolean);
  if (lines.length === 0) return null;

  let classroom = contextClassroom;
  let teacherName = contextTeacher;
  let subject = '';
  let room = '';
  let group = explicitGroup;

  // 3-line block structure: [Subject, Teacher, Room]
  if (lines.length >= 3) {
    subject = normalizeSubject(lines[0]);
    teacherName = lines[1];
    room = lines[2]; // Third line is the room name (e.g. معلوماتية_1, ق_1, مخبر 1)
  } else if (lines.length === 2) {
    subject = normalizeSubject(lines[0]);
    if (/(قاعة|ق_|مخبر|ورشة|معلوماتية|ساحة)/i.test(lines[1])) {
      room = lines[1];
    } else {
      teacherName = lines[1];
    }
  } else {
    subject = normalizeSubject(lines[0]);
  }

  // Extract group tag like TD, TP, فوج 1 from subject or lines
  lines.forEach((line) => {
    if (!line) return;
    if (/td|tp|فوج|مجموعة/i.test(line) && !group) {
      const match = line.match(/(td|tp|فوج\s*\d+|مجموعة\s*\d+)/i);
      if (match) {
        group = match[1].toUpperCase();
      }
    }
    const clsMatch = line.match(/([1-4]\s*(?:م|AM|متوسط)\s*[1-5])/i);
    if (clsMatch && !classroom) {
      classroom = normalizeClassroom(clsMatch[1]);
    }
  });

  if (!room) {
    const roomPattern = /(قاعة\s*\d+|ق\s*\d+|مخبر\s*\d*|ورشة\s*\d*|ساحة|معلوماتية[_\s]*\d*|م\s*ط\s*ح)/i;
    for (let i = 0; i < lines.length; i++) {
      const rMatch = lines[i].match(roomPattern);
      if (rMatch) {
        room = rMatch[0];
        break;
      }
    }
    if (!room) room = 'قاعة 01';
  }

  if (!classroom) classroom = '1م1';
  if (!subject) subject = normalizeSubject(lines[0] || 'الرياضيات');

  let teacherId = 'T-AUTO';
  if (teacherName && teacherName !== 'بدون إسناد') {
    const tResult = matchTeacher(teacherName, existingTeachers);
    if (tResult.matchedTeacher) {
      teacherId = tResult.matchedTeacher.id;
      teacherName = tResult.matchedTeacher.name;
    } else {
      teacherId = `T-${normalizeArabic(teacherName).slice(0, 8).replace(/\s+/g, '-')}`;
    }
  } else {
    teacherId = 'TEA-UNASSIGNED';
    teacherName = 'بدون إسناد';
  }

  const grade = inferGrade(classroom);

  return {
    id: `SES-${day}-${slotId}-${classroom}-${Math.random().toString(36).substring(2, 6)}`,
    day,
    slotId,
    classroom,
    grade,
    subject,
    teacherId,
    teacherName,
    room,
    group,
    startTime,
    endTime,
    academicYear,
  };
}

/**
 * Fallback parser for tabular sheets (columns: اليوم، الحصة، القسم، المادة، الأستاذ، القاعة)
 */
function parseTabularSheet(
  matrix: string[][],
  extractedSessions: TimetableSession[],
  rawTeachersFound: Set<string>,
  rawClassroomsFound: Set<string>,
  rawRoomsFound: Set<string>,
  academicYear: string,
  existingTeachers: Teacher[]
) {
  let headerRow = matrix[0] || [];
  let colDay = -1;
  let colSlot = -1;
  let colClass = -1;
  let colSubj = -1;
  let colTeacher = -1;
  let colRoom = -1;

  for (let r = 0; r < Math.min(5, matrix.length); r++) {
    const row = matrix[r] || [];
    row.forEach((cell, idx) => {
      const cStr = normalizeArabic(String(cell || ''));
      if (cStr.includes('يوم')) colDay = idx;
      if (cStr.includes('حصه') || cStr.includes('وقت') || cStr.includes('توقيت')) colSlot = idx;
      if (cStr.includes('قسم') || cStr.includes('فوج')) colClass = idx;
      if (cStr.includes('ماده')) colSubj = idx;
      if (cStr.includes('استاذ') || cStr.includes('معلم')) colTeacher = idx;
      if (cStr.includes('قاعه') || cStr.includes('حجره')) colRoom = idx;
    });
    if (colDay >= 0 && colClass >= 0) {
      headerRow = row;
      break;
    }
  }

  if (colDay >= 0 && colClass >= 0) {
    for (let r = 1; r < matrix.length; r++) {
      const row = matrix[r];
      if (!row || row.length < 2) continue;

      const day = parseSchoolDay(String(row[colDay] || ''));
      if (!day) continue;

      const rawClass = String(row[colClass] || '');
      const classroom = normalizeClassroom(rawClass);
      const subject = normalizeSubject(String(row[colSubj] || ''));
      const teacherName = String(row[colTeacher] || 'أستاذ المادة');
      const room = String(row[colRoom] || 'قاعة 01');

      const parsedSlot = parseTimeRange(String(row[colSlot] || '08:00 - 09:00'));
      const slotId = parsedSlot.slotId || 'p1';

      rawClassroomsFound.add(classroom);
      rawTeachersFound.add(teacherName);
      rawRoomsFound.add(room);

      const tMatch = matchTeacher(teacherName, existingTeachers);
      const teacherId = tMatch.matchedTeacher ? tMatch.matchedTeacher.id : 'TEA-AUTO';

      extractedSessions.push({
        id: `SES-TAB-${r}-${Date.now().toString().slice(-4)}`,
        day,
        slotId,
        classroom,
        grade: inferGrade(classroom),
        subject,
        teacherId,
        teacherName: tMatch.matchedTeacher ? tMatch.matchedTeacher.name : teacherName,
        room,
        startTime: parsedSlot.startTime,
        endTime: parsedSlot.endTime,
        academicYear,
      });
    }
  }
}

/**
 * Generate comprehensive matching, conflicts, and discrepancy report
 */
function generateComparisonReport(
  sessions: TimetableSession[],
  sheetName: string,
  academicYear: string,
  rawTeachers: Set<string>,
  rawClassrooms: Set<string>,
  rawRooms: Set<string>,
  existingTeachers: Teacher[],
  existingClassrooms: string[]
): ImportComparisonReport {
  // 1. Teachers matching
  const exactMatches: Array<{ excelName: string; matchedTeacher: Teacher }> = [];
  const fuzzyMatches: Array<{ excelName: string; matchedTeacher: Teacher; similarity: number }> = [];
  const unmatchedTeachers: Array<{ excelName: string }> = [];

  rawTeachers.forEach((name) => {
    if (!name || name === 'أستاذ المادة') return;
    const res = matchTeacher(name, existingTeachers);
    if (res.matchType === 'exact' && res.matchedTeacher) {
      exactMatches.push({ excelName: name, matchedTeacher: res.matchedTeacher });
    } else if (res.matchType === 'fuzzy' && res.matchedTeacher) {
      fuzzyMatches.push({ excelName: name, matchedTeacher: res.matchedTeacher, similarity: Math.round(res.similarity * 100) });
    } else {
      unmatchedTeachers.push({ excelName: name });
    }
  });

  // 2. Classrooms matching
  const matchedClassrooms: string[] = [];
  const unmatchedClassrooms: string[] = [];
  rawClassrooms.forEach((c) => {
    if (existingClassrooms.includes(c)) {
      matchedClassrooms.push(c);
    } else {
      unmatchedClassrooms.push(c);
    }
  });

  // 3. Conflicts detection
  const conflicts: ImportComparisonReport['conflicts'] = [];

  // Map to check: teacher + day + slot -> sessions
  const teacherSlotMap = new Map<string, TimetableSession[]>();
  const classroomSlotMap = new Map<string, TimetableSession[]>();

  sessions.forEach((s) => {
    // Teacher key
    if (s.teacherId && s.teacherId !== 'TEA-AUTO') {
      const tKey = `${s.teacherId}_${s.day}_${s.slotId}`;
      const list = teacherSlotMap.get(tKey) || [];
      list.push(s);
      teacherSlotMap.set(tKey, list);
    }

    // Classroom key
    const cKey = `${s.classroom}_${s.day}_${s.slotId}`;
    const cList = classroomSlotMap.get(cKey) || [];
    cList.push(s);
    classroomSlotMap.set(cKey, cList);
  });

  // Check teacher double bookings (scheduled in 2 classrooms at same time)
  teacherSlotMap.forEach((sessionsList) => {
    if (sessionsList.length > 1) {
      const distinctClasses = Array.from(new Set(sessionsList.map((s) => s.classroom)));
      if (distinctClasses.length > 1) {
        const first = sessionsList[0];
        const dayLabel = DAYS_OF_WEEK.find((d) => d.key === first.day)?.label || first.day;
        const timeStr = `${first.startTime || '08:00'} - ${first.endTime || '09:00'}`;
        conflicts.push({
          type: 'teacher_double_booking',
          day: first.day,
          slotId: first.slotId,
          timeRange: timeStr,
          description: `تعارض: الأستاذ (${first.teacherName}) مبرمج في قسمين مختلفين (${distinctClasses.join(' و ')}) يوم ${dayLabel} في التوقيت (${timeStr}).`,
          sessions: sessionsList,
        });
      }
    }
  });

  // Check classroom overlapping sessions (if not parallel group TD/TP)
  classroomSlotMap.forEach((cSessions) => {
    if (cSessions.length > 1) {
      const hasGroupTags = cSessions.every((s) => s.group);
      if (!hasGroupTags) {
        const first = cSessions[0];
        const dayLabel = DAYS_OF_WEEK.find((d) => d.key === first.day)?.label || first.day;
        const timeStr = `${first.startTime || '08:00'} - ${first.endTime || '09:00'}`;
        conflicts.push({
          type: 'classroom_overlap',
          day: first.day,
          slotId: first.slotId,
          timeRange: timeStr,
          description: `تداخل: القسم (${first.classroom}) لديه أكثر من مادة مبرمجة في نفس الوقت (${cSessions.map((s) => s.subject).join(' / ')}) دون تحديد أفواج متوازية.`,
          sessions: cSessions,
        });
      }
    }
  });

  // 4. Afternoon Timing Discrepancy Check
  // Excel imported timetable uses 13:30 for afternoon start (slots p5..p8)
  const afternoonSessions = sessions.filter((s) => ['p5', 'p6', 'p7', 'p8'].includes(s.slotId));
  const has1330 = afternoonSessions.some((s) => s.startTime === '13:30' || s.startTime === '13:35');
  const importedStartTime = has1330 ? '13:30' : (afternoonSessions[0]?.startTime || '13:30');

  const timingDiscrepancy = {
    hasDiscrepancy: importedStartTime !== '13:00',
    importedStartTime,
    currentSystemStartTime: '13:00',
    message: `يبدأ التوقيت المسائي في الملف المستورد في الساعة ${importedStartTime} (بينما إعدادات النظام الحالية 13:00). يُنصح بتحديث إعدادات النظام لتتوافق مع التوقيت المعتمد.`,
  };

  return {
    totalExtractedSessions: sessions.length,
    totalClassrooms: rawClassrooms.size,
    totalTeachers: rawTeachers.size,
    totalRooms: rawRooms.size,
    sourceSheet: sheetName,
    academicYear,
    teachersReport: {
      exactMatches,
      fuzzyMatches,
      unmatched: unmatchedTeachers,
    },
    classroomsReport: {
      matched: matchedClassrooms,
      unmatched: unmatchedClassrooms,
    },
    roomsReport: {
      rooms: Array.from(rawRooms),
    },
    conflicts,
    afternoonTimingDiscrepancy: timingDiscrepancy,
  };
}

/**
 * Builds a realistic sample Excel file matching «سعدون عاشور - كل الجداول(1).xlsx»
 * Complete with «أقسام - أفقي» and «أساتذة - أفقي» sheets
 */
export function generateSaadounAchourSampleExcel(): Uint8Array {
  const wb = XLSX.utils.book_new();

  // 1. Build «أقسام - أفقي»
  const classesData: any[][] = [
    ['الجمهورية الجزائرية الديمقراطية الشعبية'],
    ['وزارة التربية الوطنية - مديرية التربية لولاية عنابة'],
    ['متوسطة سعدون عاشور - التوقيت الأسبوعي العام للقسم'],
    ['السنة الدراسية: 2024/2025'],
    [],
  ];

  const daysLabels = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس'];
  const sampleClasses = ['1م1', '1م2', '2م1', '3م1', '4م1'];

  sampleClasses.forEach((cls) => {
    classesData.push([`القسم: ${cls} (${cls.startsWith('1') ? '1AM' : cls.startsWith('2') ? '2AM' : cls.startsWith('3') ? '3AM' : '4AM'})`]);
    // Time slots row
    classesData.push([
      'اليوم',
      '08:00 - 09:00',
      '09:00 - 10:00',
      '10:00 - 11:00',
      '11:00 - 12:00',
      '13:30 - 14:30',
      '14:30 - 15:30',
      '15:30 - 16:30',
      '16:30 - 17:30',
    ]);

    daysLabels.forEach((day, dIdx) => {
      if (day === 'الثلاثاء') {
        // Tuesday afternoon usually free in middle schools
        classesData.push([
          day,
          'اللغة العربية\nأ. دريدي سلاف\nق 01',
          'الرياضيات\nأ. بن صالح رشيد\nق 01',
          'التربية الإسلامية\nأ. فرفاش يوسف\nق 01',
          'اللغة الفرنسية\nأ. كواش أسماء\nق 01',
          '',
          '',
          '',
          '',
        ]);
      } else {
        classesData.push([
          day,
          'الرياضيات\nأ. بن صالح رشيد\nق 01',
          'اللغة العربية\nأ. دريدي سلاف\nق 01',
          'التاريخ والجغرافيا\nأ. مباركي زينب\nق 01',
          'العلوم الفيزيائية\nأ. دراجي منير\nمخبر 1',
          'اللغة الفرنسية\nأ. كواش أسماء\nق 01',
          'علوم الطبيعة والحياة\nأ. شريف حكيم\nمخبر 2',
          'الإعلام الآلي\nأ. بن عيسى\nمعلوماتية_1',
          'التربية البدنية\nأ. زايدي كمال\nالساحة',
        ]);
      }
    });

    classesData.push([]); // empty separator row
  });

  const wsClasses = XLSX.utils.aoa_to_sheet(classesData);
  XLSX.utils.book_append_sheet(wb, wsClasses, 'أقسام - أفقي');

  // 2. Build «أساتذة - أفقي»
  const teachersData: any[][] = [
    ['متوسطة سعدون عاشور - جداول توقيت الأساتذة'],
    ['السنة الدراسية: 2024/2025'],
    [],
  ];

  TEACHERS.slice(0, 6).forEach((teacher) => {
    teachersData.push([`الأستاذ: ${teacher.name} - مادة: ${teacher.subject}`]);
    teachersData.push([
      'اليوم',
      '08:00 - 09:00',
      '09:00 - 10:00',
      '10:00 - 11:00',
      '11:00 - 12:00',
      '13:30 - 14:30',
      '14:30 - 15:30',
      '15:30 - 16:30',
      '16:30 - 17:30',
    ]);

    daysLabels.forEach((day) => {
      teachersData.push([
        day,
        `1م1\n${teacher.subject}\nق 01`,
        `1م2\n${teacher.subject}\nق 02`,
        `2م1\n${teacher.subject}\nق 03`,
        '',
        `3م1\n${teacher.subject}\nق 04`,
        `4م1\n${teacher.subject}\nق 05`,
        '',
        '',
      ]);
    });

    teachersData.push([]);
  });

  const wsTeachers = XLSX.utils.aoa_to_sheet(teachersData);
  XLSX.utils.book_append_sheet(wb, wsTeachers, 'أساتذة - أفقي');

  return XLSX.write(wb, { type: 'array', bookType: 'xlsx' });
}
