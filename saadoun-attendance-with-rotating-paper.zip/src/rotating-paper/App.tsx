import React, { useState, useEffect } from 'react';
import { AppData } from './types';
import { HostSchool, applyHostSchool } from './host';
import { INITIAL_FET_XML_DATA } from './utils/constants';
import { parseFetXml, buildSchedulesIndex } from './utils/fetParser';
import { Sidebar } from './components/Sidebar';
import { Toolbar } from './components/Toolbar';
import { ClassesTeachersView } from './components/ClassesTeachersView';
import { GlobalTimetablesView } from './components/GlobalTimetablesView';
import { RoomsOverviewView } from './components/RoomsOverviewView';
import { PointingSheetView } from './components/PointingSheetView';
import { SettingsView } from './components/SettingsView';
import { ServerPortalView } from './components/ServerPortalView';
import { RenameModal } from './components/RenameModal';
import { Toast } from './components/Toast';

const LOCAL_STORAGE_KEY = 'saadoun_rotating_paper_project_v1';

export function App({ hostSchool }: { hostSchool: HostSchool }) {
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('fetprint_dark_mode') === 'true';
  });

  const [appData, setRawAppData] = useState<AppData>(() => {
    // 1. Try restoring saved .fetpro project from localStorage first
    try {
      const cached = localStorage.getItem(LOCAL_STORAGE_KEY) || localStorage.getItem('fetprint_project_cache_v3');
      if (cached) {
        const parsed = JSON.parse(cached) as AppData;
        if (parsed && parsed.activities && parsed.groups && parsed.teachers) {
          buildSchedulesIndex(parsed);
          return applyHostSchool(parsed, hostSchool);
        }
      }
    } catch (e) {
      console.warn("Failed reading cached project from localStorage", e);
    }

    // 2. Default fallback initialization
    const data: AppData = {
      institution: "ثانوية المتنبي",
      days: ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس"],
      dayMapping: {},
      hours: [
        { id: "حصة 1", label: "الحصة 1", morningTime: "08:00 - 09:00", afternoonTime: "13:00 - 14:00" },
        { id: "حصة 2", label: "الحصة 2", morningTime: "09:00 - 10:00", afternoonTime: "14:00 - 15:00" },
        { id: "حصة 3", label: "الحصة 3", morningTime: "10:00 - 11:00", afternoonTime: "15:00 - 16:00" },
        { id: "حصة 4", label: "الحصة 4", morningTime: "11:00 - 12:00", afternoonTime: "16:00 - 17:00" }
      ],
      teachers: [],
      groups: [],
      rooms: [],
      subgroupMap: {},
      groupHomeRooms: {},
      subjectDefaultRooms: {},
      subjects: [],
      activities: {},
      groupSchedules: {},
      teacherSchedules: {},
      roomSchedules: {},
      settings: {
        republic: "الجمهورية الجزائرية الديمقراطية الشعبية",
        ministry: "وزارة التربية الوطنية",
        directorate: "مديرية التربية لولاية الجزائر",
        schoolName: "ثانوية المتنبي",
        docTitle: "جدول استعمال الزمن الأسبوعي الرسمي",
        pointingTitle: "ورقة الحضور اليومي وتأشيرة الأساتذة (الورقة الدوارة)",
        pointingAdminLabel: "مستشار(ة) التربية",
        pointingSupervisorLabel: "المشرف(ة) المكلف(ة) بالجناح",
        pointingOrientation: "landscape",
        pointingPageLayout: "1page",
        pointingShowSubjects: true,
        pointingShowTeachers: true,
        pointingShowRooms: true,
        pointingShowSignatures: true,
        pointingShowAbsenceLines: true,
        pointingDistribution: "صفحة واحدة كاملة (x1 A4 - تدرج تلقائي)",
        pointingGroupBy: "classes",
        pointingFontSize: "xs",
        gridOrientation: "days-cols",
        schoolYear: "2025 / 2026",
        introText: "يشرفني أن أضع بين أيديكم جدول التوقيت الأسبوعي متمنياً للجميع كل التوفيق والنجاح في أداء المهام التربوية والتعليمية.",
        showIntroClasses: true,
        showIntroTeachers: true,
        pageOrientation: "landscape",
        template: "1. الكلاسيكي الرسمي (كما هو)",
        theme: "classic-dz",
        headerFont: "'Cairo', sans-serif",
        inkSaver: false,
        printNUp: 1,
        colorizeSubjects: true,
        showTeachers: true,
        showRooms: true,
        showClasses: true,
        projectSlug: "",
        serverUrl: "https://fetprint.fetsync.org",
        footerNote: "ملاحظة: هذا التوقيت رسمي ويسري مفعوله ابتداءً من الدخول المدرسي.",
        directorLabel: "المديـــر(ة)",
        stampLabel: "حرر بـ: الجزائر في: .................",
        roomFont: "'Fira Code', monospace",
        darkMode: false,
        subjectColors: {}
      }
    };
    parseFetXml(INITIAL_FET_XML_DATA, data);
    return applyHostSchool(data, hostSchool);
  });

  const setAppData = (next: React.SetStateAction<AppData>) => {
    setRawAppData(previous => applyHostSchool(typeof next === 'function' ? next(previous) : next, hostSchool));
  };

  useEffect(() => {
    setRawAppData(previous => applyHostSchool(previous, hostSchool));
  }, [hostSchool.schoolName, hostSchool.academicYear, hostSchool.wilaya]);

  const [currentTab, setCurrentTab] = useState<string>('pointing');
  const [currentSelectedId, setCurrentSelectedId] = useState<string>(() => appData.groups[0] || '');
  const [isPreviewActive, setIsPreviewActive] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string>('مرحباً بك في الورقة الدوارة — منصة الحضور');
  const [isPrintAllEntities, setIsPrintAllEntities] = useState<boolean>(false);
  
  // Rename Modal state
  const [isRenameModalOpen, setIsRenameModalOpen] = useState<boolean>(false);
  const [renameTarget, setRenameTarget] = useState<{ type: 'classes' | 'teachers'; id: string } | undefined>(undefined);

  // Sync dark mode class with root html
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('fetprint_dark_mode', String(isDarkMode));
  }, [isDarkMode]);

  // Auto-save project state to localStorage on every change
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(appData));
    } catch (e) {
      console.warn("Storage quota exceeded or error caching project", e);
    }
  }, [appData]);

  // Toast timer
  useEffect(() => {
    if (!toastMessage) return;
    const timer = setTimeout(() => setToastMessage(''), 4000);
    return () => clearTimeout(timer);
  }, [toastMessage]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
  };

  const handleSwitchTab = (tab: string) => {
    setCurrentTab(tab);
    if (tab === 'classes' && appData.groups.length > 0) {
      if (!appData.groups.includes(currentSelectedId)) setCurrentSelectedId(appData.groups[0]);
    } else if (tab === 'teachers' && appData.teachers.length > 0) {
      if (!appData.teachers.includes(currentSelectedId)) setCurrentSelectedId(appData.teachers[0]);
    }
  };

  // Group / Class Renaming
  const handleRenameGroup = (oldName: string, newName: string) => {
    if (!oldName || !newName || oldName === newName) return;

    const copy: AppData = JSON.parse(JSON.stringify(appData));

    // 1. Update groups array
    const gIndex = copy.groups.indexOf(oldName);
    if (gIndex !== -1) {
      copy.groups[gIndex] = newName;
    }

    // 2. Update subgroupMap
    if (copy.subgroupMap[oldName]) {
      const subs = copy.subgroupMap[oldName].map(sub => {
        if (sub.startsWith(oldName)) {
          return sub.replace(oldName, newName);
        }
        return sub;
      });
      copy.subgroupMap[newName] = subs;
      delete copy.subgroupMap[oldName];
    }

    // 3. Update groupHomeRooms
    if (copy.groupHomeRooms[oldName]) {
      copy.groupHomeRooms[newName] = copy.groupHomeRooms[oldName];
      delete copy.groupHomeRooms[oldName];
    }

    // 4. Update activities
    Object.values(copy.activities).forEach(act => {
      if (act.students) {
        act.students = act.students.map(st => {
          if (st === oldName) return newName;
          if (st.startsWith(oldName)) return st.replace(oldName, newName);
          return st;
        });
      }
    });

    // 5. Rebuild schedules
    buildSchedulesIndex(copy);

    setAppData(copy);
    if (currentSelectedId === oldName) {
      setCurrentSelectedId(newName);
    }

    showToast(`تم تغيير اسم القسم بنجاح: "${oldName}" ⬅️ "${newName}"`);
  };

  // Teacher Renaming
  const handleRenameTeacher = (oldName: string, newName: string) => {
    if (!oldName || !newName || oldName === newName) return;

    const copy: AppData = JSON.parse(JSON.stringify(appData));

    // 1. Update teachers array
    const tIndex = copy.teachers.indexOf(oldName);
    if (tIndex !== -1) {
      copy.teachers[tIndex] = newName;
    }

    // 2. Update activities
    Object.values(copy.activities).forEach(act => {
      if (act.teachers) {
        act.teachers = act.teachers.map(t => (t === oldName ? newName : t));
      }
    });

    // 3. Rebuild schedules
    buildSchedulesIndex(copy);

    setAppData(copy);
    if (currentSelectedId === oldName) {
      setCurrentSelectedId(newName);
    }

    showToast(`تم تغيير اسم الأستاذ بنجاح: "${oldName}" ⬅️ "${newName}"`);
  };

  // Export Project as .fetpro
  const handleExportProject = () => {
    const jsonStr = JSON.stringify(appData, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const cleanSchool = (appData.institution || 'school').replace(/[\s\/\\]+/g, '_');
    const cleanYear = (appData.settings.schoolYear || '2025_2026').replace(/[\s\/\\]+/g, '_');
    a.download = `مشروع_توقيت_${cleanSchool}_${cleanYear}.fetpro`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast("💾 تم تصدير وحفظ ملف المشروع بنجاح بصيغة (.fetpro)!");
  };

  // Import Project from .fetpro or .json or .xml
  const handleImportProject = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (!content) return;

      // Detect if file is XML (.fet / .xml)
      if (content.trim().startsWith('<?xml') || content.trim().startsWith('<fet')) {
        const copy: AppData = JSON.parse(JSON.stringify(appData));
        const success = parseFetXml(content, copy);
        if (success) {
          setAppData(copy);
          if (copy.groups.length > 0) setCurrentSelectedId(copy.groups[0]);
          showToast(`تم استيراد ملف FET بنجاح (${Object.keys(copy.activities).length} نشاطاً)!`);
        } else {
          showToast("تعذر تحليل ملف XML، يرجى التأكد من صلاحية الملف");
        }
        return;
      }

      // JSON / .fetpro
      try {
        const data = JSON.parse(content) as AppData;
        if (data && data.activities && data.groups) {
          buildSchedulesIndex(data);
          setAppData(data);
          if (data.groups && data.groups.length > 0) {
            setCurrentSelectedId(data.groups[0]);
          }
          showToast(`تم فتح واسترجاع مشروع (${data.institution || 'المؤسسة'}) بصيغة .fetpro بنجاح!`);
        } else {
          showToast("صيغة ملف المشروع غير صحيحة");
        }
      } catch (err) {
        console.error("Project file parse error", err);
        showToast("خطأ أثناء قراءة ملف المشروع (.fetpro)");
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Direct FET XML file import
  const handleXmlUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const xmlText = event.target?.result as string;
      if (xmlText) {
        const copy: AppData = JSON.parse(JSON.stringify(appData));
        const success = parseFetXml(xmlText, copy);
        if (success) {
          setAppData(copy);
          if (copy.groups.length > 0) setCurrentSelectedId(copy.groups[0]);
          showToast(`تم استيراد ملف FET بنجاح (${Object.keys(copy.activities).length} نشاطاً لـ ${copy.groups.length} قسماً)!`);
        } else {
          showToast("تعذر تحليل ملف XML، يرجى التحقق من الصيغة");
        }
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleNavigate = (delta: number) => {
    const list = currentTab === 'classes' ? appData.groups : appData.teachers;
    if (!list || list.length === 0) return;
    let idx = list.indexOf(currentSelectedId);
    if (idx === -1) idx = 0;
    let nextIdx = (idx + delta + list.length) % list.length;
    setCurrentSelectedId(list[nextIdx]);
  };

  const handleQuickSearch = (query: string) => {
    const list = currentTab === 'classes' ? appData.groups : appData.teachers;
    const q = query.trim().toLowerCase();
    const found = list.find(item => item.toLowerCase().includes(q));
    if (found) setCurrentSelectedId(found);
  };

  const handleOrientationChange = (orientation: 'days-cols' | 'days-rows') => {
    setAppData({
      ...appData,
      settings: { ...appData.settings, gridOrientation: orientation }
    });
    showToast(orientation === 'days-cols' ? "تم التبديل إلى هيئة الأيام أفقياً" : "تم التبديل إلى هيئة الأيام رأسياً");
  };

  const handleVisibilityToggle = () => {
    const tCheck = (document.getElementById('showTeachersToggle') as HTMLInputElement)?.checked ?? appData.settings.showTeachers;
    const rCheck = (document.getElementById('showRoomsToggle') as HTMLInputElement)?.checked ?? appData.settings.showRooms;
    const cCheck = (document.getElementById('showClassesToggle') as HTMLInputElement)?.checked ?? appData.settings.showClasses;

    setAppData({
      ...appData,
      settings: {
        ...appData.settings,
        showTeachers: tCheck,
        showRooms: rCheck,
        showClasses: cCheck
      }
    });
  };

  const handleInkSaverToggle = (checked: boolean) => {
    setAppData({
      ...appData,
      settings: { ...appData.settings, inkSaver: checked }
    });
    if (checked) {
      document.body.classList.add('ink-saver-active');
    } else {
      document.body.classList.remove('ink-saver-active');
    }
    showToast(checked ? "تم تفعيل نمط توفير الحبر الاقتصادي" : "تم إلغاء نمط توفير الحبر");
  };

  const handlePrintNUpChange = (n: number) => {
    setAppData({
      ...appData,
      settings: { ...appData.settings, printNUp: n }
    });
  };

  const handleTemplateChange = (tpl: string) => {
    setAppData({
      ...appData,
      settings: { ...appData.settings, template: tpl }
    });
    showToast(`تم تطبيق القالب بنجاح`);
  };

  const handleOpenRenameModal = (type?: 'classes' | 'teachers', id?: string) => {
    if (type && id) {
      setRenameTarget({ type, id });
    } else if (type) {
      setRenameTarget({ type, id: '' });
    } else {
      setRenameTarget(undefined);
    }
    setIsRenameModalOpen(true);
  };

  const handlePrintCurrentEntity = () => {
    setIsPrintAllEntities(false);
    setTimeout(() => {
      window.print();
    }, 150);
  };

  const handlePrintAllEntities = () => {
    setIsPrintAllEntities(true);
    showToast(`جارٍ إعداد وثائق طباعة جميع ${currentTab === 'classes' ? 'الأقسام' : 'الأساتذة'}...`);
    setTimeout(() => {
      const cleanup = () => {
        setIsPrintAllEntities(false);
        window.removeEventListener('afterprint', cleanup);
      };
      window.addEventListener('afterprint', cleanup);
      window.print();
      setTimeout(() => setIsPrintAllEntities(false), 4000);
    }, 350);
  };

  return (
    <div className={`min-h-screen flex flex-col bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 selection:bg-emerald-200 transition-colors ${isPreviewActive ? 'sheet-preview-mode' : ''}`}>
      
      {/* Right Sidebar as seen in screenshot */}
      <Sidebar
        embedded
        appData={appData}
        currentTab={currentTab}
        onSwitchTab={handleSwitchTab}
        onXmlUpload={handleXmlUpload}
        onExportProject={handleExportProject}
        onImportProject={handleImportProject}
        isDarkMode={isDarkMode}
        onToggleDarkMode={() => setIsDarkMode(!isDarkMode)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-y-auto">
        
        {/* Toolbar for Classes and Teachers tabs */}
        {(currentTab === 'classes' || currentTab === 'teachers') && (
          <Toolbar
            currentTab={currentTab}
            appData={appData}
            currentSelectedId={currentSelectedId}
            onSelectChange={setCurrentSelectedId}
            onNavigate={handleNavigate}
            onQuickSearch={handleQuickSearch}
            onOrientationChange={handleOrientationChange}
            onVisibilityToggle={handleVisibilityToggle}
            onInkSaverToggle={handleInkSaverToggle}
            onPrintNUpChange={handlePrintNUpChange}
            onTemplateChange={handleTemplateChange}
            onPrintCurrent={handlePrintCurrentEntity}
            onPrintAll={handlePrintAllEntities}
            onTogglePreview={() => setIsPreviewActive(!isPreviewActive)}
            isPreviewActive={isPreviewActive}
            onOpenRenameModal={handleOpenRenameModal}
            onExportProject={handleExportProject}
          />
        )}

        <main className="flex-grow p-3 sm:p-5">
          {/* 1. Classes or Teachers view */}
          {(currentTab === 'classes' || currentTab === 'teachers') && (
            <ClassesTeachersView
              appData={appData}
              currentTab={currentTab}
              currentSelectedId={currentSelectedId}
              isPrintAll={isPrintAllEntities}
            />
          )}

          {/* 2. Global unified view */}
          {currentTab === 'global' && <GlobalTimetablesView appData={appData} />}

          {/* 3. Rooms overview */}
          {currentTab === 'rooms' && <RoomsOverviewView appData={appData} />}

          {/* 4. Pointing Sheet View matching screenshot */}
          {currentTab === 'pointing' && (
            <PointingSheetView
              appData={appData}
              onUpdateSettings={(newSettings) => setAppData({ ...appData, settings: newSettings })}
            />
          )}

          {/* 5. Server Digital Portal without print */}
          {currentTab === 'server' && (
            <ServerPortalView
              appData={appData}
              onSelectEntity={(type, id) => {
                setCurrentTab(type);
                setCurrentSelectedId(id);
              }}
            />
          )}

          {/* 6. Settings View */}
          {currentTab === 'settings' && (
            <SettingsView
              appData={appData}
              onUpdateSettings={(newSettings) => setAppData({ ...appData, settings: newSettings })}
              onExportProject={handleExportProject}
              onImportProject={handleImportProject}
              onOpenRenameModal={handleOpenRenameModal}
              onResetToDefault={() => {
                localStorage.removeItem(LOCAL_STORAGE_KEY);
                const copy: AppData = JSON.parse(JSON.stringify(appData));
                parseFetXml(INITIAL_FET_XML_DATA, copy);
                setAppData(copy);
                showToast("تمت استعادة إعدادات المصنع الافتراضية بنجاح");
              }}
            />
          )}
        </main>

      </div>

      {/* Direct Rename Modal */}
      <RenameModal
        isOpen={isRenameModalOpen}
        onClose={() => setIsRenameModalOpen(false)}
        appData={appData}
        onRenameGroup={handleRenameGroup}
        onRenameTeacher={handleRenameTeacher}
        initialTarget={renameTarget}
      />

      <Toast message={toastMessage} />
    </div>
  );
}

export default App;
