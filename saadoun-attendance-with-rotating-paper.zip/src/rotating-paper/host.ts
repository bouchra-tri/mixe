import { AppData } from './types';

export interface HostSchool {
  schoolName: string;
  academicYear: string;
  wilaya: string;
}

export function isHostSchool(value: unknown): value is HostSchool {
  if (!value || typeof value !== 'object') return false;
  const school = value as Record<string, unknown>;
  return ['schoolName', 'academicYear', 'wilaya'].every(key => typeof school[key] === 'string');
}

export function applyHostSchool(data: AppData, school: HostSchool): AppData {
  const directorate = `مديرية التربية لولاية ${school.wilaya}`;
  if (data.institution === school.schoolName && data.settings.schoolName === school.schoolName &&
      data.settings.schoolYear === school.academicYear && data.settings.directorate === directorate) return data;
  return {
    ...data,
    institution: school.schoolName,
    settings: { ...data.settings, schoolName: school.schoolName, schoolYear: school.academicYear, directorate },
  };
}
