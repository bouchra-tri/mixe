import React, { useEffect, useRef } from 'react';
import QRCode from 'qrcode';
import { AppData } from '../types';
import { TimetableGrid } from './TimetableGrid';

interface SingleTimetableSheetProps {
  itemId: string;
  appData: AppData;
  currentTab: 'classes' | 'teachers';
  templateClass: string;
  isInk: boolean;
}

const SingleTimetableSheet: React.FC<SingleTimetableSheetProps> = ({
  itemId,
  appData,
  currentTab,
  templateClass,
  isInk
}) => {
  const qrRef = useRef<HTMLCanvasElement>(null);
  const { settings } = appData;

  const scheduleMap = currentTab === 'classes'
    ? (appData.groupSchedules[itemId] || {})
    : (appData.teacherSchedules[itemId] || {});

  useEffect(() => {
    if (qrRef.current) {
      QRCode.toCanvas(
        qrRef.current,
        `https://fetprint.fetsync.org/verify?type=${currentTab}&id=${encodeURIComponent(itemId)}&school=${encodeURIComponent(appData.institution)}`,
        { width: 68, margin: 1, color: { dark: '#000000', light: '#ffffff' } },
        (error) => {
          if (error) console.error(error);
        }
      );
    }
  }, [currentTab, itemId, appData.institution]);

  return (
    <div className={`a4-sheet-canvas bg-white rounded-xl shadow-xl p-6 sm:p-8 border border-slate-200 transition-all mb-8 page-break-after ${templateClass} ${isInk ? 'ink-saver-active' : ''}`}>
      {/* Header Block */}
      <div className="timetable-header-block flex items-center justify-between border-b-2 border-emerald-900 pb-4 mb-4 gap-4">
        <div className="text-right text-[11px] sm:text-xs font-bold leading-relaxed text-slate-800">
          <div>{settings.republic}</div>
          <div>{settings.ministry}</div>
          <div className="text-emerald-800 font-extrabold">{settings.directorate}</div>
          <div className="text-slate-900 font-black">{settings.schoolName}</div>
        </div>

        <div className="text-center">
          <div className="header-doc-title inline-block bg-emerald-900 text-white font-black px-5 py-2 rounded-xl text-sm sm:text-base shadow-md border border-emerald-700">
            {settings.docTitle}
          </div>
          <div className="mt-1 text-xs font-black text-slate-800">
            {currentTab === 'classes' ? 'القسم: ' : 'الأستاذ(ة): '}
            <span className="text-emerald-700 font-extrabold text-sm underline">{itemId}</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-left text-[11px] font-bold text-slate-700">
            <div>السنة الدراسية: <span className="font-mono font-black">{settings.schoolYear}</span></div>
            <div className="mt-1 flex items-center gap-1 justify-end">
              <span>الرمز:</span>
              <canvas ref={qrRef} className="rounded border border-slate-300 shadow-xs" />
            </div>
          </div>
        </div>
      </div>

      {/* Intro Text */}
      {settings.introText && (
        <div className="bg-emerald-50/80 border-r-4 border-emerald-600 p-2.5 rounded-l-lg mb-4 text-xs font-bold text-slate-800 shadow-xs">
          {settings.introText}
        </div>
      )}

      {/* Timetable Grid */}
      <div className="overflow-x-auto custom-scrollbar mb-6">
        <TimetableGrid scheduleMap={scheduleMap} appData={appData} mode={currentTab} />
      </div>

      {/* Footer Note & Signatures */}
      <div className="mt-6 pt-4 border-t border-slate-300 flex items-end justify-between text-xs font-bold text-slate-800">
        <div className="max-w-md">
          <p className="text-slate-600 italic">{settings.footerNote}</p>
          <p className="mt-1 font-mono text-[10px] text-slate-500">{settings.stampLabel}</p>
        </div>

        <div className="text-center min-w-[180px]">
          <div className="font-black text-emerald-900 mb-8">{settings.directorLabel}</div>
          <div className="border-t border-dashed border-slate-400 pt-1 text-[11px] text-slate-500">التوقيع والختم</div>
        </div>
      </div>
    </div>
  );
};

interface ClassesTeachersViewProps {
  appData: AppData;
  currentTab: 'classes' | 'teachers';
  currentSelectedId: string;
  isPrintAll?: boolean;
}

export const ClassesTeachersView: React.FC<ClassesTeachersViewProps> = ({
  appData,
  currentTab,
  currentSelectedId,
  isPrintAll = false
}) => {
  const { settings } = appData;
  const templateClass = `tpl-${settings.template || 'classic-dz'} theme-${settings.theme || 'classic-dz'}`;
  const isInk = settings.inkSaver || false;
  const allItems = currentTab === 'classes' ? appData.groups : appData.teachers;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {isPrintAll ? (
        <div className="space-y-6">
          <div className="no-print text-center mb-4">
            <span className="inline-flex items-center gap-2 bg-emerald-100 text-emerald-900 text-xs font-black px-4 py-1.5 rounded-full border border-emerald-300 shadow-sm animate-pulse">
              <span>🖨️</span>
              <span>جارٍ تجهيز طباعة الكل: {allItems.length} {currentTab === 'classes' ? 'قسماً' : 'أستاذاً'}...</span>
            </span>
          </div>
          {allItems.map((item) => (
            <SingleTimetableSheet
              key={item}
              itemId={item}
              appData={appData}
              currentTab={currentTab}
              templateClass={templateClass}
              isInk={isInk}
            />
          ))}
        </div>
      ) : (
        <SingleTimetableSheet
          itemId={currentSelectedId}
          appData={appData}
          currentTab={currentTab}
          templateClass={templateClass}
          isInk={isInk}
        />
      )}
    </div>
  );
};
