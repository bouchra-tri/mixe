import React from 'react';
import {
  GraduationCap,
  Users,
  BarChart3,
  Building2,
  FileText,
  Settings as SettingsIcon,
  Moon,
  Sun,
  FolderOpen,
  Save,
  Upload,
  Globe
} from 'lucide-react';
import { AppData } from '../types';

interface SidebarProps {
  embedded?: boolean;
  appData: AppData;
  currentTab: string;
  onSwitchTab: (tab: string) => void;
  onXmlUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onExportProject: () => void;
  onImportProject: (e: React.ChangeEvent<HTMLInputElement>) => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  embedded = false,
  appData,
  currentTab,
  onSwitchTab,
  onXmlUpload,
  onExportProject,
  onImportProject,
  isDarkMode,
  onToggleDarkMode
}) => {
  const navItems = [
    { id: 'classes', label: 'الأقسام والأفواج', icon: GraduationCap },
    { id: 'teachers', label: 'جداول الأساتذة', icon: Users },
    { id: 'global', label: 'الجداول العامة المجمعة', icon: BarChart3 },
    { id: 'rooms', label: 'شغل الحجرات والقاعات', icon: Building2 },
    { id: 'pointing', label: 'الورقة الدوارة (الحضور)', icon: FileText },
    { id: 'server', label: 'سيرفر المؤسسة الرقمي', icon: Globe },
    { id: 'settings', label: 'الإعدادات والمزامنة', icon: SettingsIcon },
  ];

  if (embedded) return (
    <aside className="no-print border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3 space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="font-bold text-sm">{appData.institution} · الورقة الدوارة</h2>
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <label className="cursor-pointer rounded-lg border border-slate-300 px-3 py-2 font-bold">استيراد ملف FET
            <input aria-label="استيراد ملف FET" type="file" accept=".xml,.fet" className="hidden" onChange={onXmlUpload} />
          </label>
          <button className="rounded-lg border border-slate-300 px-3 py-2" onClick={onExportProject}>حفظ كملف</button>
          <label className="cursor-pointer rounded-lg border border-slate-300 px-3 py-2">فتح ملف
            <input aria-label="فتح مشروع الورقة الدوارة" type="file" accept=".fetpro,.json" className="hidden" onChange={onImportProject} />
          </label>
          <button aria-label="تبديل المظهر" className="rounded-lg border border-slate-300 p-2" onClick={onToggleDarkMode}>
            {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </div>
      <nav aria-label="أقسام الورقة الدوارة" className="flex flex-wrap gap-1.5">
        {navItems.map(item => {
          const Icon = item.icon;
          return <button key={item.id} onClick={() => onSwitchTab(item.id)} aria-current={currentTab === item.id ? 'page' : undefined}
            className={`flex items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-bold ${currentTab === item.id ? 'bg-emerald-700 text-white' : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200'}`}>
            <Icon className="w-4 h-4" />{item.label}
          </button>;
        })}
      </nav>
    </aside>
  );

  return (
    <aside className="no-print w-full lg:w-72 flex-shrink-0 bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 p-4 flex flex-col justify-between transition-colors shadow-xs">
      
      <div className="space-y-5">
        
        {/* Top Header Card */}
        <div className="flex items-start gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="w-12 h-12 rounded-2xl bg-emerald-700 text-white flex items-center justify-center text-2xl shadow-md shadow-emerald-950/20 flex-shrink-0 relative overflow-hidden border border-emerald-500/30">
            <span className="relative z-10">🏫</span>
            <div className="absolute inset-0 bg-gradient-to-t from-emerald-950 to-transparent opacity-40"></div>
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5 flex-wrap">
              <h2 className="text-sm font-black text-slate-900 dark:text-white leading-tight truncate">
                منظومة جداول التوقيت
              </h2>
            </div>
            
            <div className="inline-block mt-0.5">
              <span className="bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-[10px] font-black px-2 py-0.5 rounded-full border border-emerald-300 dark:border-emerald-700">
                Universal Ultimate
              </span>
            </div>

            <div className="mt-2 text-xs font-bold text-slate-700 dark:text-slate-300 space-y-0.5">
              <div className="truncate">
                المؤسسة: <span className="text-emerald-700 dark:text-emerald-400 font-extrabold">{appData.institution}</span>
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                السنة الدراسية: <span className="text-slate-800 dark:text-slate-200 font-bold">{appData.settings.schoolYear}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Controls: Language & Dark Mode */}
        <div className="grid grid-cols-2 gap-2 text-xs font-bold">
          <div className="flex items-center justify-center bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-1.5 text-slate-700 dark:text-slate-200 cursor-pointer">
            <span className="truncate">SA العربية ▾</span>
          </div>

          <button
            onClick={onToggleDarkMode}
            className="flex items-center justify-center gap-1.5 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-1.5 text-slate-700 dark:text-slate-200 transition"
            title="تبديل الوضع الليلي / النهاري"
          >
            {isDarkMode ? <Sun className="w-3.5 h-3.5 text-amber-400" /> : <Moon className="w-3.5 h-3.5 text-slate-600" />}
            <span className="text-[11px]">الوضع الليلي</span>
          </button>
        </div>

        {/* Nav Links */}
        <nav className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => onSwitchTab(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-extrabold transition group ${
                  isActive
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950/20'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center gap-2.5 truncate">
                  <Icon className={`w-4 h-4 flex-shrink-0 ${isActive ? 'text-white' : 'text-emerald-700 dark:text-emerald-400'}`} />
                  <span className="truncate">{item.label}</span>
                </div>

                {isActive && (
                  <span className="w-1.5 h-1.5 rounded-full bg-white"></span>
                )}
              </button>
            );
          })}
        </nav>

      </div>

      {/* Quick Actions at Bottom */}
      <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2.5">
        <div className="text-[11px] font-black text-slate-400 dark:text-slate-500">
          إجراءات سريعة:
        </div>

        {/* Import FET XML Button */}
        <label className="cursor-pointer w-full flex items-center justify-center gap-2 bg-slate-50 dark:bg-slate-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 text-slate-800 dark:text-slate-200 hover:text-emerald-800 dark:hover:text-emerald-300 border border-slate-300 dark:border-slate-700 hover:border-emerald-400 p-2.5 rounded-xl text-xs font-black transition shadow-xs">
          <Upload className="w-4 h-4 text-emerald-600" />
          <span>استيراد ملف FET</span>
          <input type="file" accept=".xml,.fet" className="hidden" onChange={onXmlUpload} />
        </label>

        {/* Save & Open .fetpro buttons */}
        <div className="grid grid-cols-2 gap-2 text-xs font-bold">
          <button
            onClick={onExportProject}
            className="flex items-center justify-center gap-1.5 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-700 p-2 rounded-xl transition"
            title="حفظ المشروع كاملاً في ملف .fetpro"
          >
            <Save className="w-3.5 h-3.5 text-emerald-600" />
            <span>حفظ كملف</span>
          </button>

          <label
            className="cursor-pointer flex items-center justify-center gap-1.5 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-700 p-2 rounded-xl transition"
            title="فتح ملف مشروع .fetpro"
          >
            <FolderOpen className="w-3.5 h-3.5 text-emerald-600" />
            <span>فتح ملف</span>
            <input type="file" accept=".fetpro,.json" className="hidden" onChange={onImportProject} />
          </label>
        </div>
      </div>

    </aside>
  );
};
