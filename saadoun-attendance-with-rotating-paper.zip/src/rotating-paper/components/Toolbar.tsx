import React from 'react';
import { Search, ChevronRight, ChevronLeft, Printer, Edit3, Save } from 'lucide-react';
import { AppData } from '../types';

interface ToolbarProps {
  currentTab: string;
  appData: AppData;
  currentSelectedId: string;
  onSelectChange: (id: string) => void;
  onNavigate: (delta: number) => void;
  onQuickSearch: (q: string) => void;
  onOrientationChange: (orientation: 'days-cols' | 'days-rows') => void;
  onVisibilityToggle: () => void;
  onInkSaverToggle: (checked: boolean) => void;
  onPrintNUpChange: (n: number) => void;
  onTemplateChange: (tpl: string) => void;
  onPrintCurrent: () => void;
  onPrintAll: () => void;
  onTogglePreview: () => void;
  isPreviewActive: boolean;
  onOpenRenameModal: (type?: 'classes' | 'teachers', id?: string) => void;
  onExportProject: () => void;
}

export const Toolbar: React.FC<ToolbarProps> = ({
  currentTab,
  appData,
  currentSelectedId,
  onSelectChange,
  onNavigate,
  onQuickSearch,
  onOrientationChange,
  onVisibilityToggle,
  onInkSaverToggle,
  onPrintNUpChange,
  onTemplateChange,
  onPrintCurrent,
  onPrintAll,
  onTogglePreview,
  isPreviewActive,
  onOpenRenameModal,
  onExportProject
}) => {
  if (
    currentTab === 'global' ||
    currentTab === 'rooms' ||
    currentTab === 'pointing' ||
    currentTab === 'settings' ||
    currentTab === 'server'
  ) {
    return null;
  }

  const list = currentTab === 'classes' ? appData.groups : appData.teachers;

  return (
    <div id="toolbarSelectionRow" className="no-print max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between flex-wrap gap-3 text-xs">
      
      <div className="flex items-center space-x-reverse space-x-2 flex-wrap">
        <span className="font-bold text-slate-300 text-xs flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
          {currentTab === 'classes' ? 'اختر القسم:' : 'اختر الأستاذ(ة):'}
        </span>
        
        <div className="flex items-center bg-slate-800 rounded-lg p-0.5 border border-slate-700 shadow-sm">
          <button onClick={() => onNavigate(-1)} className="text-slate-300 hover:text-white hover:bg-slate-700 p-1.5 rounded-md transition" title="السابق">
            <ChevronRight className="w-4 h-4" />
          </button>
          
          <select
            value={currentSelectedId}
            onChange={(e) => onSelectChange(e.target.value)}
            className="bg-slate-800 text-white text-xs font-bold py-1.5 px-2 focus:outline-none min-w-[150px] max-w-[220px] cursor-pointer appearance-none text-center"
          >
            {list.map(item => (
              <option key={item} value={item}>{item}</option>
            ))}
          </select>

          <button onClick={() => onNavigate(1)} className="text-slate-300 hover:text-white hover:bg-slate-700 p-1.5 rounded-md transition" title="التالي">
            <ChevronLeft className="w-4 h-4" />
          </button>

          {/* Quick single-item rename button */}
          <button
            onClick={() => onOpenRenameModal(currentTab as 'classes' | 'teachers', currentSelectedId)}
            className="text-emerald-400 hover:text-emerald-300 hover:bg-slate-700 p-1.5 rounded-md transition border-r border-slate-700"
            title={`تعديل اسم ${currentTab === 'classes' ? 'هذا القسم' : 'هذا الأستاذ'} قبل الطبع`}
          >
            <Edit3 className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Global rename manager button */}
        <button
          onClick={() => onOpenRenameModal(currentTab as 'classes' | 'teachers')}
          className="bg-slate-800 hover:bg-slate-700 text-emerald-400 hover:text-white border border-emerald-500/40 px-2.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 shadow-sm"
          title="تعديل أسماء الأقسام والأساتذة دفعة واحدة قبل الطبع"
        >
          <Edit3 className="w-3.5 h-3.5" />
          <span>تعديل الأسماء</span>
        </button>

        <div className="flex items-center gap-1.5 bg-slate-800 px-2.5 py-1.5 rounded-lg border border-emerald-500/40 shadow-sm" title="تحديد شكل وهيئة عرض الجدول">
          <span className="text-emerald-400 font-extrabold flex items-center gap-1">
            <span>📐 الهيئة:</span>
          </span>
          <select
            value={appData.settings.gridOrientation}
            onChange={(e) => onOrientationChange(e.target.value as 'days-cols' | 'days-rows')}
            className="bg-slate-900 text-white text-xs font-bold p-1 rounded border border-slate-700 outline-none cursor-pointer"
          >
            <option value="days-cols">الأيام أفقياً (في الأعمدة)</option>
            <option value="days-rows">الأيام رأسياً (في الأسطر)</option>
          </select>
        </div>

        <div className="relative">
          <input
            type="text"
            onChange={(e) => onQuickSearch(e.target.value)}
            placeholder="بحث سريع..."
            className="bg-slate-800 border border-slate-700 text-white placeholder-slate-400 text-xs rounded-lg py-1.5 pr-2.5 pl-7 w-28 focus:w-44 transition-all focus:ring-1 focus:ring-emerald-500 focus:outline-none shadow-sm"
          />
          <Search className="absolute left-2.5 top-2 w-3.5 h-3.5 text-slate-400" />
        </div>
      </div>

      <div className="flex items-center space-x-reverse space-x-3 flex-wrap">
        
        <div className="flex items-center space-x-reverse space-x-2 bg-slate-800/80 p-1.5 rounded-lg border border-slate-700 shadow-inner">
          <label className="inline-flex items-center gap-1.5 cursor-pointer hover:bg-slate-700 px-2 py-0.5 rounded text-[11px] text-slate-200 transition">
            <input
              type="checkbox"
              checked={appData.settings.showTeachers}
              onChange={onVisibilityToggle}
              id="showTeachersToggle"
              className="w-3.5 h-3.5 text-emerald-600 rounded bg-slate-900 border-slate-600 focus:ring-emerald-500"
            />
            <span>👨🏫 الأستاذ</span>
          </label>
          <label className="inline-flex items-center gap-1.5 cursor-pointer hover:bg-slate-700 px-2 py-0.5 rounded text-[11px] text-slate-200 transition">
            <input
              type="checkbox"
              checked={appData.settings.showRooms}
              onChange={onVisibilityToggle}
              id="showRoomsToggle"
              className="w-3.5 h-3.5 text-emerald-600 rounded bg-slate-900 border-slate-600 focus:ring-emerald-500"
            />
            <span>🏛️ القاعة</span>
          </label>
          <label className="inline-flex items-center gap-1.5 cursor-pointer hover:bg-slate-700 px-2 py-0.5 rounded text-[11px] text-slate-200 transition">
            <input
              type="checkbox"
              checked={appData.settings.showClasses}
              onChange={onVisibilityToggle}
              id="showClassesToggle"
              className="w-3.5 h-3.5 text-emerald-600 rounded bg-slate-900 border-slate-600 focus:ring-emerald-500"
            />
            <span>👥 الفوج</span>
          </label>
        </div>

        <div className="h-6 w-px bg-slate-700"></div>

        <div className="flex items-center space-x-reverse space-x-2">
          <label className="inline-flex items-center gap-1.5 cursor-pointer bg-amber-950/40 hover:bg-amber-900/60 border border-amber-600/50 px-2.5 py-1.5 rounded-lg text-xs font-bold text-amber-300 transition" title="طباعة اقتصادية بدون خلفيات ملونة">
            <input
              type="checkbox"
              checked={appData.settings.inkSaver}
              onChange={(e) => onInkSaverToggle(e.target.checked)}
              className="w-3.5 h-3.5 text-amber-500 bg-slate-800 border-amber-500 rounded focus:ring-amber-400"
            />
            <span>🖨️ توفير الحبر</span>
          </label>

          <div className="flex items-center gap-1 bg-slate-800 px-2 py-1 rounded-lg border border-slate-700 shadow-sm" title="عدد الجداول في صفحة A4 واحدة">
            <span className="text-[11px] text-slate-400 font-bold">توزيع A4:</span>
            <select
              value={appData.settings.printNUp}
              onChange={(e) => onPrintNUpChange(parseInt(e.target.value, 10))}
              className="bg-transparent text-emerald-400 text-xs font-extrabold focus:outline-none cursor-pointer"
            >
              <option value="1">1 (ورقة كاملة)</option>
              <option value="2">2 (نصفين)</option>
              <option value="3">3 (أثلاث)</option>
              <option value="4">4 (أرباع 2x2)</option>
            </select>
          </div>

          <div className="flex items-center gap-1 bg-slate-800 px-2 py-1 rounded-lg border border-slate-700 shadow-sm" title="اختر قالب تصميم الجدول">
            <span className="text-[11px] text-slate-400 font-bold">القالب:</span>
            <select
              value={appData.settings.template}
              onChange={(e) => onTemplateChange(e.target.value)}
              className="bg-transparent text-emerald-400 text-xs font-bold focus:outline-none cursor-pointer max-w-[140px]"
            >
              <option value="classic-dz">1. الرسمي الكلاسيكي</option>
              <option value="modern-card">2. العصري النيومورفي</option>
              <option value="royal-academic">3. الأكاديمي الملكي</option>
              <option value="minimal-grid">4. المينيمالي الأحادي</option>
              <option value="tech-blueprint">5. التقني الهندسي</option>
              <option value="weekly-journal">6. المفكرة المدرسية</option>
              <option value="ribbon-edge">7. الشريطي الحديث</option>
              <option value="corporate-flat">8. المؤسساتي المنبسط</option>
              <option value="vintage-parchment">9. الورقي العتيق</option>
              <option value="ultra-compact">10. المضغوط الفائق</option>
            </select>
          </div>

          <div className="flex items-center space-x-reverse space-x-1.5 ml-1">
            <button onClick={onPrintCurrent} className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-3 py-1.5 rounded-lg shadow-md transition flex items-center gap-1.5">
              <Printer className="w-3.5 h-3.5" />
              <span>طباعة الحالية</span>
            </button>

            <button onClick={onPrintAll} className="bg-white text-slate-900 hover:bg-slate-200 font-bold text-xs px-3 py-1.5 rounded-lg shadow-md transition flex items-center gap-1.5 border border-slate-300" title="طباعة جميع عناصر هذا القسم دفعة واحدة">
              <span className="text-emerald-600 font-black">📑</span>
              <span>طباعة الكل</span>
            </button>

            <button
              onClick={onTogglePreview}
              className={`p-1.5 rounded-lg border border-slate-700 transition shadow-sm ${isPreviewActive ? 'bg-emerald-600 text-white' : 'bg-slate-800 hover:bg-slate-700 text-slate-300'}`}
              title="معاينة شكل ورقة A4 قبل الطباعة"
            >
              📄
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
