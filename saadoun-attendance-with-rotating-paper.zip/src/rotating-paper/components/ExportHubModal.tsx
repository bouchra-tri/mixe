import React, { useState } from 'react';
import { X, FileText, Download, CheckCircle, Lightbulb, Loader2, Printer } from 'lucide-react';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import { AppData, SlotItem } from '../types';

interface ExportHubModalProps {
  isOpen: boolean;
  onClose: () => void;
  appData: AppData;
  activePeriodKey: string;
  allPeriods: Array<{
    key: string;
    day: string;
    period: string;
    time: string;
    label: string;
  }>;
  showSubject: boolean;
  showTeacher: boolean;
  showRoom: boolean;
  showVisaSquare: boolean;
  showAbsenceLines: boolean;
  distribution?: string;
  template?: string;
  paperOrientation?: 'landscape' | 'portrait';
  chunkedGroups?: string[][];
  onTriggerPrint?: (scope: 'current' | 'all') => void;
}

export const ExportHubModal: React.FC<ExportHubModalProps> = ({
  isOpen,
  onClose,
  appData,
  activePeriodKey,
  allPeriods,
  showSubject,
  showTeacher,
  showRoom,
  showVisaSquare,
  showAbsenceLines,
  distribution = 'صفحة واحدة كاملة (x1 A4 - تدرج تلقائي)',
  paperOrientation = 'landscape',
  chunkedGroups,
  onTriggerPrint
}) => {
  const [exportScope, setExportScope] = useState<'current' | 'all'>('current');
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);
  const [pdfProgressText, setPdfProgressText] = useState('');

  if (!isOpen) return null;

  const currentPeriodObj = allPeriods.find(p => p.key === activePeriodKey) || allPeriods[0];
  const targetPeriods = exportScope === 'current' ? [currentPeriodObj] : allPeriods;

  // Determine groups chunking (distribution across pages)
  const getChunks = (): string[][] => {
    if (chunkedGroups && chunkedGroups.length > 0) return chunkedGroups;
    const groups = appData.groups;
    if (!groups || groups.length === 0) return [[]];

    let pagesCount = 1;
    if (distribution.includes('صفحتين')) pagesCount = 2;
    else if (distribution.includes('ثلاث صفحات')) pagesCount = 3;
    else if (distribution.includes('أربع صفحات')) pagesCount = 4;

    const chunkSize = Math.ceil(groups.length / pagesCount);
    const result: string[][] = [];
    for (let i = 0; i < groups.length; i += chunkSize) {
      result.push(groups.slice(i, i + chunkSize));
    }
    return result.length > 0 ? result : [groups];
  };

  const chunks = getChunks();

  // High-fidelity HTML table generator for PDF, Word (.doc) and Excel (.xls)
  const generatePageHtml = (
    pObj: typeof currentPeriodObj,
    groupChunk: string[],
    startIndex: number,
    pageNum: number,
    totalPages: number,
    format: 'word' | 'excel' | 'pdf'
  ) => {
    const hours = appData.hours;
    const { settings } = appData;
    const isPortrait = paperOrientation === 'portrait';
    const containerStyle = format === 'pdf'
      ? `direction: rtl; font-family: 'Cairo', Arial, sans-serif; background-color: #ffffff; padding: 7mm; box-sizing: border-box; width: ${isPortrait ? '780px' : '1100px'}; min-height: ${isPortrait ? '1100px' : '770px'}; border: 2pt double #064e3b; border-radius: 4px;`
      : `direction: rtl; font-family: 'Cairo', Arial, sans-serif; background-color: #ffffff; padding: 10pt; margin-bottom: 20pt; border: 2pt double #064e3b; border-radius: 4pt;`;

    return `
      <!-- START PAGE ${pageNum} / ${totalPages} (${pObj.key}) -->
      <div class="document-page" style="${containerStyle}">
        
        <!-- Document Official Header -->
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 8pt; border: none;" border="0">
          <tr>
            <!-- Top Right: Republic & Directorate -->
            <td style="width: 32%; text-align: right; vertical-align: top; border: none; font-size: 10pt; line-height: 1.35; padding: 0;">
              <div style="font-weight: bold; color: #0f172a;">${settings.republic}</div>
              <div style="font-weight: bold; color: #064e3b; margin-top: 3pt;">🏛️ ${settings.directorate}</div>
            </td>

            <!-- Top Center: School Name & Main Emerald Banner -->
            <td style="width: 36%; text-align: center; vertical-align: middle; border: none; padding: 0;">
              <div style="font-weight: 900; font-size: 14pt; color: #0f172a; margin-bottom: 3pt;">
                🏫 ${settings.schoolName}
              </div>
              <div style="background-color: #064e3b; color: #ffffff; padding: 5pt 16pt; border-radius: 16pt; font-weight: bold; font-size: 11pt; display: inline-block; border: 1pt solid #047857;">
                📋 ورقة الحضور اليومي وتأشيرة الأساتذة (الورقة الدوارة) ${totalPages > 1 ? `(ورقة ${pageNum} من ${totalPages})` : '(ورقة كاملة (مجمعة))'}
              </div>
              <div style="margin-top: 3pt;">
                <span style="background-color: #047857; color: #ffffff; font-weight: bold; font-size: 9.5pt; padding: 2pt 12pt; border-radius: 12pt; display: inline-block;">
                  يوم: <u>${pObj.day}</u> بتاريخ: ..... / ..... / 202.. م — ${pObj.label} (${pObj.time})
                </span>
              </div>
            </td>

            <!-- Top Left: Ministry & Academic Year -->
            <td style="width: 32%; text-align: left; vertical-align: top; border: none; font-size: 10pt; line-height: 1.35; padding: 0;">
              <div style="font-weight: bold; color: #0f172a;">${settings.ministry}</div>
              <div style="font-size: 9.5pt; font-family: monospace; color: #334155; margin-top: 3pt;">📅 السنة الدراسية: ${settings.schoolYear}</div>
            </td>
          </tr>
        </table>

        <!-- Main Timetable Table -->
        <table style="width: 100%; border-collapse: collapse; border: 1.5pt solid #064e3b; font-size: 9.5pt; table-layout: fixed;" border="1" cellpadding="4" cellspacing="0">
          <thead>
            <tr style="background-color: #064e3b; color: #ffffff; text-align: center; font-weight: bold;">
              <th style="padding: 6pt 3pt; width: 30pt; border: 1pt solid #064e3b; background-color: #064e3b; color: #ffffff; text-align: center;">N°</th>
              <th style="padding: 6pt 4pt; width: 100pt; border: 1pt solid #064e3b; background-color: #064e3b; color: #ffffff; text-align: center;">
                <div>القسم / الفوج</div>
                <div style="font-size: 7.5pt; font-weight: normal; color: #d1fae5;">(غيابات سابقة)</div>
              </th>

              ${hours.map(h => `
                <th style="padding: 5pt 3pt; border: 1pt solid #064e3b; background-color: #064e3b; color: #ffffff; text-align: center;">
                  <div style="font-weight: bold; color: #a7f3d0; font-size: 10pt;">${h.label}</div>
                  <div style="font-size: 8pt; direction: ltr; font-family: monospace; color: #ffffff;">
                    ${pObj.period === 'ص' ? h.morningTime : h.afternoonTime}
                  </div>
                </th>
              `).join('')}

              <th style="padding: 6pt 4pt; width: 85pt; border: 1pt solid #064e3b; background-color: #064e3b; color: #ffffff; text-align: center; font-size: 9pt;">
                <div>التحرير الإداري</div>
                <div>والملاحظات</div>
              </th>
            </tr>
          </thead>
          <tbody>
            ${groupChunk.map((grp, localIdx) => {
              const globalIndex = startIndex + localIdx + 1;
              const gSched = appData.groupSchedules[grp] || {};

              return `
                <tr style="border-bottom: 1pt solid #cbd5e1;">
                  <!-- Index Column -->
                  <td style="padding: 4pt; text-align: center; font-weight: bold; background-color: #f8fafc; border: 1pt solid #cbd5e1; font-family: monospace; color: #0f172a;">
                    ${globalIndex}
                  </td>

                  <!-- Group / Class Column -->
                  <td style="padding: 4pt; text-align: center; background-color: #f1f5f9; border: 1pt solid #cbd5e1; vertical-align: middle;">
                    <div style="font-size: 10.5pt; font-weight: 900; color: #0f172a;">${grp}</div>
                    <div style="font-size: 8pt; color: #64748b; font-family: monospace; margin-top: 2pt; border-top: 1px dashed #cbd5e1; padding-top: 2pt;">
                      غ.س: ........
                    </div>
                  </td>

                  <!-- Hour Slots -->
                  ${hours.map(h => {
                    const slotKey = `${pObj.day} ${pObj.period}___${h.id}`;
                    const items: SlotItem[] = gSched[slotKey] || [];

                    return `
                      <td style="padding: 4pt; border: 1pt solid #cbd5e1; vertical-align: top; text-align: right; background-color: #ffffff;">
                        ${showAbsenceLines ? `
                          <table style="width: 100%; border: none; border-collapse: collapse; margin-bottom: 2pt;" border="0">
                            <tr>
                              <td style="border: none; padding: 0; text-align: right; font-weight: 900; color: #dc2626; font-size: 8pt; width: 35pt;">الغياب:</td>
                              <td style="border: none; padding: 0; text-align: left; color: #94a3b8; font-family: monospace; font-size: 8pt;">..........</td>
                            </tr>
                          </table>
                        ` : ''}

                        ${items.length === 0 ? `
                          <div style="text-align: center; color: #94a3b8; font-style: italic; padding: 6pt 0; font-size: 9pt;">
                            فراغ
                          </div>
                        ` : `
                          ${items.map(it => `
                            <div style="background-color: #f0fdf4; border: 1pt solid #86efac; border-radius: 4pt; padding: 3pt 4pt; margin-bottom: 2pt;">
                              <table style="width: 100%; border: none; border-collapse: collapse;" border="0">
                                <tr>
                                  <td style="border: none; padding: 0; vertical-align: top; text-align: right;">
                                    ${showSubject ? `
                                      <div style="font-weight: 900; color: #064e3b; font-size: 9.5pt; line-height: 1.2;">
                                        ${it.subject} ${it.subgroup ? '(' + it.subgroup + ')' : ''}
                                      </div>
                                    ` : ''}

                                    ${showTeacher && it.teachers && it.teachers.length > 0 ? `
                                      <div style="font-size: 8.5pt; color: #334155; font-weight: bold; margin-top: 1pt;">
                                        (${it.teachers.join(' - ')})
                                      </div>
                                    ` : ''}

                                    ${showRoom && it.room ? `
                                      <div style="font-size: 7.5pt; color: #475569; font-family: monospace; font-weight: bold; margin-top: 1pt;">
                                        [${it.room}]
                                      </div>
                                    ` : ''}
                                  </td>

                                  ${showVisaSquare ? `
                                    <td style="border: none; padding: 0 0 0 3pt; width: 18pt; vertical-align: top; text-align: left;">
                                      <div style="width: 16pt; height: 16pt; border: 1pt solid #94a3b8; background-color: #ffffff; text-align: center; line-height: 16pt; font-size: 8.5pt; border-radius: 2pt;">
                                        ✍️
                                      </div>
                                    </td>
                                  ` : ''}
                                </tr>
                              </table>
                            </div>
                          `).join('')}
                        `}
                      </td>
                    `;
                  }).join('')}

                  <!-- Administrative Remarks -->
                  <td style="border: 1pt solid #cbd5e1; background-color: #ffffff; text-align: center;"></td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>

        <!-- Signatures & Official Stamp Footer -->
        <table style="width: 100%; border: none; margin-top: 8pt; font-size: 9.5pt; border-collapse: collapse;" border="0">
          <tr>
            <td style="text-align: right; width: 38%; border: none; vertical-align: top; padding: 0;">
              <div style="font-weight: 900; color: #0f172a;">${settings.pointingSupervisorLabel}</div>
              <div style="font-size: 8pt; color: #64748b;">(التأشيرة والاسم)</div>
            </td>

            <td style="text-align: center; width: 24%; border: none; vertical-align: middle; padding: 0;">
              <div style="font-size: 8.5pt; color: #64748b; font-family: monospace;">
                ${totalPages > 1 ? `[صفحة ${pageNum} من ${totalPages}]` : ''}
              </div>
            </td>

            <td style="text-align: left; width: 38%; border: none; vertical-align: top; padding: 0;">
              <div style="font-weight: 900; color: #0f172a;">${settings.pointingAdminLabel}</div>
              <div style="font-size: 8pt; color: #64748b;">(التوقيع والملاحظات)</div>
            </td>
          </tr>
        </table>

      </div>
      <!-- END PAGE -->
    `;
  };

  // 1. Export Microsoft Excel (.xls) with pristine RTL workbook options and UTF-8 BOM
  const handleExportExcel = () => {
    const pagesHtml: string[] = [];

    targetPeriods.forEach(p => {
      chunks.forEach((chunk, cIdx) => {
        const chunkSize = Math.ceil(appData.groups.length / chunks.length);
        pagesHtml.push(
          generatePageHtml(p, chunk, cIdx * chunkSize, cIdx + 1, chunks.length, 'excel')
        );
      });
    });

    const combinedHtml = pagesHtml.join('<br style="mso-data-placement:same-cell; page-break-before:always;"/><hr style="page-break-before:always; border:none;"/><br/>');

    const excelDocument = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office"
            xmlns:x="urn:schemas-microsoft-com:office:excel"
            xmlns="http://www.w3.org/TR/REC-html40">
      <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        <!--[if gte mso 9]>
        <xml>
          <x:ExcelWorkbook>
            <x:ExcelWorksheets>
              <x:ExcelWorksheet>
                <x:Name>الورقة الدوارة</x:Name>
                <x:WorksheetOptions>
                  <x:DisplayRightToLeft/>
                  <x:Print>
                    <x:ValidPrinterInfo/>
                    <x:PaperSizeIndex>9</x:PaperSizeIndex>
                    <x:Scale>82</x:Scale>
                    <x:Orientation>Landscape</x:Orientation>
                    <x:HorizontalResolution>600</x:HorizontalResolution>
                    <x:VerticalResolution>600</x:VerticalResolution>
                  </x:Print>
                  <x:Selected/>
                  <x:DoNotDisplayGridlines/>
                </x:WorksheetOptions>
              </x:ExcelWorksheet>
            </x:ExcelWorksheets>
          </x:ExcelWorkbook>
        </xml>
        <![endif]-->
        <style>
          body {
            font-family: 'Cairo', Arial, sans-serif;
            direction: rtl;
            background-color: #ffffff;
            margin: 0;
            padding: 10px;
          }
          table {
            border-collapse: collapse;
          }
          th, td {
            mso-number-format: "\\@";
          }
        </style>
      </head>
      <body>
        ${combinedHtml}
      </body>
      </html>
    `;

    // \uFEFF ensures proper UTF-8 BOM encoding for Microsoft Excel on Windows/Mac
    const blob = new Blob(['\uFEFF' + excelDocument], { type: 'application/vnd.ms-excel;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const cleanName = (appData.institution || 'المؤسسة').replace(/[\s\/\\]+/g, '_');
    a.download = `الورقة_الدوارة_${cleanName}_${exportScope === 'current' ? currentPeriodObj.key : 'الاسبوع_كاملا'}.xls`;
    a.click();
    URL.revokeObjectURL(url);

    setDownloadSuccess('تم تصدير ملف Microsoft Excel (.xls) عالي الدقة بنجاح!');
    setTimeout(() => setDownloadSuccess(null), 3500);
  };

  // 2. Export Microsoft Word (.doc) with native Word landscape section and page breaks
  const handleExportWord = () => {
    const pagesHtml: string[] = [];

    targetPeriods.forEach(p => {
      chunks.forEach((chunk, cIdx) => {
        const chunkSize = Math.ceil(appData.groups.length / chunks.length);
        pagesHtml.push(
          generatePageHtml(p, chunk, cIdx * chunkSize, cIdx + 1, chunks.length, 'word')
        );
      });
    });

    const combinedHtml = pagesHtml.join('<br clear="all" style="mso-special-character:line-break;page-break-before:always" />');

    const wordDocument = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office'
            xmlns:w='urn:schemas-microsoft-com:office:word'
            xmlns='http://www.w3.org/TR/REC-html40'>
      <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        <title>الورقة الدوارة - ${appData.institution}</title>
        <!--[if gte mso 9]>
        <xml>
          <w:WordDocument>
            <w:View>Print</w:View>
            <w:Zoom>100</w:Zoom>
            <w:DoNotOptimizeForBrowser/>
          </w:WordDocument>
        </xml>
        <![endif]-->
        <style>
          @page Section1 {
            size: 841.9pt 595.3pt; /* A4 Landscape: 297mm x 210mm */
            mso-page-orientation: landscape;
            margin: 1.2cm 1.0cm 1.2cm 1.0cm;
            mso-header-margin: 35.4pt;
            mso-footer-margin: 35.4pt;
            mso-paper-source: 0;
          }
          div.Section1 {
            page: Section1;
            direction: rtl;
          }
          body {
            font-family: 'Cairo', Arial, sans-serif;
            direction: rtl;
            background-color: #ffffff;
            margin: 0;
            padding: 0;
          }
          table {
            border-collapse: collapse;
            mso-table-lspace: 0pt;
            mso-table-rspace: 0pt;
          }
          .page-break {
            page-break-after: always;
            mso-special-character: line-break;
          }
        </style>
      </head>
      <body>
        <div class="Section1">
          ${combinedHtml}
        </div>
      </body>
      </html>
    `;

    // \uFEFF ensures proper UTF-8 BOM encoding for Microsoft Word
    const blob = new Blob(['\uFEFF' + wordDocument], { type: 'application/msword;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const cleanName = (appData.institution || 'المؤسسة').replace(/[\s\/\\]+/g, '_');
    a.download = `الورقة_الدوارة_${cleanName}_${exportScope === 'current' ? currentPeriodObj.key : 'الاسبوع_كاملا'}.doc`;
    a.click();
    URL.revokeObjectURL(url);

    setDownloadSuccess('تم تصدير مستند Microsoft Word (.doc) المنسق بنجاح!');
    setTimeout(() => setDownloadSuccess(null), 3500);
  };

  // 3. Direct Print Window
  const handleDirectPrint = () => {
    onClose();
    if (onTriggerPrint) {
      onTriggerPrint(exportScope);
    } else {
      setTimeout(() => {
        window.print();
      }, 200);
    }
  };

  // 4. Adobe PDF (High-fidelity Client-Side Direct PDF Generator)
  const handleExportPDF = async () => {
    if (isGeneratingPDF) return;
    setIsGeneratingPDF(true);
    setPdfProgressText('جارٍ إعداد صفحات PDF...');

    const isPortrait = paperOrientation === 'portrait';
    const container = document.createElement('div');
    container.id = 'pdf-render-sandbox';
    container.style.position = 'fixed';
    container.style.left = '-99999px';
    container.style.top = '0';
    container.style.width = isPortrait ? '794px' : '1122px';
    container.style.backgroundColor = '#ffffff';
    container.style.zIndex = '-9999';
    container.style.direction = 'rtl';
    container.style.fontFamily = "'Cairo', Arial, sans-serif";
    document.body.appendChild(container);

    try {
      const pdf = new jsPDF({
        orientation: paperOrientation,
        unit: 'mm',
        format: 'a4',
        compress: true
      });

      const pdfWidth = isPortrait ? 210 : 297;
      const pdfHeight = isPortrait ? 297 : 210;
      const margin = 4; // 4mm margin for crisp bounding
      const maxPrintW = pdfWidth - margin * 2;
      const maxPrintH = pdfHeight - margin * 2;

      // Collect all pages to render based on exportScope
      const pagesToRender: Array<{
        pObj: typeof currentPeriodObj;
        chunk: string[];
        startIndex: number;
        pageNum: number;
        totalPages: number;
      }> = [];

      targetPeriods.forEach(p => {
        chunks.forEach((chunk, cIdx) => {
          const chunkSize = Math.ceil(appData.groups.length / chunks.length);
          pagesToRender.push({
            pObj: p,
            chunk,
            startIndex: cIdx * chunkSize,
            pageNum: cIdx + 1,
            totalPages: chunks.length
          });
        });
      });

      const totalPagesCount = pagesToRender.length;

      for (let i = 0; i < totalPagesCount; i++) {
        const pageInfo = pagesToRender[i];
        setPdfProgressText(`جارٍ معالجة وتوليد الصفحة ${i + 1} من ${totalPagesCount}...`);

        container.innerHTML = generatePageHtml(
          pageInfo.pObj,
          pageInfo.chunk,
          pageInfo.startIndex,
          pageInfo.pageNum,
          pageInfo.totalPages,
          'pdf'
        );

        // Allow browser to render layout and fonts
        await new Promise(r => setTimeout(r, 60));

        const pageEl = container.firstElementChild as HTMLElement || container;

        const canvas = await html2canvas(pageEl, {
          scale: 2, // High DPI resolution (300dpi equivalent)
          useCORS: true,
          logging: false,
          backgroundColor: '#ffffff',
          windowWidth: isPortrait ? 800 : 1130
        });

        const imgData = canvas.toDataURL('image/jpeg', 0.95);
        const canvasRatio = canvas.width / canvas.height;

        let drawW = maxPrintW;
        let drawH = maxPrintW / canvasRatio;

        if (drawH > maxPrintH) {
          drawH = maxPrintH;
          drawW = maxPrintH * canvasRatio;
        }

        const posX = margin + (maxPrintW - drawW) / 2;
        const posY = margin + (maxPrintH - drawH) / 2;

        if (i > 0) {
          pdf.addPage('a4', paperOrientation);
        }

        pdf.addImage(imgData, 'JPEG', posX, posY, drawW, drawH, undefined, 'FAST');
      }

      setPdfProgressText('جارٍ تنزيل وحفظ ملف PDF...');
      const cleanName = (appData.institution || 'المؤسسة').replace(/[\s\/\\]+/g, '_');
      const filename = `الورقة_الدوارة_${cleanName}_${exportScope === 'current' ? currentPeriodObj.key : 'الاسبوع_كاملا'}.pdf`;

      pdf.save(filename);

      setDownloadSuccess(`تم تصدير وتحميل ملف Adobe PDF (${filename}) بنجاح!`);
      setTimeout(() => setDownloadSuccess(null), 4000);
    } catch (err) {
      console.error('Failed generating PDF:', err);
      setDownloadSuccess('تم تفعيل حوار الطباعة وتصدير PDF المباشر بدلاً من التحميل');
      setTimeout(() => {
        onClose();
        if (onTriggerPrint) {
          onTriggerPrint(exportScope);
        } else {
          window.print();
        }
      }, 600);
    } finally {
      if (document.body.contains(container)) {
        document.body.removeChild(container);
      }
      setIsGeneratingPDF(false);
      setPdfProgressText('');
    }
  };

  return (
    <div className="no-print fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-xl overflow-hidden animate-in fade-in zoom-in duration-150">
        
        {/* Header matching image_6f65108c.png */}
        <div className="p-5 bg-[#064e3b] text-white flex items-center justify-between border-b border-emerald-900">
          <button
            onClick={onClose}
            className="text-slate-300 hover:text-white p-1.5 rounded-xl hover:bg-white/10 transition cursor-pointer"
            title="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="text-center flex-1 pr-2 pl-6">
            <h3 className="font-black text-base sm:text-lg flex items-center justify-center gap-2">
              <span>مركز التصدير الشامل (Export Hub)</span>
            </h3>
            <p className="text-[11px] text-emerald-200 font-bold mt-0.5">
              تصدير مباشر بصيغ Microsoft Excel و Word و PDF بجودة عالية
            </p>
          </div>

          <div className="w-10 h-10 rounded-2xl bg-slate-900 text-teal-400 flex items-center justify-center border border-teal-500/30 flex-shrink-0 shadow-inner">
            <Download className="w-5 h-5" />
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5">
          
          {downloadSuccess && (
            <div className="p-3 bg-emerald-50 border border-emerald-300 text-emerald-900 rounded-xl text-xs font-black flex items-center gap-2 animate-in fade-in">
              <CheckCircle className="w-4 h-4 text-emerald-600 flex-shrink-0" />
              <span>{downloadSuccess}</span>
            </div>
          )}

          {isGeneratingPDF && (
            <div className="p-3 bg-red-50 border border-red-300 text-red-900 rounded-xl text-xs font-black flex items-center justify-center gap-2 animate-pulse">
              <Loader2 className="w-4 h-4 animate-spin text-red-600 flex-shrink-0" />
              <span>{pdfProgressText}</span>
            </div>
          )}

          {/* 1. حدد نطاق التصدير */}
          <div>
            <div className="text-xs font-black text-slate-900 mb-2.5">
              1. حدد نطاق التصدير:
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs font-bold">
              
              {/* Option 1: Current item only */}
              <label
                onClick={() => setExportScope('current')}
                className={`flex items-center justify-center gap-2 p-3 rounded-2xl border cursor-pointer transition ${
                  exportScope === 'current'
                    ? 'bg-emerald-50/50 border-emerald-500 text-emerald-950 ring-2 ring-emerald-500/20 shadow-xs'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <input
                  type="radio"
                  name="scope"
                  checked={exportScope === 'current'}
                  onChange={() => setExportScope('current')}
                  className="w-4 h-4 text-emerald-600"
                />
                <span className="font-extrabold truncate">
                  العنصر الحالي المعروض فقط ({activePeriodKey})
                </span>
              </label>

              {/* Option 2: All items */}
              <label
                onClick={() => setExportScope('all')}
                className={`flex items-center justify-center gap-2 p-3 rounded-2xl border cursor-pointer transition ${
                  exportScope === 'all'
                    ? 'bg-emerald-50/50 border-emerald-500 text-emerald-950 ring-2 ring-emerald-500/20 shadow-xs'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <input
                  type="radio"
                  name="scope"
                  checked={exportScope === 'all'}
                  onChange={() => setExportScope('all')}
                  className="w-4 h-4 text-emerald-600"
                />
                <span className="font-extrabold">تصدير الكل دفعة واحدة (ALL)</span>
              </label>

            </div>
          </div>

          {/* 2. اختر صيغة الملف للتوليد والتنزيل المباشر */}
          <div>
            <div className="text-xs font-black text-slate-900 mb-2.5">
              2. اختر صيغة الملف للتوليد والتنزيل المباشر:
            </div>

            <div className="grid grid-cols-3 gap-3">
              
              {/* Card 1: Adobe PDF */}
              <button
                type="button"
                onClick={handleExportPDF}
                disabled={isGeneratingPDF}
                className="group flex flex-col items-center justify-center p-4 rounded-2xl border-2 border-red-200 hover:border-red-500 bg-red-50/30 hover:bg-red-50 transition shadow-xs text-center space-y-1.5 cursor-pointer disabled:opacity-75 disabled:cursor-wait"
              >
                <div className="w-10 h-10 rounded-xl bg-white border border-red-200 flex items-center justify-center text-red-600 shadow-2xs group-hover:scale-105 transition-transform">
                  {isGeneratingPDF ? (
                    <Loader2 className="w-5 h-5 animate-spin text-red-600" />
                  ) : (
                    <FileText className="w-5 h-5" />
                  )}
                </div>
                <div className="font-black text-xs text-red-700">Adobe PDF</div>
                <div className="text-[10px] text-slate-500 font-bold">
                  {isGeneratingPDF ? 'جارٍ التوليد...' : 'تنزيل ملف pdf. مباشر'}
                </div>
              </button>

              {/* Card 2: Microsoft Word */}
              <button
                type="button"
                onClick={handleExportWord}
                disabled={isGeneratingPDF}
                className="group flex flex-col items-center justify-center p-4 rounded-2xl border-2 border-blue-200 hover:border-blue-500 bg-blue-50/30 hover:bg-blue-50 transition shadow-xs text-center space-y-1.5 cursor-pointer disabled:opacity-50"
              >
                <div className="w-10 h-10 rounded-xl bg-white border border-blue-200 flex items-center justify-center text-blue-600 shadow-2xs group-hover:scale-105 transition-transform">
                  <span className="text-xl font-bold">W</span>
                </div>
                <div className="font-black text-xs text-blue-700">Microsoft Word</div>
                <div className="text-[10px] text-slate-500 font-bold">مستند doc. مطابق للأصل</div>
              </button>

              {/* Card 3: Microsoft Excel */}
              <button
                type="button"
                onClick={handleExportExcel}
                disabled={isGeneratingPDF}
                className="group flex flex-col items-center justify-center p-4 rounded-2xl border-2 border-emerald-300 hover:border-emerald-600 bg-emerald-50/30 hover:bg-emerald-50 transition shadow-xs text-center space-y-1.5 cursor-pointer disabled:opacity-50"
              >
                <div className="w-10 h-10 rounded-xl bg-white border border-emerald-300 flex items-center justify-center text-emerald-700 shadow-2xs group-hover:scale-105 transition-transform">
                  <span className="text-xl font-bold">X</span>
                </div>
                <div className="font-black text-xs text-emerald-800">Microsoft Excel</div>
                <div className="text-[10px] text-slate-500 font-bold">مصنف xls. مرمز RTL بالكامل</div>
              </button>

            </div>

            {/* Quick Direct Print fallback */}
            <div className="mt-3 flex items-center justify-between text-[11px] font-bold text-slate-600 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2">
              <span className="flex items-center gap-1">
                <span>🖨️</span>
                <span>هل تفضل إرسال المستند مباشرة إلى الطابعة الورقية؟</span>
              </span>
              <button
                type="button"
                onClick={handleDirectPrint}
                className="text-emerald-700 hover:text-emerald-900 font-black hover:underline flex items-center gap-1 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>أمر الطباعة الورقية (Print)</span>
              </button>
            </div>
          </div>

          {/* Bottom Hint Callout */}
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-2xl flex items-center gap-2 text-[11px] text-slate-600 font-bold">
            <Lightbulb className="w-4 h-4 text-amber-500 flex-shrink-0" />
            <span>تدعم كافة الملفات المصدرة التنسيق العربي الكامل (RTL) مع خطوط واضحة وتوزيع متناسق للأيام والحصص مطابقة للمعاينة.</span>
          </div>

        </div>

        {/* Footer */}
        <div className="p-3.5 bg-slate-100 border-t border-slate-200 text-center">
          <button
            onClick={onClose}
            className="text-slate-600 hover:text-slate-900 font-black text-xs transition"
          >
            إغلاق النافذة
          </button>
        </div>

      </div>
    </div>
  );
};
