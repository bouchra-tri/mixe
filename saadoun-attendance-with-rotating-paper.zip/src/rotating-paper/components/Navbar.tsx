import React from 'react';
import { Upload, Save, FolderOpen, GraduationCap, UserCheck, BarChart3, Building2, FileText, Settings as SettingsIcon, Globe } from 'lucide-react';
import { AppData } from '../types';

interface NavbarProps {
  appData: AppData;
  currentTab: string;
  onSwitchTab: (tab: string) => void;
  onXmlUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onExportProject: () => void;
  onImportProject: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  appData,
  currentTab,
  onSwitchTab,
  onXmlUpload,
  onExportProject,
  onImportProject
}) => {
  return (
    <header className="no-print bg-slate-900 text-white shadow-xl sticky top-0 z-50 border-b border-slate-700/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="h-16 flex items-center justify-between border-b border-slate-800 gap-4">
          
          <div className="flex items-center space-x-reverse space-x-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-emerald-400 flex items-center justify-center text-xl shadow-lg shadow-emerald-950/40 flex-shrink-0 border border-emerald-400/30">
              🏫
            </div>
            <div className="truncate">
              <div className="flex items-center gap-2">
                <h1 className="text-sm sm:text-base font-black tracking-wide text-white truncate">منظومة جداول التوقيت</h1>
                <span className="bg-emerald-500/20 text-emerald-400 text-[10px] font-bold px-1.5 py-0.5 rounded border border-emerald-500/30">V3.2 Pro</span>
              </div>
              <p className="text-xs text-emerald-400 font-bold truncate">{appData.institution}</p>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            <label className="cursor-pointer bg-slate-800 hover:bg-slate-700 text-emerald-400 hover:text-white border border-slate-700 px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 shadow-sm" title="فتح ملف FET بتنسيق XML">
              <Upload className="w-4 h-4 text-emerald-400" />
              <span className="hidden md:inline">استيراد FET</span>
              <input type="file" accept=".xml,.fet" className="hidden" onChange={onXmlUpload} />
            </label>

            {/* Project .fetpro Save / Open Buttons */}
            <div className="flex items-center gap-1 bg-slate-950/90 p-1 rounded-xl border border-slate-800 text-xs font-bold">
              <button
                onClick={onExportProject}
                className="bg-emerald-800/80 hover:bg-emerald-700 text-white px-2.5 py-1.5 rounded-lg transition flex items-center gap-1.5 shadow-xs"
                title="حفظ المشروع كاملاً بصيغة .fetpro لاستعماله لاحقاً"
              >
                <Save className="w-3.5 h-3.5 text-emerald-300" />
                <span className="hidden sm:inline">حفظ .fetpro</span>
              </button>

              <label
                className="cursor-pointer text-slate-300 hover:text-white hover:bg-slate-800 px-2 py-1.5 rounded-lg transition flex items-center gap-1"
                title="فتح ملف مشروع محفوظ مسبقاً (.fetpro أو .json)"
              >
                <FolderOpen className="w-3.5 h-3.5 text-slate-400" />
                <span className="hidden lg:inline">فتح .fetpro</span>
                <input type="file" accept=".fetpro,.json" className="hidden" onChange={onImportProject} />
              </label>
            </div>

            {/* Navigation Tabs */}
            <nav className="flex items-center bg-slate-950/80 p-1 rounded-xl border border-slate-800 text-xs font-bold shadow-inner">
              <button
                onClick={() => onSwitchTab('classes')}
                className={`tab-btn px-2.5 sm:px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 ${
                  currentTab === 'classes' ? 'bg-emerald-600 text-white shadow' : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                <GraduationCap className="w-4 h-4" />
                <span className="hidden sm:inline">الأقسام</span>
              </button>

              <button
                onClick={() => onSwitchTab('teachers')}
                className={`tab-btn px-2.5 sm:px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 ${
                  currentTab === 'teachers' ? 'bg-emerald-600 text-white shadow' : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                <UserCheck className="w-4 h-4" />
                <span className="hidden sm:inline">الأساتذة</span>
              </button>

              <button
                onClick={() => onSwitchTab('global')}
                className={`tab-btn px-2.5 sm:px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 ${
                  currentTab === 'global' ? 'bg-emerald-600 text-white shadow' : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                <BarChart3 className="w-4 h-4" />
                <span className="hidden sm:inline">الجداول العامة</span>
              </button>

              <button
                onClick={() => onSwitchTab('rooms')}
                className={`tab-btn px-2.5 sm:px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 ${
                  currentTab === 'rooms' ? 'bg-emerald-600 text-white shadow' : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Building2 className="w-4 h-4" />
                <span className="hidden sm:inline">القاعات</span>
              </button>

              <button
                onClick={() => onSwitchTab('pointing')}
                className={`tab-btn px-2.5 sm:px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 ${
                  currentTab === 'pointing' ? 'bg-emerald-600 text-white shadow' : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                <FileText className="w-4 h-4" />
                <span className="hidden md:inline">الورقة الدوارة</span>
              </button>

              {/* Requirement 4: Server Tab */}
              <button
                onClick={() => onSwitchTab('server')}
                className={`tab-btn px-2.5 sm:px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 ${
                  currentTab === 'server'
                    ? 'bg-teal-600 text-white shadow ring-2 ring-emerald-400'
                    : 'text-emerald-400 hover:text-white hover:bg-emerald-950/60'
                }`}
                title="الصفحة العامة لسيرفر المؤسسة للولوج المباشر لكافة الجداول بدون طبع"
              >
                <Globe className="w-4 h-4" />
                <span className="font-extrabold">سيرفر المؤسسة</span>
              </button>

              <button
                onClick={() => onSwitchTab('settings')}
                className={`tab-btn px-2 sm:px-2.5 py-1.5 rounded-lg transition flex items-center gap-1.5 ${
                  currentTab === 'settings' ? 'bg-emerald-600 text-white shadow' : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
                title="الإعدادات وتخصيص البيانات"
              >
                <SettingsIcon className="w-4 h-4" />
              </button>
            </nav>
          </div>
        </div>
      </div>
    </header>
  );
};
