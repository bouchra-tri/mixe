import React, { useState } from 'react';
import { X, Search, Edit3, Check, Users, GraduationCap, AlertCircle, RefreshCw } from 'lucide-react';
import { AppData } from '../types';

interface RenameModalProps {
  isOpen: boolean;
  onClose: () => void;
  appData: AppData;
  onRenameGroup: (oldName: string, newName: string) => void;
  onRenameTeacher: (oldName: string, newName: string) => void;
  initialTarget?: { type: 'classes' | 'teachers'; id: string };
}

export const RenameModal: React.FC<RenameModalProps> = ({
  isOpen,
  onClose,
  appData,
  onRenameGroup,
  onRenameTeacher,
  initialTarget
}) => {
  const [activeTab, setActiveTab] = useState<'classes' | 'teachers'>(
    initialTarget?.type || 'classes'
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [editingItem, setEditingItem] = useState<string | null>(initialTarget?.id || null);
  const [newNameInput, setNewNameInput] = useState<string>(initialTarget?.id || '');
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const currentList = activeTab === 'classes' ? appData.groups : appData.teachers;
  const filteredList = currentList.filter(item =>
    item.toLowerCase().includes(searchQuery.trim().toLowerCase())
  );

  const startEdit = (item: string) => {
    setEditingItem(item);
    setNewNameInput(item);
    setErrorMsg('');
  };

  const cancelEdit = () => {
    setEditingItem(null);
    setNewNameInput('');
    setErrorMsg('');
  };

  const saveEdit = (oldName: string) => {
    const trimmed = newNameInput.trim();
    if (!trimmed) {
      setErrorMsg('لا يمكن ترك الاسم فارغاً');
      return;
    }
    if (trimmed === oldName) {
      cancelEdit();
      return;
    }

    if (currentList.includes(trimmed) && trimmed !== oldName) {
      setErrorMsg('هذا الاسم موجود بالفعل، يرجى اختيار اسم غير مكرر');
      return;
    }

    if (activeTab === 'classes') {
      onRenameGroup(oldName, trimmed);
    } else {
      onRenameTeacher(oldName, trimmed);
    }

    cancelEdit();
  };

  const getActivityCount = (item: string) => {
    if (activeTab === 'classes') {
      return Object.values(appData.activities).filter(a =>
        a.students && a.students.some(s => s.startsWith(item) || item.startsWith(s))
      ).length;
    } else {
      return Object.values(appData.activities).filter(a =>
        a.teachers && a.teachers.includes(item)
      ).length;
    }
  };

  return (
    <div className="no-print fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl max-h-[85vh] flex flex-col overflow-hidden animate-in fade-in zoom-in duration-150">
        
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 to-emerald-950 text-white flex items-center justify-between border-b border-emerald-900">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-400">
              <Edit3 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-base sm:text-lg">تعديل مسميات الأقسام والأساتذة</h3>
              <p className="text-xs text-emerald-300">
                يمكنك تخصيص وتعديل أي اسم قبل الطبع أو النشر مع الحفاظ على كافة الحصص والأنشطة
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher & Search Bar */}
        <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center bg-slate-200/80 p-1 rounded-xl text-xs font-bold">
            <button
              onClick={() => {
                setActiveTab('classes');
                cancelEdit();
              }}
              className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 ${
                activeTab === 'classes'
                  ? 'bg-emerald-600 text-white shadow'
                  : 'text-slate-700 hover:text-slate-900'
              }`}
            >
              <GraduationCap className="w-4 h-4" />
              <span>الأقسام والفصول ({appData.groups.length})</span>
            </button>
            <button
              onClick={() => {
                setActiveTab('teachers');
                cancelEdit();
              }}
              className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 ${
                activeTab === 'teachers'
                  ? 'bg-emerald-600 text-white shadow'
                  : 'text-slate-700 hover:text-slate-900'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>هيئة التدريس / الأساتذة ({appData.teachers.length})</span>
            </button>
          </div>

          <div className="relative flex-1 min-w-[180px]">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={`بحث سريع في ${activeTab === 'classes' ? 'الأقسام' : 'الأساتذة'}...`}
              className="w-full bg-white border border-slate-300 text-slate-800 text-xs rounded-lg py-1.5 pr-2.5 pl-8 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
            <Search className="absolute left-2.5 top-2 w-3.5 h-3.5 text-slate-400" />
          </div>
        </div>

        {errorMsg && (
          <div className="mx-4 mt-3 p-2.5 rounded-lg bg-red-50 border border-red-200 text-red-700 text-xs font-bold flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* List Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2 custom-scrollbar">
          {filteredList.length === 0 ? (
            <div className="text-center py-10 text-slate-400 text-xs font-bold">
              لا توجد عناصر مطابقة للبحث
            </div>
          ) : (
            filteredList.map((item) => {
              const isEditing = editingItem === item;
              const count = getActivityCount(item);

              return (
                <div
                  key={item}
                  className={`flex items-center justify-between p-3 rounded-xl border transition-all ${
                    isEditing
                      ? 'bg-emerald-50/80 border-emerald-400 shadow-sm'
                      : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0 flex-1">
                    <span className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center text-xs font-black flex-shrink-0">
                      {activeTab === 'classes' ? '👥' : '👨🏫'}
                    </span>

                    {isEditing ? (
                      <div className="flex items-center gap-2 flex-1 ml-2">
                        <input
                          type="text"
                          value={newNameInput}
                          onChange={(e) => setNewNameInput(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') saveEdit(item);
                            if (e.key === 'Escape') cancelEdit();
                          }}
                          autoFocus
                          className="w-full bg-white border-2 border-emerald-500 rounded-lg px-2.5 py-1 text-xs font-bold text-slate-900 focus:outline-none"
                          placeholder="الاسم الجديد..."
                        />
                      </div>
                    ) : (
                      <div className="min-w-0 flex-1">
                        <div className="font-extrabold text-xs text-slate-900 truncate">
                          {item}
                        </div>
                        <div className="text-[10px] text-slate-500">
                          {count} حصة / نشاط مسجل
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    {isEditing ? (
                      <>
                        <button
                          onClick={() => saveEdit(item)}
                          className="bg-emerald-600 hover:bg-emerald-700 text-white px-2.5 py-1 rounded-lg text-xs font-bold transition flex items-center gap-1 shadow-xs"
                          title="حفظ التعديل"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>حفظ</span>
                        </button>
                        <button
                          onClick={cancelEdit}
                          className="bg-slate-200 hover:bg-slate-300 text-slate-700 px-2 py-1 rounded-lg text-xs font-bold transition"
                          title="إلغاء"
                        >
                          إلغاء
                        </button>
                      </>
                    ) : (
                      <button
                        onClick={() => startEdit(item)}
                        className="bg-slate-100 hover:bg-emerald-100 text-slate-700 hover:text-emerald-800 border border-slate-300 hover:border-emerald-300 px-2.5 py-1 rounded-lg text-xs font-bold transition flex items-center gap-1"
                        title="تغيير هذا الاسم"
                      >
                        <Edit3 className="w-3 h-3 text-emerald-600" />
                        <span>تعديل</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-3.5 bg-slate-100 border-t border-slate-200 flex items-center justify-between text-xs">
          <div className="text-slate-500 text-[11px] font-bold">
            💡 يتم تحديث الجداول تلقائياً والاحتفاظ بكافة بيانات الأنشطة
          </div>
          <button
            onClick={onClose}
            className="bg-slate-800 hover:bg-slate-900 text-white px-4 py-1.5 rounded-lg font-bold transition"
          >
            إغلاق
          </button>
        </div>

      </div>
    </div>
  );
};
