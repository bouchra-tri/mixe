import React from 'react';
import { AppData, SlotItem } from '../types';

interface TimetableGridProps {
  scheduleMap: Record<string, SlotItem[]>;
  appData: AppData;
  mode: 'classes' | 'teachers';
}

export const TimetableGrid: React.FC<TimetableGridProps> = ({ scheduleMap, appData, mode }) => {
  const { days, hours, settings } = appData;
  const isInk = settings.inkSaver;

  const renderSlotCell = (items: SlotItem[]) => {
    if (!items || items.length === 0) {
      return `<td class="py-2 px-1 text-center bg-slate-50/50 border-slate-200 text-slate-300 font-bold text-xs">·</td>`;
    }

    let cellHtml = `<td class="py-1 px-1 text-center border-slate-200 bg-white align-middle">`;
    items.forEach((item) => {
      const subColor = settings.subjectColors[item.subject] || '#047857';
      const slotBg = isInk ? '#ffffff' : (settings.colorizeSubjects ? subColor : '#064e3b');
      const slotFg = isInk ? '#000000' : '#ffffff';
      
      const teacherStr = (settings.showTeachers && item.teachers && item.teachers.length > 0) ? item.teachers.join(', ') : '';
      const roomStr = (settings.showRooms && item.room) ? item.room : '';
      const groupStr = (settings.showClasses && item.students && item.students.length > 0) ? item.students.join(', ') : '';
      const subGroupStr = item.subgroup ? `(${item.subgroup})` : '';

      cellHtml += `
        <div class="slot-colored p-1.5 rounded-lg mb-1 last:mb-0 text-center transition shadow-sm border border-black/10" style="background-color: ${slotBg}; color: ${slotFg};">
          <div class="font-black text-xs sm:text-sm tracking-tight leading-snug drop-shadow-xs" style="color: ${slotFg};">${item.subject} ${subGroupStr}</div>
          ${teacherStr ? `<div class="text-[11px] font-bold opacity-90 mt-0.5 truncate" style="color: ${slotFg};">👨🏫 ${teacherStr}</div>` : ''}
          ${groupStr && mode === 'teachers' ? `<div class="text-[10px] font-bold opacity-90 mt-0.5 truncate" style="color: ${slotFg};">👥 ${groupStr}</div>` : ''}
          ${roomStr ? `<div class="inline-block px-1.5 py-0.5 rounded text-[10px] font-mono font-bold mt-1 shadow-xs badge-room" style="background: rgba(0,0,0,0.25); color: ${slotFg}; border: 1px solid rgba(255,255,255,0.3);">🏛️ ${roomStr}</div>` : ''}
        </div>
      `;
    });
    cellHtml += `</td>`;
    return cellHtml;
  };

  if (settings.gridOrientation === 'days-rows') {
    // Days Vertical in Rows
    let html = `<table class="timetable-table themed-table w-full"><thead><tr>`;
    html += `<th class="main-header w-28 py-2 text-xs font-black ${isInk ? 'bg-white text-black border-2 border-black' : ''}">اليوم والفترة</th>`;

    hours.forEach(h => {
      html += `<th class="main-header py-2 px-1 text-xs font-black ${isInk ? 'bg-white text-black border-2 border-black' : ''}">
        <div class="font-extrabold text-[11px] leading-tight ${isInk ? 'text-black' : ''}">${h.label}</div>
        <div class="text-[9px] opacity-80 mt-0.5 font-mono ${isInk ? 'text-slate-800' : ''}" dir="ltr">${h.morningTime}</div>
      </th>`;
    });
    html += `</tr></thead><tbody>`;

    days.forEach(day => {
      // Morning
      html += `<tr>`;
      html += `<td class="sub-header py-2 font-black text-[11px] ${isInk ? 'bg-white text-black border-2 border-black' : 'bg-emerald-950 text-white'} whitespace-nowrap">
        <span class="block font-black ${isInk ? 'text-black' : ''}">${day}</span>
        <span class="text-[9px] font-bold ${isInk ? 'text-slate-800' : 'text-emerald-300'}">صباحاً (ص)</span>
      </td>`;
      hours.forEach(h => {
        const slotKey = `${day} ص___${h.id}`;
        html += renderSlotCell(scheduleMap[slotKey] || []);
      });
      html += `</tr>`;

      // Afternoon
      html += `<tr>`;
      html += `<td class="sub-header py-2 font-black text-[11px] ${isInk ? 'bg-white text-black border-2 border-black' : 'bg-slate-800 text-white'} whitespace-nowrap">
        <span class="block font-black ${isInk ? 'text-black' : ''}">${day}</span>
        <span class="text-[9px] font-bold ${isInk ? 'text-slate-800' : 'text-amber-300'}">مساءً (م)</span>
      </td>`;
      hours.forEach(h => {
        const slotKey = `${day} م___${h.id}`;
        html += renderSlotCell(scheduleMap[slotKey] || []);
      });
      html += `</tr>`;
    });

    html += `</tbody></table>`;
    return <div dangerouslySetInnerHTML={{ __html: html }} />;
  } else {
    // Days Horizontal in Columns
    let html = `<table class="timetable-table themed-table w-full"><thead><tr>`;
    html += `<th class="main-header w-24 py-2 text-xs font-black ${isInk ? 'bg-white text-black border-2 border-black' : ''}">الحصة / التوقيت</th>`;

    days.forEach(d => {
      html += `<th class="main-header py-2 px-1 text-xs font-black ${isInk ? 'bg-white text-black border-2 border-black' : ''}">
        <div class="font-extrabold text-sm leading-tight ${isInk ? 'text-black' : ''}">${d}</div>
      </th>`;
    });
    html += `</tr></thead><tbody>`;

    // Morning Header
    html += `<tr><td colspan="${days.length + 1}" class="py-1 px-3 text-xs font-black text-right ${isInk ? 'bg-slate-100 text-black border-y-2 border-black' : 'bg-emerald-950 text-emerald-200 border-y border-emerald-800'}">
      <span>🌅 الفترة الصباحية (صباحاً)</span>
    </td></tr>`;

    hours.forEach(h => {
      html += `<tr>`;
      html += `<td class="sub-header py-2 font-black text-xs ${isInk ? 'bg-white text-black border-2 border-black' : 'bg-emerald-900 text-white'} whitespace-nowrap">
        <div class="font-black ${isInk ? 'text-black' : ''}">${h.label}</div>
        <div class="text-[9px] font-mono opacity-80 mt-0.5 ${isInk ? 'text-slate-800' : ''}" dir="ltr">${h.morningTime}</div>
      </td>`;
      days.forEach(day => {
        const slotKey = `${day} ص___${h.id}`;
        html += renderSlotCell(scheduleMap[slotKey] || []);
      });
      html += `</tr>`;
    });

    // Afternoon Header
    html += `<tr><td colspan="${days.length + 1}" class="py-1 px-3 text-xs font-black text-right ${isInk ? 'bg-slate-100 text-black border-y-2 border-black' : 'bg-slate-900 text-amber-200 border-y border-slate-800'}">
      <span>🌇 الفترة المسائية (مساءً)</span>
    </td></tr>`;

    hours.forEach(h => {
      html += `<tr>`;
      html += `<td class="sub-header py-2 font-black text-xs ${isInk ? 'bg-white text-black border-2 border-black' : 'bg-slate-800 text-white'} whitespace-nowrap">
        <div class="font-black ${isInk ? 'text-black' : ''}">${h.label}</div>
        <div class="text-[9px] font-mono opacity-80 mt-0.5 ${isInk ? 'text-slate-800' : ''}" dir="ltr">${h.afternoonTime}</div>
      </td>`;
      days.forEach(day => {
        const slotKey = `${day} م___${h.id}`;
        html += renderSlotCell(scheduleMap[slotKey] || []);
      });
      html += `</tr>`;
    });

    html += `</tbody></table>`;
    return <div dangerouslySetInnerHTML={{ __html: html }} />;
  }
};
