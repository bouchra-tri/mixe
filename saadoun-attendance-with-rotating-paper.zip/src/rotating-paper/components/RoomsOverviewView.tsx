import React, { useState } from 'react';
import { Building2, Printer } from 'lucide-react';
import { AppData } from '../types';

interface RoomsOverviewViewProps {
  appData: AppData;
}

export const RoomsOverviewView: React.FC<RoomsOverviewViewProps> = ({ appData }) => {
  const [selectedRoom, setSelectedRoom] = useState<string>(appData.rooms[0] || '');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="bg-white rounded-xl shadow-xl p-6 border border-slate-200">
        
        <div className="flex items-center justify-between flex-wrap gap-4 pb-6 border-b border-slate-200 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-black text-lg shadow-md">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-slate-900">إدارة القاعات والمخابر والورشات</h2>
              <p className="text-xs text-slate-500">متابعة إشغال القاعات وتوزع الأنشطة عبرها</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-bold">
              <span>🏛️ اختر القاعة:</span>
              <select
                value={selectedRoom}
                onChange={(e) => setSelectedRoom(e.target.value)}
                className="bg-white text-emerald-800 font-extrabold p-1 rounded border border-slate-300 outline-none cursor-pointer"
              >
                {appData.rooms.map(r => (
                  <option key={r} value={r}>{r}</option>
                ))}
              </select>
            </div>

            <button
              onClick={() => window.print()}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow transition flex items-center gap-1.5"
            >
              <Printer className="w-4 h-4" />
              <span>طباعة</span>
            </button>
          </div>
        </div>

        {selectedRoom ? (
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-6">
            <h3 className="text-base font-black text-emerald-900 mb-4 flex items-center gap-2">
              <span>🏛️ جدول إشغال القاعة:</span>
              <span className="underline">{selectedRoom}</span>
            </h3>

            <div className="overflow-x-auto custom-scrollbar">
              <table className="timetable-table w-full bg-white">
                <thead>
                  <tr>
                    <th className="main-header p-2 bg-emerald-900 text-white text-xs font-black">الحصة / اليوم</th>
                    {appData.days.map(d => (
                      <th key={d} className="main-header p-2 bg-emerald-900 text-white text-xs font-black">{d}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {appData.hours.map(h => (
                    <tr key={h.id}>
                      <td className="sub-header p-2 bg-emerald-800 text-white text-xs font-black">{h.label}</td>
                      {appData.days.map(day => {
                        const slotKey = `${day} ص___${h.id}`;
                        const items = (appData.roomSchedules[selectedRoom] || {})[slotKey] || [];
                        return (
                          <td key={day} className="p-2 border border-slate-200 text-center text-xs">
                            {items.map(item => (
                              <div key={item.id} className="p-1.5 rounded bg-emerald-50 border border-emerald-200 mb-1 last:mb-0">
                                <div className="font-black text-emerald-900">{item.subject}</div>
                                {item.students && <div className="text-[10px] text-slate-600">👥 {item.students.join(', ')}</div>}
                              </div>
                            ))}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <div className="text-center py-12 text-slate-400 font-bold">لا توجد قاعات مسجلة في المشروع</div>
        )}

      </div>
    </div>
  );
};
