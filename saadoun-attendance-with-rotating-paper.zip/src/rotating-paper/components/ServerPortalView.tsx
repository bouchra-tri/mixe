import React, { useState, useEffect, useRef } from 'react';
import QRCode from 'qrcode';
import {
  Globe,
  Clock,
  Search,
  Maximize2,
  Minimize2,
  Users,
  GraduationCap,
  Building2,
  Calendar,
  Sparkles,
  Share2,
  CheckCircle2,
  BookOpen,
  ArrowRight
} from 'lucide-react';
import { AppData, SlotItem } from '../types';
import { TimetableGrid } from './TimetableGrid';

interface ServerPortalViewProps {
  appData: AppData;
  onSelectEntity?: (type: 'classes' | 'teachers', id: string) => void;
}

export const ServerPortalView: React.FC<ServerPortalViewProps> = ({ appData, onSelectEntity }) => {
  const [activePortalTab, setActivePortalTab] = useState<'classes' | 'teachers' | 'rooms' | 'live'>('classes');
  const [selectedEntityId, setSelectedEntityId] = useState<string>(appData.groups[0] || '');
  const [searchFilter, setSearchFilter] = useState('');
  const [currentTimeStr, setCurrentTimeStr] = useState('');
  const [currentDayName, setCurrentDayName] = useState('');
  const [currentPeriodMatch, setCurrentPeriodMatch] = useState<{ label: string; time: string; period: 'ص' | 'م' } | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [displayTheme, setDisplayTheme] = useState<'light' | 'dark'>('light');

  const portalQrRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Live Clock & Current Session Tracker
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const timeFormatter = new Intl.DateTimeFormat('ar-DZ', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
      });
      setCurrentTimeStr(timeFormatter.format(now));

      const dayNames = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
      const dayIdx = now.getDay();
      const detectedDay = dayNames[dayIdx];
      setCurrentDayName(detectedDay);

      // Check current hour in appData.hours
      const hoursMinutes = now.getHours() * 60 + now.getMinutes();
      
      let matched = null;
      for (const h of appData.hours) {
        // Parse morning time e.g. "08:00 - 09:00"
        const parseTimeRange = (rangeStr: string) => {
          const parts = rangeStr.split(/[-–—]/).map(s => s.trim());
          if (parts.length === 2) {
            const [sh, sm] = parts[0].split(':').map(Number);
            const [eh, em] = parts[1].split(':').map(Number);
            return { start: sh * 60 + sm, end: eh * 60 + em };
          }
          return null;
        };

        const morningRange = parseTimeRange(h.morningTime);
        if (morningRange && hoursMinutes >= morningRange.start && hoursMinutes < morningRange.end) {
          matched = { label: h.label, time: h.morningTime, period: 'ص' as const };
          break;
        }

        const afternoonRange = parseTimeRange(h.afternoonTime);
        if (afternoonRange && hoursMinutes >= afternoonRange.start && hoursMinutes < afternoonRange.end) {
          matched = { label: h.label, time: h.afternoonTime, period: 'م' as const };
          break;
        }
      }
      setCurrentPeriodMatch(matched);
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [appData.hours]);

  // QR Code generator
  useEffect(() => {
    if (portalQrRef.current) {
      QRCode.toCanvas(
        portalQrRef.current,
        window.location.href,
        { width: 90, margin: 1, color: { dark: '#047857', light: '#ffffff' } },
        (err) => {
          if (err) console.error(err);
        }
      );
    }
  }, []);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen().catch(console.error);
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(console.error);
      setIsFullscreen(false);
    }
  };

  const copyPortalLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  // Switch tabs & set default selected
  const handleTabChange = (tab: 'classes' | 'teachers' | 'rooms' | 'live') => {
    setActivePortalTab(tab);
    setSearchFilter('');
    if (tab === 'classes') setSelectedEntityId(appData.groups[0] || '');
    if (tab === 'teachers') setSelectedEntityId(appData.teachers[0] || '');
    if (tab === 'rooms') setSelectedEntityId(appData.rooms[0] || '');
  };

  // Get active entity's schedule
  const currentScheduleMap: Record<string, SlotItem[]> = 
    activePortalTab === 'classes'
      ? (appData.groupSchedules[selectedEntityId] || {})
      : activePortalTab === 'teachers'
      ? (appData.teacherSchedules[selectedEntityId] || {})
      : {};

  const currentList =
    activePortalTab === 'classes'
      ? appData.groups
      : activePortalTab === 'teachers'
      ? appData.teachers
      : appData.rooms;

  const filteredList = currentList.filter(item =>
    item.toLowerCase().includes(searchFilter.trim().toLowerCase())
  );

  return (
    <div
      ref={containerRef}
      className={`min-h-full py-6 px-4 sm:px-6 lg:px-8 transition-colors duration-200 ${
        displayTheme === 'dark' ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'
      }`}
    >
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Server Portal Hero Banner */}
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white shadow-2xl p-6 sm:p-8 border border-emerald-700/40">
          <div className="absolute top-0 right-0 -mt-10 -mr-10 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>
          <div className="absolute bottom-0 left-0 -mb-10 -ml-10 w-64 h-64 bg-teal-500/10 rounded-full blur-3xl pointer-events-none"></div>

          <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            
            <div className="space-y-2">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-black border border-emerald-400/30">
                <Globe className="w-3.5 h-3.5 animate-pulse" />
                <span>البوابة الإلكترونية المباشرة لسيرفر المؤسسة</span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                <span>تصفح بدون طبع</span>
              </div>

              <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center gap-2">
                <span>{appData.institution}</span>
              </h1>

              <p className="text-xs sm:text-sm text-emerald-200/90 font-bold max-w-xl">
                المنصة الرقمية التفاعلية للولوج المباشر لكافة جداول التوقيت المدرسي (أقسام، أساتذة، قاعات) للعام الدراسي {appData.settings.schoolYear} عبر أي شاشة أو هاتف
              </p>
            </div>

            {/* Live Real-time Status Card */}
            <div className="bg-slate-950/60 backdrop-blur-md rounded-2xl p-4 border border-emerald-500/30 shadow-lg flex items-center gap-4 flex-shrink-0">
              <div className="text-right">
                <div className="text-[11px] font-bold text-emerald-400 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-emerald-400" />
                  <span>الوقت الفعلي (الجزائر):</span>
                </div>
                <div className="text-xl sm:text-2xl font-mono font-black text-white mt-0.5 tracking-wider" dir="ltr">
                  {currentTimeStr || '08:00:00'}
                </div>
                <div className="text-[11px] font-bold text-slate-300">
                  اليوم: <span className="text-emerald-300 font-black">{currentDayName || 'الأحد'}</span>
                </div>
              </div>

              <div className="h-12 w-px bg-slate-700/60"></div>

              <div>
                <canvas ref={portalQrRef} className="rounded-lg shadow-sm border border-emerald-500/40" />
                <div className="text-[9px] text-center text-emerald-300 font-bold mt-1">امسح للدخول</div>
              </div>
            </div>

          </div>

          {/* Quick Stats & Live Indicator Bar */}
          <div className="mt-6 pt-4 border-t border-emerald-700/40 flex items-center justify-between flex-wrap gap-4 text-xs font-bold">
            <div className="flex items-center gap-4 flex-wrap">
              <span className="flex items-center gap-1.5 text-emerald-200">
                <GraduationCap className="w-4 h-4 text-emerald-400" />
                <span>الأقسام: <b className="text-white">{appData.groups.length}</b></span>
              </span>
              <span className="flex items-center gap-1.5 text-emerald-200">
                <Users className="w-4 h-4 text-emerald-400" />
                <span>الأساتذة: <b className="text-white">{appData.teachers.length}</b></span>
              </span>
              <span className="flex items-center gap-1.5 text-emerald-200">
                <Building2 className="w-4 h-4 text-emerald-400" />
                <span>القاعات: <b className="text-white">{appData.rooms.length}</b></span>
              </span>
              <span className="flex items-center gap-1.5 text-emerald-200">
                <BookOpen className="w-4 h-4 text-emerald-400" />
                <span>الأنشطة: <b className="text-white">{Object.keys(appData.activities).length}</b></span>
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={copyPortalLink}
                className="bg-emerald-800/80 hover:bg-emerald-700 text-white px-3 py-1.5 rounded-xl border border-emerald-500/40 transition flex items-center gap-1.5"
                title="نسخ رابط البوابة للمشاركة"
              >
                {copiedLink ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" /> : <Share2 className="w-3.5 h-3.5" />}
                <span>{copiedLink ? 'تم نسخ الرابط!' : 'مشاركة الرابط'}</span>
              </button>

              <button
                onClick={toggleFullscreen}
                className="bg-slate-800 hover:bg-slate-700 text-white px-3 py-1.5 rounded-xl border border-slate-600 transition flex items-center gap-1.5"
                title="عرض على شاشة كاملة (لأجهزة العرض وشاشات المؤسسة)"
              >
                {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
                <span>{isFullscreen ? 'تصغير' : 'ملء الشاشة'}</span>
              </button>

              <button
                onClick={() => setDisplayTheme(displayTheme === 'light' ? 'dark' : 'light')}
                className="bg-slate-800 hover:bg-slate-700 text-white p-1.5 rounded-xl border border-slate-600 transition"
                title="تبديل مظهر الشاشة (فاتح / داكن)"
              >
                {displayTheme === 'light' ? '🌙' : '☀️'}
              </button>
            </div>
          </div>

        </div>

        {/* Current Active Period Notification */}
        {currentPeriodMatch && (
          <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-between flex-wrap gap-2 text-xs">
            <div className="flex items-center gap-2 text-emerald-800 font-extrabold">
              <Sparkles className="w-4 h-4 text-emerald-600 animate-spin" />
              <span>الحصة الجارية الآن في المؤسسة:</span>
              <span className="bg-emerald-600 text-white px-2 py-0.5 rounded-md">
                {currentPeriodMatch.label} ({currentPeriodMatch.time})
              </span>
            </div>
            <button
              onClick={() => setActivePortalTab('live')}
              className="text-emerald-700 hover:text-emerald-950 font-bold underline flex items-center gap-1"
            >
              <span>معاينة ما يدرسه كل قسم وقاعة الآن</span>
              <ArrowRight className="w-3.5 h-3.5 rotate-180" />
            </button>
          </div>
        )}

        {/* Navigation Tabs for Server Explorer */}
        <div className="flex items-center justify-between flex-wrap gap-4 border-b border-slate-200 pb-4">
          <div className="flex items-center bg-slate-200/80 p-1 rounded-2xl text-xs font-black shadow-inner">
            <button
              onClick={() => handleTabChange('classes')}
              className={`px-4 py-2 rounded-xl transition flex items-center gap-2 ${
                activePortalTab === 'classes'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-700 hover:text-slate-900'
              }`}
            >
              <GraduationCap className="w-4 h-4" />
              <span>جداول الأقسام ({appData.groups.length})</span>
            </button>

            <button
              onClick={() => handleTabChange('teachers')}
              className={`px-4 py-2 rounded-xl transition flex items-center gap-2 ${
                activePortalTab === 'teachers'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-700 hover:text-slate-900'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>جداول الأساتذة ({appData.teachers.length})</span>
            </button>

            <button
              onClick={() => handleTabChange('rooms')}
              className={`px-4 py-2 rounded-xl transition flex items-center gap-2 ${
                activePortalTab === 'rooms'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-700 hover:text-slate-900'
              }`}
            >
              <Building2 className="w-4 h-4" />
              <span>إشغال القاعات ({appData.rooms.length})</span>
            </button>

            <button
              onClick={() => handleTabChange('live')}
              className={`px-4 py-2 rounded-xl transition flex items-center gap-2 ${
                activePortalTab === 'live'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-700 hover:text-slate-900'
              }`}
            >
              <Clock className="w-4 h-4" />
              <span>الحصص الجارية الآن</span>
            </button>
          </div>

          {/* Quick Search */}
          {activePortalTab !== 'live' && (
            <div className="relative w-full sm:w-72">
              <input
                type="text"
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                placeholder={`بحث في ${
                  activePortalTab === 'classes'
                    ? 'الأقسام...'
                    : activePortalTab === 'teachers'
                    ? 'الأساتذة...'
                    : 'القاعات...'
                }`}
                className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-100 text-xs rounded-xl py-2 pr-3 pl-8 shadow-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
              <Search className="absolute left-2.5 top-2.5 w-4 h-4 text-slate-400" />
            </div>
          )}
        </div>

        {/* Dynamic Portal Content */}
        {activePortalTab === 'live' ? (
          // Live Real-Time Dashboard View
          <div className="space-y-6">
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xl">
              <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800 mb-6">
                <div>
                  <h2 className="text-lg font-black text-emerald-900 dark:text-emerald-400 flex items-center gap-2">
                    <span>⚡ نبض المؤسسة الآن: الحصص الجارية في هذا التوقيت</span>
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    متابعة فورية ومباشرة للأفواج والأساتذة والقاعات الشاغلة حالياً
                  </p>
                </div>
                <div className="text-xs font-bold px-3 py-1 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                  {currentDayName || 'الأحد'} - {currentPeriodMatch?.time || 'فترة الحصص'}
                </div>
              </div>

              {/* Grid of All Classes with their current active subject */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {appData.groups.map(group => {
                  const day = currentDayName || 'الأحد';
                  const period = currentPeriodMatch?.period || 'ص';
                  const hourId = appData.hours[0]?.id || 'حصة 1';
                  const slotKey = `${day} ${period}___${hourId}`;
                  const currentItems = (appData.groupSchedules[group] || {})[slotKey] || [];
                  const activeItem = currentItems[0];

                  return (
                    <div
                      key={group}
                      className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 hover:border-emerald-500 transition-all shadow-xs"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-black text-sm text-slate-900 dark:text-white">
                          👥 {group}
                        </span>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            activeItem
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : 'bg-slate-200 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                          }`}
                        >
                          {activeItem ? 'حصة دراسية نشطة' : 'فترة فراغ'}
                        </span>
                      </div>

                      {activeItem ? (
                        <div className="space-y-1 text-xs">
                          <div className="font-black text-emerald-800 dark:text-emerald-300 text-sm">
                            📚 {activeItem.subject}
                          </div>
                          <div className="text-slate-600 dark:text-slate-300 font-bold">
                            👨🏫 الأستاذ: {activeItem.teachers?.join(', ') || 'غير محدد'}
                          </div>
                          {activeItem.room && (
                            <div className="text-[11px] font-mono font-bold text-slate-500 dark:text-slate-400">
                              🏛️ القاعة: {activeItem.room}
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="text-xs text-slate-400 italic">لا توجد حصة مبرمجة حالياً</div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        ) : activePortalTab === 'rooms' ? (
          // Room Occupancy Explorer View
          <div className="space-y-6">
            {/* Quick Room Badges */}
            <div className="flex items-center gap-2 overflow-x-auto pb-2 custom-scrollbar">
              {filteredList.map(r => (
                <button
                  key={r}
                  onClick={() => setSelectedEntityId(r)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition ${
                    selectedEntityId === r
                      ? 'bg-emerald-600 text-white shadow-md'
                      : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:bg-slate-100'
                  }`}
                >
                  🏛️ {r}
                </button>
              ))}
            </div>

            {selectedEntityId && (
              <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xl">
                <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800 mb-6">
                  <div>
                    <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                      <span>🏛️ جدول إشغال القاعة:</span>
                      <span className="text-emerald-600 underline">{selectedEntityId}</span>
                    </h3>
                    <p className="text-xs text-slate-500">
                      توزع الحصص والأنشطة الأسبوعية داخل هذه القاعة
                    </p>
                  </div>
                </div>

                <div className="overflow-x-auto custom-scrollbar">
                  <table className="timetable-table w-full text-xs">
                    <thead>
                      <tr>
                        <th className="main-header p-2.5 bg-emerald-950 text-white font-black w-24">الحصة / اليوم</th>
                        {appData.days.map(d => (
                          <th key={d} className="main-header p-2.5 bg-emerald-900 text-white font-black">{d}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {appData.hours.map(h => (
                        <tr key={h.id}>
                          <td className="sub-header p-2 bg-emerald-900/90 text-white font-bold text-center">
                            <div>{h.label}</div>
                            <div className="text-[9px] font-mono opacity-80" dir="ltr">{h.morningTime}</div>
                          </td>
                          {appData.days.map(day => {
                            const slotKey = `${day} ص___${h.id}`;
                            const items = (appData.roomSchedules[selectedEntityId] || {})[slotKey] || [];
                            return (
                              <td key={day} className="p-2 border border-slate-200 dark:border-slate-800 text-center">
                                {items.length > 0 ? (
                                  items.map(it => (
                                    <div key={it.id} className="p-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/80 border border-emerald-300 dark:border-emerald-700">
                                      <div className="font-black text-emerald-900 dark:text-emerald-200">{it.subject}</div>
                                      <div className="text-[10px] text-slate-600 dark:text-slate-300 font-bold">
                                        👥 {it.students?.join(', ')}
                                      </div>
                                    </div>
                                  ))
                                ) : (
                                  <span className="text-slate-300 dark:text-slate-700 font-mono">—</span>
                                )}
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        ) : (
          // Classes or Teachers Timetable View on Screen
          <div className="space-y-6">
            
            {/* Quick Selector Badges */}
            <div className="flex items-center gap-2 overflow-x-auto pb-2 custom-scrollbar">
              {filteredList.map(item => (
                <button
                  key={item}
                  onClick={() => setSelectedEntityId(item)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-extrabold whitespace-nowrap transition ${
                    selectedEntityId === item
                      ? 'bg-emerald-600 text-white shadow-md'
                      : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  {activePortalTab === 'classes' ? '👥 ' : '👨🏫 '}
                  {item}
                </button>
              ))}
            </div>

            {/* Timetable Card Canvas on Screen */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-6">
              
              <div className="flex items-center justify-between flex-wrap gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center font-black text-xl shadow-lg">
                    {activePortalTab === 'classes' ? '👨🎓' : '👨🏫'}
                  </div>
                  <div>
                    <h2 className="text-lg sm:text-xl font-black text-slate-950 dark:text-white">
                      {activePortalTab === 'classes' ? 'جدول توقيت القسم:' : 'جدول توقيت الأستاذ(ة):'}{' '}
                      <span className="text-emerald-600 dark:text-emerald-400 underline">{selectedEntityId}</span>
                    </h2>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {appData.institution} • السنة الدراسية: {appData.settings.schoolYear}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 px-3 py-1.5 rounded-xl border border-emerald-300 dark:border-emerald-800">
                    {Object.values(currentScheduleMap).reduce((acc, curr) => acc + curr.length, 0)} حصة أسبوعية
                  </span>
                </div>
              </div>

              {/* The Schedule Grid Component */}
              <div className="overflow-x-auto custom-scrollbar">
                <TimetableGrid
                  scheduleMap={currentScheduleMap}
                  appData={appData}
                  mode={activePortalTab === 'classes' ? 'classes' : 'teachers'}
                />
              </div>

              {/* Server Note */}
              <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 font-bold">
                <div>منصة سيرفر الجداول الرسمية V3.2 • {appData.institution}</div>
                <div className="font-mono">fetprint.fetsync.org</div>
              </div>

            </div>

          </div>
        )}

      </div>
    </div>
  );
};
