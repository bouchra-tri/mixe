import React from 'react';
import { Save, RefreshCw, Edit3, FolderOpen, Sliders } from 'lucide-react';
import { AppData } from '../types';

interface SettingsViewProps {
  appData: AppData;
  onUpdateSettings: (newSettings: AppData['settings']) => void;
  onExportProject: () => void;
  onImportProject: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onResetToDefault: () => void;
  onOpenRenameModal: (type?: 'classes' | 'teachers') => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  appData,
  onUpdateSettings,
  onExportProject,
  onImportProject,
  onResetToDefault,
  onOpenRenameModal
}) => {
  const settings = appData.settings;

  const handleChange = (field: keyof AppData['settings'], val: any) => {
    const updated = { ...settings, [field]: val };
    onUpdateSettings(updated);
  };

  const handleColorChange = (subject: string, color: string) => {
    const updatedColors = { ...settings.subjectColors, [subject]: color };
    handleChange('subjectColors', updatedColors);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="bg-white rounded-xl shadow-xl p-6 sm:p-8 border border-slate-200 space-y-8">
        
        <div className="flex items-center justify-between pb-6 border-b border-slate-200 flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-black text-lg shadow-md">
              ⚙️
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-slate-900">إعدادات المنظومة وتخصيص المشروع</h2>
              <p className="text-xs text-slate-500">ضبط بيانات المؤسسة، ألوان المواد، وقوالب الطباعة والورقة الدوارة</p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => onOpenRenameModal()}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow transition flex items-center gap-1.5"
            >
              <Edit3 className="w-4 h-4" />
              <span>تعديل مسميات الأقسام والأساتذة</span>
            </button>

            <button
              onClick={onExportProject}
              className="bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow transition flex items-center gap-1.5"
              title="تصدير المشروع كاملاً بملف .fetpro"
            >
              <Save className="w-4 h-4 text-emerald-400" />
              <span>حفظ كملف .fetpro</span>
            </button>

            <label className="cursor-pointer bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs px-3.5 py-2 rounded-xl border border-slate-300 transition flex items-center gap-1.5">
              <FolderOpen className="w-4 h-4 text-emerald-600" />
              <span>فتح ملف .fetpro</span>
              <input type="file" accept=".fetpro,.json" className="hidden" onChange={onImportProject} />
            </label>

            <button
              onClick={onResetToDefault}
              className="bg-red-50 hover:bg-red-100 text-red-600 font-bold text-xs px-3 py-2 rounded-xl border border-red-200 transition flex items-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>إعادة ضبط المصنع</span>
            </button>
          </div>
        </div>

        {/* Project .fetpro highlight box */}
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-between flex-wrap gap-3">
          <div className="space-y-1">
            <h4 className="text-xs font-black text-emerald-950 flex items-center gap-1.5">
              <span>💾 حفظ المشروع بصيغة fetpro للاستعمال لاحقاً</span>
              <span className="bg-emerald-200 text-emerald-800 px-2 py-0.5 rounded text-[10px]">ميزة أساسية</span>
            </h4>
            <p className="text-[11px] text-emerald-800 font-medium">
              عند حفظ المشروع بصيغة <b className="font-mono">.fetpro</b> يتم تخزين كافة التعديلات، الأسماء الرسمية، ألوان المواد، وتخصيصات الورقة الدوارة للرجوع إليها في أي وقت دون الحاجة لإعادة التعديل.
            </p>
          </div>
          <button
            onClick={onExportProject}
            className="bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold px-4 py-2 rounded-xl shadow-xs transition flex items-center gap-1.5"
          >
            <Save className="w-3.5 h-3.5" />
            <span>تحميل ملف .fetpro الآن</span>
          </button>
        </div>

        {/* School & Header Info */}
        <div>
          <h3 className="text-sm font-black text-emerald-900 mb-4 pb-2 border-b border-slate-200">الترويسة الرسمية للمؤسسة</h3>
          <p className="mb-3 text-xs text-slate-600">اسم المؤسسة والمديرية والسنة الدراسية مرتبطة بإعدادات منصة الحضور وتُعدّل من هناك.</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs font-bold">
            <div>
              <label className="block text-slate-700 mb-1">اسم الجمهورية:</label>
              <input
                type="text"
                value={settings.republic}
                onChange={(e) => handleChange('republic', e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900"
              />
            </div>
            <div>
              <label className="block text-slate-700 mb-1">اسم الوزارة:</label>
              <input
                type="text"
                value={settings.ministry}
                onChange={(e) => handleChange('ministry', e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900"
              />
            </div>
            <div>
              <label className="block text-slate-700 mb-1">مديرية التربية:</label>
              <input
                type="text"
                value={settings.directorate}
                readOnly
                title="تُعدّل هذه البيانات من إعدادات المؤسسة في منصة الحضور"
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900"
              />
            </div>
            <div>
              <label className="block text-slate-700 mb-1">اسم المؤسسة:</label>
              <input
                type="text"
                value={settings.schoolName}
                readOnly
                title="تُعدّل هذه البيانات من إعدادات المؤسسة في منصة الحضور"
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900"
              />
            </div>
            <div>
              <label className="block text-slate-700 mb-1">عنوان جدول التوقيت:</label>
              <input
                type="text"
                value={settings.docTitle}
                onChange={(e) => handleChange('docTitle', e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900"
              />
            </div>
            <div>
              <label className="block text-slate-700 mb-1">السنة الدراسية:</label>
              <input
                type="text"
                value={settings.schoolYear}
                readOnly
                title="تُعدّل هذه البيانات من إعدادات المؤسسة في منصة الحضور"
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900"
              />
            </div>
            <div>
              <label className="block text-slate-700 mb-1">عنوان الورقة الدوارة:</label>
              <input
                type="text"
                value={settings.pointingTitle}
                onChange={(e) => handleChange('pointingTitle', e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900"
              />
            </div>
            <div>
              <label className="block text-slate-700 mb-1">صفة المشرف على الجناح:</label>
              <input
                type="text"
                value={settings.pointingSupervisorLabel}
                onChange={(e) => handleChange('pointingSupervisorLabel', e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900"
              />
            </div>
            <div>
              <label className="block text-slate-700 mb-1">صفة مستشار التربية / الناظر:</label>
              <input
                type="text"
                value={settings.pointingAdminLabel}
                onChange={(e) => handleChange('pointingAdminLabel', e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900"
              />
            </div>
          </div>
        </div>

        {/* Subject Colors Editor */}
        <div>
          <h3 className="text-sm font-black text-emerald-900 mb-4 pb-2 border-b border-slate-200">تخصيص ألوان المواد الدراسية</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {appData.subjects.map(subject => {
              const color = settings.subjectColors[subject] || '#047857';
              return (
                <div key={subject} className="flex items-center justify-between bg-slate-50 border border-slate-200 p-2.5 rounded-xl">
                  <span className="text-xs font-bold text-slate-800 truncate">{subject}</span>
                  <input
                    type="color"
                    value={color}
                    onChange={(e) => handleColorChange(subject, e.target.value)}
                    className="w-7 h-7 rounded cursor-pointer border-0 bg-transparent"
                  />
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </div>
  );
};
