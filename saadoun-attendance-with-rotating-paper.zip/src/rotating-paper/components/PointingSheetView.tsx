import React, { useState } from 'react';
import {
  Printer,
  BookOpen,
  CheckSquare,
  Square,
  HelpCircle
} from 'lucide-react';
import { AppData, SlotItem } from '../types';
import { ExportHubModal } from './ExportHubModal';

interface PointingSheetViewProps {
  appData: AppData;
  onUpdateSettings?: (settings: AppData['settings']) => void;
}

export const PointingSheetView: React.FC<PointingSheetViewProps> = ({ appData, onUpdateSettings }) => {
  // Periods in FET
  const allPeriods = [
    { key: 'الأحد ص', day: 'الأحد', period: 'ص', time: '08:00 - 12:00', label: 'الفترة الصباحية' },
    { key: 'الأحد م', day: 'الأحد', period: 'م', time: '13:00 - 17:00', label: 'الفترة المسائية' },
    { key: 'الإثنين ص', day: 'الإثنين', period: 'ص', time: '08:00 - 12:00', label: 'الفترة الصباحية' },
    { key: 'الإثنين م', day: 'الإثنين', period: 'م', time: '13:00 - 17:00', label: 'الفترة المسائية' },
    { key: 'الثلاثاء ص', day: 'الثلاثاء', period: 'ص', time: '08:00 - 12:00', label: 'الفترة الصباحية' },
    { key: 'الثلاثاء م', day: 'الثلاثاء', period: 'م', time: '13:00 - 17:00', label: 'الفترة المسائية' },
    { key: 'الأربعاء ص', day: 'الأربعاء', period: 'ص', time: '08:00 - 12:00', label: 'الفترة الصباحية' },
    { key: 'الأربعاء م', day: 'الأربعاء', period: 'م', time: '13:00 - 17:00', label: 'الفترة المسائية' },
    { key: 'الخميس ص', day: 'الخميس', period: 'ص', time: '08:00 - 12:00', label: 'الفترة الصباحية' },
    { key: 'الخميس م', day: 'الخميس', period: 'م', time: '13:00 - 17:00', label: 'الفترة المسائية' }
  ];

  const [selectedPeriodKey, setSelectedPeriodKey] = useState<string>('الأحد ص');
  const [distribution, setDistribution] = useState<string>('صفحة واحدة كاملة (x1 A4 - تدرج تلقائي)');
  const [paperOrientation, setPaperOrientation] = useState<'landscape' | 'portrait'>('landscape');
  const [template, setTemplate] = useState<string>('1. الكلاسيكي الرسمي (كما هو)');

  // Cell elements checkboxes matching image
  const [showSubject, setShowSubject] = useState<boolean>(true);
  const [showTeacher, setShowTeacher] = useState<boolean>(true);
  const [showRoom, setShowRoom] = useState<boolean>(true);
  const [showVisaSquare, setShowVisaSquare] = useState<boolean>(true);
  const [showAbsenceLines, setShowAbsenceLines] = useState<boolean>(true);
  const [isInkSaver, setIsInkSaver] = useState<boolean>(appData.settings.inkSaver || false);

  // Print all mode & Export Hub Modal
  const [isPrintAllMode, setIsPrintAllMode] = useState<boolean>(false);
  const [isExportHubOpen, setIsExportHubOpen] = useState<boolean>(false);

  const activePeriodObj = allPeriods.find(p => p.key === selectedPeriodKey) || allPeriods[0];
  const { settings } = appData;

  const handleInkSaverChange = (checked: boolean) => {
    setIsInkSaver(checked);
    if (checked) {
      document.body.classList.add('ink-saver-active');
    } else {
      document.body.classList.remove('ink-saver-active');
    }
  };

  const handlePrintCurrent = () => {
    setIsPrintAllMode(false);
    setTimeout(() => {
      window.print();
    }, 150);
  };

  const handlePrintAll = () => {
    setIsPrintAllMode(true);
    // Wait for all period pages to be mounted in the DOM
    setTimeout(() => {
      const onAfterPrint = () => {
        setIsPrintAllMode(false);
        window.removeEventListener('afterprint', onAfterPrint);
      };
      window.addEventListener('afterprint', onAfterPrint);
      window.print();
      // Fallback in case afterprint does not trigger
      setTimeout(() => setIsPrintAllMode(false), 4000);
    }, 350);
  };

  // 1. Distribution Chunking Logic: splits classes evenly into 1, 2, 3 or 4 pages
  const getChunkedGroups = () => {
    const groups = appData.groups;
    if (!groups || groups.length === 0) return [[]];

    let pagesCount = 1;
    if (distribution.includes('صفحتين')) pagesCount = 2;
    else if (distribution.includes('ثلاث صفحات')) pagesCount = 3;
    else if (distribution.includes('أربع صفحات')) pagesCount = 4;

    const chunkSize = Math.ceil(groups.length / pagesCount);
    const chunks: string[][] = [];
    for (let i = 0; i < groups.length; i += chunkSize) {
      chunks.push(groups.slice(i, i + chunkSize));
    }
    return chunks.length > 0 ? chunks : [groups];
  };

  // 2. Template Style Engine
  const getTemplateStyle = () => {
    if (template.includes('العصري')) {
      return {
        containerClass: 'tpl-modern-card border-2 border-emerald-400 bg-gradient-to-b from-white to-slate-50',
        headerBannerClass: 'bg-gradient-to-r from-emerald-700 via-teal-700 to-emerald-800 text-white shadow-md rounded-2xl',
        subBannerClass: 'bg-emerald-100 text-emerald-950 border border-emerald-300 rounded-full',
        tableHeaderClass: 'bg-[#064e3b] text-white',
        hourHeaderColor: 'text-emerald-200',
        borderColor: 'border-emerald-300',
        cellBg: 'bg-emerald-50/50',
        cardBorderRadius: 'rounded-xl',
        fontFamily: "'Cairo', sans-serif"
      };
    }
    if (template.includes('الأكاديمي الملكي')) {
      return {
        containerClass: 'tpl-royal-academic border-3 border-amber-800 bg-[#fffdfa]',
        headerBannerClass: 'bg-gradient-to-r from-amber-900 via-yellow-950 to-amber-900 text-amber-100 border border-amber-500 shadow-md rounded-2xl',
        subBannerClass: 'bg-amber-100 text-amber-950 border border-amber-400 rounded-full',
        tableHeaderClass: 'bg-[#451a03] text-white',
        hourHeaderColor: 'text-amber-300',
        borderColor: 'border-amber-300',
        cellBg: 'bg-amber-50/40',
        cardBorderRadius: 'rounded-lg',
        fontFamily: "'Amiri', serif"
      };
    }
    if (template.includes('المينيمالي')) {
      return {
        containerClass: 'tpl-minimal-grid border-2 border-black bg-white rounded-none',
        headerBannerClass: 'bg-black text-white rounded-none border-b-2 border-black',
        subBannerClass: 'bg-white text-black border border-black rounded-none',
        tableHeaderClass: 'bg-black text-white rounded-none',
        hourHeaderColor: 'text-white',
        borderColor: 'border-black',
        cellBg: 'bg-white',
        cardBorderRadius: 'rounded-none',
        fontFamily: "'IBM Plex Sans Arabic', sans-serif"
      };
    }
    if (template.includes('التقني الهندسي')) {
      return {
        containerClass: 'tpl-tech-blueprint border-2 border-cyan-700 bg-sky-50/30',
        headerBannerClass: 'bg-sky-950 text-cyan-200 border border-cyan-600 rounded-xl',
        subBannerClass: 'bg-sky-100 text-sky-950 border border-sky-400 rounded-md',
        tableHeaderClass: 'bg-[#082f49] text-cyan-100',
        hourHeaderColor: 'text-cyan-300',
        borderColor: 'border-sky-300',
        cellBg: 'bg-sky-50/50',
        cardBorderRadius: 'rounded-lg',
        fontFamily: "'Fira Code', 'Cairo', monospace"
      };
    }
    // Default: 1. الكلاسيكي الرسمي (كما هو)
    return {
      containerClass: 'tpl-classic-dz border-2 border-emerald-900 bg-white',
      headerBannerClass: 'bg-[#064e3b] text-white border border-emerald-600/40 rounded-full',
      subBannerClass: 'bg-emerald-700 text-emerald-50 border border-emerald-500/40 rounded-full',
      tableHeaderClass: 'bg-[#0f172a] text-white',
      hourHeaderColor: 'text-emerald-300',
      borderColor: 'border-slate-400',
      cellBg: 'bg-slate-50/90',
      cardBorderRadius: 'rounded',
      fontFamily: "'Cairo', sans-serif"
    };
  };

  const tplStyle = getTemplateStyle();
  const isPortrait = paperOrientation === 'portrait';

  // 3. Render a Single Sheet Page
  const renderSingleSheetPage = (
    periodObj: typeof activePeriodObj,
    groupChunk: string[],
    startIndex: number,
    pageNum: number,
    totalPages: number
  ) => {
    const hours = appData.hours;

    return (
      <div
        key={`${periodObj.key}_p${pageNum}`}
        style={{ fontFamily: tplStyle.fontFamily }}
        className={`pointing-canvas-wrapper a4-sheet-canvas bg-white text-slate-900 shadow-xl border p-4 sm:p-6 mb-8 page-break-after transition-all ${
          tplStyle.containerClass
        } ${isInkSaver ? 'ink-saver-active' : ''} ${
          isPortrait ? 'max-w-[780px] mx-auto' : 'max-w-[1100px] mx-auto'
        }`}
      >
        {/* Document Header Box */}
        <div className={`border p-3.5 mb-3 bg-white ${tplStyle.borderColor} rounded-xl`}>
          
          <div className="flex items-start justify-between text-xs font-bold text-slate-800 leading-tight">
            {/* Top Right */}
            <div className="text-right space-y-0.5">
              <div className="font-extrabold text-[11px] text-slate-900">{settings.republic}</div>
              <div className="text-[10px] text-emerald-900 font-bold flex items-center gap-1">
                <span>🏛️</span>
                <span>{settings.directorate}</span>
              </div>
            </div>

            {/* Top Center: School Name */}
            <div className="text-center">
              <div className="text-sm sm:text-base font-black text-slate-900 flex items-center justify-center gap-1.5">
                <span>🏫</span>
                <span>{settings.schoolName}</span>
              </div>
            </div>

            {/* Top Left */}
            <div className="text-left space-y-0.5">
              <div className="font-extrabold text-[11px] text-slate-900">{settings.ministry}</div>
              <div className="text-[10px] text-slate-600 font-mono flex items-center gap-1 justify-end">
                <span>📅</span>
                <span>السنة الدراسية: {settings.schoolYear}</span>
              </div>
            </div>
          </div>

          {/* Center Dark Green Banner with Distribution and Page details */}
          <div className="mt-2.5 text-center">
            <div className={`inline-block font-black px-6 py-1.5 text-xs sm:text-sm tracking-wide shadow-sm ${tplStyle.headerBannerClass}`}>
              📋 ورقة الحضور اليومي وتأشيرة الأساتذة (الورقة الدوارة){' '}
              {totalPages > 1 ? `(ورقة ${pageNum} من ${totalPages})` : `(ورقة كاملة (مجمعة))`}
            </div>
            
            <div className="mt-1">
              <span className={`inline-block text-[11px] font-black px-4 py-0.5 ${tplStyle.subBannerClass}`}>
                يوم: <span className="underline">{periodObj.day}</span> بتاريخ: ..... / ..... / 202.. م — {periodObj.label} ({periodObj.time})
              </span>
            </div>
          </div>

        </div>

        {/* The Main Pointing Table */}
        <div className="overflow-x-auto">
          <table className={`pointing-table timetable-table w-full border-collapse border ${tplStyle.borderColor} ${isPortrait ? 'text-[9.5px]' : 'text-[11px]'}`}>
            <thead>
              <tr className={`${tplStyle.tableHeaderClass} text-center font-black`}>
                <th className={`p-1.5 border ${tplStyle.borderColor} ${isPortrait ? 'w-6 text-[9px]' : 'w-8 text-[10px]'}`}>N°</th>
                <th className={`p-1.5 border ${tplStyle.borderColor} ${isPortrait ? 'w-24 text-[9.5px]' : 'w-32 sm:w-36 text-center'}`}>
                  <div>القسم / الفوج</div>
                  <div className="text-[8.5px] font-normal opacity-80">(غيابات سابقة)</div>
                </th>

                {hours.map((h) => (
                  <th key={h.id} className={`p-1.5 border ${tplStyle.borderColor} ${isPortrait ? 'min-w-[85px]' : 'min-w-[130px]'}`}>
                    <div className={`font-black ${isPortrait ? 'text-[10px]' : 'text-xs'} ${tplStyle.hourHeaderColor}`}>{h.label}</div>
                    <div className="text-[8.5px] font-mono opacity-80" dir="ltr">
                      {periodObj.period === 'ص' ? h.morningTime : h.afternoonTime}
                    </div>
                  </th>
                ))}

                <th className={`p-1.5 border ${tplStyle.borderColor} ${isPortrait ? 'min-w-[70px] text-[9.5px]' : 'min-w-[110px] text-xs'}`}>
                  <div>التحرير الإداري</div>
                  <div>والملاحظات</div>
                </th>
              </tr>
            </thead>

            <tbody>
              {groupChunk.map((group, localIdx) => {
                const globalIndex = startIndex + localIdx + 1;
                const gSched = appData.groupSchedules[group] || {};

                return (
                  <tr key={group} className="hover:bg-slate-50/60 border-b border-slate-300">
                    {/* Index */}
                    <td className={`p-1 border ${tplStyle.borderColor} text-center font-mono font-black text-slate-700 bg-slate-50/50`}>
                      {globalIndex}
                    </td>

                    {/* Group Name & Past Absences line */}
                    <td className={`p-1 border ${tplStyle.borderColor} text-center bg-slate-50/80 align-middle`}>
                      <div className={`font-black text-slate-950 truncate ${isPortrait ? 'text-[10px]' : 'text-xs'}`}>{group}</div>
                      <div className="text-[8.5px] text-slate-500 font-mono mt-0.5 pt-0.5 border-t border-dashed border-slate-300">
                        غ.س: ........
                      </div>
                    </td>

                    {/* Hour Slots */}
                    {hours.map((h) => {
                      const slotKey = `${periodObj.day} ${periodObj.period}___${h.id}`;
                      const items: SlotItem[] = gSched[slotKey] || [];

                      return (
                        <td key={h.id} className={`p-1 border ${tplStyle.borderColor} align-top text-right min-h-[50px]`}>
                          {showAbsenceLines && (
                            <div className="text-[8.5px] font-bold text-red-600 mb-0.5 flex items-center justify-between">
                              <span className="font-black">الغياب:</span>
                              <span className="font-mono text-slate-400">...........</span>
                            </div>
                          )}

                          {items.length === 0 ? (
                            <div className="text-center py-1.5 text-slate-400 italic text-[10px] font-medium">
                              فراغ
                            </div>
                          ) : (
                            <div className="space-y-1">
                              {items.map((it, itIdx) => (
                                <div
                                  key={itIdx}
                                  className={`pointing-cell-inner rounded p-1 border border-slate-300/80 flex items-start justify-between gap-1 ${tplStyle.cellBg} ${isPortrait ? 'text-[9px]' : 'text-[10px]'}`}
                                >
                                  <div className="min-w-0 flex-1 leading-tight">
                                    {showSubject && (
                                      <div className={`font-black text-slate-900 truncate ${isPortrait ? 'text-[9.5px]' : 'text-[10.5px]'}`}>
                                        {it.subject} {it.subgroup ? `(${it.subgroup})` : ''}
                                      </div>
                                    )}

                                    {showTeacher && it.teachers && it.teachers.length > 0 && (
                                      <div className="text-[8.5px] text-slate-600 font-bold truncate mt-0.5">
                                        ({it.teachers.join(' - ')})
                                      </div>
                                    )}

                                    {showRoom && it.room && (
                                      <div className="text-[8px] font-mono text-slate-500 font-bold mt-0.5">
                                        [{it.room}]
                                      </div>
                                    )}
                                  </div>

                                  {/* Stamp / Visa Square */}
                                  {showVisaSquare && (
                                    <div
                                      className="w-4 h-4 sm:w-5 sm:h-5 rounded border border-slate-400 bg-white flex items-center justify-center text-[9px] sm:text-[10px] flex-shrink-0 shadow-2xs mt-0.5"
                                      title="مربع تأشيرة الأستاذ"
                                    >
                                      <span className="opacity-60 text-slate-500">✍️</span>
                                    </div>
                                  )}
                                </div>
                              ))}
                            </div>
                          )}
                        </td>
                      );
                    })}

                    {/* Admin remarks column */}
                    <td className={`p-1 border ${tplStyle.borderColor} bg-white text-slate-300 text-center`}></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Official Algerian Signatures Footer */}
        <div className={`mt-3.5 pt-2 border-t border-slate-400 flex items-center justify-between font-bold text-slate-800 ${isPortrait ? 'text-[9.5px]' : 'text-[11px]'}`}>
          <div className="text-right">
            <div className="font-black">{settings.pointingSupervisorLabel}</div>
            <div className="text-[8.5px] text-slate-500">(التأشيرة والاسم)</div>
          </div>

          <div className="text-center text-[9px] text-slate-500 font-mono">
            {totalPages > 1 && `[صفحة ${pageNum} من ${totalPages}]`}
          </div>

          <div className="text-left">
            <div className="font-black">{settings.pointingAdminLabel}</div>
            <div className="text-[8.5px] text-slate-500">(التوقيع والملاحظات)</div>
          </div>
        </div>

      </div>
    );
  };

  const chunks = getChunkedGroups();

  return (
    <div className="max-w-7xl mx-auto space-y-5">
      
      {/* Dynamic Print CSS */}
      <style>{`
        @media print {
          @page {
            size: A4 ${paperOrientation};
            margin: 4.5mm;
          }
          .no-print, header, aside, .navbar, #settingsPanel, #toast {
            display: none !important;
          }
          body {
            background: #ffffff !important;
            padding: 0 !important;
            margin: 0 !important;
          }
          .pointing-canvas-wrapper {
            box-shadow: none !important;
            margin: 0 0 15px 0 !important;
            padding: 4mm !important;
            page-break-after: always !important;
            break-after: page !important;
            width: 100% !important;
            max-width: 100% !important;
          }
        }
      `}</style>

      {/* Main Control Card matching screenshot */}
      <div className="no-print bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        
        {/* Title & Subtitle */}
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-800 flex items-center justify-center text-xl flex-shrink-0">
            📝
          </div>
          <div>
            <h1 className="text-base sm:text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
              <span>ورقة الحضور اليومي وتأشيرة الأساتذة (الورقة الدوارة)</span>
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-bold mt-0.5">
              ضبط الحضور وغيابات التلاميذ وإمضاء الأساتذة - مع إظهار كامل الأقسام دون أي اقتطاع
            </p>
          </div>
        </div>

        {/* Row 1: Selectors Dropdowns (ALL 3 NOW FULLY FUNCTIONAL) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs font-bold pt-2">
          
          {/* Select Period */}
          <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2">
            <span className="text-slate-600 dark:text-slate-300 whitespace-nowrap">اختر الفترة:</span>
            <select
              value={selectedPeriodKey}
              onChange={(e) => setSelectedPeriodKey(e.target.value)}
              className="bg-transparent text-emerald-800 dark:text-emerald-400 font-black w-full outline-none cursor-pointer"
            >
              {allPeriods.map(p => (
                <option key={p.key} value={p.key} className="bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
                  {p.key}
                </option>
              ))}
            </select>
          </div>

          {/* 1. التوزيع: Active & Functional */}
          <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 border border-emerald-500/50 dark:border-emerald-500/50 rounded-xl px-3 py-2 shadow-2xs" title="توزيع الأقسام على صفحة واحدة أو عدة صفحات A4">
            <span className="text-emerald-800 dark:text-emerald-400 font-black whitespace-nowrap">التوزيع:</span>
            <select
              value={distribution}
              onChange={(e) => setDistribution(e.target.value)}
              className="bg-transparent text-slate-900 dark:text-slate-100 font-bold w-full outline-none cursor-pointer truncate"
            >
              <option value="صفحة واحدة كاملة (x1 A4 - تدرج تلقائي)">صفحة واحدة كاملة (x1 A4 - تدرج تلقائي)</option>
              <option value="صفحتين مقسمة (x2 A4 - نصفين)">صفحتين مقسمة (x2 A4 - نصفين)</option>
              <option value="ثلاث صفحات مقسمة (x3 A4 - أثلاث)">ثلاث صفحات مقسمة (x3 A4 - أثلاث)</option>
              <option value="أربع صفحات مقسمة (x4 A4)">أربع صفحات مقسمة (x4 A4)</option>
            </select>
          </div>

          {/* 2. اتجاه الورقة: Active & Functional */}
          <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 border border-emerald-500/50 dark:border-emerald-500/50 rounded-xl px-3 py-2 shadow-2xs" title="تغيير اتجاه الورقة بين الأفقي والعمودي">
            <span className="text-emerald-800 dark:text-emerald-400 font-black whitespace-nowrap">اتجاه الورقة:</span>
            <select
              value={paperOrientation}
              onChange={(e) => setPaperOrientation(e.target.value as any)}
              className="bg-transparent text-slate-900 dark:text-slate-100 font-bold w-full outline-none cursor-pointer"
            >
              <option value="landscape">أفقي (Landscape)</option>
              <option value="portrait">عمودي (Portrait)</option>
            </select>
          </div>

          {/* 3. قالب الورقة: Active & Functional */}
          <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 border border-emerald-500/50 dark:border-emerald-500/50 rounded-xl px-3 py-2 shadow-2xs" title="اختيار تصميم وثيقة الورقة الدوارة">
            <span className="text-emerald-800 dark:text-emerald-400 font-black whitespace-nowrap">قالب الورقة:</span>
            <select
              value={template}
              onChange={(e) => setTemplate(e.target.value)}
              className="bg-transparent text-slate-900 dark:text-slate-100 font-bold w-full outline-none cursor-pointer truncate"
            >
              <option value="1. الكلاسيكي الرسمي (كما هو)">1. الكلاسيكي الرسمي (كما هو)</option>
              <option value="2. العصري النيومورفي">2. العصري النيومورفي</option>
              <option value="3. الأكاديمي الملكي">3. الأكاديمي الملكي</option>
              <option value="4. المينيمالي الأحادي">4. المينيمالي الأحادي</option>
              <option value="5. التقني الهندسي">5. التقني الهندسي</option>
            </select>
          </div>

        </div>

        {/* Row 2: Action Buttons */}
        <div className="flex items-center justify-between flex-wrap gap-3 pt-2">
          
          <div className="flex items-center gap-2 flex-wrap">
            {/* Ink Saver */}
            <label className="flex items-center gap-1.5 bg-amber-50 dark:bg-amber-950/40 border border-amber-400 dark:border-amber-600 px-3 py-2 rounded-xl text-xs font-black text-amber-900 dark:text-amber-200 cursor-pointer shadow-2xs">
              <input
                type="checkbox"
                checked={isInkSaver}
                onChange={(e) => handleInkSaverChange(e.target.checked)}
                className="w-4 h-4 text-amber-600 rounded bg-white dark:bg-slate-800"
              />
              <span>🖨️ توفير الحبر</span>
            </label>

            {/* Print Current Period */}
            <button
              onClick={handlePrintCurrent}
              className="bg-emerald-700 hover:bg-emerald-800 text-white font-black text-xs px-4 py-2 rounded-xl shadow-md transition flex items-center gap-1.5"
            >
              <Printer className="w-4 h-4" />
              <span>طباعة الفترة الحالية</span>
            </button>

            {/* Print All Week */}
            <button
              onClick={handlePrintAll}
              className="bg-slate-900 hover:bg-slate-800 text-white font-black text-xs px-4 py-2 rounded-xl shadow-md transition flex items-center gap-1.5"
            >
              <BookOpen className="w-4 h-4 text-emerald-400" />
              <span>طباعة كل فترات الأسبوع</span>
            </button>

            {/* Export Hub Trigger with tray icon */}
            <button
              onClick={() => setIsExportHubOpen(true)}
              className="bg-teal-700 hover:bg-teal-800 text-white font-black text-xs px-4 py-2 rounded-xl shadow-md transition flex items-center gap-1.5 cursor-pointer"
              title="فتح مركز التصدير الشامل لملفات Excel و Word و PDF"
            >
              <svg className="w-4 h-4 text-teal-200 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8" />
                <polyline points="16 6 12 2 8 6" />
                <line x1="12" y1="2" x2="12" y2="15" />
              </svg>
              <span>تصدير (Excel / Word / PDF)</span>
            </button>
          </div>

        </div>

        {/* Row 3: Cell Elements Checkboxes ("عناصر الخلية:") */}
        <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between flex-wrap gap-3 text-xs font-extrabold text-slate-800 dark:text-slate-200">
          
          <div className="flex items-center gap-3 flex-wrap">
            <span className="text-slate-500 dark:text-slate-400 font-black">عناصر الخلية:</span>

            <label className="flex items-center gap-1.5 cursor-pointer hover:text-emerald-700">
              <input
                type="checkbox"
                checked={showSubject}
                onChange={(e) => setShowSubject(e.target.checked)}
                className="w-3.5 h-3.5 text-emerald-600 rounded"
              />
              <span>إظهار المادة</span>
            </label>

            <label className="flex items-center gap-1.5 cursor-pointer hover:text-emerald-700">
              <input
                type="checkbox"
                checked={showTeacher}
                onChange={(e) => setShowTeacher(e.target.checked)}
                className="w-3.5 h-3.5 text-emerald-600 rounded"
              />
              <span>إظهار الأستاذ</span>
            </label>

            <label className="flex items-center gap-1.5 cursor-pointer hover:text-emerald-700">
              <input
                type="checkbox"
                checked={showRoom}
                onChange={(e) => setShowRoom(e.target.checked)}
                className="w-3.5 h-3.5 text-emerald-600 rounded"
              />
              <span>إظهار القاعة</span>
            </label>

            <label className="flex items-center gap-1.5 cursor-pointer hover:text-emerald-700">
              <input
                type="checkbox"
                checked={showVisaSquare}
                onChange={(e) => setShowVisaSquare(e.target.checked)}
                className="w-3.5 h-3.5 text-emerald-600 rounded"
              />
              <span>✍️ مربع التأشيرة</span>
            </label>

            <label className="flex items-center gap-1.5 cursor-pointer hover:text-emerald-700">
              <input
                type="checkbox"
                checked={showAbsenceLines}
                onChange={(e) => setShowAbsenceLines(e.target.checked)}
                className="w-3.5 h-3.5 text-emerald-600 rounded"
              />
              <span>✏️ أسطر التنقيط للغياب</span>
            </label>
          </div>

          {/* Hint Callout badge */}
          <div className="text-[11px] font-bold text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-3 py-1 rounded-full border border-slate-200 dark:border-slate-700 flex items-center gap-1">
            <span>💡</span>
            <span>تدعم الخلايا تلقائياً إظهار كامل أساتذة الفوج في حصص التفويج (TD / TP).</span>
          </div>

        </div>

      </div>

      {/* Visual Canvas Container */}
      <div className="space-y-6">
        
        {/* Banner above canvas */}
        <div className="no-print text-center">
          <span className="inline-flex items-center gap-1.5 text-xs font-black text-emerald-800 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950 px-4 py-1 rounded-full border border-emerald-300 dark:border-emerald-700 shadow-2xs">
            <span>📄</span>
            <span>
              معاينة الورقة {chunks.length > 1 ? `(موزعة على ${chunks.length} صفحات A4)` : '1 (ورقة كاملة (مجمعة))'} • {template} • {paperOrientation === 'landscape' ? 'أفقي' : 'عمودي'}
            </span>
          </span>
        </div>

        {/* If Print All mode is active, render sheets for all periods */}
        {isPrintAllMode ? (
          allPeriods.map((p) => {
            const chunkSize = Math.ceil(appData.groups.length / chunks.length);
            return chunks.map((chunk, cIdx) =>
              renderSingleSheetPage(p, chunk, cIdx * chunkSize, cIdx + 1, chunks.length)
            );
          })
        ) : (
          chunks.map((chunk, cIdx) => {
            const chunkSize = Math.ceil(appData.groups.length / chunks.length);
            return renderSingleSheetPage(activePeriodObj, chunk, cIdx * chunkSize, cIdx + 1, chunks.length);
          })
        )}
      </div>

      {/* Export Hub Modal matching image_6f65108c.png */}
      <ExportHubModal
        isOpen={isExportHubOpen}
        onClose={() => setIsExportHubOpen(false)}
        appData={appData}
        activePeriodKey={selectedPeriodKey}
        allPeriods={allPeriods}
        showSubject={showSubject}
        showTeacher={showTeacher}
        showRoom={showRoom}
        showVisaSquare={showVisaSquare}
        showAbsenceLines={showAbsenceLines}
        distribution={distribution}
        template={template}
        paperOrientation={paperOrientation}
        chunkedGroups={chunks}
        onTriggerPrint={(scope) => {
          if (scope === 'all') {
            handlePrintAll();
          } else {
            handlePrintCurrent();
          }
        }}
      />

    </div>
  );
};
