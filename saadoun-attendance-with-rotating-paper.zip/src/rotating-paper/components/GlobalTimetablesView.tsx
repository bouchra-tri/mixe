import React, { useState } from 'react';
import { Printer } from 'lucide-react';
import { AppData } from '../types';
import { TimetableGrid } from './TimetableGrid';

interface GlobalTimetablesViewProps {
  appData: AppData;
}

export const GlobalTimetablesView: React.FC<GlobalTimetablesViewProps> = ({ appData }) => {
  const [globalSubMode, setGlobalSubMode] = useState<'classes_global' | 'teachers_global'>('classes_global');
  const [selectedDayFilter, setSelectedDayFilter] = useState<string>('ALL');

  const list = globalSubMode === 'classes_global' ? appData.groups : appData.teachers;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="bg-white rounded-xl shadow-xl p-6 border border-slate-200">
        
        <div className="flex items-center justify-between flex-wrap gap-4 pb-6 border-b border-slate-200 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-black text-lg shadow-md">
              📊
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-slate-900">الجداول العامة الموحدة</h2>
              <p className="text-xs text-slate-500">عرض شامل لجميع جداول {globalSubMode === 'classes_global' ? 'الأقسام' : 'الأساتذة'} دفعة واحدة</p>
            </div>
          </div>

          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs font-bold">
              <button
                onClick={() => setGlobalSubMode('classes_global')}
                className={`px-3 py-1.5 rounded-lg transition ${globalSubMode === 'classes_global' ? 'bg-emerald-600 text-white shadow' : 'text-slate-600 hover:text-slate-900'}`}
              >
                جداول كل الأقسام
              </button>
              <button
                onClick={() => setGlobalSubMode('teachers_global')}
                className={`px-3 py-1.5 rounded-lg transition ${globalSubMode === 'teachers_global' ? 'bg-emerald-600 text-white shadow' : 'text-slate-600 hover:text-slate-900'}`}
              >
                جداول كل الأساتذة
              </button>
            </div>

            <div className="flex items-center gap-1.5 bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-bold">
              <span>📅 فلترة اليوم:</span>
              <select
                value={selectedDayFilter}
                onChange={(e) => setSelectedDayFilter(e.target.value)}
                className="bg-white text-emerald-800 font-extrabold p-1 rounded border border-slate-300 outline-none cursor-pointer"
              >
                <option value="ALL">جميع أيام الأسبوع</option>
                {appData.days.map(d => (
                  <option key={d} value={d}>يوم {d} فقط</option>
                ))}
              </select>
            </div>

            <button
              onClick={() => window.print()}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow transition flex items-center gap-1.5"
            >
              <Printer className="w-4 h-4" />
              <span>طباعة الكل</span>
            </button>
          </div>
        </div>

        <div className="space-y-12">
          {list.map(itemName => {
            const scheduleMap = globalSubMode === 'classes_global'
              ? (appData.groupSchedules[itemName] || {})
              : (appData.teacherSchedules[itemName] || {});

            return (
              <div key={itemName} className="border border-slate-200 rounded-xl p-6 bg-slate-50/50 shadow-sm page-break-after">
                <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-300">
                  <h3 className="font-black text-emerald-900 text-base sm:text-lg flex items-center gap-2">
                    <span>📌</span>
                    <span>{globalSubMode === 'classes_global' ? 'القسم:' : 'الأستاذ(ة):'} {itemName}</span>
                  </h3>
                  <span className="text-xs font-bold bg-emerald-100 text-emerald-800 px-2.5 py-1 rounded-full">
                    {appData.institution}
                  </span>
                </div>

                <div className="overflow-x-auto custom-scrollbar">
                  <TimetableGrid
                    scheduleMap={scheduleMap}
                    appData={appData}
                    mode={globalSubMode === 'classes_global' ? 'classes' : 'teachers'}
                  />
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </div>
  );
};
