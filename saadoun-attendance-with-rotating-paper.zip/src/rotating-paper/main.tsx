import React, { useEffect, useState } from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { HostSchool, isHostSchool } from './host';
import './index.css';

function EmbeddedPaper() {
  const [school, setSchool] = useState<HostSchool | null>(null);
  const embedded = window.parent !== window;
  useEffect(() => {
    if (!embedded) return;
    const receive = (event: MessageEvent) => {
      if (event.origin !== window.location.origin || event.source !== window.parent) return;
      if (event.data?.type === 'saadoun:paper-context' && isHostSchool(event.data.school)) {
        setSchool(event.data.school);
      }
    };
    window.addEventListener('message', receive);
    window.parent.postMessage({ type: 'saadoun:paper-ready' }, window.location.origin);
    return () => window.removeEventListener('message', receive);
  }, [embedded]);
  useEffect(() => {
    if (school) window.parent.postMessage({ type: 'saadoun:paper-mounted' }, window.location.origin);
  }, [school]);
  if (!embedded) return <p className="p-8 text-center">افتح الورقة الدوارة من قائمة <a href="/" className="underline">منصة الحضور</a> بعد تسجيل الدخول.</p>;
  if (!school) return <p role="status" className="p-8 text-center">جارٍ تحميل بيانات المؤسسة…</p>;
  return <App hostSchool={school} />;
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode><EmbeddedPaper /></React.StrictMode>,
);
