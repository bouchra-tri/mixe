import { AppData, Activity, SlotItem, HourConfig } from '../types';
import { DEFAULT_SUBJECT_COLORS } from './constants';

export function getAutoColor(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  const hue = Math.abs(hash % 360);
  return `hsl(${hue}, 65%, 40%)`;
}

export function resolveStudentGroups(studentName: string, appData: AppData): { group: string; subgroup: string }[] {
  if (!studentName) return [];
  const sTrim = studentName.trim();
  
  if (appData.groups.includes(sTrim)) {
    return [{ group: sTrim, subgroup: '' }];
  }
  
  for (const grp of appData.groups) {
    const subs = appData.subgroupMap[grp] || [];
    if (subs.includes(sTrim)) {
      let label = sTrim.startsWith(grp) ? sTrim.slice(grp.length) : sTrim;
      label = label.replace(/^[-_\s]+/, '').trim();
      return [{ group: grp, subgroup: label || sTrim }];
    }
  }
  
  const sortedGroups = [...appData.groups].sort((a, b) => b.length - a.length);
  for (const grp of sortedGroups) {
    if (sTrim.startsWith(grp)) {
      let remainder = sTrim.slice(grp.length).replace(/^[-_\s]+/, '').trim();
      return [{ group: grp, subgroup: remainder }];
    }
  }

  const cleanTarget = sTrim.replace(/[\s\-_]/g, '');
  for (const grp of sortedGroups) {
    const cleanGrp = grp.replace(/[\s\-_]/g, '');
    if (cleanTarget.startsWith(cleanGrp)) {
      let remainder = cleanTarget.slice(cleanGrp.length);
      return [{ group: grp, subgroup: remainder }];
    }
  }

  return [{ group: sTrim, subgroup: '' }];
}

export function buildSchedulesIndex(appData: AppData) {
  appData.groupSchedules = {};
  appData.teacherSchedules = {};
  appData.roomSchedules = {};

  appData.groups.forEach(g => { appData.groupSchedules[g] = {}; });
  appData.teachers.forEach(t => { appData.teacherSchedules[t] = {}; });
  appData.rooms.forEach(r => { appData.roomSchedules[r] = {}; });

  const hourIds = appData.hours.map(h => h.id);

  function findHourIndex(targetHour: string): number {
    if (!targetHour) return -1;
    const tTrim = targetHour.trim();
    let idx = hourIds.indexOf(tTrim);
    if (idx !== -1) return idx;

    idx = hourIds.findIndex(h => h.toLowerCase() === tTrim.toLowerCase());
    if (idx !== -1) return idx;

    const cleanTarget = tTrim.replace(/\s+/g, '');
    idx = hourIds.findIndex(h => h.replace(/\s+/g, '') === cleanTarget);
    if (idx !== -1) return idx;

    const tNum = tTrim.match(/\d+/);
    if (tNum) {
      idx = hourIds.findIndex(h => {
        const hNum = h.match(/\d+/);
        return hNum && hNum[0] === tNum[0];
      });
      if (idx !== -1) return idx;
    }
    return -1;
  }

  Object.values(appData.activities).forEach(act => {
    if (!act.day || !act.hour) return;
    
    let startHIdx = findHourIndex(act.hour);
    if (startHIdx === -1) return;

    let dayInfo = appData.dayMapping[act.day] || appData.dayMapping[act.day.trim()] || appData.dayMapping[act.day.replace(/\s+/g, '')];
    if (!dayInfo) {
      const canon = act.day.replace(/[\s\-_]*(ص|م|صباح|مساء|صباحا|مساءا|AM|PM)$/i, '').trim();
      const period = (/\bم\b|مساء|soir|afternoon|pm/i.test(act.day)) ? 'م' : 'ص';
      dayInfo = { realDay: canon, period };
    }

    const realDay = dayInfo.realDay;
    const period = dayInfo.period;
    const duration = parseInt(String(act.duration), 10) || 1;

    let resolvedRoom = act.room;
    if (!resolvedRoom && act.students && act.students.length === 1) {
      resolvedRoom = appData.groupHomeRooms[act.students[0]] || '';
    }
    if (!resolvedRoom && appData.subjectDefaultRooms[act.subject]) {
      resolvedRoom = appData.subjectDefaultRooms[act.subject];
    }

    for (let d = 0; d < duration; d++) {
      const currentHIdx = startHIdx + d;
      if (currentHIdx >= hourIds.length) break;
      const hourId = hourIds[currentHIdx];
      const slotKey = `${realDay} ${period}___${hourId}`;

      if (act.teachers) {
        act.teachers.forEach(tName => {
          if (!tName) return;
          if (!appData.teacherSchedules[tName]) appData.teacherSchedules[tName] = {};
          if (!appData.teacherSchedules[tName][slotKey]) appData.teacherSchedules[tName][slotKey] = [];
          const exists = appData.teacherSchedules[tName][slotKey].some(x => x.id === act.id);
          if (!exists) {
            appData.teacherSchedules[tName][slotKey].push({
              id: act.id,
              subject: act.subject,
              students: act.students,
              room: resolvedRoom,
              subgroup: ''
            });
          }
        });
      }

      if (act.students) {
        act.students.forEach(stName => {
          const targets = resolveStudentGroups(stName, appData);
          targets.forEach(({ group, subgroup }) => {
            if (!appData.groupSchedules[group]) appData.groupSchedules[group] = {};
            if (!appData.groupSchedules[group][slotKey]) appData.groupSchedules[group][slotKey] = [];
            const exists = appData.groupSchedules[group][slotKey].some(x => x.id === act.id && x.subgroup === subgroup);
            if (!exists) {
              let grpRoom = resolvedRoom || appData.groupHomeRooms[group] || '';
              appData.groupSchedules[group][slotKey].push({
                id: act.id,
                subject: act.subject,
                teachers: act.teachers,
                room: grpRoom,
                subgroup: subgroup
              });
            }
          });
        });
      }

      if (resolvedRoom) {
        if (!appData.roomSchedules[resolvedRoom]) appData.roomSchedules[resolvedRoom] = {};
        if (!appData.roomSchedules[resolvedRoom][slotKey]) appData.roomSchedules[resolvedRoom][slotKey] = [];
        const rExists = appData.roomSchedules[resolvedRoom][slotKey].some(x => x.id === act.id);
        if (!rExists) {
          appData.roomSchedules[resolvedRoom][slotKey].push({
            id: act.id,
            subject: act.subject,
            teachers: act.teachers,
            students: act.students
          });
        }
      }
    }
  });
}

export function parseFetXml(xmlString: string, currentData: AppData): boolean {
  try {
    const parser = new DOMParser();
    const xml = parser.parseFromString(xmlString, "text/xml");

    const instElem = xml.querySelector("Institution_Name");
    if (instElem && instElem.textContent && instElem.textContent.trim()) {
      currentData.institution = instElem.textContent.trim();
      currentData.settings.schoolName = currentData.institution;
    }

    function getCanonicalDay(str: string): string {
      if (!str) return '';
      let s = str.trim();
      s = s.replace(/^[0-9\s\-_.]+/, '').trim();
      s = s.replace(/[\s\-_]*(ص|م|صباح|مساء|صباحا|مساءا|AM|PM|Matin|Soir)$/i, '').trim();

      if (/أحد|احد|dimanche|sunday/i.test(s)) return 'الأحد';
      if (/اثنين|إثنين|lundi|monday/i.test(s)) return 'الإثنين';
      if (/ثلاث|mardi|tuesday/i.test(s)) return 'الثلاثاء';
      if (/أربع|اربع|mercredi|wednesday/i.test(s)) return 'الأربعاء';
      if (/خميس|jeudi|thursday/i.test(s)) return 'الخميس';
      if (/جمع|vendredi|friday/i.test(s)) return 'الجمعة';
      if (/سبت|samedi|saturday/i.test(s)) return 'السبت';
      return s;
    }

    currentData.dayMapping = {};
    const realDayNodes = xml.querySelectorAll("Real_Days_List > Real_Day > Name");
    let parsedRealDays: string[] = [];
    realDayNodes.forEach(rd => {
      if (rd.textContent) {
        const raw = rd.textContent.trim();
        const canon = getCanonicalDay(raw);
        if (canon && !parsedRealDays.includes(canon)) parsedRealDays.push(canon);
      }
    });

    const dayNodes = xml.querySelectorAll("Days_List > Day > Name");
    const rawDays: string[] = [];
    dayNodes.forEach(d => {
      if (d.textContent) {
        const raw = d.textContent.trim();
        if (raw) rawDays.push(raw);
      }
    });

    if (parsedRealDays.length > 0) {
      currentData.days = parsedRealDays;
    } else {
      const detected: string[] = [];
      rawDays.forEach(raw => {
        const canon = getCanonicalDay(raw);
        if (canon && !detected.includes(canon)) detected.push(canon);
      });
      if (detected.length > 0) currentData.days = detected;
    }

    rawDays.forEach((raw, idx) => {
      let period = 'ص';
      if (/\bم\b|مساء|soir|afternoon|pm/i.test(raw)) period = 'م';
      else if (/\bص\b|صباح|matin|morning|am/i.test(raw)) period = 'ص';
      else if (rawDays.length === currentData.days.length * 2) period = (idx % 2 === 0) ? 'ص' : 'م';

      let matchedReal = getCanonicalDay(raw);
      if (!currentData.days.includes(matchedReal)) {
        const approx = currentData.days.find(d => getCanonicalDay(d) === matchedReal);
        if (approx) matchedReal = approx;
        else if (currentData.days.length > 0) {
          const dayIdx = Math.floor(idx / 2) % currentData.days.length;
          matchedReal = currentData.days[dayIdx];
        }
      }

      const mapVal = { realDay: matchedReal, period };
      currentData.dayMapping[raw] = mapVal;
      currentData.dayMapping[raw.trim()] = mapVal;
      currentData.dayMapping[raw.replace(/\s+/g, ' ')] = mapVal;
      currentData.dayMapping[raw.replace(/\s+/g, '')] = mapVal;
    });

    const hourNodes = xml.querySelectorAll("Hours_List > Hour");
    if (hourNodes.length > 0) {
      const realHourNodes = xml.querySelectorAll("Real_Hours_List > Real_Hour");
      const realHourTimes: string[] = [];
      realHourNodes.forEach(rh => {
        const longName = rh.querySelector("Long_Name")?.textContent?.trim() || "";
        const rhName = rh.querySelector("Name")?.textContent?.trim() || "";
        const fullCombined = (longName + " " + rhName).trim();
        const timeMatch = fullCombined.match(/\d{1,2}:\d{2}\s*[-–—]\s*\d{1,2}:\d{2}/);
        if (timeMatch) realHourTimes.push(timeMatch[0]);
      });

      currentData.hours = [];
      hourNodes.forEach((hNode, idx) => {
        const hId = hNode.querySelector("Name")?.textContent?.trim() || `H${idx + 1}`;
        let hNumMatch = hId.match(/\d+/);
        let hIndex = hNumMatch ? hNumMatch[0] : (idx + 1);
        let hLabel = `الحصة ${hIndex}`;

        let morningTime = "08:00 - 09:00";
        let afternoonTime = "13:30 - 14:30";

        if (realHourTimes.length >= hourNodes.length * 2) {
          morningTime = realHourTimes[idx];
          afternoonTime = realHourTimes[hourNodes.length + idx];
        } else {
          const mHour = 8 + idx;
          morningTime = `${String(mHour).padStart(2, '0')}:00 - ${String(mHour + 1).padStart(2, '0')}:00`;
          const aHour = 13 + (idx >= 2 ? idx + 0.5 : idx);
          const aStartH = Math.floor(aHour);
          const aStartM = (aHour % 1 === 0) ? '30' : '00';
          const aEndH = Math.floor(aHour + 1);
          const aEndM = aStartM;
          afternoonTime = `${String(aStartH).padStart(2, '0')}:${aStartM} - ${String(aEndH).padStart(2, '0')}:${aEndM}`;
        }

        currentData.hours.push({ id: hId, label: hLabel, morningTime, afternoonTime });
      });
    }

    const subjectElems = xml.querySelectorAll("Subjects_List > Subject > Name");
    currentData.subjects = [];
    subjectElems.forEach(el => {
      if (el.textContent) {
        const sName = el.textContent.trim();
        if (sName && !currentData.subjects.includes(sName)) {
          currentData.subjects.push(sName);
          if (!currentData.settings.subjectColors[sName]) {
            currentData.settings.subjectColors[sName] = DEFAULT_SUBJECT_COLORS[sName] || getAutoColor(sName);
          }
        }
      }
    });

    const teacherElems = xml.querySelectorAll("Teachers_List > Teacher > Name");
    currentData.teachers = [];
    teacherElems.forEach(el => {
      if (el.textContent) {
        const tName = el.textContent.trim();
        if (tName && !currentData.teachers.includes(tName)) currentData.teachers.push(tName);
      }
    });

    currentData.rooms = [];
    const roomElems = xml.querySelectorAll("Rooms_List > Room > Name");
    roomElems.forEach(el => {
      if (el.textContent) {
        const rName = el.textContent.trim();
        if (rName && !currentData.rooms.includes(rName)) currentData.rooms.push(rName);
      }
    });

    currentData.groups = [];
    currentData.subgroupMap = {};
    const yearElems = xml.querySelectorAll("Students_List > Year");
    yearElems.forEach(yearEl => {
      const yNameEl = Array.from(yearEl.children).find(c => c.tagName === "Name");
      const yName = yNameEl && yNameEl.textContent ? yNameEl.textContent.trim() : "";
      const groupElems = yearEl.querySelectorAll("Group");
      
      if (groupElems.length > 0) {
        groupElems.forEach(grpEl => {
          const grpNameEl = Array.from(grpEl.children).find(c => c.tagName === "Name");
          if (grpNameEl && grpNameEl.textContent) {
            const gName = grpNameEl.textContent.trim();
            if (gName && !currentData.groups.includes(gName)) {
              currentData.groups.push(gName);
              currentData.subgroupMap[gName] = [];
              const subElems = grpEl.querySelectorAll("Subgroup > Name");
              subElems.forEach(sEl => {
                if (sEl.textContent) {
                  const subName = sEl.textContent.trim();
                  if (subName) currentData.subgroupMap[gName].push(subName);
                }
              });
            }
          }
        });
      } else if (yName) {
        if (!currentData.groups.includes(yName)) {
          currentData.groups.push(yName);
          currentData.subgroupMap[yName] = [];
        }
      }
    });

    xml.querySelectorAll("Activities_List > Activity > Students").forEach(stNode => {
      if (stNode.textContent) {
        const st = stNode.textContent.trim();
        if (st && !currentData.groups.includes(st)) {
          const isSub = Object.values(currentData.subgroupMap).some(arr => arr.includes(st));
          if (!isSub) {
            const matched = currentData.groups.some(g => st.startsWith(g) || g.startsWith(st));
            if (!matched) {
              currentData.groups.push(st);
              currentData.subgroupMap[st] = [];
            }
          }
        }
      }
    });

    currentData.groupHomeRooms = {};
    xml.querySelectorAll("Space_Constraints_List > ConstraintStudentsSetHomeRoom").forEach(c => {
      const stEl = c.querySelector("Students");
      const rmEl = c.querySelector("Room");
      if (stEl && rmEl && stEl.textContent && rmEl.textContent) {
        currentData.groupHomeRooms[stEl.textContent.trim()] = rmEl.textContent.trim();
      }
    });

    currentData.subjectDefaultRooms = {};
    xml.querySelectorAll("Space_Constraints_List > ConstraintSubjectPreferredRoom").forEach(c => {
      const subEl = c.querySelector("Subject");
      const rmEl = c.querySelector("Room");
      if (subEl && rmEl && subEl.textContent && rmEl.textContent) {
        currentData.subjectDefaultRooms[subEl.textContent.trim()] = rmEl.textContent.trim();
      }
    });
    xml.querySelectorAll("Space_Constraints_List > ConstraintSubjectPreferredRooms").forEach(c => {
      const subEl = c.querySelector("Subject");
      const rmEl = c.querySelector("Preferred_Room");
      if (subEl && rmEl && subEl.textContent && rmEl.textContent) {
        currentData.subjectDefaultRooms[subEl.textContent.trim()] = rmEl.textContent.trim();
      }
    });

    currentData.activities = {};
    xml.querySelectorAll("Activities_List > Activity").forEach(act => {
      const id = act.querySelector("Id") ? act.querySelector("Id")?.textContent?.trim() : null;
      if (!id) return;

      const teacherNodes = act.querySelectorAll("Teacher");
      const teachers: string[] = [];
      teacherNodes.forEach(tn => {
        if (tn.textContent) {
          const name = tn.textContent.trim();
          if (name) teachers.push(name);
        }
      });

      const subject = act.querySelector("Subject") ? act.querySelector("Subject")?.textContent?.trim() || '' : '';
      
      const studentNodes = act.querySelectorAll("Students");
      const students: string[] = [];
      studentNodes.forEach(sn => {
        if (sn.textContent) {
          const st = sn.textContent.trim();
          if (st) students.push(st);
        }
      });

      const durationStr = act.querySelector("Duration")?.textContent?.trim();
      const duration = durationStr ? parseInt(durationStr, 10) : 1;

      currentData.activities[id] = {
        id,
        teachers: teachers.length > 0 ? teachers : [''],
        subject,
        students,
        duration: isNaN(duration) || duration < 1 ? 1 : duration,
        room: '',
        day: '',
        hour: ''
      };
    });

    xml.querySelectorAll("Space_Constraints_List > ConstraintActivityPreferredRoom").forEach(rc => {
      const actId = rc.querySelector("Activity_Id") ? rc.querySelector("Activity_Id")?.textContent?.trim() : null;
      const room = rc.querySelector("Room") ? rc.querySelector("Room")?.textContent?.trim() || '' : '';
      if (actId && currentData.activities[actId] && room) currentData.activities[actId].room = room;
    });

    xml.querySelectorAll("Time_Constraints_List > ConstraintActivityPreferredStartingTime").forEach(tc => {
      const actId = tc.querySelector("Activity_Id") ? tc.querySelector("Activity_Id")?.textContent?.trim() : null;
      const day = tc.querySelector("Preferred_Day")?.textContent?.trim() || tc.querySelector("Day")?.textContent?.trim() || '';
      const hour = tc.querySelector("Preferred_Hour")?.textContent?.trim() || tc.querySelector("Hour")?.textContent?.trim() || '';
      if (actId && currentData.activities[actId]) {
        currentData.activities[actId].day = day;
        currentData.activities[actId].hour = hour;
      }
    });

    xml.querySelectorAll("Time_Constraints_List > ConstraintActivitiesSameStartingTime").forEach(stc => {
      const actIdNodes = stc.querySelectorAll("Activity_Id");
      const actIds = Array.from(actIdNodes).map(n => n.textContent?.trim() || '').filter(Boolean);
      if (actIds.length > 1) {
        const scheduled = actIds.map(id => currentData.activities[id]).find(a => a && a.day && a.hour);
        if (scheduled) {
          actIds.forEach(id => {
            if (currentData.activities[id] && (!currentData.activities[id].day || !currentData.activities[id].hour)) {
              currentData.activities[id].day = scheduled.day;
              currentData.activities[id].hour = scheduled.hour;
            }
          });
        }
      }
    });

    buildSchedulesIndex(currentData);
    return true;
  } catch (err) {
    console.error("XML parse error:", err);
    return false;
  }
}
