export const INITIAL_FET_XML_DATA = `<?xml version="1.0" encoding="UTF-8"?>
<fet version="7.10.5">
  <Mode>Mornings_Afternoons</Mode>
  <Institution_Name>ثانوية المتنبي</Institution_Name>
  <Comments>البرنامج الرسمي</Comments>
  <Days_List>
    <Number_of_Days>10</Number_of_Days>
    <Day><Name>الاحد ص</Name></Day>
    <Day><Name>الاحد م</Name></Day>
    <Day><Name>الاثنين ص</Name></Day>
    <Day><Name>الاثنين م</Name></Day>
    <Day><Name>الثلاثاء ص</Name></Day>
    <Day><Name>الثلاثاء م</Name></Day>
    <Day><Name>الاربعاء ص</Name></Day>
    <Day><Name>الاربعاء م</Name></Day>
    <Day><Name>الخميس ص</Name></Day>
    <Day><Name>الخميس م</Name></Day>
  </Days_List>
  <Hours_List>
    <Number_of_Hours>4</Number_of_Hours>
    <Hour><Name>حصة 1</Name></Hour>
    <Hour><Name>حصة 2</Name></Hour>
    <Hour><Name>حصة 3</Name></Hour>
    <Hour><Name>حصة 4</Name></Hour>
  </Hours_List>
  <Teachers_List>
    <Teacher><Name>أ. بن عيسى (رياضيات)</Name></Teacher>
    <Teacher><Name>أ. قاسمي (فيزياء)</Name></Teacher>
    <Teacher><Name>أ. بوعلام (عربية)</Name></Teacher>
    <Teacher><Name>أ. زروقي (إنجليزي)</Name></Teacher>
  </Teachers_List>
  <Students_List>
    <Year>
      <Name>جذع مشترك علوم</Name>
      <Group>
        <Name>ج م ع 1</Name>
        <Subgroup><Name>ج م ع 1 - أفواج1</Name></Subgroup>
        <Subgroup><Name>ج م ع 1 - أفواج2</Name></Subgroup>
      </Group>
      <Group>
        <Name>ج م ع 2</Name>
      </Group>
    </Year>
  </Students_List>
  <Subjects_List>
    <Subject><Name>رياضيات</Name></Subject>
    <Subject><Name>فيزياء</Name></Subject>
    <Subject><Name>عربية</Name></Subject>
    <Subject><Name>إنجليزية</Name></Subject>
  </Subjects_List>
  <Rooms_List>
    <Room><Name>قاعة 01</Name></Room>
    <Room><Name>قاعة 02</Name></Room>
    <Room><Name>مخبر الفيزياء</Name></Room>
  </Rooms_List>
  <Activities_List>
    <Activity>
      <Id>1</Id>
      <Teacher>أ. بن عيسى (رياضيات)</Teacher>
      <Subject>رياضيات</Subject>
      <Students>ج م ع 1</Students>
      <Duration>2</Duration>
    </Activity>
    <Activity>
      <Id>2</Id>
      <Teacher>أ. قاسمي (فيزياء)</Teacher>
      <Subject>فيزياء</Subject>
      <Students>ج م ع 1</Students>
      <Duration>2</Duration>
    </Activity>
  </Activities_List>
</fet>`;

export const DEFAULT_SUBJECT_COLORS: Record<string, string> = {
  "عربية": "#1d4ed8",
  "اللغة العربية": "#1d4ed8",
  "لغة عربية": "#1d4ed8",
  "عربية أ.م": "#2563eb",
  "أدب عربي": "#1d4ed8",
  "ادب عربي": "#1d4ed8",
  "رياضيات": "#b45309",
  "الرياضيات": "#b45309",
  "رياضيات أ.م": "#d97706",
  "فرنسية": "#be123c",
  "اللغة الفرنسية": "#be123c",
  "لغة فرنسية": "#be123c",
  "إنجليزية": "#6d28d9",
  "اللغة الإنجليزية": "#6d28d9",
  "فيزياء": "#0284c7",
  "علوم فيزيائية": "#0284c7",
  "علوم": "#047857",
  "علوم طبيعية": "#047857",
  "إجتماعيات": "#c2410c",
  "تاريخ وجغرافيا": "#c2410c",
  "ت إسلامية": "#0f766e",
  "التربية الإسلامية": "#0f766e",
  "فلسفة": "#7c2d12",
  "تكنولوجيا": "#4f46e5",
  "إعلام آلي": "#334155",
  "رياضة": "#ca8a04",
  "التربية البدنية": "#ca8a04"
};
