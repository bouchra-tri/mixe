export interface HourConfig {
  id: string;
  label: string;
  morningTime: string;
  afternoonTime: string;
}

export interface Activity {
  id: string;
  teachers: string[];
  subject: string;
  students: string[];
  duration: number;
  room: string;
  day: string;
  hour: string;
}

export interface SlotItem {
  id: string;
  subject: string;
  teachers?: string[];
  students?: string[];
  room?: string;
  subgroup?: string;
}

export interface AppSettings {
  republic: string;
  ministry: string;
  directorate: string;
  schoolName: string;
  docTitle: string;
  pointingTitle: string;
  pointingAdminLabel: string;
  pointingSupervisorLabel: string;
  pointingOrientation: 'landscape' | 'portrait';
  pointingPageLayout: string;
  pointingShowSubjects: boolean;
  pointingShowTeachers: boolean;
  pointingShowRooms: boolean;
  pointingShowSignatures: boolean;
  pointingShowAbsenceLines?: boolean;
  pointingDistribution?: string;
  pointingGroupBy?: 'teachers' | 'classes';
  pointingFontSize?: 'xs' | 'sm' | 'md' | 'lg';
  gridOrientation: 'days-cols' | 'days-rows';
  schoolYear: string;
  introText: string;
  showIntroClasses: boolean;
  showIntroTeachers: boolean;
  pageOrientation: string;
  template: string;
  theme: string;
  headerFont: string;
  inkSaver: boolean;
  printNUp: number;
  colorizeSubjects: boolean;
  showTeachers: boolean;
  showRooms: boolean;
  showClasses: boolean;
  projectSlug: string;
  serverUrl: string;
  footerNote: string;
  directorLabel: string;
  stampLabel: string;
  roomFont: string;
  darkMode?: boolean;
  subjectColors: Record<string, string>;
}

export interface AppData {
  institution: string;
  days: string[];
  dayMapping: Record<string, { realDay: string; period: string }>;
  hours: HourConfig[];
  teachers: string[];
  groups: string[];
  rooms: string[];
  subgroupMap: Record<string, string[]>;
  groupHomeRooms: Record<string, string>;
  subjectDefaultRooms: Record<string, string>;
  subjects: string[];
  activities: Record<string, Activity>;
  groupSchedules: Record<string, Record<string, SlotItem[]>>;
  teacherSchedules: Record<string, Record<string, SlotItem[]>>;
  roomSchedules: Record<string, Record<string, SlotItem[]>>;
  settings: AppSettings;
}
