import { ThemeColorId } from './theme';

export type GradeLevel = '1AM' | '2AM' | '3AM' | '4AM';

export interface Student {
  id: string; // e.g. "SA-2026-101"
  barcode: string; // e.g. "1012026101"
  nationalId: string; // رقم التعريف المدرسي الوطني
  firstName: string; // الاسم
  lastName: string; // اللقب
  gender: 'M' | 'F'; // ذكر / أنثى
  grade: GradeLevel; // المستوى الدراسي
  classroom: string; // e.g. "1م1", "1م2", "2م1", "3م2", "4م1"
  birthDate: string; // تاريخ الميلاد
  birthPlace?: string; // مكان الميلاد
  guardianName: string; // اسم الولي
  guardianPhone: string; // هاتف الولي
  address?: string; // العنوان
  photoUrl?: string;
  notes?: string;
  status?: 'active' | 'transferred' | 'suspended';
}

export type AttendanceStatus = 'present' | 'late' | 'excused' | 'absent';

export type PeriodType = 'morning' | 'afternoon';
export type PeriodId = 'm1' | 'm2' | 'm3' | 'a1' | 'a2' | 'a3';

export interface SchoolPeriod {
  id: PeriodId;
  name: string; // e.g. "الفترة الصباحية 1 (فوج 08:00)"
  shortName: string; // e.g. "ص 1 (08:00)"
  type: PeriodType; // 'morning' | 'afternoon'
  startTime: string; // e.g. "08:00"
  lateThreshold: string; // e.g. "08:05"
  cutoffTime: string; // e.g. "08:45"
  active?: boolean;
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  barcode: string;
  studentName: string;
  grade: GradeLevel;
  classroom: string;
  date: string; // YYYY-MM-DD
  timestamp: string; // HH:mm:ss
  fullDateTime: string; // ISO
  session: string; // 'm1' | 'm2' | 'm3' | 'a1' | 'a2' | 'a3' or 'morning' | 'afternoon'
  periodId?: PeriodId;
  status: AttendanceStatus;
  lateMinutes: number;
  device: 'scanner_gun' | 'camera' | 'manual' | 'simulator';
  excuseReason?: string;
  notes?: string;
  smsSent?: boolean;
  smsSentAt?: string;
  smsMessage?: string;
  notificationChannel?: 'sms' | 'whatsapp';
}

export interface SchoolSettings {
  schoolName: string;
  schoolType: string;
  wilaya: string;
  academicYear: string;
  principalName: string;
  counselorName: string;
  // Legacy fields preserved for backward compatibility
  morningStartTime: string; // "08:00"
  morningLateThreshold: string; // "08:05"
  morningCutoffTime: string; // "08:30"
  afternoonStartTime: string; // "13:30"
  afternoonLateThreshold: string; // "13:35"
  afternoonCutoffTime: string; // "14:00"
  // 3 morning and 3 afternoon periods for multi-cohort entry
  periods: SchoolPeriod[];
  soundAlerts: boolean;
  voiceAnnouncements: boolean;
  autoPrintLateTicket: boolean;
  smsSenderId?: string;
  smsAbsenceTemplate?: string;
  attendanceMode?: 'per_period' | 'daily';
  timezone?: string;
  themeColor?: ThemeColorId;
  customHexColor?: string;
  themeMode?: 'light' | 'dark' | 'system';
  headerText?: string;
  theme?: string;
  studyDays?: string[];
  autoAbsenceDetection?: boolean;
  scanDebounceMinutes?: number;
  smsNotice1Template?: string;
  smsNotice2Template?: string;
  smsNotice3Template?: string;
}

export * from './theme';

export interface ScanResult {
  type: 'success' | 'warning' | 'late' | 'error';
  title: string;
  message: string;
  student?: Student;
  record?: AttendanceRecord;
  timestamp: string;
  rawScannedCode?: string;
  details?: string;
  candidatesTested?: string[];
}

// -------------------------------------------------------------
// Absence Warning & Staged Notices System
// Stage 1: Day 4 of absence (إشعار 1 في اليوم الرابع من الغياب)
// Stage 2: After 1 week (المرحلة الثانية تعتبر إشعار 2 بعد أسبوع)
// Stage 3: 15 days from first day of absence (المرحلة الثالثة: إعذار رسمي بعد 15 يوماً من أول يوم غياب)
// -------------------------------------------------------------
export type AbsenceNoticeStage = 'notice_1' | 'notice_2' | 'formal_warning';
export type NoticeDeliveryChannel = 'sms' | 'whatsapp' | 'official_letter' | 'hand_delivered';
export type NoticeStatus = 'pending' | 'sent' | 'justified' | 'cancelled';

export interface AbsenceNotice {
  id: string;
  studentId: string;
  studentName: string;
  nationalId?: string;
  grade: GradeLevel;
  classroom: string;
  guardianName: string;
  guardianPhone: string;
  stage: AbsenceNoticeStage;
  absenceDaysCount: number;
  startDate: string;
  lastAbsenceDate: string;
  dueDate: string;
  sentDate?: string;
  status: NoticeStatus;
  channel?: NoticeDeliveryChannel;
  referenceNumber: string;
  excuseReason?: string;
  excuseDate?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface DatabaseBackupInfo {
  lastSaved: string;
  totalStudents: number;
  totalRecords: number;
  totalNotices: number;
  storageType: 'hybrid_server_local';
}

// -------------------------------------------------------------
// Timetable & Teacher Schedule Types (تواقيت التلاميذ والأساتذة)
// -------------------------------------------------------------
export type SchoolDay = 'sunday' | 'monday' | 'tuesday' | 'wednesday' | 'thursday';

export type TimetableSlotId = 'p1' | 'p2' | 'p3' | 'p4' | 'p5' | 'p6' | 'p7' | 'p8';

export interface TimetableSlotMeta {
  id: TimetableSlotId;
  label: string; // e.g. "الحصة الأولى"
  timeRange: string; // e.g. "08:00 - 09:00"
  periodType: 'morning' | 'afternoon';
  startTime: string; // "08:00"
  endTime: string; // "09:00"
}

export interface Teacher {
  id: string;
  name: string;
  subject: string;
  phone?: string;
  email?: string;
  weeklyHours?: number;
  color?: string;
}

export interface TimetableSession {
  id: string;
  day: SchoolDay;
  slotId: TimetableSlotId;
  classroom: string; // e.g. "1م1"
  grade: GradeLevel; // "1AM"
  subject: string; // e.g. "الرياضيات"
  teacherId: string;
  teacherName: string;
  room: string; // e.g. "قاعة 04"
  color?: string;
  group?: string;
  startTime?: string;
  endTime?: string;
  academicYear?: string;
}

export interface TimetableMetadata {
  id: string;
  name: string;
  academicYear: string;
  effectiveDate: string;
  effectiveFrom?: string;
  version: number;
  importedAt: string;
  sourceSheet?: string;
  sourceFileName?: string;
  sourceFile?: string;
  totalSessions: number;
  totalTeachers: number;
  totalClassrooms: number;
  isCurrent?: boolean;
  sessionsCount?: number;
}

export interface ImportComparisonReport {
  totalExtractedSessions: number;
  totalClassrooms: number;
  totalTeachers: number;
  totalRooms: number;
  sourceSheet: string;
  academicYear: string;
  teachersReport: {
    exactMatches: Array<{ excelName: string; matchedTeacher: Teacher }>;
    fuzzyMatches: Array<{ excelName: string; matchedTeacher: Teacher; similarity: number }>;
    unmatched: Array<{ excelName: string }>;
  };
  classroomsReport: {
    matched: string[];
    unmatched: string[];
  };
  roomsReport: {
    rooms: string[];
  };
  conflicts: Array<{
    type: string;
    day: SchoolDay;
    slotId: TimetableSlotId;
    timeRange: string;
    description: string;
    sessions: TimetableSession[];
  }>;
  afternoonTimingDiscrepancy: {
    hasDiscrepancy: boolean;
    importedStartTime: string;
    currentSystemStartTime: string;
    message: string;
  };
}

export interface StudentAbsentSubjectDetail {
  studentId: string;
  studentName: string;
  classroom: string;
  day: SchoolDay;
  slotId: TimetableSlotId;
  slotLabel: string;
  timeRange: string;
  subject: string;
  teacherName: string;
  room: string;
  isOngoingNow: boolean;
}

// -------------------------------------------------------------
// Teacher Accounts & Roll Call Recording System (نظام دخول وتسجيل الأساتذة)
// -------------------------------------------------------------
export type UserRole = 'admin' | 'teacher';

export interface AppUser {
  id: string; // e.g. "USR-ADMIN", "USR-TEA-01"
  username: string; // unique login identifier
  password?: string; // used for demo/server auth validation
  name: string; // e.g. "أ. بن صالح رشيد"
  role: UserRole; // 'admin' | 'teacher'
  teacherId?: string; // links to Teacher in timetableData
  assignedClassrooms: string[]; // e.g. ["1م1", "1م2", "2م1"]
  assignedSubjects: string[]; // e.g. ["الرياضيات"]
  phone?: string;
  email?: string;
  isActive: boolean;
  token?: string;
  isCustomAdminConfigured?: boolean;
  lastPasswordChange?: string;
  createdAt?: string;
  lastLogin?: string;
}

export type TeacherAttendanceStatus = 'unrecorded' | 'present' | 'absent' | 'late';
export type TeacherSessionStatus = 'draft' | 'submitted' | 'approved' | 'locked';

export interface TeacherStudentStatusRecord {
  studentId: string;
  studentName: string;
  status: TeacherAttendanceStatus;
  notes?: string;
  lateMinutes?: number;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  action: 'created' | 'updated' | 'submitted' | 'approved' | 'locked' | 'unlocked' | 'corrected';
  details: string;
  changes?: {
    studentId: string;
    studentName: string;
    oldStatus: string;
    newStatus: string;
    oldNotes?: string;
    newNotes?: string;
  }[];
}

export interface TeacherAttendanceSession {
  id: string; // e.g. "SES_2026-10-27_1M1_p1"
  date: string; // YYYY-MM-DD
  classroom: string; // e.g. "1م1"
  grade: GradeLevel;
  periodId: string; // "p1"..."p8" or "daily"
  periodLabel: string; // e.g. "الحصة الأولى (08:00 - 09:00)"
  subject: string; // e.g. "الرياضيات"
  teacherId: string; // e.g. "TEA-01"
  teacherName: string;
  teacherUsername: string;
  status: TeacherSessionStatus;
  records: TeacherStudentStatusRecord[];
  summary: {
    total: number;
    presentCount: number;
    absentCount: number;
    lateCount: number;
    unrecordedCount: number;
  };
  createdAt: string;
  updatedAt: string;
  submittedAt?: string;
  approvedAt?: string;
  approvedBy?: string;
  lockedAt?: string;
  lockedBy?: string;
  auditTrail: AuditLogEntry[];
}

export interface OfflineAttendanceDraft {
  localId: string;
  sessionId: string;
  date: string;
  classroom: string;
  grade: GradeLevel;
  periodId: string;
  periodLabel: string;
  subject: string;
  teacherId: string;
  teacherName: string;
  records: TeacherStudentStatusRecord[];
  status: TeacherSessionStatus;
  lastSavedLocal: string;
  syncState: 'pending' | 'saving' | 'synced' | 'failed';
  errorMessage?: string;
}

