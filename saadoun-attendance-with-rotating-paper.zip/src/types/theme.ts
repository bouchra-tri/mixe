export type ThemeColorId =
  | 'burgundy'
  | 'emerald'
  | 'blue'
  | 'red'
  | 'orange'
  | 'yellow'
  | 'purple'
  | 'pink'
  | 'gray'
  | 'amber'
  | 'rose'
  | 'slate'
  | 'custom';

export type ThemeColor = ThemeColorId;

export type ThemeMode = 'light' | 'dark' | 'system';

export interface ThemePalette {
  id: ThemeColorId;
  name: string;
  nameAr: string;
  primary: string;
  hover: string;
  active: string;
  light: string;
  border: string;
  ring: string;
  foreground: string;
  gradientFrom: string;
  gradientTo: string;
  laser: string;
  darkLight?: string;
  darkBorder?: string;
}

export interface ThemeConfig {
  color: ThemeColorId;
  customHex?: string;
  mode: ThemeMode;
}
