import {
  SchoolDay,
  TimetableSlotId,
  TimetableSlotMeta,
  Teacher,
  TimetableSession,
  Student,
  StudentAbsentSubjectDetail,
  GradeLevel,
} from '../types';

export const DAYS_OF_WEEK: { key: SchoolDay; label: string; short: string }[] = [
  { key: 'sunday', label: 'الأحد', short: 'أحد' },
  { key: 'monday', label: 'الإثنين', short: 'إثنين' },
  { key: 'tuesday', label: 'الثلاثاء', short: 'ثلاثاء' },
  { key: 'wednesday', label: 'الأربعاء', short: 'أربعاء' },
  { key: 'thursday', label: 'الخميس', short: 'خميس' },
];

export const TIMETABLE_SLOTS: TimetableSlotMeta[] = [
  {
    id: 'p1',
    label: 'الحصة 1',
    timeRange: '08:00 - 09:00',
    periodType: 'morning',
    startTime: '08:00',
    endTime: '09:00',
  },
  {
    id: 'p2',
    label: 'الحصة 2',
    timeRange: '09:00 - 10:00',
    periodType: 'morning',
    startTime: '09:00',
    endTime: '10:00',
  },
  {
    id: 'p3',
    label: 'الحصة 3',
    timeRange: '10:00 - 11:00',
    periodType: 'morning',
    startTime: '10:00',
    endTime: '11:00',
  },
  {
    id: 'p4',
    label: 'الحصة 4',
    timeRange: '11:00 - 12:00',
    periodType: 'morning',
    startTime: '11:00',
    endTime: '12:00',
  },
  {
    id: 'p5',
    label: 'الحصة 5',
    timeRange: '13:30 - 14:30',
    periodType: 'afternoon',
    startTime: '13:30',
    endTime: '14:30',
  },
  {
    id: 'p6',
    label: 'الحصة 6',
    timeRange: '14:30 - 15:30',
    periodType: 'afternoon',
    startTime: '14:30',
    endTime: '15:30',
  },
  {
    id: 'p7',
    label: 'الحصة 7',
    timeRange: '15:30 - 16:30',
    periodType: 'afternoon',
    startTime: '15:30',
    endTime: '16:30',
  },
  {
    id: 'p8',
    label: 'الحصة 8',
    timeRange: '16:30 - 17:30',
    periodType: 'afternoon',
    startTime: '16:30',
    endTime: '17:30',
  },
];

export const SUBJECT_INFO: Record<
  string,
  { name: string; bg: string; text: string; border: string; badge: string }
> = {
  'اللغة العربية': {
    name: 'اللغة العربية',
    bg: 'bg-slate-50',
    text: 'text-slate-900',
    border: 'border-slate-200',
    badge: 'bg-slate-100 text-slate-800',
  },
  'الرياضيات': {
    name: 'الرياضيات',
    bg: 'bg-blue-50',
    text: 'text-blue-900',
    border: 'border-blue-200',
    badge: 'bg-blue-100 text-blue-800',
  },
  'اللغة الفرنسية': {
    name: 'اللغة الفرنسية',
    bg: 'bg-indigo-50',
    text: 'text-indigo-900',
    border: 'border-indigo-200',
    badge: 'bg-indigo-100 text-indigo-800',
  },
  'اللغة الإنجليزية': {
    name: 'اللغة الإنجليزية',
    bg: 'bg-cyan-50',
    text: 'text-cyan-900',
    border: 'border-cyan-200',
    badge: 'bg-cyan-100 text-cyan-800',
  },
  'علوم الطبيعة والحياة': {
    name: 'علوم الطبيعة والحياة',
    bg: 'bg-teal-50',
    text: 'text-teal-900',
    border: 'border-teal-200',
    badge: 'bg-teal-100 text-teal-800',
  },
  'العلوم الفيزيائية والتكنولوجيا': {
    name: 'العلوم الفيزيائية والتكنولوجيا',
    bg: 'bg-amber-50',
    text: 'text-amber-900',
    border: 'border-amber-200',
    badge: 'bg-amber-100 text-amber-800',
  },
  'التاريخ والجغرافيا': {
    name: 'التاريخ والجغرافيا',
    bg: 'bg-orange-50',
    text: 'text-orange-900',
    border: 'border-orange-200',
    badge: 'bg-orange-100 text-orange-800',
  },
  'التربية الإسلامية': {
    name: 'التربية الإسلامية',
    bg: 'bg-green-50',
    text: 'text-green-900',
    border: 'border-green-200',
    badge: 'bg-green-100 text-green-800',
  },
  'التربية المدنية': {
    name: 'التربية المدنية',
    bg: 'bg-purple-50',
    text: 'text-purple-900',
    border: 'border-purple-200',
    badge: 'bg-purple-100 text-purple-800',
  },
  'التربية البدنية والرياضية': {
    name: 'التربية البدنية والرياضية',
    bg: 'bg-slate-50',
    text: 'text-slate-900',
    border: 'border-slate-200',
    badge: 'bg-slate-100 text-slate-800',
  },
  'الإعلام الآلي': {
    name: 'الإعلام الآلي',
    bg: 'bg-sky-50',
    text: 'text-sky-900',
    border: 'border-sky-200',
    badge: 'bg-sky-100 text-sky-800',
  },
};

// Official teachers extracted from "متوسطة سعدون عاشور" weekly timetable (Annaba, 2026-2027)
export const TEACHERS: (Teacher & { assignedClasses: string[]; username: string })[] = [
  // 1. اللغة العربية
  {
    id: 'TEA-01',
    username: 'dridi',
    name: 'أ. دريدي سلاف',
    subject: 'اللغة العربية',
    phone: '0661234001',
    email: 'dridi.ar@cem-saadoun.dz',
    weeklyHours: 20,
    assignedClasses: ['4م1', '4م2'],
    color: '#059669',
  },
  {
    id: 'TEA-02',
    username: 'debchi',
    name: 'أ. دبشي سارة',
    subject: 'اللغة العربية',
    phone: '0661234002',
    email: 'debchi.ar@cem-saadoun.dz',
    weeklyHours: 20,
    assignedClasses: ['2م1', '4م3', '4م4'],
    color: '#059669',
  },
  {
    id: 'TEA-03',
    username: 'houas',
    name: 'أ. حواس سهيلة',
    subject: 'اللغة العربية',
    phone: '0661234003',
    email: 'houas.ar@cem-saadoun.dz',
    weeklyHours: 20,
    assignedClasses: ['2م2', '3م1', '3م2'],
    color: '#059669',
  },
  {
    id: 'TEA-04',
    username: 'hadi',
    name: 'أ. هادي حنان',
    subject: 'اللغة العربية',
    phone: '0661234004',
    email: 'hadi.ar@cem-saadoun.dz',
    weeklyHours: 19,
    assignedClasses: ['1م1', '1م2', '3م3'],
    color: '#059669',
  },
  {
    id: 'TEA-05',
    username: 'boudaba',
    name: 'أ. بودابة مروة',
    subject: 'اللغة العربية',
    phone: '0661234005',
    email: 'boudaba.ar@cem-saadoun.dz',
    weeklyHours: 19,
    assignedClasses: ['1م3', '1م4', '3م4'],
    color: '#059669',
  },
  {
    id: 'TEA-06',
    username: 'benaissa',
    name: 'أ. بن عيسى بهية',
    subject: 'اللغة العربية',
    phone: '0661234006',
    email: 'benaissa.ar@cem-saadoun.dz',
    weeklyHours: 19,
    assignedClasses: ['1م5', '2م3', '2م4'],
    color: '#059669',
  },

  // 2. التربية الإسلامية
  {
    id: 'TEA-07',
    username: 'ferfache',
    name: 'أ. فرفاش يوسف',
    subject: 'التربية الإسلامية',
    phone: '0661234007',
    email: 'ferfache.is@cem-saadoun.dz',
    weeklyHours: 17,
    assignedClasses: [
      '1م1', '1م2', '1م3', '1م4', '1م5',
      '2م1', '2م2', '2م3', '2م4',
      '3م1', '3م2', '3م3', '3م4',
      '4م1', '4م2', '4م3', '4م4'
    ],
    color: '#16a34a',
  },

  // 3. الرياضيات
  {
    id: 'TEA-08',
    username: 'zouinet',
    name: 'أ. زوينت تقي الدين',
    subject: 'الرياضيات',
    phone: '0661234008',
    email: 'zouinet.math@cem-saadoun.dz',
    weeklyHours: 19,
    assignedClasses: ['1م1', '4م1', '4م2'],
    color: '#2563eb',
  },
  {
    id: 'TEA-09',
    username: 'hamiha',
    name: 'أ. محية شهرزاد',
    subject: 'الرياضيات',
    phone: '0661234009',
    email: 'hamiha.math@cem-saadoun.dz',
    weeklyHours: 19,
    assignedClasses: ['1م2', '4م3', '4م4'],
    color: '#2563eb',
  },
  {
    id: 'TEA-10',
    username: 'aissani',
    name: 'أ. عيساني إيمان',
    subject: 'الرياضيات',
    phone: '0661234010',
    email: 'aissani.math@cem-saadoun.dz',
    weeklyHours: 18,
    assignedClasses: ['1م3', '3م1', '3م2'],
    color: '#2563eb',
  },
  {
    id: 'TEA-11',
    username: 'math4',
    name: 'أ. رياضيات 4',
    subject: 'الرياضيات',
    phone: '0661234011',
    email: 'math4@cem-saadoun.dz',
    weeklyHours: 18,
    assignedClasses: ['1م4', '1م5', '3م3', '3م4'],
    color: '#2563eb',
  },
  {
    id: 'TEA-12',
    username: 'blelita',
    name: 'أ. بليلطة هاجر',
    subject: 'الرياضيات',
    phone: '0661234012',
    email: 'blelita.math@cem-saadoun.dz',
    weeklyHours: 19,
    assignedClasses: ['2م1', '2م2', '2م3', '2م4'],
    color: '#2563eb',
  },

  // 4. اللغة الفرنسية
  {
    id: 'TEA-13',
    username: 'hmisene',
    name: 'أ. محيسن وداد',
    subject: 'اللغة الفرنسية',
    phone: '0661234013',
    email: 'hmisene.fr@cem-saadoun.dz',
    weeklyHours: 18,
    assignedClasses: ['4م1', '4م2', '4م3'],
    color: '#4f46e5',
  },
  {
    id: 'TEA-14',
    username: 'housseini',
    name: 'أ. حسيني أسماء',
    subject: 'اللغة الفرنسية',
    phone: '0661234014',
    email: 'housseini.fr@cem-saadoun.dz',
    weeklyHours: 18,
    assignedClasses: ['3م1', '3م2', '4م4'],
    color: '#4f46e5',
  },
  {
    id: 'TEA-15',
    username: 'allouche',
    name: 'أ. علوش إيمان',
    subject: 'اللغة الفرنسية',
    phone: '0661234015',
    email: 'allouche.fr@cem-saadoun.dz',
    weeklyHours: 18,
    assignedClasses: ['1م1', '3م3', '3م4'],
    color: '#4f46e5',
  },
  {
    id: 'TEA-16',
    username: 'beltrache',
    name: 'أ. بلطرش هالة',
    subject: 'اللغة الفرنسية',
    phone: '0661234016',
    email: 'beltrache.fr@cem-saadoun.dz',
    weeklyHours: 19,
    assignedClasses: ['1م2', '1م3', '2م1', '2م2'],
    color: '#4f46e5',
  },
  {
    id: 'TEA-17',
    username: 'tahri',
    name: 'أ. طهير سارة',
    subject: 'اللغة الفرنسية',
    phone: '0661234017',
    email: 'tahri.fr@cem-saadoun.dz',
    weeklyHours: 19,
    assignedClasses: ['1م4', '1م5', '2م3', '2م4'],
    color: '#4f46e5',
  },

  // 5. اللغة الإنجليزية
  {
    id: 'TEA-18',
    username: 'triki',
    name: 'أ. تريكي بشرى',
    subject: 'اللغة الإنجليزية',
    phone: '0661234018',
    email: 'triki.ang@cem-saadoun.dz',
    weeklyHours: 16,
    assignedClasses: ['1م1', '1م2', '4م1', '4م2'],
    color: '#0891b2',
  },
  {
    id: 'TEA-19',
    username: 'daghmani',
    name: 'أ. دغماني نوال',
    subject: 'اللغة الإنجليزية',
    phone: '0661234019',
    email: 'daghmani.ang@cem-saadoun.dz',
    weeklyHours: 16,
    assignedClasses: ['1م3', '1م4', '4م3', '4م4'],
    color: '#0891b2',
  },
  {
    id: 'TEA-20',
    username: 'guerfi',
    name: 'أ. قرفي نور الصباح',
    subject: 'اللغة الإنجليزية',
    phone: '0661234020',
    email: 'guerfi.ang@cem-saadoun.dz',
    weeklyHours: 16,
    assignedClasses: ['1م5', '3م1', '3م2', '3م3'],
    color: '#0891b2',
  },
  {
    id: 'TEA-21',
    username: 'bahloul',
    name: 'أ. بهلول نور الهدى',
    subject: 'اللغة الإنجليزية',
    phone: '0661234021',
    email: 'bahloul.ang@cem-saadoun.dz',
    weeklyHours: 17,
    assignedClasses: ['2م1', '2م2', '2م3', '2م4', '3م4'],
    color: '#0891b2',
  },

  // 6. التاريخ والجغرافيا والتربية المدنية
  {
    id: 'TEA-22',
    username: 'bouakkaz',
    name: 'أ. بوعكاز سهام',
    subject: 'التاريخ والجغرافيا',
    phone: '0661234022',
    email: 'bouakkaz.hg@cem-saadoun.dz',
    weeklyHours: 18,
    assignedClasses: ['1م1', '1م2', '1م3', '4م1', '4م2'],
    color: '#ea580c',
  },
  {
    id: 'TEA-23',
    username: 'bouchareb',
    name: 'أ. بوشارب سناء',
    subject: 'التاريخ والجغرافيا',
    phone: '0661234023',
    email: 'bouchareb.hg@cem-saadoun.dz',
    weeklyHours: 19,
    assignedClasses: ['2م1', '2م2', '2م3', '2م4', '4م3', '4م4'],
    color: '#ea580c',
  },
  {
    id: 'TEA-24',
    username: 'benjaballah',
    name: 'أ. بن جاب الله رندة',
    subject: 'التاريخ والجغرافيا',
    phone: '0661234024',
    email: 'benjaballah.hg@cem-saadoun.dz',
    weeklyHours: 18,
    assignedClasses: ['1م4', '1م5', '3م1', '3م2', '3م3', '3م4'],
    color: '#ea580c',
  },

  // 7. علوم الطبيعة والحياة
  {
    id: 'TEA-25',
    username: 'kraghel',
    name: 'أ. كراغل صونية',
    subject: 'علوم الطبيعة والحياة',
    phone: '0661234025',
    email: 'kraghel.snv@cem-saadoun.dz',
    weeklyHours: 18,
    assignedClasses: ['2م1', '2م2', '4م1', '4م2'],
    color: '#0d9488',
  },
  {
    id: 'TEA-26',
    username: 'hefidallah',
    name: 'أ. حفظ الله شيماء',
    subject: 'علوم الطبيعة والحياة',
    phone: '0661234026',
    email: 'hefidallah.snv@cem-saadoun.dz',
    weeklyHours: 18,
    assignedClasses: ['1م1', '1م2', '4م3', '4م4'],
    color: '#0d9488',
  },
  {
    id: 'TEA-27',
    username: 'bouhouche',
    name: 'أ. بوحوش منال',
    subject: 'علوم الطبيعة والحياة',
    phone: '0661234027',
    email: 'bouhouche.snv@cem-saadoun.dz',
    weeklyHours: 18,
    assignedClasses: ['2م3', '2م4', '3م1', '3م2'],
    color: '#0d9488',
  },
  {
    id: 'TEA-28',
    username: 'drissi',
    name: 'أ. دريسي مونية',
    subject: 'علوم الطبيعة والحياة',
    phone: '0661234028',
    email: 'drissi.snv@cem-saadoun.dz',
    weeklyHours: 18,
    assignedClasses: ['1م3', '1م4', '1م5', '3م3', '3م4'],
    color: '#0d9488',
  },

  // 8. العلوم الفيزيائية والتكنولوجيا
  {
    id: 'TEA-29',
    username: 'berkane',
    name: 'أ. بركان عبد الرحيم',
    subject: 'العلوم الفيزيائية والتكنولوجيا',
    phone: '0661234029',
    email: 'berkane.phy@cem-saadoun.dz',
    weeklyHours: 18,
    assignedClasses: ['2م1', '2م2', '4م1', '4م2'],
    color: '#d97706',
  },
  {
    id: 'TEA-30',
    username: 'sissaoui',
    name: 'أ. سيساوي نعيمة',
    subject: 'العلوم الفيزيائية والتكنولوجيا',
    phone: '0661234030',
    email: 'sissaoui.phy@cem-saadoun.dz',
    weeklyHours: 18,
    assignedClasses: ['1م1', '1م2', '4م3', '4م4'],
    color: '#d97706',
  },
  {
    id: 'TEA-31',
    username: 'berinis',
    name: 'أ. برينيس روميساء',
    subject: 'العلوم الفيزيائية والتكنولوجيا',
    phone: '0661234031',
    email: 'berinis.phy@cem-saadoun.dz',
    weeklyHours: 18,
    assignedClasses: ['2م3', '2م4', '3م1', '3م2'],
    color: '#d97706',
  },
  {
    id: 'TEA-32',
    username: 'mezghiche',
    name: 'أ. مزغيش روميساء',
    subject: 'العلوم الفيزيائية والتكنولوجيا',
    phone: '0661234032',
    email: 'mezghiche.phy@cem-saadoun.dz',
    weeklyHours: 18,
    assignedClasses: ['1م3', '1م4', '1م5', '3م3', '3م4'],
    color: '#d97706',
  },

  // 9. التربية البدنية والرياضية
  {
    id: 'TEA-33',
    username: 'karim',
    name: 'أ. كريم سفيان',
    subject: 'التربية البدنية والرياضية',
    phone: '0661234033',
    email: 'karim.eps@cem-saadoun.dz',
    weeklyHours: 18,
    assignedClasses: [
      '3م1', '3م2', '3م3', '3م4',
      '4م1', '4م2', '4م3', '4م4'
    ],
    color: '#e11d48',
  },
  {
    id: 'TEA-34',
    username: 'walid',
    name: 'أ. وليد سفيان',
    subject: 'التربية البدنية والرياضية',
    phone: '0661234034',
    email: 'walid.eps@cem-saadoun.dz',
    weeklyHours: 18,
    assignedClasses: [
      '1م1', '1م2', '1م3', '1م4', '1م5',
      '2م1', '2م2', '2م3', '2م4'
    ],
    color: '#e11d48',
  },

  // 10. الإعلام الآلي
  {
    id: 'TEA-35',
    username: 'bennoui',
    name: 'أ. بن نوي نور الهدى',
    subject: 'الإعلام الآلي',
    phone: '0661234035',
    email: 'bennoui.info@cem-saadoun.dz',
    weeklyHours: 16,
    assignedClasses: [
      '2م1', '2م2', '2م3', '2م4',
      '3م1', '3م2', '3م3', '3م4'
    ],
    color: '#0284c7',
  },
];

const createSession = (
  day: SchoolDay,
  slotId: TimetableSlotId,
  classroom: string,
  grade: GradeLevel,
  subject: string,
  teacherId: string,
  teacherName: string,
  room: string
): TimetableSession => ({
  id: `${classroom}-${day}-${slotId}`,
  day,
  slotId,
  classroom,
  grade,
  subject,
  teacherId,
  teacherName,
  room,
});

export const INITIAL_TIMETABLE_SESSIONS: TimetableSession[] = [
  // =========================================================================
  // 1م1 (السنة الأولى متوسط 1)
  // =========================================================================
  createSession('sunday', 'p1', '1م1', '1AM', 'اللغة الإنجليزية', 'TEA-18', 'أ. تريكي بشرى', 'ق_1'),
  createSession('sunday', 'p2', '1م1', '1AM', 'اللغة الفرنسية', 'TEA-15', 'أ. علوش إيمان', 'ق_1'),
  createSession('sunday', 'p3', '1م1', '1AM', 'اللغة الإنجليزية', 'TEA-18', 'أ. تريكي بشرى', 'ق_3'),
  createSession('sunday', 'p4', '1م1', '1AM', 'التاريخ والجغرافيا', 'TEA-22', 'أ. بوعكاز سهام', 'ق_1'),
  createSession('sunday', 'p6', '1م1', '1AM', 'اللغة العربية', 'TEA-04', 'أ. هادي حنان', 'ق_1'),
  createSession('sunday', 'p7', '1م1', '1AM', 'اللغة العربية', 'TEA-04', 'أ. هادي حنان', 'ق_1'),

  createSession('monday', 'p1', '1م1', '1AM', 'اللغة الفرنسية', 'TEA-15', 'أ. علوش إيمان', 'ق_1'),
  createSession('monday', 'p2', '1م1', '1AM', 'اللغة الإنجليزية', 'TEA-18', 'أ. تريكي بشرى', 'ق_1'),
  createSession('monday', 'p3', '1م1', '1AM', 'علوم الطبيعة والحياة', 'TEA-26', 'أ. حفظ الله شيماء', 'ق_1'),
  createSession('monday', 'p4', '1م1', '1AM', 'الرياضيات', 'TEA-08', 'أ. زوينت تقي الدين', 'ق_1'),
  createSession('monday', 'p6', '1م1', '1AM', 'التاريخ والجغرافيا', 'TEA-22', 'أ. بوعكاز سهام', 'ق_1'),
  createSession('monday', 'p7', '1م1', '1AM', 'اللغة العربية', 'TEA-04', 'أ. هادي حنان', 'ق_1'),

  createSession('tuesday', 'p1', '1م1', '1AM', 'اللغة العربية', 'TEA-04', 'أ. هادي حنان', 'ق_13'),
  createSession('tuesday', 'p2', '1م1', '1AM', 'الرياضيات', 'TEA-08', 'أ. زوينت تقي الدين', 'ق_1'),
  createSession('tuesday', 'p3', '1م1', '1AM', 'التربية الإسلامية', 'TEA-07', 'أ. فرفاش يوسف', 'ق_1'),
  createSession('tuesday', 'p4', '1م1', '1AM', 'الرياضيات', 'TEA-08', 'أ. زوينت تقي الدين', 'ق_1'),

  createSession('wednesday', 'p1', '1م1', '1AM', 'اللغة العربية', 'TEA-04', 'أ. هادي حنان', 'ق_1'),
  createSession('wednesday', 'p2', '1م1', '1AM', 'اللغة الفرنسية', 'TEA-15', 'أ. علوش إيمان', 'ق_1'),
  createSession('wednesday', 'p3', '1م1', '1AM', 'الرياضيات', 'TEA-08', 'أ. زوينت تقي الدين', 'ق_1'),
  createSession('wednesday', 'p4', '1م1', '1AM', 'العلوم الفيزيائية والتكنولوجيا', 'TEA-30', 'أ. سيساوي نعيمة', 'ق_1'),
  createSession('wednesday', 'p6', '1م1', '1AM', 'اللغة الإنجليزية', 'TEA-18', 'أ. تريكي بشرى', 'ق_1'),

  createSession('thursday', 'p1', '1م1', '1AM', 'التاريخ والجغرافيا', 'TEA-22', 'أ. بوعكاز سهام', 'ق_1'),
  createSession('thursday', 'p2', '1م1', '1AM', 'اللغة الفرنسية', 'TEA-15', 'أ. علوش إيمان', 'ق_1'),
  createSession('thursday', 'p3', '1م1', '1AM', 'الرياضيات', 'TEA-08', 'أ. زوينت تقي الدين', 'ق_1'),
  createSession('thursday', 'p4', '1م1', '1AM', 'اللغة العربية', 'TEA-04', 'أ. هادي حنان', 'ق_1'),
  createSession('thursday', 'p6', '1م1', '1AM', 'التربية البدنية والرياضية', 'TEA-34', 'أ. وليد سفيان', 'الملعب_1'),
  createSession('thursday', 'p7', '1م1', '1AM', 'علوم الطبيعة والحياة', 'TEA-26', 'أ. حفظ الله شيماء', 'المخبر_1'),
  createSession('thursday', 'p8', '1م1', '1AM', 'العلوم الفيزيائية والتكنولوجيا', 'TEA-30', 'أ. سيساوي نعيمة', 'ق_13'),

  // =========================================================================
  // 1م2 (السنة الأولى متوسط 2)
  // =========================================================================
  createSession('sunday', 'p1', '1م2', '1AM', 'علوم الطبيعة والحياة', 'TEA-26', 'أ. حفظ الله شيماء', 'ق_2'),
  createSession('sunday', 'p2', '1م2', '1AM', 'اللغة الفرنسية', 'TEA-16', 'أ. بلطرش هالة', 'ق_2'),
  createSession('sunday', 'p3', '1م2', '1AM', 'الرياضيات', 'TEA-09', 'أ. محية شهرزاد', 'ق_2'),
  createSession('sunday', 'p4', '1م2', '1AM', 'التاريخ والجغرافيا', 'TEA-22', 'أ. بوعكاز سهام', 'ق_2'),
  createSession('sunday', 'p6', '1م2', '1AM', 'اللغة الإنجليزية', 'TEA-18', 'أ. تريكي بشرى', 'ق_2'),

  createSession('monday', 'p1', '1م2', '1AM', 'اللغة الإنجليزية', 'TEA-18', 'أ. تريكي بشرى', 'ق_2'),
  createSession('monday', 'p2', '1م2', '1AM', 'اللغة العربية', 'TEA-04', 'أ. هادي حنان', 'ق_2'),
  createSession('monday', 'p3', '1م2', '1AM', 'الرياضيات', 'TEA-09', 'أ. محية شهرزاد', 'ق_3'),
  createSession('monday', 'p4', '1م2', '1AM', 'اللغة العربية', 'TEA-04', 'أ. هادي حنان', 'ق_2'),
  createSession('monday', 'p6', '1م2', '1AM', 'اللغة الفرنسية', 'TEA-16', 'أ. بلطرش هالة', 'ق_2'),
  createSession('monday', 'p7', '1م2', '1AM', 'التاريخ والجغرافيا', 'TEA-22', 'أ. بوعكاز سهام', 'ق_2'),

  createSession('tuesday', 'p1', '1م2', '1AM', 'الرياضيات', 'TEA-09', 'أ. محية شهرزاد', 'ق_2'),
  createSession('tuesday', 'p2', '1م2', '1AM', 'اللغة العربية', 'TEA-04', 'أ. هادي حنان', 'ق_2'),
  createSession('tuesday', 'p3', '1م2', '1AM', 'التاريخ والجغرافيا', 'TEA-22', 'أ. بوعكاز سهام', 'ق_2'),
  createSession('tuesday', 'p4', '1م2', '1AM', 'التربية الإسلامية', 'TEA-07', 'أ. فرفاش يوسف', 'ق_2'),

  createSession('wednesday', 'p1', '1م2', '1AM', 'الرياضيات', 'TEA-09', 'أ. محية شهرزاد', 'ق_2'),
  createSession('wednesday', 'p2', '1م2', '1AM', 'اللغة العربية', 'TEA-04', 'أ. هادي حنان', 'ق_2'),
  createSession('wednesday', 'p3', '1م2', '1AM', 'اللغة العربية', 'TEA-04', 'أ. هادي حنان', 'ق_2'),
  createSession('wednesday', 'p4', '1م2', '1AM', 'اللغة الفرنسية', 'TEA-16', 'أ. بلطرش هالة', 'ق_2'),
  createSession('wednesday', 'p6', '1م2', '1AM', 'اللغة الإنجليزية', 'TEA-18', 'أ. تريكي بشرى', 'ق_8'),
  createSession('wednesday', 'p7', '1م2', '1AM', 'العلوم الفيزيائية والتكنولوجيا', 'TEA-30', 'أ. سيساوي نعيمة', 'ق_2'),

  createSession('thursday', 'p1', '1م2', '1AM', 'اللغة الإنجليزية', 'TEA-18', 'أ. تريكي بشرى', 'ق_2'),
  createSession('thursday', 'p2', '1م2', '1AM', 'اللغة الفرنسية', 'TEA-16', 'أ. بلطرش هالة', 'ق_2'),
  createSession('thursday', 'p3', '1م2', '1AM', 'الرياضيات', 'TEA-09', 'أ. محية شهرزاد', 'ق_2'),
  createSession('thursday', 'p4', '1م2', '1AM', 'اللغة العربية', 'TEA-04', 'أ. هادي حنان', 'ق_2'),
  createSession('thursday', 'p6', '1م2', '1AM', 'التربية البدنية والرياضية', 'TEA-34', 'أ. وليد سفيان', 'الملعب_2'),
  createSession('thursday', 'p7', '1م2', '1AM', 'علوم الطبيعة والحياة', 'TEA-26', 'أ. حفظ الله شيماء', 'ق_2'),
  createSession('thursday', 'p8', '1م2', '1AM', 'العلوم الفيزيائية والتكنولوجيا', 'TEA-30', 'أ. سيساوي نعيمة', 'المخبر_1'),

  // =========================================================================
  // 4م1 (السنة الرابعة متوسط 1)
  // =========================================================================
  createSession('sunday', 'p1', '4م1', '4AM', 'اللغة العربية', 'TEA-01', 'أ. دريدي سلاف', 'ق_10'),
  createSession('sunday', 'p2', '4م1', '4AM', 'الرياضيات', 'TEA-08', 'أ. زوينت تقي الدين', 'ق_10'),
  createSession('sunday', 'p3', '4م1', '4AM', 'العلوم الفيزيائية والتكنولوجيا', 'TEA-29', 'أ. بركان عبد الرحيم', 'المخبر_2'),
  createSession('sunday', 'p4', '4م1', '4AM', 'اللغة الفرنسية', 'TEA-13', 'أ. محيسن وداد', 'ق_10'),
  createSession('sunday', 'p6', '4م1', '4AM', 'اللغة العربية', 'TEA-01', 'أ. دريدي سلاف', 'ق_10'),
  createSession('sunday', 'p7', '4م1', '4AM', 'التاريخ والجغرافيا', 'TEA-22', 'أ. بوعكاز سهام', 'ق_10'),

  createSession('monday', 'p1', '4م1', '4AM', 'الرياضيات', 'TEA-08', 'أ. زوينت تقي الدين', 'ق_10'),
  createSession('monday', 'p2', '4م1', '4AM', 'علوم الطبيعة والحياة', 'TEA-25', 'أ. كراغل صونية', 'المخبر_1'),
  createSession('monday', 'p3', '4م1', '4AM', 'اللغة العربية', 'TEA-01', 'أ. دريدي سلاف', 'ق_10'),
  createSession('monday', 'p4', '4م1', '4AM', 'اللغة الإنجليزية', 'TEA-18', 'أ. تريكي بشرى', 'ق_10'),
  createSession('monday', 'p6', '4م1', '4AM', 'اللغة العربية', 'TEA-01', 'أ. دريدي سلاف', 'ق_10'),
  createSession('monday', 'p7', '4م1', '4AM', 'التربية الإسلامية', 'TEA-07', 'أ. فرفاش يوسف', 'ق_10'),

  createSession('tuesday', 'p1', '4م1', '4AM', 'اللغة العربية', 'TEA-01', 'أ. دريدي سلاف', 'ق_10'),
  createSession('tuesday', 'p2', '4م1', '4AM', 'الرياضيات', 'TEA-08', 'أ. زوينت تقي الدين', 'ق_10'),
  createSession('tuesday', 'p3', '4م1', '4AM', 'اللغة العربية', 'TEA-01', 'أ. دريدي سلاف', 'ق_10'),
  createSession('tuesday', 'p4', '4م1', '4AM', 'اللغة الفرنسية', 'TEA-13', 'أ. محيسن وداد', 'ق_10'),

  createSession('wednesday', 'p1', '4م1', '4AM', 'التربية البدنية والرياضية', 'TEA-33', 'أ. كريم سفيان', 'الملعب_1'),
  createSession('wednesday', 'p2', '4م1', '4AM', 'اللغة العربية', 'TEA-01', 'أ. دريدي سلاف', 'ق_10'),
  createSession('wednesday', 'p3', '4م1', '4AM', 'الرياضيات', 'TEA-08', 'أ. زوينت تقي الدين', 'ق_10'),
  createSession('wednesday', 'p4', '4م1', '4AM', 'اللغة الإنجليزية', 'TEA-18', 'أ. تريكي بشرى', 'ق_10'),
  createSession('wednesday', 'p6', '4م1', '4AM', 'اللغة الفرنسية', 'TEA-13', 'أ. محيسن وداد', 'ق_10'),
  createSession('wednesday', 'p7', '4م1', '4AM', 'اللغة العربية', 'TEA-01', 'أ. دريدي سلاف', 'ق_10'),

  createSession('thursday', 'p1', '4م1', '4AM', 'اللغة العربية', 'TEA-01', 'أ. دريدي سلاف', 'ق_10'),
  createSession('thursday', 'p2', '4م1', '4AM', 'التاريخ والجغرافيا', 'TEA-22', 'أ. بوعكاز سهام', 'ق_10'),
  createSession('thursday', 'p3', '4م1', '4AM', 'العلوم الفيزيائية والتكنولوجيا', 'TEA-29', 'أ. بركان عبد الرحيم', 'المخبر_2'),
  createSession('thursday', 'p4', '4م1', '4AM', 'اللغة العربية', 'TEA-01', 'أ. دريدي سلاف', 'ق_10'),

  // =========================================================================
  // 4م2 (السنة الرابعة متوسط 2)
  // =========================================================================
  createSession('sunday', 'p1', '4م2', '4AM', 'الرياضيات', 'TEA-08', 'أ. زوينت تقي الدين', 'ق_11'),
  createSession('sunday', 'p2', '4م2', '4AM', 'اللغة العربية', 'TEA-01', 'أ. دريدي سلاف', 'ق_11'),
  createSession('sunday', 'p3', '4م2', '4AM', 'اللغة الفرنسية', 'TEA-13', 'أ. محيسن وداد', 'ق_11'),
  createSession('sunday', 'p4', '4م2', '4AM', 'علوم الطبيعة والحياة', 'TEA-25', 'أ. كراغل صونية', 'المخبر_1'),
  createSession('sunday', 'p6', '4م2', '4AM', 'التاريخ والجغرافيا', 'TEA-22', 'أ. بوعكاز سهام', 'ق_11'),
  createSession('sunday', 'p7', '4م2', '4AM', 'اللغة العربية', 'TEA-01', 'أ. دريدي سلاف', 'ق_11'),

  createSession('monday', 'p1', '4م2', '4AM', 'اللغة الفرنسية', 'TEA-13', 'أ. محيسن وداد', 'ق_11'),
  createSession('monday', 'p2', '4م2', '4AM', 'الرياضيات', 'TEA-08', 'أ. زوينت تقي الدين', 'ق_11'),
  createSession('monday', 'p3', '4م2', '4AM', 'اللغة الإنجليزية', 'TEA-18', 'أ. تريكي بشرى', 'ق_11'),
  createSession('monday', 'p4', '4م2', '4AM', 'اللغة العربية', 'TEA-01', 'أ. دريدي سلاف', 'ق_11'),
  createSession('monday', 'p6', '4م2', '4AM', 'التربية الإسلامية', 'TEA-07', 'أ. فرفاش يوسف', 'ق_11'),
  createSession('monday', 'p7', '4م2', '4AM', 'اللغة العربية', 'TEA-01', 'أ. دريدي سلاف', 'ق_11'),

  createSession('tuesday', 'p1', '4م2', '4AM', 'الرياضيات', 'TEA-08', 'أ. زوينت تقي الدين', 'ق_11'),
  createSession('tuesday', 'p2', '4م2', '4AM', 'اللغة العربية', 'TEA-01', 'أ. دريدي سلاف', 'ق_11'),
  createSession('tuesday', 'p3', '4م2', '4AM', 'التربية البدنية والرياضية', 'TEA-33', 'أ. كريم سفيان', 'الملعب_1'),
  createSession('tuesday', 'p4', '4م2', '4AM', 'اللغة العربية', 'TEA-01', 'أ. دريدي سلاف', 'ق_11'),

  createSession('wednesday', 'p1', '4م2', '4AM', 'اللغة العربية', 'TEA-01', 'أ. دريدي سلاف', 'ق_11'),
  createSession('wednesday', 'p2', '4م2', '4AM', 'العلوم الفيزيائية والتكنولوجيا', 'TEA-29', 'أ. بركان عبد الرحيم', 'المخبر_2'),
  createSession('wednesday', 'p3', '4م2', '4AM', 'اللغة الفرنسية', 'TEA-13', 'أ. محيسن وداد', 'ق_11'),
  createSession('wednesday', 'p4', '4م2', '4AM', 'الرياضيات', 'TEA-08', 'أ. زوينت تقي الدين', 'ق_11'),
  createSession('wednesday', 'p6', '4م2', '4AM', 'اللغة العربية', 'TEA-01', 'أ. دريدي سلاف', 'ق_11'),
  createSession('wednesday', 'p7', '4م2', '4AM', 'اللغة الإنجليزية', 'TEA-18', 'أ. تريكي بشرى', 'ق_11'),

  createSession('thursday', 'p1', '4م2', '4AM', 'الرياضيات', 'TEA-08', 'أ. زوينت تقي الدين', 'ق_11'),
  createSession('thursday', 'p2', '4م2', '4AM', 'اللغة العربية', 'TEA-01', 'أ. دريدي سلاف', 'ق_11'),
  createSession('thursday', 'p3', '4م2', '4AM', 'اللغة العربية', 'TEA-01', 'أ. دريدي سلاف', 'ق_11'),
  createSession('thursday', 'p4', '4م2', '4AM', 'التاريخ والجغرافيا', 'TEA-22', 'أ. بوعكاز سهام', 'ق_11'),

  // =========================================================================
  // 4م3 (السنة الرابعة متوسط 3)
  // =========================================================================
  createSession('sunday', 'p1', '4م3', '4AM', 'الرياضيات', 'TEA-09', 'أ. محية شهرزاد', 'ق_12'),
  createSession('sunday', 'p2', '4م3', '4AM', 'اللغة العربية', 'TEA-02', 'أ. دبشي سارة', 'ق_12'),
  createSession('sunday', 'p3', '4م3', '4AM', 'اللغة الفرنسية', 'TEA-13', 'أ. محيسن وداد', 'ق_12'),
  createSession('sunday', 'p4', '4م3', '4AM', 'علوم الطبيعة والحياة', 'TEA-26', 'أ. حفظ الله شيماء', 'المخبر_1'),
  createSession('sunday', 'p6', '4م3', '4AM', 'التاريخ والجغرافيا', 'TEA-23', 'أ. بوشارب سناء', 'ق_12'),
  createSession('sunday', 'p7', '4م3', '4AM', 'اللغة العربية', 'TEA-02', 'أ. دبشي سارة', 'ق_12'),

  createSession('monday', 'p1', '4م3', '4AM', 'اللغة الفرنسية', 'TEA-13', 'أ. محيسن وداد', 'ق_12'),
  createSession('monday', 'p2', '4م3', '4AM', 'الرياضيات', 'TEA-09', 'أ. محية شهرزاد', 'ق_12'),
  createSession('monday', 'p3', '4م3', '4AM', 'التربية الإسلامية', 'TEA-07', 'أ. فرفاش يوسف', 'ق_12'),
  createSession('monday', 'p4', '4م3', '4AM', 'اللغة العربية', 'TEA-02', 'أ. دبشي سارة', 'ق_12'),
  createSession('monday', 'p6', '4م3', '4AM', 'اللغة العربية', 'TEA-02', 'أ. دبشي سارة', 'ق_12'),
  createSession('monday', 'p7', '4م3', '4AM', 'العلوم الفيزيائية والتكنولوجيا', 'TEA-30', 'أ. سيساوي نعيمة', 'المخبر_1'),

  createSession('tuesday', 'p1', '4م3', '4AM', 'الرياضيات', 'TEA-09', 'أ. محية شهرزاد', 'ق_12'),
  createSession('tuesday', 'p2', '4م3', '4AM', 'اللغة الإنجليزية', 'TEA-19', 'أ. دغماني نوال', 'ق_12'),
  createSession('tuesday', 'p3', '4م3', '4AM', 'اللغة العربية', 'TEA-02', 'أ. دبشي سارة', 'ق_12'),
  createSession('tuesday', 'p4', '4م3', '4AM', 'التربية البدنية والرياضية', 'TEA-33', 'أ. كريم سفيان', 'الملعب_1'),

  createSession('wednesday', 'p1', '4م3', '4AM', 'اللغة الفرنسية', 'TEA-13', 'أ. محيسن وداد', 'ق_12'),
  createSession('wednesday', 'p2', '4م3', '4AM', 'اللغة العربية', 'TEA-02', 'أ. دبشي سارة', 'ق_12'),
  createSession('wednesday', 'p3', '4م3', '4AM', 'الرياضيات', 'TEA-09', 'أ. محية شهرزاد', 'ق_12'),
  createSession('wednesday', 'p4', '4م3', '4AM', 'اللغة الإنجليزية', 'TEA-19', 'أ. دغماني نوال', 'ق_12'),
  createSession('wednesday', 'p6', '4م3', '4AM', 'اللغة العربية', 'TEA-02', 'أ. دبشي سارة', 'ق_12'),
  createSession('wednesday', 'p7', '4م3', '4AM', 'التاريخ والجغرافيا', 'TEA-23', 'أ. بوشارب سناء', 'ق_12'),

  createSession('thursday', 'p1', '4م3', '4AM', 'اللغة الإنجليزية', 'TEA-19', 'أ. دغماني نوال', 'ق_12'),
  createSession('thursday', 'p2', '4م3', '4AM', 'الرياضيات', 'TEA-09', 'أ. محية شهرزاد', 'ق_12'),
  createSession('thursday', 'p3', '4م3', '4AM', 'العلوم الفيزيائية والتكنولوجيا', 'TEA-30', 'أ. سيساوي نعيمة', 'المخبر_1'),
  createSession('thursday', 'p4', '4م3', '4AM', 'اللغة العربية', 'TEA-02', 'أ. دبشي سارة', 'ق_12'),

  // =========================================================================
  // 4م4 (السنة الرابعة متوسط 4)
  // =========================================================================
  createSession('sunday', 'p1', '4م4', '4AM', 'اللغة العربية', 'TEA-02', 'أ. دبشي سارة', 'ق_13'),
  createSession('sunday', 'p2', '4م4', '4AM', 'الرياضيات', 'TEA-09', 'أ. محية شهرزاد', 'ق_13'),
  createSession('sunday', 'p3', '4م4', '4AM', 'التربية الإسلامية', 'TEA-07', 'أ. فرفاش يوسف', 'ق_13'),
  createSession('sunday', 'p4', '4م4', '4AM', 'اللغة الفرنسية', 'TEA-14', 'أ. حسيني أسماء', 'ق_13'),
  createSession('sunday', 'p6', '4م4', '4AM', 'اللغة العربية', 'TEA-02', 'أ. دبشي سارة', 'ق_13'),
  createSession('sunday', 'p7', '4م4', '4AM', 'العلوم الفيزيائية والتكنولوجيا', 'TEA-30', 'أ. سيساوي نعيمة', 'المخبر_2'),

  createSession('monday', 'p1', '4م4', '4AM', 'الرياضيات', 'TEA-09', 'أ. محية شهرزاد', 'ق_13'),
  createSession('monday', 'p2', '4م4', '4AM', 'علوم الطبيعة والحياة', 'TEA-26', 'أ. حفظ الله شيماء', 'المخبر_1'),
  createSession('monday', 'p3', '4م4', '4AM', 'اللغة العربية', 'TEA-02', 'أ. دبشي سارة', 'ق_13'),
  createSession('monday', 'p4', '4م4', '4AM', 'اللغة الإنجليزية', 'TEA-19', 'أ. دغماني نوال', 'ق_13'),
  createSession('monday', 'p6', '4م4', '4AM', 'اللغة الفرنسية', 'TEA-14', 'أ. حسيني أسماء', 'ق_13'),
  createSession('monday', 'p7', '4م4', '4AM', 'اللغة العربية', 'TEA-02', 'أ. دبشي سارة', 'ق_13'),

  createSession('tuesday', 'p1', '4م4', '4AM', 'اللغة الفرنسية', 'TEA-14', 'أ. حسيني أسماء', 'ق_13'),
  createSession('tuesday', 'p2', '4م4', '4AM', 'الرياضيات', 'TEA-09', 'أ. محية شهرزاد', 'ق_13'),
  createSession('tuesday', 'p3', '4م4', '4AM', 'التاريخ والجغرافيا', 'TEA-23', 'أ. بوشارب سناء', 'ق_13'),
  createSession('tuesday', 'p4', '4م4', '4AM', 'اللغة العربية', 'TEA-02', 'أ. دبشي سارة', 'ق_13'),

  createSession('wednesday', 'p1', '4م4', '4AM', 'اللغة العربية', 'TEA-02', 'أ. دبشي سارة', 'ق_13'),
  createSession('wednesday', 'p2', '4م4', '4AM', 'الرياضيات', 'TEA-09', 'أ. محية شهرزاد', 'ق_13'),
  createSession('wednesday', 'p3', '4م4', '4AM', 'التربية البدنية والرياضية', 'TEA-33', 'أ. كريم سفيان', 'الملعب_2'),
  createSession('wednesday', 'p4', '4م4', '4AM', 'اللغة الإنجليزية', 'TEA-19', 'أ. دغماني نوال', 'ق_13'),
  createSession('wednesday', 'p6', '4م4', '4AM', 'التاريخ والجغرافيا', 'TEA-23', 'أ. بوشارب سناء', 'ق_13'),
  createSession('wednesday', 'p7', '4م4', '4AM', 'اللغة العربية', 'TEA-02', 'أ. دبشي سارة', 'ق_13'),

  createSession('thursday', 'p1', '4م4', '4AM', 'الرياضيات', 'TEA-09', 'أ. محية شهرزاد', 'ق_13'),
  createSession('thursday', 'p2', '4م4', '4AM', 'اللغة الفرنسية', 'TEA-14', 'أ. حسيني أسماء', 'ق_13'),
  createSession('thursday', 'p3', '4م4', '4AM', 'اللغة العربية', 'TEA-02', 'أ. دبشي سارة', 'ق_13'),
  createSession('thursday', 'p4', '4م4', '4AM', 'العلوم الفيزيائية والتكنولوجيا', 'TEA-30', 'أ. سيساوي نعيمة', 'المخبر_2'),
];

// Helper to get school day
export function getSchoolDay(date?: Date | string): SchoolDay {
  const d = date ? (typeof date === 'string' ? new Date(date) : date) : new Date();
  const dayIndex = d.getDay();
  switch (dayIndex) {
    case 0:
      return 'sunday';
    case 1:
      return 'monday';
    case 2:
      return 'tuesday';
    case 3:
      return 'wednesday';
    case 4:
      return 'thursday';
    default:
      return 'sunday';
  }
}

// Find the slot matching current hour/minute in Algeria local time
export function getCurrentSlotMeta(date?: Date | string): TimetableSlotMeta {
  const d = date ? (typeof date === 'string' ? new Date(date) : date) : new Date();

  const timeStr = new Intl.DateTimeFormat('fr-DZ', {
    timeZone: 'Africa/Algiers',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).format(d);

  const [hours, minutes] = timeStr.split(':').map(Number);
  const currentMinutes = hours * 60 + minutes;

  for (const slot of TIMETABLE_SLOTS) {
    const [startH, startM] = slot.startTime.split(':').map(Number);
    const [endH, endM] = slot.endTime.split(':').map(Number);
    const startTotal = startH * 60 + startM;
    const endTotal = endH * 60 + endM;

    if (currentMinutes >= startTotal && currentMinutes < endTotal) {
      return slot;
    }
  }

  if (hours < 12) {
    return TIMETABLE_SLOTS[0];
  }
  return TIMETABLE_SLOTS[4];
}

export function mapPeriodToSlotId(periodId: string): TimetableSlotId {
  const normalized = periodId.toLowerCase();
  if (normalized === 'm1' || normalized === 'p1') return 'p1';
  if (normalized === 'm2' || normalized === 'p2') return 'p2';
  if (normalized === 'm3' || normalized === 'p3') return 'p3';
  if (normalized === 'm4' || normalized === 'p4') return 'p4';
  if (normalized === 'a1' || normalized === 'p5') return 'p5';
  if (normalized === 'a2' || normalized === 'p6') return 'p6';
  if (normalized === 'a3' || normalized === 'p7') return 'p7';
  if (normalized === 'a4' || normalized === 'p8') return 'p8';
  return 'p1';
}

export function getSubjectForClassroom(
  classroom: string,
  day: SchoolDay,
  slotId: TimetableSlotId,
  sessions: TimetableSession[] = INITIAL_TIMETABLE_SESSIONS
): TimetableSession | undefined {
  return sessions.find(
    (s) =>
      (s.classroom === classroom || s.classroom.replace('AM', 'م') === classroom) &&
      s.day === day &&
      s.slotId === slotId
  );
}

export function getTeacherSessions(
  teacherId: string,
  sessions: TimetableSession[] = INITIAL_TIMETABLE_SESSIONS
): TimetableSession[] {
  return sessions.filter((s) => s.teacherId === teacherId);
}

export function getCurrentTeacherSession(
  teacherId: string,
  date?: Date | string,
  sessions: TimetableSession[] = INITIAL_TIMETABLE_SESSIONS
): TimetableSession | undefined {
  const day = getSchoolDay(date);
  const slot = getCurrentSlotMeta(date);
  return sessions.find((s) => s.teacherId === teacherId && s.day === day && s.slotId === slot.id);
}

export function getClassroomSessions(
  classroom: string,
  sessions: TimetableSession[] = INITIAL_TIMETABLE_SESSIONS
): TimetableSession[] {
  return sessions.filter(
    (s) => s.classroom === classroom || s.classroom.replace('AM', 'م') === classroom
  );
}

export function getAbsentStudentSubjectInfo(
  student: Student,
  options?: {
    date?: string | Date;
    periodId?: string;
    slotId?: TimetableSlotId;
    sessions?: TimetableSession[];
  }
): StudentAbsentSubjectDetail | null {
  const sessions = options?.sessions || INITIAL_TIMETABLE_SESSIONS;
  const day = getSchoolDay(options?.date);

  let targetSlot: TimetableSlotMeta;
  if (options?.slotId) {
    targetSlot = TIMETABLE_SLOTS.find((s) => s.id === options.slotId) || TIMETABLE_SLOTS[0];
  } else if (options?.periodId) {
    const mapped = mapPeriodToSlotId(options.periodId);
    targetSlot = TIMETABLE_SLOTS.find((s) => s.id === mapped) || TIMETABLE_SLOTS[0];
  } else {
    targetSlot = getCurrentSlotMeta();
  }

  const sessionMatch = getSubjectForClassroom(student.classroom, day, targetSlot.id, sessions);

  if (!sessionMatch) {
    return {
      studentId: student.id,
      studentName: `${student.lastName} ${student.firstName}`,
      classroom: student.classroom,
      day,
      slotId: targetSlot.id,
      slotLabel: targetSlot.label,
      timeRange: targetSlot.timeRange,
      subject: 'ساعة دراسة / فراغ مبرمج',
      teacherName: 'غير مبرمج',
      room: student.classroom,
      isOngoingNow: true,
    };
  }

  return {
    studentId: student.id,
    studentName: `${student.lastName} ${student.firstName}`,
    classroom: student.classroom,
    day,
    slotId: targetSlot.id,
    slotLabel: targetSlot.label,
    timeRange: targetSlot.timeRange,
    subject: sessionMatch.subject,
    teacherName: sessionMatch.teacherName,
    room: sessionMatch.room,
    isOngoingNow: true,
  };
}
