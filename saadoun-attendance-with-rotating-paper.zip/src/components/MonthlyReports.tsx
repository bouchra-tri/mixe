import React, { useState, useMemo } from 'react';
import { Student, AttendanceRecord, SchoolSettings, GradeLevel } from '../types';
import {
  Calendar,
  FileSpreadsheet,
  Printer,
  TrendingUp,
  Users,
  CheckCircle2,
  Clock,
  UserX,
  Award,
  Filter,
  Search,
  School,
  ChevronRight,
  ChevronLeft,
  AlertTriangle
} from 'lucide-react';
import { exportMonthlyAttendanceToExcel } from '../utils/excelExport';

interface MonthlyReportsProps {
  students: Student[];
  records: AttendanceRecord[];
  settings: SchoolSettings;
  onOpenNotice?: (student: Student) => void;
}

const ARABIC_MONTHS = [
  { value: 1, name: 'جانفي (يناير)' },
  { value: 2, name: 'فيفري (فبراير)' },
  { value: 3, name: 'مارس' },
  { value: 4, name: 'أفريل (أبريل)' },
  { value: 5, name: 'ماي (مايو)' },
  { value: 6, name: 'جوان (يونيو)' },
  { value: 7, name: 'جويلية (يوليو)' },
  { value: 8, name: 'أوت (أغسطس)' },
  { value: 9, name: 'سبتمبر' },
  { value: 10, name: 'أكتوبر' },
  { value: 11, name: 'نوفمبر' },
  { value: 12, name: 'ديسمبر' },
];

export const MonthlyReports: React.FC<MonthlyReportsProps> = ({
  students,
  records,
  settings,
  onOpenNotice,
}) => {
  const currentDate = new Date();
  const [selectedYear, setSelectedYear] = useState<number>(currentDate.getFullYear());
  const [selectedMonth, setSelectedMonth] = useState<number>(currentDate.getMonth() + 1); // 1-12
  const [selectedGrade, setSelectedGrade] = useState<string>('all');
  const [selectedClassroom, setSelectedClassroom] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Extract unique classrooms
  const classrooms = useMemo(() => {
    const set = new Set<string>();
    students.forEach((s) => {
      if (s.classroom) set.add(s.classroom);
    });
    return Array.from(set).sort();
  }, [students]);

  // Days in selected month
  const totalDaysInMonth = useMemo(() => {
    return new Date(selectedYear, selectedMonth, 0).getDate();
  }, [selectedYear, selectedMonth]);

  const daysList = useMemo(() => {
    return Array.from({ length: totalDaysInMonth }, (_, i) => i + 1);
  }, [totalDaysInMonth]);

  // Month prefix YYYY-MM
  const monthPrefix = `${selectedYear}-${String(selectedMonth).padStart(2, '0')}`;
  const monthName = ARABIC_MONTHS.find((m) => m.value === selectedMonth)?.name || `شهر ${selectedMonth}`;

  // Month records
  const monthRecords = useMemo(() => {
    return records.filter((r) => r.date.startsWith(monthPrefix));
  }, [records, monthPrefix]);

  // Filter students
  const filteredStudents = useMemo(() => {
    return students.filter((s) => {
      if (selectedGrade !== 'all' && s.grade !== selectedGrade) return false;
      if (selectedClassroom !== 'all' && s.classroom !== selectedClassroom) return false;
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase().trim();
        const fullName = `${s.lastName} ${s.firstName}`.toLowerCase();
        return (
          fullName.includes(query) ||
          s.id.toLowerCase().includes(query) ||
          s.barcode.includes(query) ||
          (s.nationalId && s.nationalId.includes(query))
        );
      }
      return true;
    });
  }, [students, selectedGrade, selectedClassroom, searchQuery]);

  // Compute student-by-student monthly stats
  const studentsMonthlyData = useMemo(() => {
    return filteredStudents.map((st) => {
      let presentCount = 0;
      let lateCount = 0;
      let unexcusedAbsentCount = 0;
      let excusedCount = 0;

      const dayStatusMap: Record<number, { status: string; label: string; text: string; lateMinutes?: number }> = {};

      daysList.forEach((d) => {
        const dayDateStr = `${monthPrefix}-${String(d).padStart(2, '0')}`;
        const dayRecords = monthRecords.filter((r) => r.studentId === st.id && r.date === dayDateStr);

        // Check if weekend in Algeria (Fri 5, Sat 6)
        const dayOfWeek = new Date(selectedYear, selectedMonth - 1, d).getDay();
        const isWeekend = dayOfWeek === 5 || dayOfWeek === 6;

        if (dayRecords.length === 0) {
          if (isWeekend) {
            dayStatusMap[d] = { status: 'weekend', label: 'عطلة', text: 'عطلة أسبوعية' };
          } else {
            // Unrecorded or absent
            dayStatusMap[d] = { status: 'empty', label: '-', text: 'لا يوجد تسجيل' };
          }
          return;
        }

        const hasPresent = dayRecords.find((r) => r.status === 'present');
        const hasLate = dayRecords.find((r) => r.status === 'late');
        const hasExcused = dayRecords.find((r) => r.status === 'excused');
        const hasAbsent = dayRecords.find((r) => r.status === 'absent');

        if (hasPresent) {
          presentCount++;
          dayStatusMap[d] = { status: 'present', label: 'ح', text: 'حاضر في الموعد' };
        } else if (hasLate) {
          lateCount++;
          presentCount++;
          dayStatusMap[d] = {
            status: 'late',
            label: 'ت',
            text: `متأخر (+${hasLate.lateMinutes} د)`,
            lateMinutes: hasLate.lateMinutes,
          };
        } else if (hasExcused) {
          excusedCount++;
          dayStatusMap[d] = { status: 'excused', label: 'م', text: 'غياب مبرر' };
        } else if (hasAbsent) {
          unexcusedAbsentCount++;
          dayStatusMap[d] = { status: 'absent', label: 'غ', text: 'غياب غير مبرر' };
        }
      });

      const totalSchoolDaysRecorded = presentCount + unexcusedAbsentCount + excusedCount;
      const rate = totalSchoolDaysRecorded > 0 ? Math.round((presentCount / totalSchoolDaysRecorded) * 100) : 100;

      return {
        student: st,
        presentCount,
        lateCount,
        unexcusedAbsentCount,
        excusedCount,
        totalSchoolDaysRecorded,
        rate,
        dayStatusMap,
      };
    });
  }, [filteredStudents, daysList, monthPrefix, monthRecords, selectedYear, selectedMonth]);

  // Overall aggregates
  const totalPresents = useMemo(() => {
    return studentsMonthlyData.reduce((acc, curr) => acc + curr.presentCount, 0);
  }, [studentsMonthlyData]);

  const totalLates = useMemo(() => {
    return studentsMonthlyData.reduce((acc, curr) => acc + curr.lateCount, 0);
  }, [studentsMonthlyData]);

  const totalUnexcused = useMemo(() => {
    return studentsMonthlyData.reduce((acc, curr) => acc + curr.unexcusedAbsentCount, 0);
  }, [studentsMonthlyData]);

  const totalExcused = useMemo(() => {
    return studentsMonthlyData.reduce((acc, curr) => acc + curr.excusedCount, 0);
  }, [studentsMonthlyData]);

  const overallMonthlyAttendanceRate = useMemo(() => {
    const totalPossible = totalPresents + totalUnexcused + totalExcused;
    if (totalPossible === 0) return 96;
    return Math.round((totalPresents / totalPossible) * 100);
  }, [totalPresents, totalUnexcused, totalExcused]);

  // Top Absentees of the month
  const topAbsentees = useMemo(() => {
    return [...studentsMonthlyData]
      .filter((s) => s.unexcusedAbsentCount > 0)
      .sort((a, b) => b.unexcusedAbsentCount - a.unexcusedAbsentCount)
      .slice(0, 5);
  }, [studentsMonthlyData]);

  // Grade Breakdown
  const gradeBreakdown = useMemo(() => {
    const grades: GradeLevel[] = ['1AM', '2AM', '3AM', '4AM'];
    const names: Record<GradeLevel, string> = {
      '1AM': 'الأولى متوسط',
      '2AM': 'الثانية متوسط',
      '3AM': 'الثالثة متوسط',
      '4AM': 'الرابعة متوسط',
    };

    return grades.map((g) => {
      const gradeItems = studentsMonthlyData.filter((i) => i.student.grade === g);
      const totalSt = gradeItems.length;
      const presents = gradeItems.reduce((acc, c) => acc + c.presentCount, 0);
      const absents = gradeItems.reduce((acc, c) => acc + c.unexcusedAbsentCount, 0);
      const totalChecks = presents + absents;
      const rate = totalChecks > 0 ? Math.round((presents / totalChecks) * 100) : 100;

      return {
        grade: g,
        name: names[g],
        totalSt,
        presents,
        absents,
        rate,
      };
    });
  }, [studentsMonthlyData]);

  const handleExportExcel = () => {
    exportMonthlyAttendanceToExcel({
      students,
      records,
      settings,
      year: selectedYear,
      month: selectedMonth,
      filterClassroom: selectedClassroom,
      filterGrade: selectedGrade,
    });
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Top Bar: Title, Month Selector & Actions */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4 no-print">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-slate-700 text-white flex items-center justify-center shadow-xs">
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-slate-900">سجل التقارير الشهرية للحضور والمواظبة</h2>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-50 text-slate-800 border border-slate-200">
                {monthName} {selectedYear}
              </span>
            </div>
            <p className="text-xs text-slate-500">
              المتابعة الإدارية الشهرية المفصلة، مصفوفة الحضور اليومية ونسب المواظبة المدرسية
            </p>
          </div>
        </div>

        {/* Month & Year Selectors and Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Month selector */}
          <select
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(Number(e.target.value))}
            className="px-3 py-1.5 text-xs font-bold bg-slate-50 border border-slate-300 rounded-xl text-slate-800 cursor-pointer focus:ring-2 focus:ring-slate-500"
          >
            {ARABIC_MONTHS.map((m) => (
              <option key={m.value} value={m.value}>
                {m.name}
              </option>
            ))}
          </select>

          {/* Year selector */}
          <select
            value={selectedYear}
            onChange={(e) => setSelectedYear(Number(e.target.value))}
            className="px-3 py-1.5 text-xs font-bold bg-slate-50 border border-slate-300 rounded-xl text-slate-800 cursor-pointer font-mono-numbers focus:ring-2 focus:ring-slate-500"
          >
            <option value={2026}>2026</option>
            <option value={2027}>2027</option>
            <option value={2025}>2025</option>
          </select>

          {/* Export to Excel */}
          <button
            type="button"
            onClick={handleExportExcel}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-slate-800 bg-slate-50 hover:bg-slate-100 border border-slate-300 rounded-xl transition-all cursor-pointer shadow-2xs"
            title="تصدير كشف الحضور الشهري كاملاً إلى Excel"
          >
            <FileSpreadsheet className="w-4 h-4 text-slate-700" />
            <span>تصدير Excel الشهري</span>
          </button>

          {/* Print official report */}
          <button
            type="button"
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-slate-700 hover:bg-slate-800 active:scale-95 rounded-xl transition-all cursor-pointer shadow-xs"
            title="طباعة التقرير الشهري الرسمي"
          >
            <Printer className="w-4 h-4" />
            <span>طباعة التقرير الرسمي</span>
          </button>
        </div>
      </div>

      {/* Official Printable Header (Visible only when printing) */}
      <div className="hidden print:block bg-white p-6 border-b-2 border-slate-900 mb-6 space-y-4">
        <div className="flex items-center justify-between text-xs font-bold text-slate-800 border-b pb-4">
          <div className="space-y-1">
            <p className="text-sm font-black">الجمهورية الجزائرية الديمقراطية الشعبية</p>
            <p>وزارة التربية الوطنية</p>
            <p>مديرية التربية لولاية {settings.wilaya || 'عنابة'}</p>
            <p className="font-extrabold text-slate-950">{settings.schoolName || 'متوسطة سعدون عاشور'}</p>
          </div>
          <div className="text-center space-y-1">
            <h1 className="text-base font-black border-2 border-slate-900 px-4 py-1.5 rounded-lg">
              سجل الغياب الشهري الرسمي
            </h1>
            <p className="text-xs font-semibold">{monthName} {selectedYear}</p>
          </div>
          <div className="text-left space-y-1">
            <p>السنة الدراسية: {settings.academicYear || '2026-2027'}</p>
            <p>تاريخ الاستخراج: {new Date().toLocaleDateString('ar-DZ')}</p>
            <p>مصلحة الاستشارة التربوية</p>
          </div>
        </div>
      </div>

      {/* KPI Aggregate Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4 no-print">
        {/* Attendance Rate */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-slate-500">نسبة المواظبة الشهرية</p>
            <h3 className="text-2xl font-black text-slate-700 mt-1 font-mono-numbers">
              {overallMonthlyAttendanceRate}%
            </h3>
            <p className="text-[11px] text-slate-800 flex items-center gap-1 mt-1 font-semibold">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>معدل مواظبة متميز</span>
            </p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-slate-50 text-slate-700 flex items-center justify-center border border-slate-200">
            <Award className="w-6 h-6" />
          </div>
        </div>

        {/* Total Presents */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-slate-500">مجموع الحضور المسجل</p>
            <h3 className="text-2xl font-black text-slate-800 mt-1 font-mono-numbers">
              {totalPresents}
            </h3>
            <p className="text-[11px] text-slate-500 mt-1">
              حضور فعلي خلال {daysList.length} يوماً
            </p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center">
            <CheckCircle2 className="w-6 h-6 text-slate-600" />
          </div>
        </div>

        {/* Total Unexcused Absences */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-slate-500">غيابات غير مبررة</p>
            <h3 className="text-2xl font-black text-slate-600 mt-1 font-mono-numbers">
              {totalUnexcused}
            </h3>
            <p className="text-[11px] text-slate-800 mt-1 font-semibold">
              تستوجب الإشعار والإعذار
            </p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-slate-50 text-slate-600 flex items-center justify-center border border-slate-200">
            <UserX className="w-6 h-6" />
          </div>
        </div>

        {/* Total Lates & Excused */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-slate-500">تأخرات ومبررات</p>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-amber-600 font-mono-numbers">{totalLates}</span>
              <span className="text-xs text-slate-400">تأخر / </span>
              <span className="text-lg font-bold text-blue-600 font-mono-numbers">{totalExcused}</span>
              <span className="text-xs text-slate-400">مبرر</span>
            </div>
            <p className="text-[11px] text-slate-500 mt-1">متابعة دقيقة للانضباط</p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center border border-amber-200">
            <Clock className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Middle Row: Grade Comparison & Top Absentees */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 no-print">
        {/* Grade Comparison */}
        <div className="lg:col-span-2 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Award className="w-4 h-4 text-slate-700" />
              <h3 className="font-bold text-slate-800 text-xs">
                مقارنة نسبة المواظبة الشهرية حسب المستويات الدراسية
              </h3>
            </div>
            <span className="text-[11px] text-slate-500 font-semibold">{monthName} {selectedYear}</span>
          </div>

          <div className="space-y-3">
            {gradeBreakdown.map((g) => (
              <div key={g.grade} className="space-y-1">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-slate-800">{g.name}</span>
                  <div className="flex items-center gap-3">
                    <span className="text-slate-500 font-normal">{g.totalSt} تلميذ</span>
                    <span className="text-slate-800 font-mono-numbers">{g.rate}%</span>
                  </div>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                  <div
                    className={`h-2.5 rounded-full transition-all duration-500 ${
                      g.rate >= 95
                        ? 'bg-slate-600'
                        : g.rate >= 90
                        ? 'bg-slate-500'
                        : g.rate >= 80
                        ? 'bg-amber-500'
                        : 'bg-slate-500'
                    }`}
                    style={{ width: `${g.rate}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Absentees Alert Box */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div className="flex items-center gap-2 text-slate-700">
              <AlertTriangle className="w-4 h-4" />
              <h3 className="font-bold text-xs">أعلى حالات الغياب في الشهر</h3>
            </div>
            <span className="text-[10px] bg-slate-50 text-slate-700 px-2 py-0.5 rounded font-bold border border-slate-200">
              متابعة عاجلة
            </span>
          </div>

          {topAbsentees.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-400">
              لا توجد حالات غياب غير مبررة مسجلة في هذا الشهر
            </div>
          ) : (
            <div className="space-y-2.5">
              {topAbsentees.map((item, idx) => (
                <div
                  key={item.student.id}
                  className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs hover:bg-slate-100 transition-colors"
                >
                  <div>
                    <p className="font-bold text-slate-900">
                      {idx + 1}. {item.student.lastName} {item.student.firstName}
                    </p>
                    <p className="text-[11px] text-slate-500">
                      قسم: {item.student.classroom} · هاتف: {item.student.guardianPhone}
                    </p>
                  </div>
                  <div className="text-left">
                    <span className="inline-block px-2 py-0.5 rounded bg-slate-100 text-slate-800 font-bold font-mono-numbers">
                      {item.unexcusedAbsentCount} أيام
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Filters Bar: Classroom, Grade, and Search */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3 no-print">
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <div className="flex items-center gap-1 font-semibold text-slate-600 pl-2">
            <Filter className="w-3.5 h-3.5 text-slate-500" />
            <span>تصفية المصفوفة:</span>
          </div>

          {/* Grade filter */}
          <select
            value={selectedGrade}
            onChange={(e) => setSelectedGrade(e.target.value)}
            className="px-3 py-1.5 border border-slate-300 rounded-lg text-slate-700 bg-white"
          >
            <option value="all">جميع المستويات</option>
            <option value="1AM">الأولى متوسط (1AM)</option>
            <option value="2AM">الثانية متوسط (2AM)</option>
            <option value="3AM">الثالثة متوسط (3AM)</option>
            <option value="4AM">الرابعة متوسط (4AM)</option>
          </select>

          {/* Classroom filter */}
          <select
            value={selectedClassroom}
            onChange={(e) => setSelectedClassroom(e.target.value)}
            className="px-3 py-1.5 border border-slate-300 rounded-lg text-slate-700 bg-white"
          >
            <option value="all">جميع الأقسام</option>
            {classrooms.map((c) => (
              <option key={c} value={c}>
                قسم {c}
              </option>
            ))}
          </select>

          {/* Legend */}
          <div className="hidden md:flex items-center gap-2 mr-4 text-[11px] font-semibold">
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-slate-500"></span> حاضر (ح)
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span> متأخر (ت)
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-slate-500"></span> غائب (غ)
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span> مبرر (م)
            </span>
          </div>
        </div>

        {/* Search input */}
        <div className="relative w-full sm:w-64">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="بحث بالاسم أو رقم التعريف..."
            className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500"
          />
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
        </div>
      </div>

      {/* Comprehensive Monthly Attendance Grid Matrix */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-xs text-slate-800">
              مصفوفة متابعة الحضور والغياب اليومي لشهر {monthName} {selectedYear}
            </h3>
            <span className="text-[11px] text-slate-500">
              (إجمالي التلاميذ المعروضين: {studentsMonthlyData.length} تلميذ)
            </span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200 text-[11px]">
                <th className="p-2.5 text-center w-10 border-l border-slate-200">#</th>
                <th className="p-2.5 w-44 border-l border-slate-200">اسم ولقب التلميذ</th>
                <th className="p-2.5 text-center w-16 border-l border-slate-200">القسم</th>

                {/* Day Columns */}
                {daysList.map((d) => {
                  const dayOfWeek = new Date(selectedYear, selectedMonth - 1, d).getDay();
                  const isWeekend = dayOfWeek === 5 || dayOfWeek === 6;
                  return (
                    <th
                      key={d}
                      className={`p-1.5 text-center min-w-[28px] border-l border-slate-200 font-mono-numbers ${
                        isWeekend ? 'bg-slate-200/60 text-slate-400' : ''
                      }`}
                      title={`يوم ${d} ${monthName}`}
                    >
                      {d}
                    </th>
                  );
                })}

                {/* Summaries */}
                <th className="p-2 text-center w-14 bg-slate-50 text-slate-900 border-l border-slate-200">
                  حضور
                </th>
                <th className="p-2 text-center w-12 bg-amber-50 text-amber-900 border-l border-slate-200">
                  تأخر
                </th>
                <th className="p-2 text-center w-14 bg-slate-50 text-slate-900 border-l border-slate-200">
                  غياب
                </th>
                <th className="p-2 text-center w-14 bg-blue-50 text-blue-900 border-l border-slate-200">
                  مبرر
                </th>
                <th className="p-2 text-center w-16 bg-slate-100 text-slate-900 font-bold">
                  النسبة %
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {studentsMonthlyData.length === 0 ? (
                <tr>
                  <td colSpan={totalDaysInMonth + 8} className="p-8 text-center text-slate-400">
                    لا يوجد تلاميذ مطابقين لمعايير التصفية المحددة.
                  </td>
                </tr>
              ) : (
                studentsMonthlyData.map((item, idx) => (
                  <tr
                    key={item.student.id}
                    className="hover:bg-slate-50 transition-colors text-slate-800 text-[11px]"
                  >
                    <td className="p-2 text-center font-mono-numbers text-slate-400 border-l border-slate-100">
                      {idx + 1}
                    </td>
                    <td className="p-2 font-bold text-slate-900 border-l border-slate-100 truncate max-w-[180px]">
                      {item.student.lastName} {item.student.firstName}
                    </td>
                    <td className="p-2 text-center border-l border-slate-100 font-semibold text-slate-600">
                      {item.student.classroom}
                    </td>

                    {/* Day Cells */}
                    {daysList.map((d) => {
                      const dayData = item.dayStatusMap[d];
                      const status = dayData?.status;

                      let cellBg = 'bg-white text-slate-300';
                      if (status === 'present') cellBg = 'bg-slate-500 text-white font-bold';
                      else if (status === 'late') cellBg = 'bg-amber-400 text-amber-950 font-bold';
                      else if (status === 'absent') cellBg = 'bg-slate-500 text-white font-bold';
                      else if (status === 'excused') cellBg = 'bg-blue-500 text-white font-bold';
                      else if (status === 'weekend') cellBg = 'bg-slate-100 text-slate-300';

                      return (
                        <td
                          key={d}
                          className="p-0.5 text-center border-l border-slate-100"
                          title={`${item.student.lastName} ${item.student.firstName} - يوم ${d}: ${dayData?.text || ''}`}
                        >
                          <div
                            className={`w-6 h-6 mx-auto rounded flex items-center justify-center text-[10px] ${cellBg}`}
                          >
                            {dayData?.label || '-'}
                          </div>
                        </td>
                      );
                    })}

                    {/* Summary Columns */}
                    <td className="p-2 text-center font-bold text-slate-700 bg-slate-50/50 border-l border-slate-100 font-mono-numbers">
                      {item.presentCount}
                    </td>
                    <td className="p-2 text-center font-bold text-amber-700 bg-amber-50/50 border-l border-slate-100 font-mono-numbers">
                      {item.lateCount}
                    </td>
                    <td className="p-2 text-center font-bold text-slate-700 bg-slate-50/50 border-l border-slate-100 font-mono-numbers">
                      {item.unexcusedAbsentCount}
                    </td>
                    <td className="p-2 text-center font-bold text-blue-700 bg-blue-50/50 border-l border-slate-100 font-mono-numbers">
                      {item.excusedCount}
                    </td>
                    <td className="p-2 text-center font-black text-slate-900 bg-slate-50 font-mono-numbers">
                      <span
                        className={`inline-block px-1.5 py-0.5 rounded text-[10px] ${
                          item.rate >= 95
                            ? 'bg-slate-100 text-slate-800'
                            : item.rate >= 85
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-slate-100 text-slate-800'
                        }`}
                      >
                        {item.rate}%
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Official Signatures Box for Print */}
      <div className="hidden print:block pt-8 text-xs font-bold">
        <div className="flex justify-between items-center text-center px-12">
          <div className="space-y-16">
            <p>مستشارة التربية الرئيسية</p>
            <p className="font-extrabold text-sm">{settings.counselorName || 'حليلو صليحة'}</p>
          </div>
          <div className="space-y-16">
            <p>ختم المؤسسة الرسمي</p>
            <div className="w-24 h-24 border-2 border-dashed border-slate-300 rounded-full mx-auto flex items-center justify-center text-slate-300">
              الختم
            </div>
          </div>
          <div className="space-y-16">
            <p>مديرة المتوسطة</p>
            <p className="font-extrabold text-sm">{settings.principalName || 'بويمة ليلى بن تروش'}</p>
          </div>
        </div>
      </div>
    </div>
  );
};
