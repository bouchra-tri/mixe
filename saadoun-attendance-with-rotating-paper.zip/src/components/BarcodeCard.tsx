import React, { useMemo } from 'react';
import { generateBarcodeSVG } from '../utils/barcode';

interface BarcodeCardProps {
  value: string;
  height?: number;
  includeText?: boolean;
  className?: string;
}

export const BarcodeCard: React.FC<BarcodeCardProps> = ({
  value,
  height = 48,
  includeText = true,
  className = '',
}) => {
  const svgContent = useMemo(() => {
    return generateBarcodeSVG(value, {
      height,
      includeText,
      color: '#0f172a',
      bgColor: 'transparent',
    });
  }, [value, height, includeText]);

  return (
    <div
      className={`inline-block select-none overflow-hidden ${className}`}
      dangerouslySetInnerHTML={{ __html: svgContent }}
      title={`باركود: ${value}`}
    />
  );
};
