import React, { useState } from 'react';
import { SchoolSettings, Student, AttendanceRecord, SchoolPeriod } from '../types';
import {
  Settings,
  Save,
  RotateCcw,
  Download,
  Upload,
  Clock,
  School,
  Volume2,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  FileSpreadsheet,
  Monitor,
  Smartphone,
  Sun,
  Moon
} from 'lucide-react';
import { ExcelImportModal } from './ExcelImportModal';
import { soundEffects } from '../utils/barcode';
import { getSettingsPeriods, DEFAULT_PERIODS } from '../utils/periodHelper';
import { ThemeSettingsSection } from './ThemeSettingsSection';
import { useTheme } from '../context/ThemeContext';

interface SettingsModalProps {
  settings: SchoolSettings;
  students: Student[];
  records: AttendanceRecord[];
  onSaveSettings: (settings: SchoolSettings) => void;
  onResetToday: () => void;
  onResetDefaultData: () => void;
  onImportData: (importedStudents: Student[], importedRecords: AttendanceRecord[]) => void;
  onImportExcelStudents?: (importedStudents: Student[], mode: 'upsert' | 'append' | 'replace') => void;
  onClearAllStudents?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  students,
  records,
  onSaveSettings,
  onResetToday,
  onResetDefaultData,
  onImportData,
  onImportExcelStudents,
  onClearAllStudents,
}) => {
  const { palette } = useTheme();
  const [formData, setFormData] = useState<SchoolSettings>(() => {
    const validPeriods = getSettingsPeriods(settings);
    return {
      ...settings,
      periods: validPeriods,
    };
  });
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [isExcelModalOpen, setIsExcelModalOpen] = useState(false);

  const handleUpdatePeriod = (id: string, field: keyof SchoolPeriod, value: any) => {
    setFormData((prev) => {
      const updatedPeriods = (prev.periods || DEFAULT_PERIODS).map((p) => {
        if (p.id === id) {
          const updated = { ...p, [field]: value };
          if (field === 'startTime') {
            updated.shortName = `${p.type === 'morning' ? 'ص' : 'م'} ${p.id.slice(1)} (${value})`;
          }
          return updated;
        }
        return p;
      });

      const m1 = updatedPeriods.find((p) => p.id === 'm1');
      const a1 = updatedPeriods.find((p) => p.id === 'a1');

      return {
        ...prev,
        periods: updatedPeriods,
        morningStartTime: m1 ? m1.startTime : prev.morningStartTime,
        morningLateThreshold: m1 ? m1.lateThreshold : prev.morningLateThreshold,
        afternoonStartTime: a1 ? a1.startTime : prev.afternoonStartTime,
        afternoonLateThreshold: a1 ? a1.lateThreshold : prev.afternoonLateThreshold,
      };
    });
  };

  const handleResetDefaultPeriods = () => {
    if (confirm('هل تريد استعادة التوقيت النموذجي الافتراضي للفترات الست (3 صباحية + 3 مسائية للأفواج)؟')) {
      setFormData((prev) => ({
        ...prev,
        periods: DEFAULT_PERIODS,
        morningStartTime: '08:00',
        morningLateThreshold: '08:05',
        afternoonStartTime: '13:00',
        afternoonLateThreshold: '13:05',
      }));
    }
  };

  const handleSaveAll = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    onSaveSettings(formData);
    setSaveSuccess(true);
    if (formData.soundAlerts) {
      soundEffects.playSuccess();
    }
    setTimeout(() => setSaveSuccess(false), 3500);
  };

  const handleSubmit = (e: React.FormEvent) => {
    handleSaveAll(e);
  };

  // Export JSON backup
  const handleExportBackup = () => {
    const backupData = {
      exportDate: new Date().toISOString(),
      settings: formData,
      students,
      records,
    };
    const blob = new Blob([JSON.stringify(backupData, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `نسخة_احتياطية_متوسطة_سعدون_عاشور_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Import JSON backup
  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed.students && Array.isArray(parsed.students)) {
          onImportData(parsed.students, parsed.records || []);
          if (parsed.settings) {
            onSaveSettings(parsed.settings);
            setFormData(parsed.settings);
          }
          alert('تم استيراد قاعدة البيانات بنجاح!');
        } else {
          alert('الملف غير صالح أو لا يحتوي على بنية بيانات صحيحة.');
        }
      } catch (err) {
        alert('حدث خطأ أثناء قراءة ملف النسخة الاحتياطية.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-wrap items-center justify-between gap-4 transition-colors">
        <div className="flex items-center gap-3">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center shadow-xs transition-colors"
            style={{
              backgroundColor: palette.light,
              color: palette.primary,
              border: `1px solid ${palette.border}`,
            }}
          >
            <Settings className="w-5 h-5 text-current" />
          </div>
          <div>
            <h3 className="font-bold text-slate-900 dark:text-slate-100 text-sm">إعدادات المنصة ومواقيت الدخول</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              تخصيص هوية متوسطة سعدون عاشور وضبط توقيتات الدخول وحساب التأخرات
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          {saveSuccess && (
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 rounded-xl text-xs font-semibold animate-fade-in shadow-2xs">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>تم حفظ البيانات بنجاح</span>
            </div>
          )}
          <button
            type="button"
            onClick={() => handleSaveAll()}
            className="flex items-center gap-2 px-4 py-2 text-xs font-bold active:scale-95 rounded-xl transition-all cursor-pointer shadow-xs hover:shadow-sm"
            style={{
              backgroundColor: palette.primary,
              color: palette.foreground,
            }}
            title="حفظ بيانات وإعدادات النظام"
          >
            <Save className="w-4 h-4 text-current" />
            <span>حفظ البيانات</span>
          </button>
        </div>
      </div>

      {/* Main Theme & Colors Configuration Section (Requirement 1, 4, 5, 6, 8) */}
      <ThemeSettingsSection
        onSettingsThemeChange={(themeColor, customHex, themeMode) => {
          setFormData((prev) => ({
            ...prev,
            themeColor,
            customHexColor: customHex,
            themeMode,
          }));
        }}
      />

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Section 1: Institution Info */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 transition-colors">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800 text-slate-800 dark:text-slate-200 font-bold text-xs">
            <School className="w-4 h-4 text-current" style={{ color: palette.primary }} />
            بيانات المؤسسة التعليمية الرسمية
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">اسم المؤسسة:</label>
              <input
                type="text"
                required
                value={formData.schoolName}
                onChange={(e) => setFormData({ ...formData, schoolName: e.target.value })}
                className="w-full p-2 border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 theme-input-focus"
              />
            </div>

            <div>
              <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">الولاية:</label>
              <input
                type="text"
                required
                value={formData.wilaya}
                onChange={(e) => setFormData({ ...formData, wilaya: e.target.value })}
                className="w-full p-2 border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 theme-input-focus"
              />
            </div>

            <div>
              <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">السنة الدراسية:</label>
              <input
                type="text"
                required
                value={formData.academicYear}
                onChange={(e) => setFormData({ ...formData, academicYear: e.target.value })}
                className="w-full p-2 border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 theme-input-focus font-mono-numbers"
              />
            </div>

            <div>
              <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">اسم مديرة المؤسسة:</label>
              <input
                type="text"
                required
                value={formData.principalName}
                onChange={(e) => setFormData({ ...formData, principalName: e.target.value })}
                className="w-full p-2 border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 theme-input-focus"
              />
            </div>

            <div>
              <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">اسم مستشارة التربية الرئيسية:</label>
              <input
                type="text"
                required
                value={formData.counselorName}
                onChange={(e) => setFormData({ ...formData, counselorName: e.target.value })}
                className="w-full p-2 border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 theme-input-focus"
              />
            </div>

            <div>
              <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">نمط تسجيل حضور الأساتذة:</label>
              <select
                value={formData.attendanceMode || 'per_period'}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    attendanceMode: e.target.value as 'per_period' | 'daily',
                  })
                }
                className="w-full p-2 border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 theme-input-focus"
              >
                <option value="per_period">سجل لكل حصة تعليمية (افتراضي موصى به)</option>
                <option value="daily">سجل يومي موحد للفوج</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">التوقيت الزمني للمؤسسة:</label>
              <input
                type="text"
                required
                value={formData.timezone || 'Africa/Algiers'}
                onChange={(e) => setFormData({ ...formData, timezone: e.target.value })}
                placeholder="Africa/Algiers"
                className="w-full p-2 border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 theme-input-focus font-mono"
              />
            </div>
          </div>
        </div>

        {/* Section 2: Multi-Cohort 6 Periods Customizer (3 Morning + 3 Afternoon) */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 transition-colors">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2 text-slate-800 dark:text-slate-200 font-bold text-xs">
              <Clock className="w-4 h-4 text-current" style={{ color: palette.primary }} />
              <span>مواقيت فترات دخول الأفواج (3 فترات صباحية + 3 فترات مسائية)</span>
            </div>
            <button
              type="button"
              onClick={handleResetDefaultPeriods}
              className="text-[11px] text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 flex items-center gap-1 cursor-pointer transition-colors"
              title="إعادة تعيين كافة مواقيت الفترات إلى الجدول النموذجي"
            >
              <RotateCcw className="w-3 h-3 text-current" />
              <span>استعادة التوقيت الافتراضي للأفواج</span>
            </button>
          </div>

          <p className="text-[11px] text-slate-500">
            يمكنك تخصيص توقيت دخول كل فوج وعتبة التأخر بدقة؛ بحيث يتم احتساب التأخر وفقاً للفترة المحددة لدخول كل فوج دون أي تداخل.
          </p>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 text-xs">
            {/* 3 Morning Periods */}
            <div className="space-y-3">
              <div className="flex items-center gap-1.5 font-bold text-amber-900 pb-1 border-b border-amber-200">
                <Sun className="w-4 h-4 text-amber-600" />
                <span>الفترات الصباحية (3 أفواج دخول):</span>
              </div>

              {(formData.periods || DEFAULT_PERIODS)
                .filter((p) => p.type === 'morning')
                .map((period, idx) => (
                  <div
                    key={period.id}
                    className="p-3.5 bg-amber-50/40 rounded-xl border border-amber-200/80 space-y-2.5 shadow-2xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-amber-950 text-xs">
                        الفترة {idx + 1} ({period.id.toUpperCase()})
                      </span>
                      <input
                        type="text"
                        value={period.name}
                        onChange={(e) => handleUpdatePeriod(period.id, 'name', e.target.value)}
                        className="text-[11px] font-semibold px-2 py-0.5 border border-amber-300 rounded bg-white text-slate-800 w-44"
                        placeholder="اسم الفترة"
                      />
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-[11px]">
                      <div>
                        <label className="block text-slate-600 mb-0.5">وقت الدخول:</label>
                        <input
                          type="time"
                          required
                          value={period.startTime}
                          onChange={(e) => handleUpdatePeriod(period.id, 'startTime', e.target.value)}
                          className="w-full p-1.5 border border-slate-300 rounded-lg font-mono-numbers bg-white text-center"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-600 mb-0.5">بداية التأخر:</label>
                        <input
                          type="time"
                          required
                          value={period.lateThreshold}
                          onChange={(e) => handleUpdatePeriod(period.id, 'lateThreshold', e.target.value)}
                          className="w-full p-1.5 border border-slate-300 rounded-lg font-mono-numbers bg-white text-center"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-600 mb-0.5">إغلاق الفترة:</label>
                        <input
                          type="time"
                          required
                          value={period.cutoffTime}
                          onChange={(e) => handleUpdatePeriod(period.id, 'cutoffTime', e.target.value)}
                          className="w-full p-1.5 border border-slate-300 rounded-lg font-mono-numbers bg-white text-center"
                        />
                      </div>
                    </div>
                  </div>
                ))}
            </div>

            {/* 3 Afternoon Periods */}
            <div className="space-y-3">
              <div className="flex items-center gap-1.5 font-bold text-indigo-900 pb-1 border-b border-indigo-200">
                <Moon className="w-4 h-4 text-indigo-600" />
                <span>الفترات المسائية (3 أفواج دخول):</span>
              </div>

              {(formData.periods || DEFAULT_PERIODS)
                .filter((p) => p.type === 'afternoon')
                .map((period, idx) => (
                  <div
                    key={period.id}
                    className="p-3.5 bg-indigo-50/40 rounded-xl border border-indigo-200/80 space-y-2.5 shadow-2xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-indigo-950 text-xs">
                        الفترة {idx + 1} ({period.id.toUpperCase()})
                      </span>
                      <input
                        type="text"
                        value={period.name}
                        onChange={(e) => handleUpdatePeriod(period.id, 'name', e.target.value)}
                        className="text-[11px] font-semibold px-2 py-0.5 border border-indigo-300 rounded bg-white text-slate-800 w-44"
                        placeholder="اسم الفترة"
                      />
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-[11px]">
                      <div>
                        <label className="block text-slate-600 mb-0.5">وقت الدخول:</label>
                        <input
                          type="time"
                          required
                          value={period.startTime}
                          onChange={(e) => handleUpdatePeriod(period.id, 'startTime', e.target.value)}
                          className="w-full p-1.5 border border-slate-300 rounded-lg font-mono-numbers bg-white text-center"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-600 mb-0.5">بداية التأخر:</label>
                        <input
                          type="time"
                          required
                          value={period.lateThreshold}
                          onChange={(e) => handleUpdatePeriod(period.id, 'lateThreshold', e.target.value)}
                          className="w-full p-1.5 border border-slate-300 rounded-lg font-mono-numbers bg-white text-center"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-600 mb-0.5">إغلاق الفترة:</label>
                        <input
                          type="time"
                          required
                          value={period.cutoffTime}
                          onChange={(e) => handleUpdatePeriod(period.id, 'cutoffTime', e.target.value)}
                          className="w-full p-1.5 border border-slate-300 rounded-lg font-mono-numbers bg-white text-center"
                        />
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>

        {/* Section 3: Audio alerts */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 transition-colors">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800 text-slate-800 dark:text-slate-200 font-bold text-xs">
            <Volume2 className="w-4 h-4 text-current" style={{ color: palette.primary }} />
            التنبيهات الصوتية وتأكيد المسح
          </div>

          <label className="flex items-center gap-3 text-xs cursor-pointer">
            <input
              type="checkbox"
              checked={formData.soundAlerts}
              onChange={(e) => setFormData({ ...formData, soundAlerts: e.target.checked })}
              className="w-4 h-4 rounded border-slate-300 dark:border-slate-700"
              style={{ accentColor: palette.primary }}
            />
            <span className="text-slate-800 dark:text-slate-200 font-medium">
              تشغيل الأصوات التفاعلية (صوت التأكيد عند الدخول في الوقت، وصوت تنبيه التأخر، وصوت الخطأ)
            </span>
          </label>
        </div>

        {/* Save button */}
        <div className="flex justify-end">
          <button
            type="submit"
            className="flex items-center gap-2 px-6 py-2.5 text-xs font-bold rounded-xl transition-all cursor-pointer shadow-xs active:scale-95"
            style={{
              backgroundColor: palette.primary,
              color: palette.foreground,
            }}
          >
            <Save className="w-4 h-4 text-current" />
            حفظ جميع التعديلات
          </button>
        </div>
      </form>

      {/* Section: Desktop & Offline Installation */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-950 text-white p-6 rounded-2xl shadow-md border border-slate-700/80 space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-slate-500/20 border border-slate-400/30 flex items-center justify-center text-slate-400 shrink-0">
              <Monitor className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-white text-sm sm:text-base">
                تحميل وتثبيت المنصة على الكمبيوتر (Windows / Mac / Linux) للعمل بدون إنترنت
              </h4>
              <p className="text-xs text-slate-300 mt-0.5">
                يمكنك تثبيت هذا التطبيق كبرنامج مستقل على سطح المكتب على جهاز الكمبيوتر الخاص بك ليعمل بسرعة فائقة وبدون حاجة للاتصال بالإنترنت.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => {
                alert('طريقة تثبيت البرنامج على الكمبيوتر:\n\n1. في شريط عنوان المتصفح (أعلى اليمين أو اليسار)، انقر على أداة التثبيت 🖥️ أو أيقونة التنزيل (Install App).\n2. أو انقر على قائمة المتصفح (ثلاث نقاط ⋮) ثم اختر "تثبيت المنصة - متوسطة سعدون عاشور" (Install App).\n3. سيتم فتح البرنامج في نافذة مستقلة على سطح المكتب مع اختصار خاص.');
              }}
              className="flex items-center gap-2 px-4 py-2.5 bg-slate-600 hover:bg-slate-500 text-white rounded-xl font-bold text-xs shadow-md transition-all cursor-pointer border border-slate-400/40"
            >
              <Download className="w-4 h-4" />
              <span>خطوات التثبيت على الكمبيوتر</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-slate-700/60 text-[11px] text-slate-300">
          <div className="flex items-center gap-2 bg-white/5 p-2.5 rounded-xl border border-white/10">
            <span className="w-6 h-6 rounded-lg bg-blue-500/20 text-blue-300 flex items-center justify-center font-bold">1</span>
            <span>افتح المنصة من متصفح Chrome أو Edge على الكمبيوتر.</span>
          </div>
          <div className="flex items-center gap-2 bg-white/5 p-2.5 rounded-xl border border-white/10">
            <span className="w-6 h-6 rounded-lg bg-blue-500/20 text-blue-300 flex items-center justify-center font-bold">2</span>
            <span>انقر أيقونة التثبيت 📥 في شريط العنوان أو من قائمة المتصفح.</span>
          </div>
          <div className="flex items-center gap-2 bg-white/5 p-2.5 rounded-xl border border-white/10">
            <span className="w-6 h-6 rounded-lg bg-slate-500/20 text-slate-300 flex items-center justify-center font-bold">3</span>
            <span>استمتع بالبرنامج كأي برنامج كمبيوتر عادي يعمل بدون إنترنت!</span>
          </div>
        </div>
      </div>

      {/* Section 4: Data Management & Backup */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 transition-colors">
        <h4 className="font-bold text-slate-900 dark:text-slate-100 text-xs pb-2 border-b border-slate-100 dark:border-slate-800">
          إدارة البيانات والنسخ الاحتياطي
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
          {/* Save Data Direct Card */}
          <button
            type="button"
            onClick={() => handleSaveAll()}
            className="flex flex-row items-center gap-3 p-3.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50/80 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors cursor-pointer text-right shadow-2xs group"
          >
            <div
              className="p-2.5 rounded-lg shrink-0 group-hover:scale-105 transition-transform"
              style={{
                backgroundColor: palette.light,
                color: palette.primary,
              }}
            >
              <Save className="w-5 h-5 text-current" />
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-slate-950 dark:text-slate-100 text-xs sm:text-sm">حفظ البيانات</span>
              <span className="text-[10px] text-slate-500 dark:text-slate-400">تثبيت وتحديث القاعدة</span>
            </div>
          </button>

          {/* Import Excel */}
          <button
            type="button"
            onClick={() => setIsExcelModalOpen(true)}
            className="flex flex-row items-center gap-3 p-3.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/50 hover:bg-slate-100/60 dark:hover:bg-slate-700/60 transition-colors cursor-pointer text-right shadow-2xs group"
          >
            <div className="p-2.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 shrink-0 group-hover:scale-105 transition-transform">
              <FileSpreadsheet className="w-5 h-5 text-current" />
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-slate-950 dark:text-slate-100 text-xs sm:text-sm">استيراد من Excel</span>
              <span className="text-[10px] text-slate-500 dark:text-slate-400">رفع ملف .XLSX / .XLS</span>
            </div>
          </button>

          {/* Export JSON */}
          <button
            type="button"
            onClick={handleExportBackup}
            className="flex flex-row items-center gap-3 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer text-right group"
          >
            <div className="p-2.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 shrink-0 group-hover:scale-105 transition-transform">
              <Download className="w-5 h-5 text-current" />
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-slate-800 dark:text-slate-200 text-xs sm:text-sm">تصدير نسخة احتياطية</span>
              <span className="text-[10px] text-slate-400 dark:text-slate-500">تحميل ملف JSON كامل</span>
            </div>
          </button>

          {/* Import JSON */}
          <label className="flex flex-row items-center gap-3 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer text-right group">
            <div className="p-2.5 rounded-lg bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 shrink-0 group-hover:scale-105 transition-transform">
              <Upload className="w-5 h-5 text-current" />
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-slate-800 dark:text-slate-200 text-xs sm:text-sm">استيراد نسخة احتياطية</span>
              <span className="text-[10px] text-slate-400 dark:text-slate-500">رفع ملف JSON سابق</span>
            </div>
            <input
              type="file"
              accept=".json"
              onChange={handleImportFile}
              className="hidden"
            />
          </label>

          {/* Reset Today */}
          <button
            type="button"
            onClick={() => {
              if (confirm('هل أنت متأكد من رغبتك في تفريغ سجلات تسجيل دخول اليوم للبدء من جديد؟')) {
                onResetToday();
              }
            }}
            className="flex flex-row items-center gap-3 p-3.5 rounded-xl border border-amber-200 dark:border-amber-800/60 bg-amber-50/40 dark:bg-amber-950/20 hover:bg-amber-50 dark:hover:bg-amber-950/40 transition-colors cursor-pointer text-right group"
          >
            <div className="p-2.5 rounded-lg bg-amber-100 dark:bg-amber-900/50 text-amber-700 dark:text-amber-300 shrink-0 group-hover:scale-105 transition-transform">
              <RotateCcw className="w-5 h-5 text-current" />
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-amber-900 dark:text-amber-200 text-xs sm:text-sm">إعادة ضبط اليوم</span>
              <span className="text-[10px] text-amber-700 dark:text-amber-400">مسح عمليات مسح اليوم</span>
            </div>
          </button>

          {/* Clear All Students */}
          <button
            type="button"
            onClick={() => {
              if (confirm('هل أنت متأكد تماماً من رغبتك في مسح كافة بيانات التلاميذ وتفريغ السجل بالكامل؟')) {
                onClearAllStudents?.();
              }
            }}
            className="flex flex-row items-center gap-3 p-3.5 rounded-xl border border-red-200 dark:border-red-900/60 bg-red-50/30 dark:bg-red-950/20 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors cursor-pointer text-right group"
          >
            <div className="p-2.5 rounded-lg bg-red-100 dark:bg-red-900/50 text-red-700 dark:text-red-300 shrink-0 group-hover:scale-105 transition-transform">
              <Trash2 className="w-5 h-5 text-current" />
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-red-900 dark:text-red-200 text-xs sm:text-sm">مسح بيانات التلاميذ</span>
              <span className="text-[10px] text-red-700 dark:text-red-400">تفريغ السجل وقاعدة البيانات</span>
            </div>
          </button>
        </div>
      </div>

      {/* Excel Import Modal */}
      {isExcelModalOpen && (
        <ExcelImportModal
          onClose={() => setIsExcelModalOpen(false)}
          currentStudentsCount={students.length}
          existingStudents={students}
          onImportStudents={(imported, mode) => {
            if (onImportExcelStudents) {
              onImportExcelStudents(imported, mode);
            }
          }}
        />
      )}
    </div>
  );
};
