import React from 'react';
import { AttendanceRecord, Student, SchoolSettings } from '../types';
import { Printer, X, Clock, AlertTriangle, CheckCircle } from 'lucide-react';

interface LateTicketModalProps {
  record: AttendanceRecord;
  student: Student;
  settings: SchoolSettings;
  onClose: () => void;
}

export const LateTicketModal: React.FC<LateTicketModalProps> = ({
  record,
  student,
  settings,
  onClose,
}) => {
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full overflow-hidden border border-slate-200">
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 bg-slate-50 no-print">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-amber-600" />
            <h3 className="font-bold text-slate-800 text-sm">
              إشعار وتذكرة دخول تلميذ متأخر
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-600 hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              طباعة التذكرة
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Ticket Content */}
        <div className="p-6 space-y-4 print:p-0 print:m-0 text-slate-900">
          {/* Header */}
          <div className="text-center border-b pb-3 border-slate-200">
            <p className="text-[11px] text-slate-600 font-medium">الجمهورية الجزائرية الديمقراطية الشعبية</p>
            <p className="text-[11px] text-slate-600 font-medium">وزارة التربية الوطنية · مديرية التربية لولاية {settings.wilaya}</p>
            <h2 className="text-base font-bold text-slate-900 mt-1">{settings.schoolName}</h2>
            <p className="text-xs font-semibold text-slate-700 mt-0.5">مصلحة الاستشارة التربوية · شؤون التلاميذ</p>
            <div className="inline-block mt-2 px-3 py-1 bg-amber-50 border border-amber-200 rounded text-amber-900 text-xs font-bold">
              تذكرة دخول للقسم (حالة تأخر)
            </div>
          </div>

          {/* Ticket Body */}
          <div className="bg-slate-50/70 p-4 rounded-xl border border-slate-200 text-sm space-y-2.5">
            <div className="flex justify-between items-center text-xs text-slate-500 pb-2 border-b border-slate-200">
              <span>التاريخ: <strong className="font-mono-numbers text-slate-800">{record.date}</strong></span>
              <span>رقم التسجيل: <strong className="font-mono-numbers text-slate-800">{student.id}</strong></span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <span className="text-slate-500 block">اسم ولقب التلميذ:</span>
                <span className="font-bold text-slate-900 text-sm">{student.lastName} {student.firstName}</span>
              </div>
              <div>
                <span className="text-slate-500 block">القسم والفوج:</span>
                <span className="font-bold text-slate-900 text-sm">{student.classroom}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs pt-1">
              <div>
                <span className="text-slate-500 block">وقت تسجيل الدخول بالبوابة:</span>
                <span className="font-mono-numbers font-bold text-amber-700 text-sm">{record.timestamp}</span>
              </div>
              <div>
                <span className="text-slate-500 block">مقدار التأخر المسجل:</span>
                <span className="font-bold text-amber-700 text-sm">+{record.lateMinutes} دقيقة</span>
              </div>
            </div>

            <div className="pt-2 text-xs">
              <span className="text-slate-500 block">الفترة التعليمية:</span>
              <span className="font-medium text-slate-800">
                {record.session === 'morning' ? 'الفترة الصباحية (حصص الصباح)' : 'الفترة المسائية (حصص المساء)'}
              </span>
            </div>

            {record.excuseReason && (
              <div className="pt-1 text-xs">
                <span className="text-slate-500 block">السبب المصرح به:</span>
                <span className="font-medium text-slate-700">{record.excuseReason}</span>
              </div>
            )}
          </div>

          {/* Instructions for Teacher */}
          <div className="p-3 bg-blue-50 border border-blue-100 rounded-lg text-xs text-blue-900 leading-relaxed">
            <p className="font-bold mb-0.5">ملاحظة موجهة لأستاذ الحصة:</p>
            <p>يُرخص للتلميذ(ة) بالالتحاق بحجرته الدراسية لمتابعة الدرس، مع تسجيل التأخر في سجل الغياب الخاص بالقسم وتنبيهه إلى وجوب الانضباط بالمواعيد الرسمية للمؤسسة.</p>
          </div>

          {/* Signatures */}
          <div className="grid grid-cols-2 gap-8 pt-4 text-xs text-center border-t border-slate-200">
            <div>
              <p className="font-bold text-slate-700 mb-8">مستشارة التربية / المراقبة العامة</p>
              <p className="text-[10px] text-slate-400">التوقيع والختم</p>
            </div>
            <div>
              <p className="font-bold text-slate-700 mb-8">أستاذ الحصة المستقبل</p>
              <p className="text-[10px] text-slate-400">تأشيرة الدخول</p>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 bg-slate-50 border-t border-slate-100 flex justify-end gap-2 no-print">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-800 bg-white border border-slate-200 rounded-lg transition-colors cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
