import React, { useState, useRef, useMemo } from 'react';
import {
  FileSpreadsheet,
  Upload,
  Download,
  X,
  CheckCircle2,
  AlertTriangle,
  FileCheck,
  HelpCircle,
  Users,
  Clock,
  Sparkles,
  Calendar,
  Layers,
  Search,
  BookOpen,
  MapPin,
  Check,
  ArrowRight,
  ShieldAlert,
  Loader2,
  Info,
} from 'lucide-react';
import {
  TimetableSession,
  TimetableSlotId,
  SchoolDay,
  Teacher,
  SchoolSettings,
  TimetableMetadata,
} from '../types';
import {
  parseTimetableWorkbook,
  ParseResult,
  generateSaadounAchourSampleExcel,
  OFFICIAL_SLOTS_MAP,
} from '../utils/timetableExcelParser';
import { DAYS_OF_WEEK, TEACHERS, SUBJECT_INFO } from '../data/timetableData';

interface TimetableExcelImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: SchoolSettings;
  existingTeachers?: Teacher[];
  teachers?: Teacher[];
  existingSessions?: TimetableSession[];
  availableClassrooms?: string[];
  onCommitImport: (
    sessions: TimetableSession[],
    meta: TimetableMetadata,
    updateSchoolSettings: boolean
  ) => Promise<void> | void;
}

export const TimetableExcelImportModal: React.FC<TimetableExcelImportModalProps> = ({
  isOpen,
  onClose,
  settings,
  existingTeachers,
  teachers,
  existingSessions,
  availableClassrooms = [
    '1م1', '1م2', '1م3', '1م4', '1م5',
    '2م1', '2م2', '2م3', '2م4',
    '3م1', '3م2', '3م3', '3م4',
    '4م1', '4م2', '4م3', '4م4',
  ],
  onCommitImport,
}) => {
  const teacherList = existingTeachers || teachers || TEACHERS;
  if (!isOpen) return null;

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // States
  const [file, setFile] = useState<File | null>(null);
  const [isParsing, setIsParsing] = useState(false);
  const [parseError, setParseError] = useState<string | null>(null);
  const [parseResult, setParseResult] = useState<ParseResult | null>(null);

  // Active step / tab in modal
  const [activeTab, setActiveTab] = useState<'report' | 'grid_preview' | 'commit_settings'>('report');

  // Preview filters
  const [previewClassroom, setPreviewClassroom] = useState<string>('1م1');

  // Commit Form Settings
  const [timetableName, setTimetableName] = useState<string>(
    'التوقيت الأسبوعي العام - متوسطة سعدون عاشور'
  );
  const [academicYear, setAcademicYear] = useState<string>('2024/2025');
  const [effectiveDate, setEffectiveDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [updateSchoolSettings, setUpdateSchoolSettings] = useState<boolean>(true);
  const [isCommitting, setIsCommitting] = useState(false);
  const [commitError, setCommitError] = useState<string | null>(null);
  const [commitSuccess, setCommitSuccess] = useState<string | null>(null);

  // Handle file upload
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (!selected) return;
    await processFile(selected);
  };

  const processFile = async (f: File) => {
    setFile(f);
    setIsParsing(true);
    setParseError(null);
    setCommitError(null);

    try {
      const buffer = await f.arrayBuffer();
      const result = await parseTimetableWorkbook(buffer, existingTeachers, availableClassrooms);

      if (result.sessions.length === 0) {
        setParseError('لم يتم العثور على أي حصص صالحة في الملف. يرجى التأكد من اختيار ورقة "أقسام - أفقي" أو "أساتذة - أفقي".');
        setParseResult(null);
      } else {
        setParseResult(result);
        if (result.academicYear) {
          setAcademicYear(result.academicYear);
        }
        setTimetableName(`توقيت المؤسسة (${f.name.replace(/\.[^/.]+$/, '')})`);
        setActiveTab('report');
      }
    } catch (err: any) {
      console.error('Error parsing timetable excel:', err);
      setParseError(err?.message || 'حدث خطأ أثناء قراءة ملف Excel.');
      setParseResult(null);
    } finally {
      setIsParsing(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  // One-click: Load sample Saadoun Achour workbook directly
  const handleLoadSampleDirectly = async () => {
    setIsParsing(true);
    setParseError(null);
    try {
      const bytes = generateSaadounAchourSampleExcel();
      const buffer = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
      const result = await parseTimetableWorkbook(buffer, teacherList, availableClassrooms);
      setParseResult(result);
      setAcademicYear(result.academicYear);
      setTimetableName('توقيت متوسطة سعدون عاشور المعتمد');
      setActiveTab('report');
    } catch (err: any) {
      setParseError('فشل تحميل النموذج التجريبي');
    } finally {
      setIsParsing(false);
    }
  };

  // Download template workbook
  const handleDownloadTemplate = () => {
    const bytes = generateSaadounAchourSampleExcel();
    const buffer = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
    const blob = new Blob([buffer], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'سعدون عاشور - كل الجداول(1).xlsx';
    a.click();
    URL.revokeObjectURL(url);
  };

  // Submit and commit imported timetable
  const handleCommit = async () => {
    if (!parseResult || parseResult.sessions.length === 0) return;

    setIsCommitting(true);
    setCommitError(null);

    try {
      const metaPayload: TimetableMetadata = {
        id: `TT-${Date.now()}`,
        name: timetableName,
        academicYear,
        effectiveDate,
        effectiveFrom: effectiveDate,
        version: 1,
        importedAt: new Date().toISOString(),
        sourceSheet: parseResult.selectedSheet,
        sourceFileName: file?.name || 'سعدون عاشور - كل الجداول(1).xlsx',
        sourceFile: file?.name || 'سعدون عاشور - كل الجداول(1).xlsx',
        totalSessions: parseResult.sessions.length,
        totalTeachers: parseResult.report.totalTeachers,
        totalClassrooms: parseResult.report.totalClassrooms,
        isCurrent: true,
      };

      await onCommitImport(parseResult.sessions, metaPayload, updateSchoolSettings);
      setCommitSuccess(`تم اعتماد وحفظ ${parseResult.sessions.length} حصة بنجاح في قاعدة البيانات.`);
      setTimeout(() => {
        onClose();
      }, 1500);
    } catch (err: any) {
      console.error('Commit timetable error:', err);
      setCommitError(err?.message || 'فشل حفظ التوقيت في قاعدة البيانات.');
    } finally {
      setIsCommitting(false);
    }
  };

  // Filtered sessions for the grid preview
  const previewClassSessions = useMemo(() => {
    if (!parseResult) return [];
    return parseResult.sessions.filter((s) => s.classroom === previewClassroom);
  }, [parseResult, previewClassroom]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/75 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-5xl my-6 bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-emerald-950 via-emerald-900 to-teal-900 text-white flex items-center justify-between border-b border-emerald-800">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-amber-400/20 border border-amber-300/40 flex items-center justify-center text-amber-300 shadow-inner">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-black text-amber-100 flex items-center gap-2">
                استيراد توقيت المؤسسة من ملف Excel
                <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-emerald-800/80 text-emerald-200 border border-emerald-700">
                  XLSX
                </span>
              </h2>
              <p className="text-xs text-emerald-200">
                متوسطة سعدون عاشور • قراءة أوراق «أقسام - أفقي» و«أساتذة - أفقي» وربطها بالسكانر والحضور
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isCommitting}
            className="p-2 rounded-xl text-emerald-300 hover:text-white hover:bg-emerald-800/60 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* Upload Dropzone & Quick Action Bar */}
          <div className="bg-slate-50 border-2 border-dashed border-emerald-300 rounded-2xl p-6 text-center hover:bg-emerald-50/40 transition">
            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx, .xls"
              className="hidden"
              onChange={handleFileChange}
            />

            <div className="flex flex-col items-center justify-center space-y-3">
              <div className="w-14 h-14 rounded-2xl bg-emerald-100 border border-emerald-200 flex items-center justify-center text-emerald-700 shadow-sm">
                {isParsing ? (
                  <Loader2 className="w-7 h-7 animate-spin text-emerald-600" />
                ) : (
                  <Upload className="w-7 h-7" />
                )}
              </div>

              <div>
                <p className="text-base font-bold text-slate-800">
                  {file ? `الملف المحدد: ${file.name}` : 'اختر ملف التوقيت الأسبوعي «سعدون عاشور - كل الجداول(1).xlsx»'}
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  يدعم صيغ XLSX الرسمية من برمجيات التوقيت المدرسي (يدعم الخلايا المدمجة، متعددة الأسطر، والأفواج المتوازية)
                </p>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isParsing || isCommitting}
                  className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm shadow-md shadow-emerald-900/20 flex items-center gap-2 transition"
                >
                  <Upload className="w-4 h-4" />
                  اختيار ملف من الجهاز
                </button>

                <button
                  type="button"
                  onClick={handleLoadSampleDirectly}
                  disabled={isParsing || isCommitting}
                  className="px-4 py-2.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 font-semibold text-xs flex items-center gap-1.5 transition"
                >
                  <Sparkles className="w-4 h-4 text-amber-600" />
                  تحميل ومعاينة توقيت سعدون عاشور فوراً
                </button>

                <button
                  type="button"
                  onClick={handleDownloadTemplate}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 font-semibold text-xs flex items-center gap-1.5 transition"
                >
                  <Download className="w-4 h-4 text-slate-600" />
                  تحميل ملف Excel نموذجي
                </button>
              </div>
            </div>
          </div>

          {/* Error Message */}
          {parseError && (
            <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-red-800 text-sm flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">خطأ أثناء معالجة الملف</p>
                <p className="text-xs mt-0.5 text-red-700">{parseError}</p>
              </div>
            </div>
          )}

          {/* Commit Success Message */}
          {commitSuccess && (
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-900 text-sm flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              <p className="font-bold">{commitSuccess}</p>
            </div>
          )}

          {/* Parsed Result Display */}
          {parseResult && (
            <div className="space-y-5">
              {/* Navigation Tabs */}
              <div className="flex border-b border-slate-200 gap-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('report')}
                  className={`pb-3 px-4 font-bold text-sm border-b-2 flex items-center gap-2 transition ${
                    activeTab === 'report'
                      ? 'border-emerald-600 text-emerald-800'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <FileCheck className="w-4 h-4" />
                  تقرير المطابقة والتحقق
                  <span className="px-2 py-0.5 text-xs rounded-full bg-emerald-100 text-emerald-800 font-semibold">
                    {parseResult.sessions.length} حصة
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('grid_preview')}
                  className={`pb-3 px-4 font-bold text-sm border-b-2 flex items-center gap-2 transition ${
                    activeTab === 'grid_preview'
                      ? 'border-emerald-600 text-emerald-800'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <Calendar className="w-4 h-4" />
                  معاينة الجدول الأسبوعي
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('commit_settings')}
                  className={`pb-3 px-4 font-bold text-sm border-b-2 flex items-center gap-2 transition ${
                    activeTab === 'commit_settings'
                      ? 'border-emerald-600 text-emerald-800'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  خيارات السريان والاعتماد
                </button>
              </div>

              {/* TAB 1: Report & Matching */}
              {activeTab === 'report' && (
                <div className="space-y-5">
                  {/* Overview Quick Stats */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="p-3.5 bg-emerald-50 rounded-xl border border-emerald-200">
                      <p className="text-xs text-emerald-700 font-medium">إجمالي الحصص المستخرجة</p>
                      <p className="text-2xl font-black text-emerald-950 mt-1">
                        {parseResult.sessions.length}
                      </p>
                      <p className="text-[11px] text-emerald-600 mt-0.5">
                        الورقة: {parseResult.selectedSheet}
                      </p>
                    </div>

                    <div className="p-3.5 bg-blue-50 rounded-xl border border-blue-200">
                      <p className="text-xs text-blue-700 font-medium">الأقسام المكتشفة</p>
                      <p className="text-2xl font-black text-blue-950 mt-1">
                        {parseResult.report.totalClassrooms}
                      </p>
                      <p className="text-[11px] text-blue-600 mt-0.5">
                        {parseResult.report.classroomsReport.matched.length} متطابقة مع المنصة
                      </p>
                    </div>

                    <div className="p-3.5 bg-indigo-50 rounded-xl border border-indigo-200">
                      <p className="text-xs text-indigo-700 font-medium">الأساتذة المكتشفون</p>
                      <p className="text-2xl font-black text-indigo-950 mt-1">
                        {parseResult.report.totalTeachers}
                      </p>
                      <p className="text-[11px] text-indigo-600 mt-0.5">
                        {parseResult.report.teachersReport.exactMatches.length} متطابق تماماً
                      </p>
                    </div>

                    <div className="p-3.5 bg-amber-50 rounded-xl border border-amber-200">
                      <p className="text-xs text-amber-700 font-medium">القاعات والمخابر</p>
                      <p className="text-2xl font-black text-amber-950 mt-1">
                        {parseResult.report.totalRooms}
                      </p>
                      <p className="text-[11px] text-amber-700 mt-0.5">
                        السنة: {parseResult.academicYear}
                      </p>
                    </div>
                  </div>

                  {/* Afternoon Shift Alert (13:30) */}
                  {parseResult.report.afternoonTimingDiscrepancy.hasDiscrepancy && (
                    <div className="p-4 rounded-xl bg-amber-50/90 border border-amber-300 text-amber-950 space-y-2">
                      <div className="flex items-start gap-2.5">
                        <Clock className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                        <div>
                          <p className="font-bold text-sm">
                            ملاحظة هامة حول مواعيد الفترة المسائية (13:30)
                          </p>
                          <p className="text-xs text-amber-800 mt-0.5">
                            يبدأ التوقيت المسائي في الملف المستورد في الساعة{' '}
                            <span className="font-bold text-amber-950 bg-amber-200/80 px-1.5 py-0.5 rounded">
                              13:30
                            </span>{' '}
                            (بينما إعدادات النظام الحالية 13:00). الحصص المسائية المعتمدة: 13:30–14:30، 14:30–15:30، 15:30–16:30، 16:30–17:30.
                          </p>
                        </div>
                      </div>

                      <label className="flex items-center gap-2.5 pt-1 text-xs font-bold text-amber-900 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={updateSchoolSettings}
                          onChange={(e) => setUpdateSchoolSettings(e.target.checked)}
                          className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-amber-400"
                        />
                        تحديث إعدادات النظام وفترات بوابة الدخول تلقائياً لتتوافق مع توقيت 13:30 المعتمد (موصى به)
                      </label>
                    </div>
                  )}

                  {/* Teachers Matching Details */}
                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                    <h3 className="font-bold text-sm text-slate-800 flex items-center justify-between">
                      <span>تقرير مطابقة الأساتذة في المنصة</span>
                      <span className="text-xs font-normal text-slate-500">
                        مقارنة مع قاعدة بيانات متوسطة سعدون عاشور
                      </span>
                    </h3>

                    {/* Exact Matches */}
                    <div>
                      <p className="text-xs font-semibold text-emerald-700 mb-1.5 flex items-center gap-1">
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        متطابقون تماماً ({parseResult.report.teachersReport.exactMatches.length})
                      </p>
                      <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto p-1 bg-white rounded-lg border border-slate-200">
                        {parseResult.report.teachersReport.exactMatches.map((m, idx) => (
                          <span
                            key={idx}
                            className="text-[11px] px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 font-medium"
                          >
                            {m.matchedTeacher.name} ({m.matchedTeacher.subject})
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Fuzzy / Near Matches */}
                    {parseResult.report.teachersReport.fuzzyMatches.length > 0 && (
                      <div>
                        <p className="text-xs font-semibold text-blue-700 mb-1.5 flex items-center gap-1">
                          <Info className="w-3.5 h-3.5 text-blue-600" />
                          مطابقة تقريبية تمت تسويتها تلقائياً ({parseResult.report.teachersReport.fuzzyMatches.length})
                        </p>
                        <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto p-1 bg-white rounded-lg border border-slate-200">
                          {parseResult.report.teachersReport.fuzzyMatches.map((m, idx) => (
                            <span
                              key={idx}
                              className="text-[11px] px-2 py-0.5 rounded-full bg-blue-50 text-blue-800 border border-blue-200 font-medium"
                              title={`الاسم بالملف: ${m.excelName} ⟵ المعتمد: ${m.matchedTeacher.name}`}
                            >
                              {m.matchedTeacher.name} ⟵ {m.excelName}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Unmatched */}
                    {parseResult.report.teachersReport.unmatched.length > 0 && (
                      <div>
                        <p className="text-xs font-semibold text-amber-700 mb-1.5 flex items-center gap-1">
                          <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                          أسماء أساتذة جدد في الملف ({parseResult.report.teachersReport.unmatched.length})
                        </p>
                        <div className="flex flex-wrap gap-1.5 p-1 bg-white rounded-lg border border-slate-200">
                          {parseResult.report.teachersReport.unmatched.map((m, idx) => (
                            <span
                              key={idx}
                              className="text-[11px] px-2 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200 font-medium"
                            >
                              {m.excelName}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Conflicts Report */}
                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                    <h3 className="font-bold text-sm text-slate-800 flex items-center gap-2">
                      <ShieldAlert className="w-4 h-4 text-emerald-700" />
                      فحص التداخلات والتعارضات في الحصص
                    </h3>

                    {parseResult.report.conflicts.length === 0 ? (
                      <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2 font-medium">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        الجدول سليم ومطابق تماماً: لا توجد أي تعارضات في برمجة الأساتذة أو ازدواجية في القاعات.
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {parseResult.report.conflicts.map((conf, idx) => (
                          <div
                            key={idx}
                            className="p-3 bg-red-50 rounded-lg border border-red-200 text-red-800 text-xs flex items-start gap-2"
                          >
                            <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                            <div>
                              <p className="font-bold">{conf.description}</p>
                              <p className="text-[11px] text-red-600 mt-0.5">
                                الحصة: {conf.slotId} • التوقيت: {conf.timeRange}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Computer Science & Informatics Rooms Report */}
                  <div className="p-4 bg-emerald-50/60 rounded-xl border border-emerald-200 space-y-3">
                    <h3 className="font-bold text-sm text-emerald-950 flex items-center gap-2">
                      <BookOpen className="w-4 h-4 text-emerald-700" />
                      <span>تقرير حصص الإعلام الآلي وقاعات المعلوماتية المستخرجة (معلوماتية_1 / معلوماتية_2)</span>
                    </h3>
                    {parseResult.sessions.filter(s => /اعلام|معلوماتية|كمبيوتر/i.test(s.subject) || /معلوماتية/i.test(s.room)).length === 0 ? (
                      <p className="text-xs text-emerald-800">لم يتم العثور على حصص إعلام آلي صريحة في النطاق المفحوص.</p>
                    ) : (
                      <div className="overflow-x-auto">
                        <table className="w-full text-right text-xs border-collapse bg-white rounded-lg overflow-hidden border border-emerald-200">
                          <thead>
                            <tr className="bg-emerald-100 text-emerald-950 border-b border-emerald-200">
                              <th className="p-2.5">القسم</th>
                              <th className="p-2.5">اليوم</th>
                              <th className="p-2.5">التوقيت والحصة</th>
                              <th className="p-2.5">المادة</th>
                              <th className="p-2.5">الأستاذ</th>
                              <th className="p-2.5">القاعة</th>
                              <th className="p-2.5">حالة الاستخراج والحفظ</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-emerald-100">
                            {parseResult.sessions
                              .filter(s => /اعلام|معلوماتية|كمبيوتر/i.test(s.subject) || /معلوماتية/i.test(s.room))
                              .map((s, idx) => (
                                <tr key={idx} className="hover:bg-emerald-50/40">
                                  <td className="p-2.5 font-bold">{s.classroom}</td>
                                  <td className="p-2.5">{s.day}</td>
                                  <td className="p-2.5 font-mono-numbers">{s.slotId.toUpperCase()} ({s.startTime}-{s.endTime})</td>
                                  <td className="p-2.5 font-bold text-emerald-900">{s.subject}</td>
                                  <td className="p-2.5">{s.teacherName}</td>
                                  <td className="p-2.5 font-bold text-amber-800">{s.room}</td>
                                  <td className="p-2.5">
                                    <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                                      مستخرجة ومحفوظة بنجاح
                                    </span>
                                  </td>
                                </tr>
                              ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB 2: Timetable Grid Preview */}
              {activeTab === 'grid_preview' && (
                <div className="space-y-4">
                  {/* Classroom Selector */}
                  <div className="flex items-center justify-between bg-slate-50 p-3 rounded-xl border border-slate-200">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-700">معاينة جدول القسم:</span>
                      <select
                        value={previewClassroom}
                        onChange={(e) => setPreviewClassroom(e.target.value)}
                        className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500"
                      >
                        {Array.from(new Set(parseResult.sessions.map((s) => s.classroom)))
                          .sort()
                          .map((cls) => (
                            <option key={cls} value={cls}>
                              {cls} ({cls.startsWith('1') ? 'الأولى متوسط' : cls.startsWith('2') ? 'الثانية متوسط' : cls.startsWith('3') ? 'الثالثة متوسط' : 'الرابعة متوسط'})
                            </option>
                          ))}
                      </select>
                    </div>

                    <span className="text-xs text-slate-500">
                      عدد الحصص المبرمجة للقسم: {previewClassSessions.length} حصة
                    </span>
                  </div>

                  {/* Weekly Grid */}
                  <div className="overflow-x-auto rounded-xl border border-slate-200 shadow-sm">
                    <table className="w-full text-right text-xs border-collapse">
                      <thead>
                        <tr className="bg-emerald-900 text-white">
                          <th className="p-2.5 font-bold border-l border-emerald-800 w-24">اليوم</th>
                          {Object.entries(OFFICIAL_SLOTS_MAP).map(([id, meta]) => (
                            <th key={id} className="p-2 font-bold text-center border-l border-emerald-800 last:border-l-0">
                              <div>{meta.label}</div>
                              <div className="text-[10px] font-normal opacity-90">{meta.startTime}–{meta.endTime}</div>
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {DAYS_OF_WEEK.map((dayObj, dIdx) => (
                          <tr key={dayObj.key} className={dIdx % 2 === 0 ? 'bg-white' : 'bg-slate-50/70'}>
                            <td className="p-2.5 font-bold text-slate-800 border-l border-b border-slate-200 bg-slate-100/70">
                              {dayObj.label}
                            </td>
                            {(['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8'] as TimetableSlotId[]).map((slotId) => {
                              const slotSessions = previewClassSessions.filter(
                                (s) => s.day === dayObj.key && s.slotId === slotId
                              );

                              if (slotSessions.length === 0) {
                                return (
                                  <td
                                    key={slotId}
                                    className="p-2 text-center text-slate-300 border-l border-b border-slate-200 bg-slate-50/30"
                                  >
                                    -
                                  </td>
                                );
                              }

                              return (
                                <td
                                  key={slotId}
                                  className="p-2 border-l border-b border-slate-200 align-top"
                                >
                                  {slotSessions.map((session, sIdx) => {
                                    const subInfo = SUBJECT_INFO[session.subject] || {
                                      bg: 'bg-emerald-50',
                                      text: 'text-emerald-900',
                                      border: 'border-emerald-200',
                                    };
                                    return (
                                      <div
                                        key={sIdx}
                                        className={`p-1.5 rounded-lg border ${subInfo.bg} ${subInfo.border} mb-1 last:mb-0 shadow-xs`}
                                      >
                                        <p className={`font-bold text-[11px] ${subInfo.text} leading-tight`}>
                                          {session.subject}
                                        </p>
                                        <p className="text-[10px] text-slate-600 truncate mt-0.5">
                                          {session.teacherName}
                                        </p>
                                        <p className="text-[9px] text-slate-500 font-mono">
                                          {session.room}
                                          {session.group && ` (${session.group})`}
                                        </p>
                                      </div>
                                    );
                                  })}
                                </td>
                              );
                            })}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB 3: Commit & Metadata Settings */}
              {activeTab === 'commit_settings' && (
                <div className="space-y-4 bg-slate-50 p-5 rounded-xl border border-slate-200">
                  <h3 className="font-bold text-sm text-slate-800 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-emerald-600" />
                    بيانات اعتماد التوقيت في قاعدة البيانات
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        عنوان أو تسمية التوقيت
                      </label>
                      <input
                        type="text"
                        value={timetableName}
                        onChange={(e) => setTimetableName(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500"
                        placeholder="التوقيت الأسبوعي العام..."
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        السنة الدراسية
                      </label>
                      <input
                        type="text"
                        value={academicYear}
                        onChange={(e) => setAcademicYear(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500"
                        placeholder="2024/2025"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        تاريخ سريان التوقيت
                      </label>
                      <input
                        type="date"
                        value={effectiveDate}
                        onChange={(e) => setEffectiveDate(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500"
                      />
                    </div>

                    <div className="flex flex-col justify-end">
                      <div className="p-3 bg-white rounded-xl border border-slate-200 text-xs text-slate-600 space-y-1">
                        <p className="font-semibold text-slate-800">
                          حفظ التوقيت يضمن استمرارية البيانات:
                        </p>
                        <p className="text-[11px] text-slate-500">
                          • لا يتم حذف أي سجل حضور سابق.
                          <br />
                          • يتم حفظ التوقيت برقم إصدار رسمي في قاعدة البيانات.
                        </p>
                      </div>
                    </div>
                  </div>

                  {commitError && (
                    <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-800 text-xs font-semibold">
                      {commitError}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-slate-100 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            disabled={isCommitting}
            className="px-5 py-2.5 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 font-bold text-xs transition"
          >
            إلغاء
          </button>

          <div className="flex items-center gap-3">
            {parseResult && activeTab !== 'commit_settings' && (
              <button
                type="button"
                onClick={() => setActiveTab('commit_settings')}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs flex items-center gap-2 transition"
              >
                متابعة لاعتماد التوقيت
                <ArrowRight className="w-3.5 h-3.5 rotate-180" />
              </button>
            )}

            {parseResult && (
              <button
                type="button"
                onClick={handleCommit}
                disabled={isCommitting || !parseResult.sessions.length}
                className="px-6 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-black text-xs shadow-md shadow-emerald-900/20 flex items-center gap-2 transition disabled:opacity-50"
              >
                {isCommitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    جاري حفظ التوقيت في قاعدة البيانات...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    اعتماد وحفظ التوقيت في المنصة ({parseResult.sessions.length} حصة)
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
