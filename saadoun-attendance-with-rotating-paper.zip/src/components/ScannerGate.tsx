import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Student, AttendanceRecord, SchoolSettings, ScanResult, PeriodId } from '../types';
import { soundEffects } from '../utils/barcode';
import { getPeriodById, getSettingsPeriods, detectPeriodForScanTime } from '../utils/periodHelper';
import {
  DualBarcodeScanner,
  isTorchSupported,
  toggleTorch,
  getZoomCapabilities,
  setZoom,
  triggerHapticFeedback,
} from '../utils/barcodeScanner';
import {
  matchStudentByBarcode,
  getBarcodeCandidates,
  normalizeDigits,
  stripBarcodeControlChars,
} from '../utils/barcodeNormalizer';
import { SmsNotificationModal } from './SmsNotificationModal';
import { useTheme } from '../context/ThemeContext';
import {
  Scan,
  Camera,
  CameraOff,
  Keyboard,
  Clock,
  CheckCircle2,
  AlertTriangle,
  UserX,
  Sparkles,
  Users,
  Search,
  Volume2,
  VolumeX,
  FileText,
  RotateCcw,
  Maximize2,
  Minimize2,
  Zap,
  ZapOff,
  Smartphone,
  MessageSquare,
  HelpCircle,
  Video,
  Check,
  ChevronDown,
  Wrench,
  ShieldAlert,
  Cpu,
  Terminal,
  RefreshCw,
  X,
  Info,
  Sun,
  Moon,
} from 'lucide-react';

interface ScannerGateProps {
  students: Student[];
  records: AttendanceRecord[];
  settings: SchoolSettings;
  currentSession: 'morning' | 'afternoon';
  currentPeriodId?: string;
  onChangePeriod?: (periodId: PeriodId) => void;
  onAddRecord: (record: AttendanceRecord) => void;
  onUpdateRecord?: (record: AttendanceRecord) => void;
  onOpenLateTicket: (record: AttendanceRecord, student: Student) => void;
  onViewStudentCard: (student: Student) => void;
}

export const ScannerGate: React.FC<ScannerGateProps> = ({
  students,
  records,
  settings,
  currentSession,
  currentPeriodId = 'm1',
  onChangePeriod,
  onAddRecord,
  onUpdateRecord,
  onOpenLateTicket,
  onViewStudentCard,
}) => {
  const { palette } = useTheme();
  const [manualCode, setManualCode] = useState('');
  const [activeTab, setActiveTab] = useState<'gun' | 'camera' | 'simulator'>('camera');
  const [lastScanResult, setLastScanResult] = useState<ScanResult | null>(null);
  
  // Camera State
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraFacingMode, setCameraFacingMode] = useState<'environment' | 'user'>('environment');
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [availableDevices, setAvailableDevices] = useState<MediaDeviceInfo[]>([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>('');
  const [torchSupported, setTorchSupported] = useState<boolean>(false);
  const [isTorchOn, setIsTorchOn] = useState<boolean>(false);
  const [zoomRange, setZoomRange] = useState<{ min: number; max: number; step: number; current?: number } | null>(null);
  const [currentZoom, setCurrentZoom] = useState<number>(1);
  const [scanPulse, setScanPulse] = useState<'none' | 'success' | 'late' | 'warning' | 'error'>('none');
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [cameraScannedCount, setCameraScannedCount] = useState<number>(0);
  const [smsModalStudent, setSmsModalStudent] = useState<Student | null>(null);
  const [showTips, setShowTips] = useState<boolean>(false);
  const [showTroubleshooter, setShowTroubleshooter] = useState<boolean>(false);
  const [lastRawInput, setLastRawInput] = useState<string>('');
  const [recentDiagnosticScans, setRecentDiagnosticScans] = useState<
    Array<{
      raw: string;
      normalized: string;
      studentName?: string;
      status: 'matched' | 'unmatched' | 'duplicate';
      time: string;
      device: string;
    }>
  >([]);

  // Simulator State
  const [simulatorGrade, setSimulatorGrade] = useState<string>('all');
  const [simulatorSearch, setSimulatorSearch] = useState('');
  const [soundEnabled, setSoundEnabled] = useState(settings.soundAlerts);

  // Refs
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const scannerEngineRef = useRef<DualBarcodeScanner | null>(null);
  const manualInputRef = useRef<HTMLInputElement | null>(null);
  const barcodeBufferRef = useRef<string>('');
  const lastKeyTimeRef = useRef<number>(0);
  const fullscreenContainerRef = useRef<HTMLDivElement | null>(null);

  // Today's date YYYY-MM-DD
  const todayStr = new Date().toISOString().split('T')[0];

  const periods = getSettingsPeriods(settings);
  const activePeriod = getPeriodById(settings, currentPeriodId);

  // Records for current date and active period
  const todayRecords = records.filter(
    (r) =>
      r.date === todayStr &&
      (r.session === activePeriod.id || r.periodId === activePeriod.id)
  );

  const presentCount = todayRecords.filter((r) => r.status === 'present').length;
  const lateCount = todayRecords.filter((r) => r.status === 'late').length;
  const totalScanned = todayRecords.length;
  const totalStudents = students.length;
  const attendanceRate = totalStudents > 0 ? Math.round((totalScanned / totalStudents) * 100) : 0;

  // Process a barcode scan with intelligent normalization and optional override
  const handleProcessBarcode = useCallback(
    (
      scannedBarcode: string,
      device: 'scanner_gun' | 'camera' | 'manual' | 'simulator',
      overrideExisting: boolean = false
    ) => {
      const cleanCode = stripBarcodeControlChars(scannedBarcode);
      if (!cleanCode) return;

      setLastRawInput(cleanCode);
      const now = new Date();
      const timeStr = now.toTimeString().split(' ')[0]; // HH:mm:ss
      const hours = now.getHours();
      const minutes = now.getMinutes();

      // Multi-candidate tolerant matching (Arabic numerals, French AZERTY digits, punctuation-stripped)
      const matchResult = matchStudentByBarcode(students, cleanCode);
      const student = matchResult.student;

      // 1. If student is not registered in database
      if (!student) {
        if (soundEnabled) soundEffects.playError();
        triggerHapticFeedback([100, 50, 100]);
        setScanPulse('error');
        setTimeout(() => setScanPulse('none'), 800);

        setRecentDiagnosticScans((prev) => [
          {
            raw: cleanCode,
            normalized: matchResult.candidatesTested[0] || cleanCode,
            status: 'unmatched',
            time: timeStr,
            device,
          },
          ...prev.slice(0, 9),
        ]);

        setLastScanResult({
          type: 'error',
          title: 'رمز باركود غير مسجل في قاعدة البيانات',
          message: `الرمز المقروء "${cleanCode}" غير مسجل لأي تلميذ في مؤسسة ${settings.schoolName}.`,
          rawScannedCode: cleanCode,
          candidatesTested: matchResult.candidatesTested,
          details: `تم فحص الباركود ورقم التعريف الوطني والمعرف المدرسي (${matchResult.candidatesTested.slice(0, 3).join(' / ')}). يرجى التأكد من إضافة التلميذ في قائمة التلاميذ أو مطابقة رقم الباركود.`,
          timestamp: timeStr,
        });
        return;
      }

      // 2. Check if student already checked in for this date and session
      // 2. Auto-detect period from scan time
      const detectedPeriod = detectPeriodForScanTime(settings, now);
      const periodToUse = detectedPeriod || activePeriod;

      if (!detectedPeriod) {
        if (soundEnabled) soundEffects.playError();
        triggerHapticFeedback([100, 50, 100]);
        setScanPulse('error');
        setTimeout(() => setScanPulse('none'), 800);

        setLastScanResult({
          type: 'error',
          title: 'وقت المسح خارج أوقات الفترات الدراسية المعتمدة',
          message: `وقت المسح الحالي (${timeStr}) خارج مواعيد الحصص والفترات الرسمية. لم يتم تسجيل الحضور في فترة عشوائية. يرجى اختيار الفترة يدوياً أو المسح في أوقات الحصص الرسمية.`,
          rawScannedCode: cleanCode,
          timestamp: timeStr,
        });
        return;
      }

      // 3. Check if student already checked in for this date and exact period
      const existingInPeriod = records.find(
        (r) =>
          r.studentId === student.id &&
          r.date === todayStr &&
          (r.periodId === periodToUse.id || r.session === periodToUse.id)
      );

      if (existingInPeriod && !overrideExisting) {
        if (soundEnabled) soundEffects.playDuplicate();
        triggerHapticFeedback([80, 40, 80]);
        setScanPulse('warning');
        setTimeout(() => setScanPulse('none'), 800);

        setRecentDiagnosticScans((prev) => [
          {
            raw: cleanCode,
            normalized: matchResult.matchedCandidate,
            studentName: `${student.lastName} ${student.firstName}`,
            status: 'duplicate',
            time: timeStr,
            device,
          },
          ...prev.slice(0, 9),
        ]);

        setLastScanResult({
          type: 'warning',
          title: 'تم تسجيل حضورك مسبقًا لهذه الفترة',
          message: `تم تسجيل حضور التلميذ (${student.lastName} ${student.firstName}) مسبقًا لهذه الفترة (${periodToUse.name}) في تمام الساعة ${existingInPeriod.timestamp}.`,
          student,
          record: existingInPeriod,
          rawScannedCode: cleanCode,
          details: 'النظام يمنع تكرار تسجيل حضور نفس التلميذ داخل الفترة نفسها في اليوم نفسه.',
          timestamp: timeStr,
        });
        return;
      }

      // 4. Determine on-time vs late status based on periodToUse
      let isLate = false;
      let lateMinutes = 0;

      const [startHour, startMin] = (periodToUse.startTime || '08:00').split(':').map(Number);
      const [thresholdHour, thresholdMin] = (periodToUse.lateThreshold || '08:05').split(':').map(Number);

      const currentMinutesOfDay = hours * 60 + minutes;
      const thresholdMinutesOfDay = thresholdHour * 60 + thresholdMin;
      const startMinutesOfDay = startHour * 60 + startMin;

      if (currentMinutesOfDay > thresholdMinutesOfDay) {
        isLate = true;
        lateMinutes = Math.max(1, currentMinutesOfDay - startMinutesOfDay);
      }

      const status = isLate ? 'late' : 'present';

      const newRecord: AttendanceRecord = {
        id: `ATT-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        studentId: student.id,
        barcode: student.barcode,
        studentName: `${student.lastName} ${student.firstName}`,
        grade: student.grade,
        classroom: student.classroom,
        date: todayStr,
        timestamp: timeStr,
        fullDateTime: now.toISOString(),
        session: periodToUse.id,
        periodId: periodToUse.id,
        status,
        lateMinutes,
        device,
      };

      onAddRecord(newRecord);

      setRecentDiagnosticScans((prev) => [
        {
          raw: cleanCode,
          normalized: matchResult.matchedCandidate,
          studentName: `${student.lastName} ${student.firstName}`,
          status: 'matched',
          time: timeStr,
          device,
        },
        ...prev.slice(0, 9),
      ]);

      if (device === 'camera') {
        setCameraScannedCount((prev) => prev + 1);
      }

      triggerHapticFeedback(isLate ? [120, 60, 120] : [70, 30, 70]);

      // Informative hint if automatic keyboard layout conversion was applied
      const wasConverted = matchResult.matchedCandidate !== cleanCode;
      const conversionNote = wasConverted
        ? ` (تم التعرف تلقائياً ومعالجة لغة لوحة المفاتيح: ${cleanCode} ⟵ ${matchResult.matchedCandidate})`
        : '';

      if (isLate) {
        if (soundEnabled) soundEffects.playLate();
        setScanPulse('late');
        setTimeout(() => setScanPulse('none'), 800);
        setLastScanResult({
          type: 'late',
          title: 'تسجيل دخول متأخر',
          message: `تم تسجيل حضور التلميذ (${student.lastName} ${student.firstName}) في الفترة (${periodToUse.name}) متأخراً بـ ${lateMinutes} دقيقة في تمام الساعة ${timeStr}.${conversionNote}`,
          student,
          record: newRecord,
          rawScannedCode: cleanCode,
          timestamp: timeStr,
        });
      } else {
        if (soundEnabled) soundEffects.playSuccess();
        setScanPulse('success');
        setTimeout(() => setScanPulse('none'), 800);
        setLastScanResult({
          type: 'success',
          title: 'تم تسجيل الحضور بنجاح',
          message: `تم تسجيل حضور التلميذ (${student.lastName} ${student.firstName}) في الفترة (${periodToUse.name}) بنجاح في تمام الساعة ${timeStr}.${conversionNote}`,
          student,
          record: newRecord,
          rawScannedCode: cleanCode,
          timestamp: timeStr,
        });
      }

      setManualCode('');
    },
    [students, todayRecords, activePeriod, settings, todayStr, soundEnabled, onAddRecord, onUpdateRecord]
  );

  // USB Barcode Scanner hardware listener (keyboard wedge mode)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const activeElement = document.activeElement;
      const isOtherInput =
        activeElement &&
        (activeElement.tagName === 'INPUT' || activeElement.tagName === 'TEXTAREA') &&
        activeElement !== manualInputRef.current;

      // Do not capture if user is typing in unrelated search boxes
      if (isOtherInput) return;

      const currentTime = Date.now();
      const timeDiff = currentTime - lastKeyTimeRef.current;
      lastKeyTimeRef.current = currentTime;

      if (e.key === 'Enter') {
        const rawBuffer = barcodeBufferRef.current.trim();
        const manualVal = manualInputRef.current ? manualInputRef.current.value.trim() : '';
        const codeToProcess = rawBuffer || manualVal;

        barcodeBufferRef.current = '';
        if (manualInputRef.current) {
          setManualCode('');
        }

        if (codeToProcess.length >= 1) {
          e.preventDefault();
          handleProcessBarcode(codeToProcess, 'scanner_gun');
        }
      } else if (e.key.length === 1) {
        // Generous 450ms gap allowance for wireless/USB barcode scanners
        if (timeDiff > 450) {
          barcodeBufferRef.current = '';
        }
        barcodeBufferRef.current += e.key;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [handleProcessBarcode]);

  // Handle Manual Submit
  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (manualCode.trim()) {
      handleProcessBarcode(manualCode.trim(), 'manual');
    }
  };

  // Stop Camera helper
  const stopCamera = useCallback(() => {
    if (scannerEngineRef.current) {
      scannerEngineRef.current.stop();
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
    setIsTorchOn(false);
    setTorchSupported(false);
    setZoomRange(null);
  }, []);

  // Start Camera with flexible facing mode and device selection
  const startCamera = useCallback(
    async (targetFacingMode?: 'environment' | 'user', specificDeviceId?: string) => {
      stopCamera();
      setCameraError(null);

      const activeFacing = targetFacingMode || cameraFacingMode;

      try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          throw new Error('كاميرا الهاتف/الويب غير مدعومة في متصفحك الحالي. يرجى استخدام متصفح حديث مثل Chrome أو Safari.');
        }

        // Try getting video devices list
        try {
          const devices = await DualBarcodeScanner.getVideoDevices();
          setAvailableDevices(devices);
        } catch {}

        // Video constraints prioritizing high-frame-rate back camera for phone barcode scanning
        const videoConstraints: MediaTrackConstraints = specificDeviceId
          ? { deviceId: { exact: specificDeviceId } }
          : {
              facingMode: { ideal: activeFacing },
              width: { ideal: 1280, min: 640 },
              height: { ideal: 720, min: 480 },
            };

        const stream = await navigator.mediaDevices.getUserMedia({
          video: videoConstraints,
          audio: false,
        });

        streamRef.current = stream;

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play().catch((playErr) => {
            console.warn('Video play interrupted:', playErr);
          });
        }

        setIsCameraActive(true);
        if (targetFacingMode) setCameraFacingMode(targetFacingMode);
        if (specificDeviceId) setSelectedDeviceId(specificDeviceId);

        // Check torch support on the current track
        const hasTorch = isTorchSupported(stream);
        setTorchSupported(hasTorch);
        setIsTorchOn(false);

        // Check zoom capabilities
        const zoomCaps = getZoomCapabilities(stream);
        setZoomRange(zoomCaps);
        if (zoomCaps?.current) {
          setCurrentZoom(zoomCaps.current);
        }

        // Initialize DualBarcodeScanner (Native BarcodeDetector + ZXing fallback)
        if (!scannerEngineRef.current) {
          scannerEngineRef.current = new DualBarcodeScanner();
        }

        if (videoRef.current) {
          await scannerEngineRef.current.startScanning(
            videoRef.current,
            stream,
            (scannedBarcode) => {
              handleProcessBarcode(scannedBarcode, 'camera');
            },
            (scanErr) => {
              // Frame level warning
            }
          );
        }
      } catch (err: any) {
        console.warn('Camera start error:', err);
        let errorMsg = 'تعذر تشغيل كاميرا الهاتف.';
        if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
          errorMsg = 'تم رفض إذن الوصول للكاميرا. يرجى النقر على أيقونة القفل أو الكاميرا في شريط عنوان المتصفح والسماح بالوصول للكاميرا.';
        } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
          errorMsg = 'لم يتم العثور على كاميرا في هذا الجهاز.';
        } else if (err.name === 'NotReadableError' || err.name === 'TrackStartError') {
          errorMsg = 'الكاميرا قيد الاستخدام حالياً بواسطة تطبيق آخر.';
        } else if (err.message) {
          errorMsg = err.message;
        }
        setCameraError(errorMsg);
        setIsCameraActive(false);
      }
    },
    [cameraFacingMode, handleProcessBarcode, stopCamera]
  );

  // Switch between back & front cameras
  const handleToggleFacingMode = () => {
    const nextFacing = cameraFacingMode === 'environment' ? 'user' : 'environment';
    setCameraFacingMode(nextFacing);
    setSelectedDeviceId('');
    startCamera(nextFacing);
  };

  // Toggle torch / flashlight
  const handleToggleTorch = async () => {
    if (!streamRef.current || !torchSupported) return;
    const nextState = !isTorchOn;
    const success = await toggleTorch(streamRef.current, nextState);
    if (success) {
      setIsTorchOn(nextState);
    }
  };

  // Set zoom
  const handleZoomChange = async (val: number) => {
    if (!streamRef.current) return;
    const ok = await setZoom(streamRef.current, val);
    if (ok) {
      setCurrentZoom(val);
    }
  };

  // Toggle Fullscreen Viewfinder (handheld mobile terminal mode)
  const handleToggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  // Auto-start camera when activeTab is 'camera'
  useEffect(() => {
    if (activeTab === 'camera' && !isCameraActive) {
      startCamera();
    }
    return () => {
      if (activeTab !== 'camera') {
        stopCamera();
      }
    };
  }, [activeTab]);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, [stopCamera]);

  // Filtered simulator list
  const filteredSimulatorStudents = students.filter((s) => {
    const matchesGrade = simulatorGrade === 'all' || s.grade === simulatorGrade;
    const matchesSearch =
      !simulatorSearch ||
      s.firstName.includes(simulatorSearch) ||
      s.lastName.includes(simulatorSearch) ||
      s.classroom.includes(simulatorSearch) ||
      s.barcode.includes(simulatorSearch);
    return matchesGrade && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* 6-Period Cohort Switcher Banner */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-3 sm:p-4 shadow-xs">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3 mb-3 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm ${
              activePeriod.type === 'morning'
                ? 'bg-amber-100 text-amber-800'
                : 'bg-indigo-100 text-indigo-800'
            }`}>
              {activePeriod.type === 'morning' ? <Sun className="w-5 h-5 text-amber-600" /> : <Moon className="w-5 h-5 text-indigo-600" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
                  فوج المسح النشط:
                </span>
                <span className="text-sm font-bold text-slate-900">{activePeriod.name}</span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                توقيت الدخول: <strong className="text-slate-800 font-mono-numbers">{activePeriod.startTime}</strong> | حد احتساب التأخر: <strong className="text-amber-700 font-mono-numbers">{activePeriod.lateThreshold}</strong> | نهاية الاستقبال: <strong className="text-slate-700 font-mono-numbers">{activePeriod.cutoffTime}</strong>
              </p>
            </div>
          </div>
          <div className="text-xs text-slate-400 hidden sm:block">
            اختر توقيت الفوج لدخول التلاميذ بدقة وحساب التأخر حسب كل دفعة
          </div>
        </div>

        {/* 6 Periods quick selector grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
          {periods.map((p) => {
            const isSelected = p.id === activePeriod.id;
            const isMorning = p.type === 'morning';
            return (
              <button
                key={p.id}
                type="button"
                onClick={() => onChangePeriod && onChangePeriod(p.id)}
                className={`p-2.5 rounded-xl text-right transition-all flex flex-col border ${
                  isSelected
                    ? isMorning
                      ? 'bg-amber-500 text-white border-amber-600 shadow-sm shadow-amber-200 ring-2 ring-amber-300'
                      : 'bg-indigo-600 text-white border-indigo-700 shadow-sm shadow-indigo-200 ring-2 ring-indigo-300'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200/80'
                }`}
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                    isSelected
                      ? 'bg-white/20 text-white'
                      : isMorning
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-indigo-100 text-indigo-800'
                  }`}>
                    {isMorning ? 'صباحي' : 'مسائي'}
                  </span>
                  <span className={`text-xs font-mono font-bold ${isSelected ? 'text-white' : 'text-slate-800'}`}>
                    {p.startTime}
                  </span>
                </div>
                <span className="text-xs font-bold truncate leading-tight">
                  {p.name}
                </span>
                <span className={`text-[10px] mt-1 ${isSelected ? 'text-white/80' : 'text-slate-500'}`}>
                  تأخر بعد: {p.lateThreshold}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Top Session & KPI Strip */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 block mb-1">إجمالي الحاضرين اليوم</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-2xl font-bold font-mono-numbers text-slate-900">
                {totalScanned}
              </span>
              <span className="text-xs text-slate-400">/ {totalStudents} تلميذ</span>
            </div>
          </div>
          <div className="w-10 h-10 rounded-lg bg-slate-50 text-slate-700 flex items-center justify-center">
            <Users className="w-5 h-5" />
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 block mb-1">حاضرون في الوقت</span>
            <span className="text-2xl font-bold font-mono-numbers text-slate-600">
              {presentCount}
            </span>
          </div>
          <div className="w-10 h-10 rounded-lg bg-slate-50 text-slate-600 flex items-center justify-center">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 block mb-1">المتأخرون عن الحصة</span>
            <span className="text-2xl font-bold font-mono-numbers text-amber-600">
              {lateCount}
            </span>
          </div>
          <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
            <Clock className="w-5 h-5" />
          </div>
        </div>

        {/* Metric 4 */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 block mb-1">نسبة الحضور الإجمالية</span>
            <span className="text-2xl font-bold font-mono-numbers text-slate-900">
              {attendanceRate}%
            </span>
          </div>
          <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
            <Sparkles className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Main Scanner Section Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left / Center Main Scanning Terminal (7 cols) */}
        <div className="lg:col-span-7 space-y-5">
          {/* Scanner Device Mode Selector Tabs */}
          <div className="bg-white dark:bg-slate-900 p-1.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-1">
              {/* Tab 1: Camera Scanner (Featured for Mobile & Phone usage) */}
              <button
                onClick={() => {
                  setActiveTab('camera');
                  if (!isCameraActive) startCamera();
                }}
                style={activeTab === 'camera' ? { backgroundColor: palette.primary, color: palette.foreground } : {}}
                className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                  activeTab === 'camera'
                    ? 'shadow-xs'
                    : 'text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <Smartphone className="w-4 h-4 opacity-80" />
                <span>كاميرا الهاتف (سكانر)</span>
                {isCameraActive && (
                  <span className="w-2 h-2 rounded-full bg-current animate-ping" />
                )}
              </button>

              {/* Tab 2: Laser Gun Scanner */}
              <button
                onClick={() => {
                  setActiveTab('gun');
                  stopCamera();
                }}
                style={activeTab === 'gun' ? { backgroundColor: palette.primary, color: palette.foreground } : {}}
                className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                  activeTab === 'gun'
                    ? 'shadow-xs'
                    : 'text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <Scan className="w-4 h-4" />
                <span>قارئ ليزري (USB)</span>
              </button>

              {/* Tab 3: Simulator */}
              <button
                onClick={() => {
                  setActiveTab('simulator');
                  stopCamera();
                }}
                style={activeTab === 'simulator' ? { backgroundColor: palette.primary, color: palette.foreground } : {}}
                className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                  activeTab === 'simulator'
                    ? 'shadow-xs'
                    : 'text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <Sparkles className="w-4 h-4" />
                <span>مسح تجريبي سريع</span>
              </button>
            </div>

            {/* Sound Toggle */}
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setSoundEnabled(!soundEnabled)}
                className={`p-2 rounded-lg border transition-colors cursor-pointer ${
                  soundEnabled
                    ? 'border-slate-200 text-slate-700 bg-slate-50'
                    : 'border-slate-200 text-slate-400 bg-slate-50'
                }`}
                title={soundEnabled ? 'التنبيهات الصوتية مفعلة' : 'التنبيهات الصوتية معطلة'}
              >
                {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Scanner Viewport Box */}
          <div
            ref={fullscreenContainerRef}
            className={`bg-white rounded-2xl border border-slate-200 p-5 shadow-xs overflow-hidden relative transition-all ${
              isFullscreen ? 'fixed inset-0 z-50 rounded-none p-4 flex flex-col justify-between bg-black' : ''
            }`}
          >
            {/* Camera Viewport (Activated Phone Camera) */}
            {activeTab === 'camera' && (
              <div className="space-y-4">
                {/* Camera Top Control Bar */}
                <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-slate-500 animate-pulse" />
                    <span className="text-xs font-bold text-slate-800">
                      ماسح كاميرا الهاتف المباشر
                    </span>
                    {cameraFacingMode === 'environment' ? (
                      <span className="text-[10px] bg-slate-50 text-slate-700 font-semibold px-2 py-0.5 rounded-full border border-slate-200">
                        الكاميرا الخلفية (تركيز تلقائي)
                      </span>
                    ) : (
                      <span className="text-[10px] bg-blue-50 text-blue-700 font-semibold px-2 py-0.5 rounded-full border border-blue-200">
                        الكاميرا الأمامية
                      </span>
                    )}
                  </div>

                  {/* Active controls when camera is running */}
                  {isCameraActive && (
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {/* Flip Camera */}
                      <button
                        onClick={handleToggleFacingMode}
                        className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
                        title="تبديل بين الكاميرا الخلفية والأمامية"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>تبديل الكاميرا</span>
                      </button>

                      {/* Torch Button (if supported) */}
                      {torchSupported && (
                        <button
                          onClick={handleToggleTorch}
                          className={`flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                            isTorchOn
                              ? 'bg-amber-400 text-amber-950 shadow-xs'
                              : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                          }`}
                          title={isTorchOn ? 'إطفاء الكشاف' : 'تشغيل كشاف الهاتف للإضاءة'}
                        >
                          {isTorchOn ? <Zap className="w-3.5 h-3.5 text-amber-900 fill-amber-900" /> : <ZapOff className="w-3.5 h-3.5" />}
                          <span>{isTorchOn ? 'الكشاف شغال' : 'كشاف الهاتف'}</span>
                        </button>
                      )}

                      {/* Zoom Buttons (if supported) */}
                      {zoomRange && (
                        <div className="flex items-center bg-slate-100 rounded-lg p-0.5 text-xs">
                          <button
                            onClick={() => handleZoomChange(1)}
                            className={`px-2 py-1 rounded text-[11px] font-bold ${currentZoom === 1 ? 'bg-white shadow-xs text-slate-900' : 'text-slate-600'}`}
                          >
                            1x
                          </button>
                          <button
                            onClick={() => handleZoomChange(Math.min(zoomRange.max, 1.8))}
                            className={`px-2 py-1 rounded text-[11px] font-bold ${currentZoom > 1.2 ? 'bg-white shadow-xs text-slate-900' : 'text-slate-600'}`}
                          >
                            2x
                          </button>
                        </div>
                      )}

                      {/* Fullscreen Toggle */}
                      <button
                        onClick={handleToggleFullscreen}
                        className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
                        title={isFullscreen ? 'تصغير' : 'ملء الشاشة لوضع الماسح المحمول'}
                      >
                        {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                      </button>

                      {/* Stop Camera Button */}
                      <button
                        onClick={stopCamera}
                        className="px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-slate-50 hover:bg-slate-100 text-slate-700 transition-colors cursor-pointer"
                      >
                        إيقاف
                      </button>
                    </div>
                  )}
                </div>

                {/* Viewfinder Frame Container */}
                <div
                  className={`relative w-full aspect-video sm:aspect-16/10 bg-slate-950 rounded-2xl overflow-hidden flex items-center justify-center border-2 transition-all shadow-inner ${
                    scanPulse === 'success'
                      ? 'border-slate-400 ring-4 ring-slate-400/30'
                      : scanPulse === 'late'
                      ? 'border-amber-400 ring-4 ring-amber-400/30'
                      : scanPulse === 'warning'
                      ? 'border-blue-400 ring-4 ring-blue-400/30'
                      : scanPulse === 'error'
                      ? 'border-slate-400 ring-4 ring-slate-400/30'
                      : 'border-slate-800'
                  }`}
                >
                  {isCameraActive ? (
                    <>
                      <video
                        ref={videoRef}
                        autoPlay
                        playsInline
                        muted
                        className="w-full h-full object-cover"
                      />

                      {/* Targeting Reticle & Visual Laser Frame */}
                      <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center p-4">
                        {/* Aiming Reticle Box */}
                        <div
                          className={`relative w-72 sm:w-80 h-44 sm:h-48 border-2 rounded-2xl transition-all flex flex-col justify-between p-3 ${
                            scanPulse === 'success'
                              ? 'border-slate-400 bg-slate-500/10'
                              : scanPulse === 'late'
                              ? 'border-amber-400 bg-amber-500/10'
                              : 'border-slate-400/80 bg-black/15 shadow-[0_0_20px_rgba(16,185,129,0.15)]'
                          }`}
                        >
                          {/* Corner Markers */}
                          <div className="flex justify-between">
                            <span className="w-6 h-6 border-t-3 border-r-3 rounded-tr-lg" style={{ borderColor: palette.primary }} />
                            <span className="w-6 h-6 border-t-3 border-l-3 rounded-tl-lg" style={{ borderColor: palette.primary }} />
                          </div>

                          {/* Center scan hint */}
                          <div className="text-center">
                            <span className="text-[11px] font-semibold text-slate-300 bg-black/60 px-3 py-1 rounded-full backdrop-blur-xs shadow-xs border border-white/20">
                              وجّه الكاميرا نحو باركود بطاقة التلميذ
                            </span>
                          </div>

                          {/* Animated Scan Laser Line */}
                          <div
                            className="w-full h-0.5 animate-scan-laser absolute inset-x-0"
                            style={{
                              background: `linear-gradient(to right, transparent, ${palette.primary}, transparent)`,
                              boxShadow: `0 0 14px ${palette.primary}`,
                            }}
                          />

                          <div className="flex justify-between">
                            <span className="w-6 h-6 border-b-3 border-r-3 rounded-br-lg" style={{ borderColor: palette.primary }} />
                            <span className="w-6 h-6 border-b-3 border-l-3 rounded-bl-lg" style={{ borderColor: palette.primary }} />
                          </div>
                        </div>

                        {/* Scanner Engine Badge */}
                        <div className="absolute bottom-3 inset-x-0 flex justify-center pointer-events-none">
                          <span className="text-[10px] text-white/80 bg-slate-900/80 px-3 py-0.5 rounded-full backdrop-blur-xs font-mono-numbers">
                            Code 128 · QR Code · EAN-13 | مستشعر فائق السرعة
                          </span>
                        </div>
                      </div>

                      {/* Instant Scan Success Flash Overlay */}
                      {scanPulse !== 'none' && (
                        <div
                          className={`absolute inset-0 pointer-events-none transition-opacity duration-300 flex items-center justify-center ${
                            scanPulse === 'success'
                              ? 'bg-slate-500/25'
                              : scanPulse === 'late'
                              ? 'bg-amber-500/25'
                              : scanPulse === 'warning'
                              ? 'bg-blue-500/25'
                              : 'bg-slate-500/25'
                          }`}
                        >
                          <div className="bg-black/80 backdrop-blur-md px-5 py-2.5 rounded-xl text-white font-bold text-sm shadow-xl flex items-center gap-2 border border-white/20 animate-bounce">
                            {scanPulse === 'success' && <CheckCircle2 className="w-5 h-5 text-slate-400" />}
                            {scanPulse === 'late' && <Clock className="w-5 h-5 text-amber-400" />}
                            {scanPulse === 'warning' && <AlertTriangle className="w-5 h-5 text-blue-400" />}
                            {scanPulse === 'error' && <UserX className="w-5 h-5 text-slate-400" />}
                            <span>
                              {scanPulse === 'success'
                                ? 'تم المسح بنجاح!'
                                : scanPulse === 'late'
                                ? 'مسجل كمتأخر!'
                                : scanPulse === 'warning'
                                ? 'مسجل مسبقاً'
                                : 'رمز غير معروف'}
                            </span>
                          </div>
                        </div>
                      )}
                    </>
                  ) : (
                    /* Inactive Camera State / Permission Prompt */
                    <div className="text-center p-8 space-y-4 max-w-md">
                      <div className="w-16 h-16 rounded-2xl bg-slate-900 text-slate-400 flex items-center justify-center mx-auto shadow-inner border border-slate-800">
                        <Smartphone className="w-8 h-8 text-slate-400" />
                      </div>

                      <div className="space-y-1.5">
                        <h4 className="text-sm font-bold text-white">
                          تشغيل كاميرا الهاتف كسكانر للباركود
                        </h4>
                        <p className="text-xs text-slate-400 leading-relaxed">
                          يمكنك تحويل كاميرا الهاتف المحمول أو حاسوب البوابة إلى ماسح باركود ذكي لقراءة بطاقات التلاميذ فورياً مع خاصية التركيز التلقائي والكشاف الليلي.
                        </p>
                      </div>

                      {cameraError && (
                        <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 text-slate-300 text-xs text-right space-y-1">
                          <div className="font-bold flex items-center gap-1.5">
                            <AlertTriangle className="w-4 h-4 shrink-0 text-slate-400" />
                            <span>تنبيه في إذن الكاميرا:</span>
                          </div>
                          <p className="text-[11px] leading-relaxed">{cameraError}</p>
                        </div>
                      )}

                      <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-2">
                        <button
                          onClick={() => startCamera('environment')}
                          style={{ backgroundColor: palette.primary, color: palette.foreground }}
                          className="w-full sm:w-auto px-5 py-2.5 text-xs font-bold rounded-xl transition-all shadow-md cursor-pointer flex items-center justify-center gap-2"
                        >
                          <Camera className="w-4 h-4" />
                          <span>تفعيل كاميرا الهاتف الآن</span>
                        </button>
                        <button
                          onClick={() => setShowTips(!showTips)}
                          className="w-full sm:w-auto px-3.5 py-2.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5"
                        >
                          <HelpCircle className="w-3.5 h-3.5" />
                          <span>نصائح المسح بالهاتف</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* Multiple Cameras Selector (if device has wide/telephoto/rear cameras) */}
                {availableDevices.length > 1 && (
                  <div className="flex items-center gap-2 text-xs text-slate-600 pt-1">
                    <Video className="w-3.5 h-3.5 text-slate-400" />
                    <span>الكاميرا المختارة:</span>
                    <select
                      value={selectedDeviceId}
                      onChange={(e) => startCamera(undefined, e.target.value)}
                      className="px-2.5 py-1 text-xs rounded-lg border border-slate-300 bg-white focus:ring-2 focus:ring-slate-500"
                    >
                      <option value="">الكاميرا التلقائية (الخلفية الذكية)</option>
                      {availableDevices.map((dev, idx) => (
                        <option key={dev.deviceId || idx} value={dev.deviceId}>
                          {dev.label || `كاميرا ${idx + 1}`}
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                {/* Tips Accordion for Mobile Camera Scanning */}
                {showTips && (
                  <div className="p-3.5 rounded-xl bg-slate-50/70 border border-slate-200 text-xs text-slate-950 space-y-2">
                    <div className="font-bold flex items-center gap-1.5 text-slate-900">
                      <HelpCircle className="w-4 h-4 text-slate-700" />
                      <span>إرشادات للحصول على أسرع قراءة بكاميرا الهاتف:</span>
                    </div>
                    <ul className="list-disc list-inside space-y-1 text-[11px] text-slate-900/90 pr-1">
                      <li>احرص على تثبيت بطاقة التلميذ على مسافة 10 إلى 20 سم من عدسة الهاتف.</li>
                      <li>تأكد من اختيار <strong>الكاميرا الخلفية</strong> لأنها تتضمن خاصية التركيز التلقائي (Autofocus).</li>
                      <li>عند انخفاض الإضاءة صباحاً في مدخل المؤسسة، انقر على زر <strong>"كشاف الهاتف"</strong> لتشغيل الفلاش المدمج.</li>
                      <li>يدعم النظام قراءة باركود Code 128 القياسي وكذلك رموز QR Codes بصورة فورية.</li>
                      <li>يعمل في جميع المتصفحات على أجهزة Android و iPhone.</li>
                    </ul>
                  </div>
                )}
              </div>
            )}

            {/* Laser Gun Mode */}
            {activeTab === 'gun' && (
              <div className="flex flex-col items-center justify-center py-6 text-center space-y-4">
                <div className="w-20 h-20 rounded-2xl bg-slate-50 text-slate-700 flex items-center justify-center relative shadow-inner">
                  <Scan className="w-10 h-10 animate-pulse text-slate-600" />
                  <div className="absolute inset-0 rounded-2xl border-2 border-dashed border-slate-400 animate-spin" style={{ animationDuration: '10s' }} />
                </div>

                <div className="space-y-1 max-w-lg">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 text-slate-800 text-xs font-bold mb-1">
                    <span className="w-2 h-2 rounded-full bg-slate-600 animate-ping" />
                    <span>القارئ الليزري متصل ومستعد للاستقبال في أي وقت</span>
                  </div>
                  <h3 className="text-base font-bold text-slate-800">
                    بوابة الدخول جاهزة لاستقبال المسح الليزري
                  </h3>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    وجّه مسدس قارئ الباركود (USB أو اللاسلكي) نحو بطاقة التلميذ. يتعرف النظام تلقائياً على كل الصيغ ولوحات المفاتيح (عربي / فرنسي AZERTY).
                  </p>
                </div>

                {/* Instant Manual Search / Barcode form */}
                <form
                  onSubmit={handleManualSubmit}
                  className="w-full max-w-md flex items-center gap-2 pt-2"
                >
                  <div className="relative flex-1">
                    <Keyboard className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
                    <input
                      ref={manualInputRef}
                      type="text"
                      value={manualCode}
                      onChange={(e) => setManualCode(e.target.value)}
                      placeholder="اكتب رقم الباركود يدويًا أو امسح بالمسدس..."
                      className="w-full pr-9 pl-3 py-2 text-xs font-mono-numbers rounded-lg border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-slate-500 focus:border-transparent bg-slate-50/50"
                    />
                  </div>
                  <button
                    type="submit"
                    style={{ backgroundColor: palette.primary, color: palette.foreground }}
                    className="px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer shrink-0 shadow-2xs hover:opacity-95"
                  >
                    تسجيل يدوي
                  </button>
                </form>

                {/* Helpful Quick Bar & Diagnostic Button */}
                <div className="pt-2 flex flex-wrap items-center justify-center gap-3 text-xs">
                  <button
                    onClick={() => setShowTroubleshooter(true)}
                    className="px-3.5 py-1.5 rounded-lg bg-blue-50 dark:bg-blue-950/40 hover:bg-blue-100 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800/60 font-semibold transition-all cursor-pointer flex items-center gap-1.5 shadow-2xs"
                  >
                    <HelpCircle className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                    <span>لماذا لا تدخل المعلومات عند استعمال الكود بار؟ (دليل الحلول)</span>
                  </button>

                  {lastRawInput && (
                    <div className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 text-[11px] font-mono-numbers flex items-center gap-1.5">
                      <span>آخر قراءة ملتقطة:</span>
                      <strong className="text-slate-900 dark:text-white">{lastRawInput}</strong>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Quick Simulator Mode */}
            {activeTab === 'simulator' && (
              <div className="space-y-3">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
                  <div>
                    <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">
                      محاكي المسح الفوري (انقر على أي تلميذ لتسجيل دخوله فوراً)
                    </h4>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      لتجربة النظام فوراً والتحقق من آلية كشف المتأخرين والحاضرين دون الحاجة لأجهزة مادية
                    </p>
                  </div>
                  {/* Grade filter */}
                  <div className="flex items-center gap-1 text-xs">
                    {(['all', '1AM', '2AM', '3AM', '4AM'] as const).map((grade) => {
                      const isSel = simulatorGrade === grade;
                      const label = grade === 'all' ? 'الكل' : grade === '1AM' ? '1م' : grade === '2AM' ? '2م' : grade === '3AM' ? '3م' : '4م';
                      return (
                        <button
                          key={grade}
                          onClick={() => setSimulatorGrade(grade)}
                          style={isSel ? { backgroundColor: palette.primary, color: palette.foreground } : {}}
                          className={`px-2.5 py-1 rounded-md font-medium transition-all cursor-pointer ${
                            isSel
                              ? 'shadow-xs'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                          }`}
                        >
                          {label}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Search input in simulator */}
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={simulatorSearch}
                    onChange={(e) => setSimulatorSearch(e.target.value)}
                    placeholder="ابحث باسم التلميذ أو القسم للتجربة..."
                    className="w-full pr-8 pl-3 py-1.5 text-xs rounded-lg border border-slate-200 bg-slate-50/50"
                  />
                </div>

                {/* Quick cards grid */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-72 overflow-y-auto p-1">
                  {filteredSimulatorStudents.map((st) => {
                    const isAlreadyScanned = todayRecords.some((r) => r.studentId === st.id);
                    return (
                      <button
                        key={st.id}
                        onClick={() => handleProcessBarcode(st.barcode, 'simulator')}
                        className={`p-2.5 rounded-xl border text-right transition-all flex flex-col justify-between gap-1.5 cursor-pointer hover:scale-[1.02] ${
                          isAlreadyScanned
                            ? 'bg-slate-50/60 border-slate-200 text-slate-950'
                            : 'bg-white border-slate-200 hover:border-slate-300 hover:shadow-xs'
                        }`}
                      >
                        <div className="flex justify-between items-start">
                          <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-1 rounded">
                            {st.classroom}
                          </span>
                          {isAlreadyScanned ? (
                            <span className="text-[9px] font-bold text-slate-700 flex items-center gap-0.5">
                              <CheckCircle2 className="w-2.5 h-2.5" /> مسجل
                            </span>
                          ) : (
                            <span className="text-[9px] text-slate-400">انقر للمسح</span>
                          )}
                        </div>

                        <div>
                          <div className="text-xs font-bold text-slate-800 line-clamp-1">
                            {st.lastName} {st.firstName}
                          </div>
                          <div className="text-[10px] font-mono-numbers text-slate-400 mt-0.5">
                            {st.barcode}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Flash Card: Last Scan Result Banner */}
          {lastScanResult && (
            <div
              className={`rounded-2xl p-5 border transition-all shadow-sm ${
                lastScanResult.type === 'success'
                  ? 'bg-slate-50 border-slate-200 text-slate-950'
                  : lastScanResult.type === 'late'
                  ? 'bg-amber-50 border-amber-200 text-amber-950'
                  : lastScanResult.type === 'warning'
                  ? 'bg-blue-50 border-blue-200 text-blue-950'
                  : 'bg-slate-50 border-slate-200 text-slate-950'
              }`}
            >
              <div className="flex flex-col sm:flex-row items-start justify-between gap-4">
                <div className="flex items-start gap-3.5">
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${
                      lastScanResult.type === 'success'
                        ? 'bg-slate-600 text-white'
                        : lastScanResult.type === 'late'
                        ? 'bg-amber-600 text-white'
                        : lastScanResult.type === 'warning'
                        ? 'bg-blue-600 text-white'
                        : 'bg-slate-600 text-white'
                    }`}
                  >
                    {lastScanResult.type === 'success' && <CheckCircle2 className="w-6 h-6" />}
                    {lastScanResult.type === 'late' && <Clock className="w-6 h-6" />}
                    {lastScanResult.type === 'warning' && <AlertTriangle className="w-6 h-6" />}
                    {lastScanResult.type === 'error' && <UserX className="w-6 h-6" />}
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold">{lastScanResult.title}</h4>
                      <span className="text-[11px] font-mono-numbers opacity-75">
                        {lastScanResult.timestamp}
                      </span>
                    </div>

                    <p className="text-xs opacity-90">{lastScanResult.message}</p>

                    {lastScanResult.details && (
                      <p className="text-[11px] opacity-80 pt-1.5 border-t border-current/20 mt-1">
                        {lastScanResult.details}
                      </p>
                    )}

                    {lastScanResult.student && (
                      <div className="pt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs">
                        <span>
                          التلميذ: <strong>{lastScanResult.student.lastName} {lastScanResult.student.firstName}</strong>
                        </span>
                        <span>
                          القسم: <strong>{lastScanResult.student.classroom}</strong>
                        </span>
                        <span>
                          رقم التسجيل: <strong className="font-mono-numbers">{lastScanResult.student.id}</strong>
                        </span>
                        <span>
                          هاتف الولي: <strong className="font-mono-numbers">{lastScanResult.student.guardianPhone}</strong>
                        </span>
                      </div>
                    )}

                    {lastScanResult.type === 'error' && (
                      <div className="pt-2">
                        <button
                          onClick={() => setShowTroubleshooter(true)}
                          className="px-3 py-1.5 text-xs font-bold rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-950 transition-colors cursor-pointer flex items-center gap-1.5"
                        >
                          <HelpCircle className="w-3.5 h-3.5" />
                          <span>فتح دليل تشخيص وحل مشكلة الباركود</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Quick actions for the scanned pupil */}
                <div className="flex flex-wrap sm:flex-col gap-1.5 shrink-0 w-full sm:w-auto">
                  {/* Re-check-in / update attendance time if already scanned */}
                  {lastScanResult.type === 'warning' && lastScanResult.student && (
                    <button
                      onClick={() =>
                        handleProcessBarcode(lastScanResult.student!.barcode, 'manual', true)
                      }
                      className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-blue-600 hover:bg-blue-700 text-white shadow-2xs transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                      title="تحديث وقت الحضور وحساب التأخر من جديد"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>تحديث وقت الحضور الآن</span>
                    </button>
                  )}

                  {lastScanResult.student && (
                    <>
                      {/* Notify Guardian via SMS or WhatsApp */}
                      <button
                        onClick={() => setSmsModalStudent(lastScanResult.student!)}
                        className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-700 hover:bg-slate-800 text-white shadow-2xs transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>إشعار الولي (SMS/واتساب)</span>
                      </button>

                      {/* View Card */}
                      <button
                        onClick={() => onViewStudentCard(lastScanResult.student!)}
                        className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-white/80 hover:bg-white text-slate-800 shadow-2xs border border-slate-200 transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>عرض البطاقة</span>
                      </button>

                      {/* Late Ticket */}
                      {lastScanResult.type === 'late' && lastScanResult.record && (
                        <button
                          onClick={() =>
                            onOpenLateTicket(lastScanResult.record!, lastScanResult.student!)
                          }
                          className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-amber-600 hover:bg-amber-700 text-white shadow-2xs transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                        >
                          <Clock className="w-3.5 h-3.5" />
                          <span>طباعة تذكرة التأخر</span>
                        </button>
                      )}
                    </>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Right Recent Scans Live Stream (5 cols) */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="font-bold text-slate-800 text-sm">
                سجل الدخول اللحظي المباشر
              </h3>
              <p className="text-[11px] text-slate-500">
                {currentSession === 'morning' ? 'الفترة الصباحية' : 'الفترة المسائية'} · {todayStr}
              </p>
            </div>
            <span className="text-xs font-mono-numbers font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded-full">
              {todayRecords.length} مسجل
            </span>
          </div>

          {/* List of Recent Scans */}
          <div className="space-y-2 max-h-[520px] overflow-y-auto pr-1">
            {todayRecords.length === 0 ? (
              <div className="text-center py-14 space-y-2 text-slate-400">
                <Smartphone className="w-8 h-8 mx-auto opacity-40 text-slate-600" />
                <p className="text-xs">لم يتم تسجيل أي تلميذ بعد في هذه الفترة.</p>
                <p className="text-[11px] text-slate-400">
                  قم بتوجيه كاميرا الهاتف أو القارئ نحو باركود التلميذ لبدء التسجيل.
                </p>
              </div>
            ) : (
              todayRecords
                .slice()
                .reverse()
                .map((rec) => {
                  const student = students.find((s) => s.id === rec.studentId);
                  const isLate = rec.status === 'late';
                  return (
                    <div
                      key={rec.id}
                      className="p-3 rounded-xl border border-slate-100 hover:border-slate-200 bg-slate-50/40 hover:bg-white transition-all flex items-center justify-between gap-2"
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-9 h-9 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 ${
                            isLate
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-slate-100 text-slate-800'
                          }`}
                        >
                          {rec.studentName[0]}
                        </div>

                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-900 text-xs">
                              {rec.studentName}
                            </span>
                            <span className="text-[10px] text-slate-500 bg-white border border-slate-200 px-1.5 py-0.2 rounded">
                              {rec.classroom}
                            </span>
                          </div>
                          <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                            <span className="font-mono-numbers">{rec.timestamp}</span>
                            <span>·</span>
                            <span>{rec.device === 'scanner_gun' ? 'قارئ ليزري' : rec.device === 'camera' ? 'كاميرا الهاتف' : rec.device === 'simulator' ? 'مسح سريع' : 'يدوي'}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        {isLate ? (
                          <span
                            onClick={() => student && onOpenLateTicket(rec, student)}
                            className="text-[10px] font-bold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded cursor-pointer hover:bg-amber-100"
                            title="انقر لطباعة تذكرة التأخر"
                          >
                            تأخر +{rec.lateMinutes}د
                          </span>
                        ) : (
                          <span className="text-[10px] font-semibold text-slate-700 bg-slate-50 px-2 py-0.5 rounded">
                            في الوقت
                          </span>
                        )}

                        {student && (
                          <button
                            onClick={() => setSmsModalStudent(student)}
                            className="p-1 text-slate-400 hover:text-slate-700 rounded transition-colors cursor-pointer"
                            title="إشعار الولي عبر SMS أو واتساب"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                          </button>
                        )}

                        {student && (
                          <button
                            onClick={() => onViewStudentCard(student)}
                            className="p-1 text-slate-400 hover:text-slate-700 rounded transition-colors cursor-pointer"
                            title="عرض بطاقة التلميذ"
                          >
                            <FileText className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })
            )}
          </div>
        </div>
      </div>

      {/* SMS/WhatsApp notification modal if opened from Scanner */}
      {smsModalStudent && (
        <SmsNotificationModal
          student={smsModalStudent}
          date={todayStr}
          session={currentSession}
          settings={settings}
          initialChannel="whatsapp"
          onClose={() => setSmsModalStudent(null)}
          onNotificationSent={(stId, msg, ch) => {
            setSmsModalStudent(null);
          }}
        />
      )}

      {/* Barcode Troubleshooter & Diagnostic Guide Modal */}
      {showTroubleshooter && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full border border-slate-200 shadow-xl overflow-hidden my-6">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 bg-gradient-to-l from-slate-900 to-slate-800 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center border border-blue-400/30">
                  <Wrench className="w-5 h-5 text-blue-300" />
                </div>
                <div>
                  <h3 className="font-bold text-sm sm:text-base">
                    دليل تشخيص: لماذا لا تدخل المعلومات عند استعمال الكود بار؟
                  </h3>
                  <p className="text-xs text-slate-300">
                    أهم 4 أسباب لعدم تسجيل بطاقة التلميذ وحلولها الفورية المعتمدة
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowTroubleshooter(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700/50 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 sm:p-6 space-y-6 max-h-[75vh] overflow-y-auto text-right text-xs">
              {/* Interactive Live Barcode Diagnostic Tester */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800 text-sm flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-slate-600" />
                    <span>مختبر فحص استجابة الباركود الفوري</span>
                  </span>
                  <span className="text-[10px] bg-slate-100 text-slate-800 font-semibold px-2 py-0.5 rounded-full">
                    مباشر
                  </span>
                </div>
                <p className="text-slate-500 text-[11px] leading-relaxed">
                  امسح أي بطاقة الآن بمسدس الباركود أو اكتب الكود في المربع أدناه لفحص كيف يقرأه النظام والتأكد من مطابقة التلميذ:
                </p>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    const inputEl = e.currentTarget.elements.namedItem('testCode') as HTMLInputElement;
                    if (inputEl && inputEl.value.trim()) {
                      handleProcessBarcode(inputEl.value.trim(), 'manual');
                      inputEl.value = '';
                    }
                  }}
                  className="flex gap-2"
                >
                  <input
                    name="testCode"
                    type="text"
                    placeholder="امسح بالمسدس أو اكتب رقم الباركود للاختبار..."
                    className="flex-1 px-3 py-2 text-xs font-mono-numbers rounded-lg border border-slate-300 bg-white focus:ring-2 focus:ring-slate-500"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 bg-slate-700 hover:bg-slate-800 text-white font-semibold rounded-lg text-xs cursor-pointer"
                  >
                    فحص ومسح
                  </button>
                </form>

                {recentDiagnosticScans.length > 0 && (
                  <div className="space-y-1.5 pt-2 border-t border-slate-200">
                    <span className="text-[10px] text-slate-500 block font-bold">آخر عمليات الفحص الملتقطة:</span>
                    <div className="space-y-1 max-h-32 overflow-y-auto">
                      {recentDiagnosticScans.map((diag, idx) => (
                        <div
                          key={idx}
                          className="flex items-center justify-between p-2 rounded-lg bg-white border border-slate-100 text-[11px]"
                        >
                          <div className="flex items-center gap-2 font-mono-numbers">
                            <span className="text-slate-400">{diag.time}</span>
                            <span className="text-slate-700 font-semibold">{diag.raw}</span>
                            {diag.raw !== diag.normalized && (
                              <span className="text-slate-700 bg-slate-50 px-1 rounded text-[10px]">
                                ⟵ {diag.normalized}
                              </span>
                            )}
                          </div>
                          <div>
                            {diag.status === 'matched' && (
                              <span className="text-slate-700 font-bold bg-slate-50 px-2 py-0.5 rounded">
                                تم التسجيل ({diag.studentName})
                              </span>
                            )}
                            {diag.status === 'duplicate' && (
                              <span className="text-blue-700 font-bold bg-blue-50 px-2 py-0.5 rounded">
                                مسجل مسبقاً ({diag.studentName})
                              </span>
                            )}
                            {diag.status === 'unmatched' && (
                              <span className="text-slate-700 font-bold bg-slate-50 px-2 py-0.5 rounded">
                                غير موجود بالقاعدة
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* The 4 Common Reasons with Detailed Solutions */}
              <div className="space-y-4">
                <h4 className="font-bold text-slate-800 text-sm">
                  أهم 4 أسباب لعدم دخول المعلومات وكيف يتعامل معها النظام:
                </h4>

                {/* Reason 1 */}
                <div className="p-4 rounded-xl border border-blue-100 bg-blue-50/50 space-y-2">
                  <div className="flex items-center gap-2 font-bold text-blue-900 text-xs">
                    <Cpu className="w-4 h-4 text-blue-700" />
                    <span>1. لغة لوحة المفاتيح بالحاسوب (لوحة AZERTY الفرنسية أو العربية)</span>
                  </div>
                  <p className="text-slate-600 text-[11px] leading-relaxed">
                    مسدس الباركود يتصرف كلوحة مفاتيح حاسوب. إذا كانت لغة الحاسوب فرنسية (AZERTY)، فإن كتابة الأرقام دون زر Shift تنتج رموزاً مثل <code className="bg-white px-1 rounded text-blue-900 font-mono">éàé-&à</code> بدلاً من <code className="bg-white px-1 rounded text-blue-900 font-mono">2026101001</code>. وإذا كانت عربية فإنها تكتب أرقاماً شرقية أو حروفاً.
                  </p>
                  <div className="p-2.5 rounded-lg bg-slate-50 text-slate-900 border border-slate-200 text-[11px]">
                    <strong>الحل الذكي المطبق بالنظام:</strong> يتضمن النظام الآن محولاً ذكياً يترجم تلقائياً رموز AZERTY وأرقام العربية الشرقية (٠-٩) إلى أرقام صحيحة فورياً.
                    <span className="block mt-1 font-semibold text-slate-800">
                      نصيحة إضافية: يفضل دائماً تفعيل زر <strong>Caps Lock</strong> في لوحة المفاتيح أو ضبط لغة الجهاز على <strong>EN</strong> (الإنجليزية).
                    </span>
                  </div>
                </div>

                {/* Reason 2 */}
                <div className="p-4 rounded-xl border border-amber-100 bg-amber-50/50 space-y-2">
                  <div className="flex items-center gap-2 font-bold text-amber-900 text-xs">
                    <ShieldAlert className="w-4 h-4 text-amber-700" />
                    <span>2. منع تكرار التسجيل لنفس التلميذ في نفس الفترة (صباح / مساء)</span>
                  </div>
                  <p className="text-slate-600 text-[11px] leading-relaxed">
                    لحماية إحصائيات المؤسسة ومنع الأخطاء، يرفض النظام تلقائياً إضافة سطر جديد إذا كان التلميذ قد سُجّل دخوله بالفعل مسبقاً في نفس الفترة (صباحاً أو مساءً).
                  </p>
                  <div className="p-2.5 rounded-lg bg-white border border-amber-200 text-amber-950 text-[11px]">
                    <strong>الحل:</strong> عند مسح تلميذ مسجل سابقاً، يظهر شريط أزرق يُعلمك بالساعة الدقيقة التي سُجّل فيها. إذا أردت تحديث وقت دخوله، فقط انقر على زر <strong>"تحديث وقت الحضور الآن"</strong> المتاح في شريط التنبيه.
                  </div>
                </div>

                {/* Reason 3 */}
                <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2">
                  <div className="flex items-center gap-2 font-bold text-slate-900 text-xs">
                    <Info className="w-4 h-4 text-slate-700" />
                    <span>3. رقم الباركود غير مطابق لقاعدة بيانات التلاميذ</span>
                  </div>
                  <p className="text-slate-600 text-[11px] leading-relaxed">
                    يجب أن يكون رقم الباركود المطبوع على البطاقة مطابقاً لرقم الباركود أو رقم التعريف المدرسي الوطني أو المعرف الداخلي للتلميذ المسجل في قائمة التلاميذ.
                  </p>
                  <div className="p-2.5 rounded-lg bg-white border border-slate-200 text-slate-800 text-[11px]">
                    <strong>الحل المرن:</strong> النظام يفحص الآن بمرونة 6 صيغ مختلفة (بالشرطات وبدونها، بالأصفار البادئة وبدونها). تأكد من إدراج التلميذ في قائمة التلاميذ عبر تبويب <strong>"قائمة التلاميذ"</strong> أو استيراد ملف Excel.
                  </div>
                </div>

                {/* Reason 4 */}
                <div className="p-4 rounded-xl border border-slate-100 bg-slate-50/50 space-y-2">
                  <div className="flex items-center gap-2 font-bold text-slate-900 text-xs">
                    <Smartphone className="w-4 h-4 text-slate-700" />
                    <span>4. استخدام كاميرا الهاتف كسكانر مباشر بديل</span>
                  </div>
                  <p className="text-slate-600 text-[11px] leading-relaxed">
                    إذا كان جهاز مسدس الباركود غير متوفر أو به عطل، يمكنك استخدام كاميرا الهاتف المحمول أو حاسوب البوابة مباشرة عبر النقر على تبويب <strong>"كاميرا الهاتف (سكانر)"</strong>.
                  </p>
                  <div className="p-2.5 rounded-lg bg-slate-100/60 text-slate-950 border border-slate-300 text-[11px]">
                    تتميز الكاميرا بالتركيز التلقائي التام ودعم الكشاف الليلي، ولا تتأثر بلغة لوحة المفاتيح أبداً!
                  </div>
                </div>
              </div>

              {/* Close Button */}
              <div className="pt-3 flex justify-end">
                <button
                  onClick={() => setShowTroubleshooter(false)}
                  className="px-5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs cursor-pointer shadow-xs"
                >
                  فهمت ذلك، إغلاق الدليل
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
