import React, { useState, useMemo, useEffect, useRef } from 'react';
import * as XLSX from 'xlsx';
import {
  Student,
  AttendanceRecord,
  SchoolSettings,
  SchoolDay,
  TimetableSlotId,
  TimetableSession,
  Teacher,
  PeriodId,
  AppUser,
  GradeLevel,
  TimetableMetadata,
} from '../types';
import { TimetableExcelImportModal } from './TimetableExcelImportModal';
import {
  DAYS_OF_WEEK,
  TIMETABLE_SLOTS,
  TEACHERS,
  INITIAL_TIMETABLE_SESSIONS,
  SUBJECT_INFO,
  getSchoolDay,
  getCurrentSlotMeta,
  getSubjectForClassroom,
  getAbsentStudentSubjectInfo,
} from '../data/timetableData';
import {
  Calendar,
  Clock,
  User,
  Users,
  Search,
  Printer,
  Sparkles,
  BookOpen,
  MapPin,
  Phone,
  AlertTriangle,
  CheckCircle2,
  Filter,
  Eye,
  FileText,
  UserX,
  School,
  Info,
  FileSpreadsheet,
  Upload,
  Download,
  Edit3,
  Plus,
  Trash2,
  X,
  Layers,
} from 'lucide-react';

interface TimetableManagerProps {
  students: Student[];
  records: AttendanceRecord[];
  settings: SchoolSettings;
  currentSession: 'morning' | 'afternoon';
  currentPeriodId?: string;
  onViewStudentCard?: (student: Student) => void;
  timetableSessions?: TimetableSession[];
  onUpdateTimetableSessions?: (sessions: TimetableSession[]) => void;
  currentUser?: AppUser | null;
  activeTimetableMeta?: TimetableMetadata | null;
  timetableHistory?: TimetableMetadata[];
  onImportTimetable?: (
    sessions: TimetableSession[],
    meta: TimetableMetadata,
    updateSettings?: boolean | Partial<SchoolSettings> | any
  ) => Promise<any> | void;
  onSwitchTimetable?: (versionId: string) => Promise<any> | void;
}

export const TimetableManager: React.FC<TimetableManagerProps> = ({
  students,
  records,
  settings,
  currentSession,
  currentPeriodId = 'm1',
  onViewStudentCard,
  timetableSessions,
  onUpdateTimetableSessions,
  currentUser,
  activeTimetableMeta,
  timetableHistory,
  onImportTimetable,
  onSwitchTimetable,
}) => {
  const activeSessions = timetableSessions || INITIAL_TIMETABLE_SESSIONS;
  const [isAdvancedImportModalOpen, setIsAdvancedImportModalOpen] = useState(false);
  const [isSwitchingVersion, setIsSwitchingVersion] = useState(false);

  // Navigation tabs within Timetable Manager
  const [activeTab, setActiveTab] = useState<'classes' | 'teachers' | 'absence_detector' | 'rooms'>(
    'absence_detector'
  );

  const [selectedRoom, setSelectedRoom] = useState<string>('معلوماتية_1');

  // Available rooms list
  const allRooms = useMemo(() => {
    const set = new Set<string>();
    activeSessions.forEach((s) => {
      if (s.room) set.add(s.room);
    });
    ['معلوماتية_1', 'معلوماتية_2', 'مخبر 1', 'مخبر 2', 'قاعة 01', 'الساحة'].forEach((r) => set.add(r));
    return Array.from(set).sort();
  }, [activeSessions]);

  // Class timetable filter
  const [selectedClassroom, setSelectedClassroom] = useState<string>('1م1');
  const [classSearchQuery, setClassSearchQuery] = useState<string>('');

  // Teacher timetable filter
  const [selectedTeacherId, setSelectedTeacherId] = useState<string>(TEACHERS[0].id);
  const [teacherSubjectFilter, setTeacherSubjectFilter] = useState<string>('all');

  // Absence Detector filters
  const [detectorDate, setDetectorDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [detectorSlotId, setDetectorSlotId] = useState<TimetableSlotId>(
    getCurrentSlotMeta().id
  );
  const [detectorSearch, setDetectorSearch] = useState<string>('');
  const [selectedAbsentStudentId, setSelectedAbsentStudentId] = useState<string | null>(null);

  // Excel Import / Export states
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [importSuccessMsg, setImportSuccessMsg] = useState<string | null>(null);

  // Edit / Add Timetable Session modal state
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editForm, setEditForm] = useState<{
    id?: string;
    day: SchoolDay;
    slotId: TimetableSlotId;
    classroom: string;
    grade: GradeLevel;
    subject: string;
    teacherId: string;
    teacherName: string;
    room: string;
  }>({
    day: 'sunday',
    slotId: 'p1',
    classroom: '1م1',
    grade: '1AM',
    subject: 'الرياضيات',
    teacherId: TEACHERS[0]?.id || 'T01',
    teacherName: TEACHERS[0]?.name || 'الأستاذ',
    room: 'قاعة 01',
  });

  // Live real-time clock
  const [currentTime, setCurrentTime] = useState(new Date());
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 15000);
    return () => clearInterval(timer);
  }, []);

  const currentSchoolDay = getSchoolDay(currentTime);
  const currentActiveSlot = getCurrentSlotMeta(currentTime);

  // Available classrooms from students dataset
  const availableClassrooms = useMemo(() => {
    const set = new Set<string>();
    students.forEach((s) => set.add(s.classroom));
    [
      '1م1', '1م2', '1م3', '1م4', '1م5',
      '2م1', '2م2', '2م3', '2م4',
      '3م1', '3م2', '3م3', '3م4',
      '4م1', '4م2', '4م3', '4م4'
    ].forEach((c) => set.add(c));
    return Array.from(set).sort();
  }, [students]);

  // Handle student search in class timetable tab to jump directly to student's class
  const handleStudentSearchSelect = (classroom: string) => {
    setSelectedClassroom(classroom);
    setClassSearchQuery('');
  };

  const studentSearchMatches = useMemo(() => {
    if (!classSearchQuery.trim()) return [];
    const q = classSearchQuery.trim().toLowerCase();
    return students
      .filter(
        (s) =>
          s.firstName.toLowerCase().includes(q) ||
          s.lastName.toLowerCase().includes(q) ||
          s.id.toLowerCase().includes(q) ||
          s.barcode.includes(q) ||
          s.classroom.toLowerCase().includes(q)
      )
      .slice(0, 6);
  }, [students, classSearchQuery]);

  // Selected teacher details
  const activeTeacher = useMemo(() => {
    return TEACHERS.find((t) => t.id === selectedTeacherId) || TEACHERS[0];
  }, [selectedTeacherId]);

  // Teacher sessions
  const teacherSessions = useMemo(() => {
    return activeSessions.filter((s) => s.teacherId === selectedTeacherId);
  }, [activeSessions, selectedTeacherId]);

  // Filtered teachers list for dropdown
  const filteredTeachers = useMemo(() => {
    if (teacherSubjectFilter === 'all') return TEACHERS;
    return TEACHERS.filter((t) => t.subject === teacherSubjectFilter);
  }, [teacherSubjectFilter]);

  // Distinct subjects for filter
  const allSubjects = useMemo(() => {
    const set = new Set<string>();
    TEACHERS.forEach((t) => set.add(t.subject));
    return Array.from(set);
  }, []);

  // Today's absent students list for the detector tab
  const absentStudentsToday = useMemo(() => {
    const dayRecords = records.filter((r) => r.date === detectorDate);
    const presentOrLateIds = new Set(
      dayRecords
        .filter((r) => r.status === 'present' || r.status === 'late' || r.status === 'excused')
        .map((r) => r.studentId)
    );

    return students
      .filter((s) => {
        const explicitRecord = dayRecords.find((r) => r.studentId === s.id);
        if (explicitRecord && explicitRecord.status === 'absent') return true;
        if (dayRecords.length > 0 && !presentOrLateIds.has(s.id)) return true;
        return false;
      })
      .map((student) => {
        const detail = getAbsentStudentSubjectInfo(student, {
          date: detectorDate,
          slotId: detectorSlotId,
          sessions: activeSessions,
        });
        return {
          student,
          detail,
        };
      })
      .filter(({ student, detail }) => {
        if (!detectorSearch.trim()) return true;
        const q = detectorSearch.trim().toLowerCase();
        return (
          student.firstName.toLowerCase().includes(q) ||
          student.lastName.toLowerCase().includes(q) ||
          student.classroom.toLowerCase().includes(q) ||
          (detail?.subject && detail.subject.toLowerCase().includes(q)) ||
          (detail?.teacherName && detail.teacherName.toLowerCase().includes(q))
        );
      });
  }, [students, records, detectorDate, detectorSlotId, detectorSearch, activeSessions]);

  // Currently focused absent student
  const activeAbsentStudent = useMemo(() => {
    if (!selectedAbsentStudentId && absentStudentsToday.length > 0) {
      return absentStudentsToday[0];
    }
    return absentStudentsToday.find((a) => a.student.id === selectedAbsentStudentId) || absentStudentsToday[0] || null;
  }, [selectedAbsentStudentId, absentStudentsToday]);

  // Absent student's full day schedule
  const studentDaySchedule = useMemo(() => {
    if (!activeAbsentStudent) return [];
    const day = getSchoolDay(detectorDate);
    return TIMETABLE_SLOTS.map((slot) => {
      const session = getSubjectForClassroom(
        activeAbsentStudent.student.classroom,
        day,
        slot.id,
        activeSessions
      );
      return {
        slot,
        session,
        isCurrentSelectedSlot: slot.id === detectorSlotId,
      };
    });
  }, [activeAbsentStudent, detectorDate, detectorSlotId, activeSessions]);

  // Excel Export Handler
  const handleExportTimetableExcel = () => {
    const dataToExport = activeSessions.map((s) => ({
      'اليوم': s.day,
      'رقم الحصة': s.slotId,
      'القسم': s.classroom,
      'المستوى': s.grade,
      'المادة': s.subject,
      'معرف الأستاذ': s.teacherId,
      'اسم الأستاذ': s.teacherName,
      'القاعة': s.room,
    }));
    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'جداول التوقيت');
    XLSX.writeFile(workbook, `Timetable_Saadoun_Achour_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  // Excel Import Handler
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const data = XLSX.utils.sheet_to_json<any>(ws);

        if (!Array.isArray(data) || data.length === 0) {
          alert('الملف فارغ أو غير صالح.');
          return;
        }

        const newSessions: TimetableSession[] = data.map((row, idx) => ({
          id: `SES-${Date.now()}-${idx}`,
          day: (row['اليوم'] || row['day'] || 'sunday') as SchoolDay,
          slotId: (row['رقم الحصة'] || row['slotId'] || 'p1') as TimetableSlotId,
          classroom: row['القسم'] || row['classroom'] || '1م1',
          grade: row['المستوى'] || row['grade'] || '1AM',
          subject: row['المادة'] || row['subject'] || 'الرياضيات',
          teacherId: row['معرف الأستاذ'] || row['teacherId'] || 'T01',
          teacherName: row['اسم الأستاذ'] || row['teacherName'] || 'أستاذ',
          room: row['القاعة'] || row['room'] || 'قاعة 01',
        }));

        if (onUpdateTimetableSessions) {
          onUpdateTimetableSessions(newSessions);
          setImportSuccessMsg(`تم استيراد وتحديث ${newSessions.length} حصة بنجاح من ملف Excel.`);
          setTimeout(() => setImportSuccessMsg(null), 5000);
        }
      } catch (err) {
        console.error('Import excel error:', err);
        alert('حدث خطأ أثناء قراءة ملف Excel. تأكد من صحة الأعمدة.');
      }
    };
    reader.readAsBinaryString(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Save or Add Session Form Handler
  const handleSaveSessionForm = (e: React.FormEvent) => {
    e.preventDefault();
    const updated = [...activeSessions];
    const existingIdx = updated.findIndex(
      (s) => s.day === editForm.day && s.slotId === editForm.slotId && s.classroom === editForm.classroom
    );

    const newSessionItem: TimetableSession = {
      id: editForm.id || `SES-${Date.now()}`,
      day: editForm.day,
      slotId: editForm.slotId,
      classroom: editForm.classroom,
      grade: editForm.grade,
      subject: editForm.subject,
      teacherId: editForm.teacherId,
      teacherName: editForm.teacherName,
      room: editForm.room,
    };

    if (existingIdx >= 0) {
      updated[existingIdx] = newSessionItem;
    } else {
      updated.push(newSessionItem);
    }

    if (onUpdateTimetableSessions) {
      onUpdateTimetableSessions(updated);
    }
    setIsEditModalOpen(false);
  };

  const handleDeleteSession = () => {
    if (!editForm.id) {
      setIsEditModalOpen(false);
      return;
    }
    const updated = activeSessions.filter((s) => s.id !== editForm.id);
    if (onUpdateTimetableSessions) {
      onUpdateTimetableSessions(updated);
    }
    setIsEditModalOpen(false);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Top Banner / Breadcrumb */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-800 font-bold mb-1">
            <School className="w-4 h-4" />
            <span>متوسطة سعدون عاشور — وادي فرشة - عنابة</span>
            <span className="text-slate-300">•</span>
            <span className="text-slate-600">نظام جداول التوقيت والمواد الرسمية</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            جداول التوقيت والمواد الدراسية (تلاميذ وأساتذة)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            متابعة دقيقة لجداول توقيت الأقسام، جدول حصص الأساتذة، الاستيراد والتصدير عبر Excel، وتعديل الحصص فورياً.
          </p>
        </div>

        {/* Actions & Live Active Slot Badge */}
        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <div className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-slate-600 animate-ping"></div>
            <div>
              <div className="text-[10px] text-slate-800 font-bold">الحصة الجارية الآن</div>
              <div className="text-xs font-black text-slate-950 font-mono-numbers">
                {currentActiveSlot.label} ({currentActiveSlot.timeRange})
              </div>
            </div>
          </div>

          {/* Excel Export Button */}
          <button
            onClick={handleExportTimetableExcel}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-50 hover:bg-slate-100 text-slate-900 border border-slate-200 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer active:scale-95"
            title="تصدير جدول التوقيت إلى ملف Excel"
          >
            <Download className="w-4 h-4 text-slate-700" />
            <span>تصدير Excel</span>
          </button>

          {/* Primary Institutional Timetable Excel Import Button */}
          <button
            onClick={() => setIsAdvancedImportModalOpen(true)}
            className="flex items-center gap-2 px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer active:scale-95"
            title="استيراد التوقيت الأسبوعي للمؤسسة من ملف Excel (أقسام وأساتذة أفقي مع المعاينة والتحقق)"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
            <span>استيراد توقيت المؤسسة</span>
          </button>

          {/* Quick Import Button */}
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer active:scale-95"
            title="استيراد سريع للجدول"
          >
            <Upload className="w-4 h-4 text-slate-600" />
            <span>استيراد سريع</span>
          </button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".xlsx, .xls, .csv"
            className="hidden"
          />

          {/* Add / Edit Session Button */}
          <button
            onClick={() => {
              setEditForm({
                day: currentSchoolDay,
                slotId: currentActiveSlot.id,
                classroom: selectedClassroom,
                grade: '1AM',
                subject: 'الرياضيات',
                teacherId: TEACHERS[0]?.id || 'T01',
                teacherName: TEACHERS[0]?.name || 'الأستاذ',
                room: 'قاعة 01',
              });
              setIsEditModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-3 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة / تعديل حصة</span>
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer active:scale-95 no-print"
            title="طباعة الجدول الحالي"
          >
            <Printer className="w-4 h-4 text-slate-600" />
            <span>طباعة</span>
          </button>
        </div>
      </div>

      {/* Active Timetable Metadata & Version Switcher Banner */}
      <div className="bg-emerald-50 border border-emerald-200/80 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 shadow-xs">
        <div className="flex items-start sm:items-center gap-3">
          <div className="p-2 bg-emerald-700 text-white rounded-xl shrink-0 shadow-xs">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-black text-sm text-emerald-950">
                {activeTimetableMeta?.name || 'جدول التوقيت الأسبوعي العام المعتمد'}
              </span>
              <span className="bg-emerald-200/80 text-emerald-900 px-2.5 py-0.5 rounded-full text-xs font-mono font-bold">
                {activeTimetableMeta?.version || 'v1.0'}
              </span>
              <span className="inline-flex items-center gap-1 bg-white text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded-md text-[11px] font-semibold">
                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                <span>ساري المفعول من: {activeTimetableMeta?.effectiveFrom || '2026-10-18'}</span>
              </span>
            </div>
            <div className="text-xs text-emerald-800/90 mt-1 flex flex-wrap items-center gap-x-3 gap-y-1">
              <span>إجمالي الحصص المسجلة: <strong className="font-mono-numbers">{activeSessions.length}</strong> حصة</span>
              <span>• السنة الدراسية: <strong>{activeTimetableMeta?.academicYear || '2026-2027'}</strong></span>
              <span>• المؤسسة: <strong>متوسطة سعدون عاشور</strong></span>
              {activeTimetableMeta?.sourceFile && (
                <span>• المصدر: <span className="font-mono text-[11px]">{activeTimetableMeta.sourceFile}</span></span>
              )}
            </div>
          </div>
        </div>

        {/* Action button & Switcher */}
        <div className="flex items-center gap-2.5 shrink-0">
          {timetableHistory && timetableHistory.length > 1 && onSwitchTimetable && (
            <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-xl border border-emerald-200">
              <Layers className="w-4 h-4 text-emerald-700" />
              <label htmlFor="history-select" className="text-xs text-emerald-900 font-bold">الإصدار:</label>
              <select
                id="history-select"
                value={activeTimetableMeta?.id || ''}
                onChange={async (e) => {
                  const verId = e.target.value;
                  if (verId && verId !== activeTimetableMeta?.id) {
                    setIsSwitchingVersion(true);
                    try {
                      await onSwitchTimetable(verId);
                    } finally {
                      setIsSwitchingVersion(false);
                    }
                  }
                }}
                disabled={isSwitchingVersion}
                className="bg-transparent text-xs text-emerald-950 font-bold focus:outline-none cursor-pointer"
              >
                {timetableHistory.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.name} ({v.version}) - {v.effectiveFrom}
                  </option>
                ))}
              </select>
            </div>
          )}

          <button
            onClick={() => setIsAdvancedImportModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer active:scale-95"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>تحديث / استيراد إصدار جديد</span>
          </button>
        </div>
      </div>

      {/* Success Import Notification Alert */}
      {importSuccessMsg && (
        <div className="bg-slate-700 text-white text-xs px-4 py-2.5 rounded-xl shadow-md flex items-center justify-between gap-2 animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-slate-200" />
            <span className="font-bold">{importSuccessMsg}</span>
          </div>
          <button onClick={() => setImportSuccessMsg(null)} className="text-slate-200 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Main Tab Switcher */}
      <div className="bg-slate-100 p-1.5 rounded-2xl flex flex-wrap gap-1 border border-slate-200/80 no-print">
        <button
          onClick={() => setActiveTab('absence_detector')}
          className={`flex-1 min-w-[200px] py-2.5 px-4 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'absence_detector'
              ? 'bg-white text-slate-900 shadow-sm border border-slate-100'
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
          }`}
        >
          <UserX className="w-4 h-4 text-slate-600" />
          <span>كاشف مادة التلميذ الغائب (فوري)</span>
          <span className="bg-slate-100 text-slate-800 text-[10px] px-2 py-0.5 rounded-full font-black">
            {absentStudentsToday.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('classes')}
          className={`flex-1 min-w-[200px] py-2.5 px-4 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'classes'
              ? 'bg-white text-slate-900 shadow-sm border border-slate-100'
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
          }`}
        >
          <Users className="w-4 h-4 text-slate-700" />
          <span>تواقيت الأقسام والتلاميذ</span>
        </button>

        <button
          onClick={() => setActiveTab('teachers')}
          className={`flex-1 min-w-[200px] py-2.5 px-4 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'teachers'
              ? 'bg-white text-blue-900 shadow-sm border border-blue-100'
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
          }`}
        >
          <User className="w-4 h-4 text-blue-700" />
          <span>تواقيت الأساتذة وهيئة التدريس</span>
        </button>

        <button
          onClick={() => setActiveTab('rooms')}
          className={`flex-1 min-w-[200px] py-2.5 px-4 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'rooms'
              ? 'bg-white text-emerald-900 shadow-sm border border-emerald-100'
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
          }`}
        >
          <MapPin className="w-4 h-4 text-emerald-700" />
          <span>تواقيت القاعات والمخابر (معلوماتية)</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: ABSENCE TO SUBJECT DETECTOR (كاشف مادة التلميذ الغائب) */}
      {/* ========================================================================= */}
      {activeTab === 'absence_detector' && (
        <div className="space-y-6">
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs">
                <Calendar className="w-3.5 h-3.5 text-slate-500" />
                <span className="text-slate-500 font-medium">تاريخ المعاينة:</span>
                <input
                  type="date"
                  value={detectorDate}
                  onChange={(e) => setDetectorDate(e.target.value)}
                  className="bg-transparent font-bold text-slate-800 outline-none font-mono-numbers cursor-pointer"
                />
              </div>

              <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs">
                <Clock className="w-3.5 h-3.5 text-slate-500" />
                <span className="text-slate-500 font-medium">الحصة المراد فحصها:</span>
                <select
                  value={detectorSlotId}
                  onChange={(e) => setDetectorSlotId(e.target.value as TimetableSlotId)}
                  className="bg-transparent font-bold text-slate-800 outline-none cursor-pointer"
                >
                  {TIMETABLE_SLOTS.map((slot) => (
                    <option key={slot.id} value={slot.id}>
                      {slot.label} ({slot.timeRange})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="relative min-w-[240px]">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="ابحث عن تلميذ غائب أو مادة أو أستاذ..."
                value={detectorSearch}
                onChange={(e) => setDetectorSearch(e.target.value)}
                className="w-full pl-3 pr-8 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:border-slate-400 outline-none transition-all"
              />
            </div>
          </div>

          <div className="bg-slate-50/70 border border-slate-200 rounded-2xl p-4 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-slate-600 shrink-0 mt-0.5" />
            <div className="text-xs text-slate-950">
              <p className="font-bold mb-0.5">
                تحديد المادة والأستاذ لكل تلميذ غائب آلياً بحسب التشريع والمخطط التربوي للمؤسسة
              </p>
              <p className="text-slate-800 leading-relaxed">
                يقوم النظام بمطابقة قسم التلميذ المسجل غيابه مع جدول التوقيت الأسبوعي لمتوسطة سعدون عاشور لليوم المحدد،
                ليظهر فوراً للأمانة العامة ومستشارة التربية المادة التي ضاعت على التلميذ، والأستاذ الواجب إشعاره، والقاعة التي كان يفترض تواجده بها.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 space-y-3">
              <div className="flex items-center justify-between px-1">
                <h3 className="text-xs font-black text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                  <UserX className="w-3.5 h-3.5 text-slate-600" />
                  <span>قائمة الغائبين في هذه الحصة ({absentStudentsToday.length})</span>
                </h3>
                <span className="text-[11px] text-slate-500 font-mono-numbers">
                  {TIMETABLE_SLOTS.find((s) => s.id === detectorSlotId)?.timeRange}
                </span>
              </div>

              {absentStudentsToday.length === 0 ? (
                <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-400 space-y-2">
                  <CheckCircle2 className="w-8 h-8 text-slate-500 mx-auto" />
                  <p className="text-xs font-bold text-slate-700">لا يوجد تلاميذ غائبون مسجلون في هذه الحصة!</p>
                  <p className="text-[11px]">جميع التلاميذ حاضرون أو لم يتم تسجيل غيابات لهذا التاريخ بعد.</p>
                </div>
              ) : (
                <div className="space-y-2.5 max-h-[620px] overflow-y-auto pr-0.5">
                  {absentStudentsToday.map(({ student, detail }) => {
                    const isSelected = activeAbsentStudent?.student.id === student.id;
                    const subjectStyle = detail?.subject ? SUBJECT_INFO[detail.subject] : null;

                    return (
                      <div
                        key={student.id}
                        onClick={() => setSelectedAbsentStudentId(student.id)}
                        className={`p-3.5 rounded-2xl border transition-all cursor-pointer text-right ${
                          isSelected
                            ? 'bg-slate-50/50 border-slate-300 shadow-xs ring-2 ring-slate-200/50'
                            : 'bg-white border-slate-200 hover:border-slate-300 hover:shadow-xs'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <span className="w-7 h-7 rounded-xl bg-slate-100 text-slate-700 font-black text-xs flex items-center justify-center">
                              {student.classroom}
                            </span>
                            <div>
                              <h4 className="text-xs font-black text-slate-900 leading-tight">
                                {student.lastName} {student.firstName}
                              </h4>
                              <span className="text-[10px] text-slate-400 font-mono-numbers">
                                {student.id}
                              </span>
                            </div>
                          </div>

                          {detail && (
                            <span
                              className={`text-[11px] font-bold px-2.5 py-1 rounded-lg border ${
                                subjectStyle
                                  ? `${subjectStyle.bg} ${subjectStyle.text} ${subjectStyle.border}`
                                  : 'bg-slate-100 text-slate-800 border-slate-200'
                              }`}
                            >
                              {detail.subject}
                            </span>
                          )}
                        </div>

                        {detail && (
                          <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-600">
                            <div className="flex items-center gap-1">
                              <User className="w-3 h-3 text-slate-400" />
                              <span className="font-semibold text-slate-700">{detail.teacherName}</span>
                            </div>
                            <div className="flex items-center gap-1 font-medium text-slate-500">
                              <MapPin className="w-3 h-3 text-slate-400" />
                              <span>{detail.room}</span>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="lg:col-span-7">
              {activeAbsentStudent ? (
                <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
                  <div className="p-5 border-b border-slate-100 bg-slate-50/70 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-slate-600 text-white font-black flex items-center justify-center text-sm shadow-xs">
                        {activeAbsentStudent.student.classroom}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-base font-black text-slate-900">
                            {activeAbsentStudent.student.lastName} {activeAbsentStudent.student.firstName}
                          </h3>
                          <span className="text-xs bg-slate-100 text-slate-800 font-bold px-2 py-0.5 rounded-full">
                            غائب
                          </span>
                        </div>
                        <div className="flex items-center gap-3 text-xs text-slate-500 mt-1 font-mono-numbers">
                          <span>القسم: {activeAbsentStudent.student.classroom}</span>
                          <span>•</span>
                          <span>المستوى: {activeAbsentStudent.student.grade}</span>
                          <span>•</span>
                          <span>هاتف الولي: {activeAbsentStudent.student.guardianPhone}</span>
                        </div>
                      </div>
                    </div>

                    {onViewStudentCard && (
                      <button
                        onClick={() => onViewStudentCard(activeAbsentStudent.student)}
                        className="flex items-center gap-1 text-xs font-bold text-slate-700 bg-white border border-slate-200 px-3 py-1.5 rounded-xl hover:bg-slate-50 cursor-pointer transition-colors shadow-xs"
                      >
                        <Eye className="w-3.5 h-3.5 text-slate-500" />
                        <span>بطاقة التلميذ</span>
                      </button>
                    )}
                  </div>

                  <div className="p-5 border-b border-slate-100">
                    <div className="text-[11px] font-black text-slate-400 uppercase tracking-wider mb-2">
                      تفاصيل الحصة المحددة حالياً ({TIMETABLE_SLOTS.find((s) => s.id === detectorSlotId)?.label})
                    </div>

                    <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white rounded-2xl p-4.5 shadow-sm space-y-4">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="text-slate-300 text-xs font-bold flex items-center gap-1.5 mb-1">
                            <BookOpen className="w-3.5 h-3.5" />
                            <span>المادة الدراسية التي غاب عنها:</span>
                          </div>
                          <div className="text-xl sm:text-2xl font-black text-white">
                            {activeAbsentStudent.detail?.subject || 'غير محدد'}
                          </div>
                        </div>

                        <div className="bg-white/10 px-3 py-1.5 rounded-xl backdrop-blur-xs text-right">
                          <div className="text-[10px] text-slate-300">التوقيت الساعي</div>
                          <div className="text-xs font-mono-numbers font-bold text-white">
                            {activeAbsentStudent.detail?.timeRange}
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-white/10 text-xs">
                        <div className="flex items-center gap-2 bg-white/5 p-2 rounded-xl">
                          <User className="w-4 h-4 text-slate-400 shrink-0" />
                          <div>
                            <span className="text-[10px] text-slate-300 block">الأستاذ المكلف:</span>
                            <span className="font-bold text-white">
                              {activeAbsentStudent.detail?.teacherName}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 bg-white/5 p-2 rounded-xl">
                          <MapPin className="w-4 h-4 text-amber-400 shrink-0" />
                          <div>
                            <span className="text-[10px] text-slate-300 block">مكان الحصة:</span>
                            <span className="font-bold text-white">
                              {activeAbsentStudent.detail?.room}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="p-5">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-slate-700" />
                        <span>
                          سير حصص التلميذ لليوم كاملاً (يوم {DAYS_OF_WEEK.find((d) => d.key === getSchoolDay(detectorDate))?.label})
                        </span>
                      </h4>
                      <span className="text-[11px] text-slate-400 font-mono-numbers">
                        قسم {activeAbsentStudent.student.classroom}
                      </span>
                    </div>

                    <div className="border border-slate-200 rounded-xl overflow-hidden divide-y divide-slate-100 text-xs">
                      {studentDaySchedule.map(({ slot, session, isCurrentSelectedSlot }) => {
                        const style = session ? SUBJECT_INFO[session.subject] : null;

                        return (
                          <div
                            key={slot.id}
                            className={`p-3 flex items-center justify-between transition-colors ${
                              isCurrentSelectedSlot
                                ? 'bg-amber-50/80 font-medium'
                                : 'hover:bg-slate-50/60'
                            }`}
                          >
                            <div className="flex items-center gap-3">
                              <span
                                className={`w-8 h-8 rounded-lg flex items-center justify-center font-black text-xs ${
                                  isCurrentSelectedSlot
                                    ? 'bg-amber-600 text-white'
                                    : 'bg-slate-100 text-slate-600'
                                }`}
                              >
                                {slot.id.toUpperCase()}
                              </span>
                              <div>
                                <div className="font-bold text-slate-800 flex items-center gap-2">
                                  <span>{slot.label}</span>
                                  {isCurrentSelectedSlot && (
                                    <span className="text-[10px] bg-amber-200 text-amber-900 px-1.5 py-0.2 rounded font-black">
                                      الحصة المفحوصة
                                    </span>
                                  )}
                                </div>
                                <span className="text-[10px] text-slate-400 font-mono-numbers">
                                  {slot.timeRange}
                                </span>
                              </div>
                            </div>

                            {session ? (
                              <div className="text-left flex items-center gap-3">
                                <div>
                                  <span
                                    className={`inline-block font-bold px-2 py-0.5 rounded text-[11px] ${
                                      style ? `${style.bg} ${style.text}` : 'bg-slate-100 text-slate-800'
                                    }`}
                                  >
                                    {session.subject}
                                  </span>
                                  <div className="text-[10px] text-slate-500 mt-0.5 text-right">
                                    {session.teacherName}
                                  </div>
                                </div>
                                <span className="text-[10px] text-slate-500 bg-slate-100 px-2 py-1 rounded">
                                  {session.room}
                                </span>
                              </div>
                            ) : (
                              <span className="text-slate-400 text-[11px] italic">
                                فراغ / لا توجد حصة
                              </span>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center text-slate-400">
                  <Info className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-bold text-slate-600">اختر تلميذاً من القائمة لمعاينة تفاصيل مادته وحصصه</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: CLASS / STUDENT TIMETABLE (تواقيت الأقسام والتلاميذ) */}
      {/* ========================================================================= */}
      {activeTab === 'classes' && (
        <div className="space-y-6">
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold text-slate-500 ml-1">اختر القسم:</span>
              {availableClassrooms.map((cls) => (
                <button
                  key={cls}
                  onClick={() => setSelectedClassroom(cls)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    selectedClassroom === cls
                      ? 'bg-slate-800 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {cls}
                </button>
              ))}
            </div>

            <div className="relative min-w-[260px]">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="ابحث عن تلميذ لعرض جدول قسمه فوراً..."
                value={classSearchQuery}
                onChange={(e) => setClassSearchQuery(e.target.value)}
                className="w-full pl-3 pr-8 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:border-slate-600 outline-none transition-all"
              />

              {studentSearchMatches.length > 0 && (
                <div className="absolute z-20 top-full mt-1.5 w-full bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden divide-y divide-slate-100">
                  {studentSearchMatches.map((st) => (
                    <button
                      key={st.id}
                      onClick={() => handleStudentSearchSelect(st.classroom)}
                      className="w-full text-right px-3 py-2 text-xs hover:bg-slate-50 flex items-center justify-between cursor-pointer transition-colors"
                    >
                      <div>
                        <div className="font-bold text-slate-800">
                          {st.lastName} {st.firstName}
                        </div>
                        <span className="text-[10px] text-slate-400 font-mono-numbers">
                          {st.id} ({st.grade})
                        </span>
                      </div>
                      <span className="bg-slate-100 text-slate-800 font-black px-2 py-0.5 rounded text-[11px]">
                        قسم {st.classroom}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-slate-100 bg-slate-50/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-[11px] font-black text-slate-800 uppercase tracking-wider block">
                  الجمهورية الجزائرية الديمقراطية الشعبية — وزارة التربية الوطنية
                </span>
                <h3 className="text-base sm:text-lg font-black text-slate-900 mt-0.5">
                  جدول التوقيت الأسبوعي لقسم: {selectedClassroom}
                </h3>
                <p className="text-xs text-slate-500 font-mono-numbers mt-0.5">
                  السنة الدراسية {settings.academicYear} • متوسطة {settings.schoolName}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setEditForm({
                      day: 'sunday',
                      slotId: 'p1',
                      classroom: selectedClassroom,
                      grade: '1AM',
                      subject: 'الرياضيات',
                      teacherId: TEACHERS[0]?.id || 'T01',
                      teacherName: TEACHERS[0]?.name || 'الأستاذ',
                      room: 'قاعة 01',
                    });
                    setIsEditModalOpen(true);
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-700 text-white rounded-xl text-xs font-bold hover:bg-slate-800 transition-all cursor-pointer"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>تعديل هذا القسم</span>
                </button>
              </div>
            </div>

            <div className="overflow-x-auto p-4 sm:p-6">
              <table className="w-full border-collapse text-right text-xs">
                <thead>
                  <tr className="border-b-2 border-slate-200">
                    <th className="py-3 px-3 font-bold text-slate-500 w-28 bg-slate-50/80 rounded-tr-xl">
                      اليوم / الحصة
                    </th>
                    {TIMETABLE_SLOTS.map((slot) => {
                      const isCurrent = slot.id === currentActiveSlot.id;
                      return (
                        <th
                          key={slot.id}
                          className={`py-2 px-2 text-center border-r border-slate-200 transition-colors ${
                            isCurrent ? 'bg-slate-50 text-slate-950 font-black' : 'bg-slate-50/80 text-slate-700 font-bold'
                          }`}
                        >
                          <div className="text-[11px] font-bold">{slot.label}</div>
                          <div className="text-[10px] text-slate-500 font-mono-numbers font-normal">
                            {slot.timeRange}
                          </div>
                          {isCurrent && (
                            <span className="inline-block mt-0.5 bg-slate-600 text-white text-[9px] px-1 rounded font-black">
                              الآن
                            </span>
                          )}
                        </th>
                      );
                    })}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {DAYS_OF_WEEK.map((day) => {
                    const isToday = day.key === currentSchoolDay;

                    return (
                      <tr
                        key={day.key}
                        className={`transition-colors ${
                          isToday ? 'bg-slate-50/20' : 'hover:bg-slate-50/50'
                        }`}
                      >
                        <td className="py-3 px-3 font-black text-slate-800 bg-slate-50/50 border-l border-slate-200">
                          <div className="flex items-center gap-1.5">
                            <span>{day.label}</span>
                            {isToday && (
                              <span className="w-1.5 h-1.5 rounded-full bg-slate-600 animate-pulse"></span>
                            )}
                          </div>
                        </td>

                        {TIMETABLE_SLOTS.map((slot) => {
                          const cellSessions = activeSessions.filter(
                            (s) => s.classroom === selectedClassroom && s.day === day.key && s.slotId === slot.id
                          );
                          const isCurrentActive = isToday && slot.id === currentActiveSlot.id;

                          return (
                            <td
                              key={slot.id}
                              className={`py-2.5 px-2 border-r border-slate-200 align-top transition-all ${
                                isCurrentActive
                                  ? 'ring-2 ring-slate-500/50 bg-slate-50/40'
                                  : ''
                              }`}
                            >
                              {cellSessions.length > 0 ? (
                                <div className="space-y-1.5 h-full flex flex-col justify-center">
                                  {cellSessions.map((session) => {
                                    const subjectStyle = SUBJECT_INFO[session.subject];
                                    return (
                                      <div
                                        key={session.id}
                                        onClick={() => {
                                          setEditForm({
                                            id: session.id,
                                            day: session.day,
                                            slotId: session.slotId,
                                            classroom: session.classroom,
                                            grade: session.grade,
                                            subject: session.subject,
                                            teacherId: session.teacherId,
                                            teacherName: session.teacherName,
                                            room: session.room,
                                          });
                                          setIsEditModalOpen(true);
                                        }}
                                        className={`rounded-xl p-2 border transition-all flex flex-col justify-between cursor-pointer hover:shadow-xs ${
                                          subjectStyle
                                            ? `${subjectStyle.bg} ${subjectStyle.border}`
                                            : 'bg-slate-50 border-slate-200'
                                        }`}
                                        title="انقر لتعديل هذه الحصة"
                                      >
                                        <div>
                                          <div
                                            className={`font-black text-[11px] leading-tight ${
                                              subjectStyle ? subjectStyle.text : 'text-slate-900'
                                            }`}
                                          >
                                            {session.subject} {session.group ? <span className="text-[9px] bg-white/80 px-1 rounded text-slate-700 font-bold mr-1">({session.group})</span> : ''}
                                          </div>
                                          <div className="text-[10px] text-slate-600 font-medium mt-1 truncate">
                                            {session.teacherName}
                                          </div>
                                        </div>
                                        <div className="mt-1 pt-1 border-t border-slate-200/60 flex items-center justify-between text-[9px] text-slate-500 font-mono-numbers">
                                          <span>{session.room}</span>
                                          {isCurrentActive && (
                                            <span className="font-bold text-slate-700">جارية</span>
                                          )}
                                        </div>
                                      </div>
                                    );
                                  })}
                                </div>
                              ) : (
                                <div
                                  onClick={() => {
                                    setEditForm({
                                      day: day.key,
                                      slotId: slot.id,
                                      classroom: selectedClassroom,
                                      grade: '1AM',
                                      subject: 'الرياضيات',
                                      teacherId: TEACHERS[0]?.id || 'T01',
                                      teacherName: TEACHERS[0]?.name || 'الأستاذ',
                                      room: 'قاعة 01',
                                    });
                                    setIsEditModalOpen(true);
                                  }}
                                  className="h-full min-h-[55px] flex items-center justify-center text-slate-300 text-[10px] font-medium bg-slate-50/30 rounded-lg cursor-pointer hover:bg-slate-50 hover:text-slate-700 transition-colors"
                                  title="إضافة حصة في هذا الفراغ"
                                >
                                  + إضافة
                                </div>
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center gap-3 text-[11px]">
              <span className="font-bold text-slate-600">دليل المواد:</span>
              {Object.entries(SUBJECT_INFO).slice(0, 8).map(([subName, info]) => (
                <div key={subName} className="flex items-center gap-1.5">
                  <span className={`w-2.5 h-2.5 rounded-full ${info.bg} border ${info.border}`}></span>
                  <span className="text-slate-700 font-medium">{subName}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: TEACHER TIMETABLE (تواقيت الأساتذة) */}
      {/* ========================================================================= */}
      {activeTab === 'teachers' && (
        <div className="space-y-6">
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs">
                <Filter className="w-3.5 h-3.5 text-slate-500" />
                <span className="text-slate-500 font-medium">تصفية حسب المادة:</span>
                <select
                  value={teacherSubjectFilter}
                  onChange={(e) => setTeacherSubjectFilter(e.target.value)}
                  className="bg-transparent font-bold text-slate-800 outline-none cursor-pointer"
                >
                  <option value="all">جميع المواد ({TEACHERS.length} أستاذ)</option>
                  {allSubjects.map((sub) => (
                    <option key={sub} value={sub}>
                      {sub}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs">
                <User className="w-3.5 h-3.5 text-blue-600" />
                <span className="text-slate-500 font-medium">الأستاذ:</span>
                <select
                  value={selectedTeacherId}
                  onChange={(e) => setSelectedTeacherId(e.target.value)}
                  className="bg-transparent font-bold text-blue-900 outline-none cursor-pointer"
                >
                  {filteredTeachers.map((teacher) => (
                    <option key={teacher.id} value={teacher.id}>
                      {teacher.name} — {teacher.subject}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="px-3 py-1 bg-blue-50 text-blue-900 border border-blue-200 rounded-xl text-xs font-bold font-mono-numbers">
                الحجم الساعي الأسبوعي: {activeTeacher.weeklyHours || 18} ساعة
              </span>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-5 border-b border-slate-100 bg-slate-50/60 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-blue-700 text-white font-black flex items-center justify-center text-base shadow-xs">
                  <User className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base sm:text-lg font-black text-slate-900">
                      {activeTeacher.name}
                    </h3>
                    <span className="text-xs bg-blue-100 text-blue-800 font-bold px-2.5 py-0.5 rounded-full">
                      أستاذ {activeTeacher.subject}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-slate-500 mt-1 font-mono-numbers">
                    <span>الهاتف: {activeTeacher.phone}</span>
                    <span>•</span>
                    <span>البريد المهني: {activeTeacher.email}</span>
                  </div>
                </div>
              </div>

              {(() => {
                const currentSessionOfTeacher = teacherSessions.find(
                  (s) => s.day === currentSchoolDay && s.slotId === currentActiveSlot.id
                );

                return currentSessionOfTeacher ? (
                  <div className="bg-slate-50 border border-slate-200 text-slate-950 px-3 py-1.5 rounded-xl text-xs flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-slate-600 animate-ping"></span>
                    <div>
                      <span className="font-bold block">متواجد الآن في القسم:</span>
                      <span className="font-mono-numbers">
                        قسم {currentSessionOfTeacher.classroom} ({currentSessionOfTeacher.room})
                      </span>
                    </div>
                  </div>
                ) : (
                  <div className="bg-slate-100 border border-slate-200 text-slate-700 px-3 py-1.5 rounded-xl text-xs flex items-center gap-2">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span>ساعة راحة / غير مبرمج حالياً</span>
                  </div>
                );
              })()}
            </div>

            <div className="overflow-x-auto p-4 sm:p-6">
              <table className="w-full border-collapse text-right text-xs">
                <thead>
                  <tr className="border-b-2 border-slate-200">
                    <th className="py-3 px-3 font-bold text-slate-500 w-28 bg-slate-50/80 rounded-tr-xl">
                      اليوم / الحصة
                    </th>
                    {TIMETABLE_SLOTS.map((slot) => {
                      const isCurrent = slot.id === currentActiveSlot.id;
                      return (
                        <th
                          key={slot.id}
                          className={`py-2 px-2 text-center border-r border-slate-200 transition-colors ${
                            isCurrent ? 'bg-blue-50 text-blue-950 font-black' : 'bg-slate-50/80 text-slate-700 font-bold'
                          }`}
                        >
                          <div className="text-[11px] font-bold">{slot.label}</div>
                          <div className="text-[10px] text-slate-500 font-mono-numbers font-normal">
                            {slot.timeRange}
                          </div>
                          {isCurrent && (
                            <span className="inline-block mt-0.5 bg-blue-600 text-white text-[9px] px-1 rounded font-black">
                              الآن
                            </span>
                          )}
                        </th>
                      );
                    })}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {DAYS_OF_WEEK.map((day) => {
                    const isToday = day.key === currentSchoolDay;

                    return (
                      <tr
                        key={day.key}
                        className={`transition-colors ${
                          isToday ? 'bg-blue-50/20' : 'hover:bg-slate-50/50'
                        }`}
                      >
                        <td className="py-3 px-3 font-black text-slate-800 bg-slate-50/50 border-l border-slate-200">
                          <div className="flex items-center gap-1.5">
                            <span>{day.label}</span>
                            {isToday && (
                              <span className="w-1.5 h-1.5 rounded-full bg-blue-600 animate-pulse"></span>
                            )}
                          </div>
                        </td>

                        {TIMETABLE_SLOTS.map((slot) => {
                          const session = teacherSessions.find(
                            (s) => s.day === day.key && s.slotId === slot.id
                          );
                          const isCurrentActive = isToday && slot.id === currentActiveSlot.id;

                          return (
                            <td
                              key={slot.id}
                              className={`py-2.5 px-2 border-r border-slate-200 align-top transition-all ${
                                isCurrentActive
                                  ? 'ring-2 ring-blue-500/50 bg-blue-50/40'
                                  : ''
                              }`}
                            >
                              {session ? (
                                <div
                                  onClick={() => {
                                    setEditForm({
                                      id: session.id,
                                      day: session.day,
                                      slotId: session.slotId,
                                      classroom: session.classroom,
                                      grade: session.grade,
                                      subject: session.subject,
                                      teacherId: session.teacherId,
                                      teacherName: session.teacherName,
                                      room: session.room,
                                    });
                                    setIsEditModalOpen(true);
                                  }}
                                  className="rounded-xl p-2 border bg-blue-50/80 border-blue-200 text-blue-900 transition-all h-full flex flex-col justify-between cursor-pointer hover:shadow-xs"
                                  title="تعديل جدول الأستاذ"
                                >
                                  <div>
                                    <div className="font-black text-xs">
                                      قسم: {session.classroom}
                                    </div>
                                    <div className="text-[10px] text-blue-700 font-medium mt-0.5">
                                      {session.subject}
                                    </div>
                                  </div>
                                  <div className="mt-1 pt-1 border-t border-blue-200 flex items-center justify-between text-[9px] text-blue-600 font-mono-numbers">
                                    <span>{session.room}</span>
                                    {isCurrentActive && (
                                      <span className="font-bold text-blue-800">نشط الآن</span>
                                    )}
                                  </div>
                                </div>
                              ) : (
                                <div
                                  onClick={() => {
                                    setEditForm({
                                      day: day.key,
                                      slotId: slot.id,
                                      classroom: '1م1',
                                      grade: '1AM',
                                      subject: activeTeacher.subject,
                                      teacherId: activeTeacher.id,
                                      teacherName: activeTeacher.name,
                                      room: 'قاعة 01',
                                    });
                                    setIsEditModalOpen(true);
                                  }}
                                  className="h-full min-h-[55px] flex items-center justify-center text-slate-300 text-[10px] font-medium bg-slate-50/30 rounded-lg cursor-pointer hover:bg-blue-50 hover:text-blue-700 transition-colors"
                                >
                                  فراغ
                                </div>
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* EDIT / ADD TIMETABLE SESSION MODAL */}
      {/* ========================================================================= */}
      {isEditModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 duration-150">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <Edit3 className="w-5 h-5 text-slate-700" />
                <h3 className="text-base font-black text-slate-900">إضافة أو تعديل حصة دراسية</h3>
              </div>
              <button
                onClick={() => setIsEditModalOpen(false)}
                className="w-8 h-8 rounded-xl bg-white border border-slate-200 text-slate-500 hover:text-slate-800 flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveSessionForm} className="p-6 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">اليوم:</label>
                  <select
                    value={editForm.day}
                    onChange={(e) => setEditForm({ ...editForm, day: e.target.value as SchoolDay })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold outline-none cursor-pointer"
                  >
                    {DAYS_OF_WEEK.map((d) => (
                      <option key={d.key} value={d.key}>
                        {d.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">الحصة:</label>
                  <select
                    value={editForm.slotId}
                    onChange={(e) => setEditForm({ ...editForm, slotId: e.target.value as TimetableSlotId })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold outline-none cursor-pointer"
                  >
                    {TIMETABLE_SLOTS.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.label} ({s.timeRange})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">القسم:</label>
                  <select
                    value={editForm.classroom}
                    onChange={(e) => setEditForm({ ...editForm, classroom: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold outline-none cursor-pointer"
                  >
                    {availableClassrooms.map((c) => (
                      <option key={c} value={c}>
                        قسم {c}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">المادة الدراسية:</label>
                  <select
                    value={editForm.subject}
                    onChange={(e) => {
                      const sub = e.target.value;
                      const matchedTeacher = TEACHERS.find((t) => t.subject === sub) || TEACHERS[0];
                      setEditForm({
                        ...editForm,
                        subject: sub,
                        teacherId: matchedTeacher.id,
                        teacherName: matchedTeacher.name,
                      });
                    }}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold outline-none cursor-pointer"
                  >
                    {allSubjects.map((sub) => (
                      <option key={sub} value={sub}>
                        {sub}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">الأستاذ المكلف:</label>
                <select
                  value={editForm.teacherId}
                  onChange={(e) => {
                    const tId = e.target.value;
                    const t = TEACHERS.find((tch) => tch.id === tId);
                    if (t) {
                      setEditForm({
                        ...editForm,
                        teacherId: t.id,
                        teacherName: t.name,
                        subject: t.subject,
                      });
                    }
                  }}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold outline-none cursor-pointer"
                >
                  {TEACHERS.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name} ({t.subject})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">القاعة:</label>
                <input
                  type="text"
                  value={editForm.room}
                  onChange={(e) => setEditForm({ ...editForm, room: e.target.value })}
                  placeholder="مثال: قاعة 04 أو مخبر العلوم"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold outline-none"
                />
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                {editForm.id ? (
                  <button
                    type="button"
                    onClick={handleDeleteSession}
                    className="flex items-center gap-1.5 px-4 py-2 bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold rounded-xl cursor-pointer transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>مسح الحصة</span>
                  </button>
                ) : (
                  <div></div>
                )}

                <div className="flex items-center gap-2.5">
                  <button
                    type="button"
                    onClick={() => setIsEditModalOpen(false)}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl cursor-pointer"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-slate-700 hover:bg-slate-800 text-white font-bold rounded-xl shadow-xs cursor-pointer"
                  >
                    حفظ الحصة
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: ROOMS SCHEDULE (تواقيت القاعات والمخابر - معلوماتية) */}
      {/* ========================================================================= */}
      {activeTab === 'rooms' && (
        <div className="space-y-6">
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold text-slate-500 ml-1">اختر القاعة أو المخبر:</span>
              {allRooms.map((roomName) => (
                <button
                  key={roomName}
                  onClick={() => setSelectedRoom(roomName)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    selectedRoom === roomName
                      ? 'bg-emerald-700 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {roomName}
                </button>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-slate-100 bg-emerald-50/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-[11px] font-black text-emerald-800 uppercase tracking-wider block">
                  جدول إشغال القاعات والمخابر (بما فيها قاعات الإعلام الآلي معلوماتية_1 و معلوماتية_2)
                </span>
                <h3 className="text-base sm:text-lg font-black text-slate-900 mt-0.5">
                  جدول توقيت القاعة: {selectedRoom}
                </h3>
              </div>
            </div>

            <div className="overflow-x-auto p-4 sm:p-6">
              <table className="w-full border-collapse text-right text-xs">
                <thead>
                  <tr className="border-b-2 border-slate-200">
                    <th className="py-3 px-3 font-bold text-slate-500 w-28 bg-slate-50/80 rounded-tr-xl">
                      اليوم / الحصة
                    </th>
                    {TIMETABLE_SLOTS.map((slot) => (
                      <th key={slot.id} className="py-2 px-2 text-center border-r border-slate-200 bg-slate-50/80 text-slate-700 font-bold">
                        <div className="text-[11px] font-bold">{slot.label}</div>
                        <div className="text-[10px] text-slate-500 font-mono-numbers font-normal">
                          {slot.timeRange}
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {DAYS_OF_WEEK.map((day) => (
                    <tr key={day.key} className="hover:bg-slate-50/50">
                      <td className="py-3 px-3 font-black text-slate-800 bg-slate-50/50 border-l border-slate-200">
                        {day.label}
                      </td>
                      {TIMETABLE_SLOTS.map((slot) => {
                        const cellSessions = activeSessions.filter(
                          (s) => (s.room === selectedRoom || (selectedRoom.includes('معلوماتية') && s.room?.includes('معلوماتية'))) && s.day === day.key && s.slotId === slot.id
                        );
                        return (
                          <td key={slot.id} className="py-2.5 px-2 border-r border-slate-200 align-top">
                            {cellSessions.length > 0 ? (
                              <div className="space-y-1.5 h-full flex flex-col justify-center">
                                {cellSessions.map((session) => (
                                  <div
                                    key={session.id}
                                    className="p-2 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-950 text-right shadow-xs"
                                  >
                                    <div className="font-black text-emerald-950 flex items-center justify-between">
                                      <span>{session.subject}</span>
                                      <span className="text-[10px] bg-emerald-200 text-emerald-900 px-1.5 py-0.2 rounded font-black">
                                        {session.classroom}
                                      </span>
                                    </div>
                                    <div className="text-[10px] text-emerald-800 mt-1">
                                      أ. {session.teacherName}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <span className="text-slate-300 text-[10px] italic">-</span>
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Advanced Institutional Timetable Excel Import Modal */}
      {isAdvancedImportModalOpen && (
        <TimetableExcelImportModal
          isOpen={isAdvancedImportModalOpen}
          onClose={() => setIsAdvancedImportModalOpen(false)}
          existingSessions={activeSessions}
          settings={settings}
          teachers={TEACHERS}
          onCommitImport={async (importedSessions, meta, updateSettings) => {
            if (onImportTimetable) {
              await onImportTimetable(importedSessions, meta, updateSettings);
            } else if (onUpdateTimetableSessions) {
              onUpdateTimetableSessions(importedSessions);
            }
            setIsAdvancedImportModalOpen(false);
          }}
        />
      )}
    </div>
  );
};
