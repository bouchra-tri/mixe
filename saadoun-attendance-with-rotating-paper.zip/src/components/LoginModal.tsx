import React, { useState, useEffect } from 'react';
import { AppUser } from '../types';
import { apiLogin, apiSetupAdmin, apiGetAuthStatus } from '../services/api';
import { TEACHERS } from '../data/timetableData';
import {
  ShieldCheck,
  User,
  KeyRound,
  LogIn,
  CheckCircle2,
  AlertTriangle,
  School,
  Lock,
  ArrowRight,
  Sparkles,
  ChevronDown,
  ShieldAlert,
  Phone,
  Mail,
  HelpCircle,
  Eye,
  EyeOff,
  Crown,
  BookOpen,
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface LoginModalProps {
  isOpen: boolean;
  onClose?: () => void;
  onLoginSuccess: (user: AppUser, token: string) => void;
  currentUser: AppUser | null;
  initialMode?: 'login' | 'setup' | 'admin_login';
  schoolPrincipalName?: string;
}

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
  currentUser,
  initialMode = 'admin_login',
  schoolPrincipalName,
}) => {
  const { palette } = useTheme();
  const [activeTab, setActiveTab] = useState<'admin_login' | 'teacher_login' | 'setup'>(
    initialMode === 'setup' ? 'setup' : 'admin_login'
  );

  // Admin Login States
  const [adminUsername, setAdminUsername] = useState<string>('leila.bentrouch');
  const [adminPassword, setAdminPassword] = useState<string>('');
  const [showAdminPassword, setShowAdminPassword] = useState<boolean>(false);

  // Teacher Login States
  const [teacherUsername, setTeacherUsername] = useState<string>('');
  const [teacherPassword, setTeacherPassword] = useState<string>('password123');
  const [showTeacherPassword, setShowTeacherPassword] = useState<boolean>(false);
  const [selectedTeacherUsername, setSelectedTeacherUsername] = useState<string>('');

  // Setup Admin Form States
  const [setupName, setSetupName] = useState<string>(schoolPrincipalName || 'ليلى بن تروش');
  const [setupUsername, setSetupUsername] = useState<string>('leila.bentrouch');
  const [setupPassword, setSetupPassword] = useState<string>('');
  const [setupConfirmPassword, setSetupConfirmPassword] = useState<string>('');
  const [setupPhone, setSetupPhone] = useState<string>('038000000');
  const [setupEmail, setSetupEmail] = useState<string>('');
  const [currentPassword, setCurrentPassword] = useState<string>('');
  const [showSetupPassword, setShowSetupPassword] = useState<boolean>(false);

  // Status and feedback
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [authStatus, setAuthStatus] = useState<{
    adminExists: boolean;
    isCustomAdminConfigured: boolean;
    adminUsername: string;
    adminName: string;
  } | null>(null);

  // Load auth configuration status when modal opens
  useEffect(() => {
    if (isOpen) {
      apiGetAuthStatus()
        .then((status) => {
          setAuthStatus(status);
          if (status.adminUsername) {
            setAdminUsername(status.adminUsername);
            setSetupUsername(status.adminUsername);
          }
          if (status.adminName) {
            setSetupName(status.adminName);
          }
          if (!status.isCustomAdminConfigured && initialMode === 'setup') {
            setActiveTab('setup');
          }
        })
        .catch(() => {});
    }
  }, [isOpen, initialMode]);

  if (!isOpen) return null;

  // Handle Login Submission
  const handleLoginSubmit = async (usernameInput: string, passwordInput: string) => {
    if (!usernameInput.trim() || !passwordInput) {
      setError('يرجى إدخال اسم المستخدم وكلمة المرور');
      return;
    }

    setIsLoading(true);
    setError(null);
    setSuccessMessage(null);

    try {
      const res = await apiLogin(usernameInput.trim(), passwordInput);
      setSuccessMessage(res.message || 'تم تسجيل الدخول بنجاح');
      setTimeout(() => {
        onLoginSuccess(res.user, res.token);
        onClose?.();
      }, 400);
    } catch (err: any) {
      setError(err.message || 'فشل تسجيل الدخول: تأكد من صحة البيانات');
    } finally {
      setIsLoading(false);
    }
  };

  // Handle Initial Admin Setup / Update
  const handleSetupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage(null);

    if (!setupName.trim()) {
      setError('يرجى إدخال اسم المدير الكامل');
      return;
    }
    if (!setupUsername.trim()) {
      setError('يرجى تحديد اسم المستخدم للمدير');
      return;
    }
    if (setupUsername.trim().length < 3) {
      setError('اسم المستخدم يجب أن يتكون من 3 أحرف على الأقل');
      return;
    }
    if (!setupPassword) {
      setError('يرجى إدخال كلمة المرور الخاصة بحساب المدير');
      return;
    }
    if (setupPassword.length < 6) {
      setError('كلمة المرور يجب ألا تقل عن 6 أحرف أو أرقام');
      return;
    }
    if (setupPassword !== setupConfirmPassword) {
      setError('كلمتا المرور غير متطابقتين، يرجى إعادة التأكد');
      return;
    }

    setIsLoading(true);

    try {
      const res = await apiSetupAdmin({
        name: setupName.trim(),
        username: setupUsername.trim().toLowerCase(),
        password: setupPassword,
        phone: setupPhone.trim() || undefined,
        email: setupEmail.trim() || undefined,
        currentPassword: currentPassword || undefined,
      });

      setSuccessMessage('تم ضبط وتفعيل حساب المدير بنجاح!');
      setTimeout(() => {
        onLoginSuccess(res.user, res.token);
        onClose?.();
      }, 700);
    } catch (err: any) {
      setError(err.message || 'فشل إعداد حساب المدير');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectOfficialTeacher = (u: string) => {
    setSelectedTeacherUsername(u);
    if (u) {
      setTeacherUsername(u);
      handleLoginSubmit(u, 'password123');
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-fade-in"
      dir="rtl"
    >
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-5 sm:p-6 shadow-2xl border border-slate-200 dark:border-slate-800 text-right animate-scale-up relative max-h-[92vh] overflow-y-auto text-slate-900 dark:text-slate-100 transition-colors">
        {onClose && (
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 left-4 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1 rounded-full cursor-pointer transition-colors"
            title="إغلاق"
          >
            ✕
          </button>
        )}

        {/* Institution Brand */}
        <div className="text-center mb-4">
          <div
            className="w-12 h-12 rounded-2xl flex items-center justify-center mx-auto mb-2 shadow-sm transition-all"
            style={{
              backgroundColor: palette.primary,
              color: palette.foreground,
            }}
          >
            <Crown className="w-6 h-6 text-current" />
          </div>
          <h2 className="font-extrabold text-base sm:text-lg text-slate-900 dark:text-slate-100 leading-tight">
            بوابة الإدارة المركزية ودخول المنصة
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            متوسطة سعدون عاشور —  البوني - عنابة
          </p>
        </div>

        {/* Navigation Tabs */}
        <div className="grid grid-cols-3 gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl mb-4 text-xs font-bold">
          <button
            type="button"
            onClick={() => {
              setActiveTab('admin_login');
              setError(null);
            }}
            className={`py-2 rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1 ${
              activeTab === 'admin_login'
                ? 'shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
            style={
              activeTab === 'admin_login'
                ? {
                    backgroundColor: palette.primary,
                    color: palette.foreground,
                  }
                : undefined
            }
          >
            <Crown className="w-3.5 h-3.5 text-current" />
            <span>بوابة المدير</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab('teacher_login');
              setError(null);
            }}
            className={`py-2 rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1 ${
              activeTab === 'teacher_login'
                ? 'shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
            style={
              activeTab === 'teacher_login'
                ? {
                    backgroundColor: palette.primary,
                    color: palette.foreground,
                  }
                : undefined
            }
          >
            <User className="w-3.5 h-3.5 text-current" />
            <span>دخول الأساتذة</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab('setup');
              setError(null);
            }}
            className={`py-2 rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1 ${
              activeTab === 'setup'
                ? 'shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
            style={
              activeTab === 'setup'
                ? {
                    backgroundColor: palette.primary,
                    color: palette.foreground,
                  }
                : undefined
            }
          >
            <ShieldCheck className="w-3.5 h-3.5 text-current" />
            <span>تهيئة المدير</span>
            {!authStatus?.isCustomAdminConfigured && (
              <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping" />
            )}
          </button>
        </div>

        {/* Feedback Messages */}
        {error && (
          <div className="mb-4 p-3 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-xs font-bold flex items-center gap-2 animate-fade-in">
            <AlertTriangle className="w-4 h-4 text-slate-600 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {successMessage && (
          <div className="mb-4 p-3 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-xs font-bold flex items-center gap-2 animate-fade-in">
            <CheckCircle2 className="w-4 h-4 text-slate-600 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 1: PRINCIPAL / ADMIN LOGIN PORTAL (واجهة دخول المدير) */}
        {/* ========================================================= */}
        {activeTab === 'admin_login' && (
          <div className="space-y-4">
            <div className="bg-gradient-to-br from-slate-950 to-slate-900 text-white rounded-2xl p-4 shadow-sm space-y-2">
              <div className="flex items-center gap-2 text-slate-200 text-xs font-bold">
                <Crown className="w-4 h-4 text-amber-400" />
                <span>واجهة مدير المؤسسة — الصلاحيات الإدارية الكاملة</span>
              </div>
              <p className="text-[11px] text-slate-100 leading-relaxed">
                مخصص لمدير(ة) المؤسسة لمتابعة لوحة التحكم العامة، إدارة قوائم التلاميذ، اعتماد تسجيلات الأساتذة، إصدار التقارير الشهرية لوزارة التربية، وتدقيق سجلات الحضور.
              </p>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleLoginSubmit(adminUsername, adminPassword);
              }}
              className="space-y-3"
            >
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  اسم المستخدم الإداري
                </label>
                <div className="relative">
                  <User className="w-4 h-4 absolute right-3 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    required
                    value={adminUsername}
                    onChange={(e) => setAdminUsername(e.target.value)}
                    placeholder="admin"
                    className="w-full text-xs font-bold bg-slate-50 border border-slate-300 rounded-xl pr-9 pl-3 py-2 text-slate-900 focus:outline-slate-600 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  كلمة المرور الخاصة بالمدير
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 absolute right-3 top-2.5 text-slate-400" />
                  <input
                    type={showAdminPassword ? 'text' : 'password'}
                    required
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full text-xs font-bold bg-slate-50 border border-slate-300 rounded-xl pr-9 pl-9 py-2 text-slate-900 focus:outline-slate-600 font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setShowAdminPassword(!showAdminPassword)}
                    className="absolute left-2.5 top-2.5 text-slate-400 hover:text-slate-600 p-0.5 cursor-pointer"
                  >
                    {showAdminPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 rounded-xl text-xs sm:text-sm font-black active:scale-95 transition-all cursor-pointer shadow-md flex items-center justify-center gap-2 mt-2 disabled:opacity-50"
                style={{
                  backgroundColor: palette.primary,
                  color: palette.foreground,
                }}
              >
                {isLoading ? (
                  <span>جاري تسجيل دخول المدير...</span>
                ) : (
                  <>
                    <Crown className="w-4 h-4 text-amber-300" />
                    <span>دخول لوحة تحكم المدير</span>
                  </>
                )}
              </button>
            </form>

            {!authStatus?.isCustomAdminConfigured && (
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-slate-500">للتجربة السريعة المبدئية:</span>
                <button
                  type="button"
                  onClick={() => handleLoginSubmit('admin', 'password123')}
                  className="px-3 py-1.5 bg-slate-50 text-slate-900 font-bold rounded-lg border border-slate-200 hover:bg-slate-100 cursor-pointer"
                >
                  دخول سريع (admin / password123)
                </button>
              </div>
            )}
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 2: TEACHER LOGIN PORTAL (دخول الأساتذة) */}
        {/* ========================================================= */}
        {activeTab === 'teacher_login' && (
          <div className="space-y-4">
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3 text-xs">
              <span className="font-bold text-slate-900 block mb-0.5">بوابة تسجيل دخول الأساتذة</span>
              <p className="text-slate-500 text-[11px]">
                يختار كل أستاذ حسابه من القائمة أدناه أو يسجل الدخول بحسابه الشخصي لتسجيل حضور وغياب أقسامه المخصصة حصرياً.
              </p>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleLoginSubmit(teacherUsername, teacherPassword);
              }}
              className="space-y-3"
            >
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  اختر الأستاذ من القائمة الرسمية (35 أستاذاً)
                </label>
                <div className="relative mb-2">
                  <select
                    value={teacherUsername}
                    onChange={(e) => {
                      const u = e.target.value;
                      setTeacherUsername(u);
                      setSelectedTeacherUsername(u);
                    }}
                    className="w-full bg-slate-50 hover:bg-slate-100 border border-slate-300 text-slate-800 text-xs font-bold rounded-xl px-3 py-2 pr-3 pl-8 appearance-none cursor-pointer transition-colors"
                  >
                    <option value="">-- اختر اسم الأستاذ --</option>
                    {TEACHERS.map((t) => (
                      <option key={t.id} value={t.username}>
                        {t.name} ({t.subject} - {t.assignedClasses.join('، ')})
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="w-4 h-4 text-slate-500 absolute left-2.5 top-2.5 pointer-events-none" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  كلمة المرور الشخصية للأستاذ
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 absolute right-3 top-2.5 text-slate-400" />
                  <input
                    type={showTeacherPassword ? 'text' : 'password'}
                    required
                    value={teacherPassword}
                    onChange={(e) => setTeacherPassword(e.target.value)}
                    placeholder="password123"
                    className="w-full text-xs font-bold bg-slate-50 border border-slate-300 rounded-xl pr-9 pl-9 py-2 text-slate-900 focus:outline-slate-600 font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setShowTeacherPassword(!showTeacherPassword)}
                    className="absolute left-2.5 top-2.5 text-slate-400 hover:text-slate-600 p-0.5 cursor-pointer"
                  >
                    {showTeacherPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading || !teacherUsername}
                className="w-full py-2.5 rounded-xl text-xs sm:text-sm font-bold active:scale-95 transition-all cursor-pointer shadow-md flex items-center justify-center gap-2 mt-2 disabled:opacity-50"
                style={{
                  backgroundColor: palette.primary,
                  color: palette.foreground,
                }}
              >
                {isLoading ? (
                  <span>جاري تسجيل دخول الأستاذ...</span>
                ) : (
                  <>
                    <LogIn className="w-4 h-4" />
                    <span>دخول منصة الأستاذ</span>
                  </>
                )}
              </button>
            </form>
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 3: FIRST-TIME ADMIN SETUP (تهيئة حساب المدير الأول) */}
        {/* ========================================================= */}
        {activeTab === 'setup' && (
          <div>
            <div className="bg-slate-50/70 border border-slate-200 p-3 rounded-2xl mb-3 text-xs">
              <div className="flex items-center gap-2 text-slate-950 font-bold mb-1">
                <ShieldCheck className="w-4 h-4 text-slate-800" />
                <span>إعداد حساب مدير المؤسسة الأول</span>
              </div>
              <p className="text-[11px] text-slate-800 leading-relaxed">
                عيّن اسم المستخدم وكلمة المرور الخاصة بك كمدير لمؤسسة سعدون عاشور. بمجرد الحفظ يتم توليد جلسة مشفرة
                وتمنحك المنصة كافة الصلاحيات الإدارية وتوثيق إدارة الأساتذة تلقائياً دون مشاركة كلمة المرور.
              </p>
            </div>

            <form onSubmit={handleSetupSubmit} className="space-y-2.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  اسم مدير(ة) المؤسسة الكامل
                </label>
                <div className="relative">
                  <User className="w-4 h-4 absolute right-3 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    required
                    value={setupName}
                    onChange={(e) => setSetupName(e.target.value)}
                    placeholder="مثلاً: بويمة ليلى بن تروش"
                    className="w-full text-xs font-bold bg-slate-50 border border-slate-300 rounded-xl pr-9 pl-3 py-2 text-slate-900 focus:outline-slate-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  اسم المستخدم الخاص بالمدير
                </label>
                <div className="relative">
                  <span className="absolute right-3 top-2.5 text-xs text-slate-400 font-mono">@</span>
                  <input
                    type="text"
                    required
                    value={setupUsername}
                    onChange={(e) => setSetupUsername(e.target.value)}
                    placeholder="admin"
                    className="w-full text-xs font-bold bg-slate-50 border border-slate-300 rounded-xl pr-9 pl-3 py-2 text-slate-900 focus:outline-slate-600 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  كلمة المرور الجديدة (6 أحرف على الأقل)
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 absolute right-3 top-2.5 text-slate-400" />
                  <input
                    type={showSetupPassword ? 'text' : 'password'}
                    required
                    value={setupPassword}
                    onChange={(e) => setSetupPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full text-xs font-bold bg-slate-50 border border-slate-300 rounded-xl pr-9 pl-9 py-2 text-slate-900 focus:outline-slate-600 font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setShowSetupPassword(!showSetupPassword)}
                    className="absolute left-2.5 top-2.5 text-slate-400 hover:text-slate-600 p-0.5 cursor-pointer"
                  >
                    {showSetupPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  تأكيد كلمة المرور
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 absolute right-3 top-2.5 text-slate-400" />
                  <input
                    type={showSetupPassword ? 'text' : 'password'}
                    required
                    value={setupConfirmPassword}
                    onChange={(e) => setSetupConfirmPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full text-xs font-bold bg-slate-50 border border-slate-300 rounded-xl pr-9 pl-3 py-2 text-slate-900 focus:outline-slate-600 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">الهاتف المهني</label>
                  <input
                    type="text"
                    value={setupPhone}
                    onChange={(e) => setSetupPhone(e.target.value)}
                    className="w-full text-xs bg-slate-50 border border-slate-300 rounded-xl px-3 py-1.5 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">البريد الإلكتروني</label>
                  <input
                    type="email"
                    value={setupEmail}
                    onChange={(e) => setSetupEmail(e.target.value)}
                    placeholder="principal@cem.dz"
                    className="w-full text-xs bg-slate-50 border border-slate-300 rounded-xl px-3 py-1.5 font-mono"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-2.5 rounded-xl text-xs sm:text-sm font-bold active:scale-95 transition-all cursor-pointer shadow-md flex items-center justify-center gap-2 mt-3 disabled:opacity-50"
                style={{
                  backgroundColor: palette.primary,
                  color: palette.foreground,
                }}
              >
                {isLoading ? (
                  <span>جاري الحفظ والتثبيت...</span>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    <span>حفظ وتفعيل حساب المدير</span>
                  </>
                )}
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
