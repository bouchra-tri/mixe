import React from 'react';
import { Student, SchoolSettings } from '../types';
import { StudentBadge } from './StudentBadge';
import { X, Printer, Scan, Check, Edit } from 'lucide-react';

interface StudentCardModalProps {
  student: Student;
  settings: SchoolSettings;
  onClose: () => void;
  onScanThisStudent: (barcode: string) => void;
  onEditStudent?: (student: Student) => void;
}

export const StudentCardModal: React.FC<StudentCardModalProps> = ({
  student,
  settings,
  onClose,
  onScanThisStudent,
  onEditStudent,
}) => {
  const handlePrint = () => {
    document.body.classList.add('printing-single-card');
    const originalTitle = document.title;
    document.title = `بطاقة_التلميذ_${student.lastName}_${student.firstName}_${student.classroom}`;

    const cleanup = () => {
      document.body.classList.remove('printing-single-card');
      document.title = originalTitle;
      window.removeEventListener('afterprint', cleanup);
    };

    window.addEventListener('afterprint', cleanup);
    window.print();
    setTimeout(cleanup, 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 overflow-y-auto single-card-modal-container">
      <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6 space-y-4 border border-slate-200 single-card-modal-content">
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 no-print">
          <div>
            <h3 className="font-bold text-slate-800 text-sm">
              بطاقة التلميذ المدرسية بالباركود
            </h3>
            <p className="text-[11px] text-slate-500">
              متوسطة سعدون عاشور · {settings.academicYear}
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-lg cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Badge Card Display */}
        <div className="py-2 flex justify-center">
          <StudentBadge
            student={student}
            settings={settings}
          />
        </div>

        {/* Modal Action Controls */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2 pt-2 border-t border-slate-100 no-print">
          <button
            onClick={() => {
              onScanThisStudent(student.barcode);
              onClose();
            }}
            className="w-full sm:w-auto flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-800 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors cursor-pointer"
          >
            <Scan className="w-3.5 h-3.5" />
            مسح وتسجيل دخول التلميذ فوراً
          </button>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            {onEditStudent && (
              <button
                onClick={() => {
                  onEditStudent(student);
                  onClose();
                }}
                className="flex items-center gap-1 px-3 py-2 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition-colors cursor-pointer"
              >
                <Edit className="w-3.5 h-3.5" />
                تعديل البيانات
              </button>
            )}
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              طباعة البطاقة
            </button>
            <button
              onClick={onClose}
              className="px-3 py-2 text-xs text-slate-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
            >
              إغلاق
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
