import React, { useState } from 'react';
import { Student, AttendanceRecord, SchoolSettings, AbsenceNotice } from '../types';
import {
  Database,
  Save,
  Download,
  Upload,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Server,
  HardDrive,
  FileSpreadsheet,
  Clock,
  ShieldCheck,
  X,
  RefreshCw,
  FolderArchive
} from 'lucide-react';
import { apiSaveDatabaseNow } from '../services/api';
import * as XLSX from 'xlsx';

interface DataPersistenceModalProps {
  students: Student[];
  records: AttendanceRecord[];
  settings: SchoolSettings;
  notices: AbsenceNotice[];
  lastSavedTime: string;
  onClose: () => void;
  onManualSaveSuccess?: (savedTime: string) => void;
  onImportFullData: (backup: {
    students: Student[];
    records: AttendanceRecord[];
    settings?: SchoolSettings;
    notices?: AbsenceNotice[];
  }) => void;
  onResetDefaults: () => void;
}

export const DataPersistenceModal: React.FC<DataPersistenceModalProps> = ({
  students,
  records,
  settings,
  notices,
  lastSavedTime,
  onClose,
  onManualSaveSuccess,
  onImportFullData,
  onResetDefaults,
}) => {
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccessMessage, setSaveSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Manual Instant Save to Server Disk & Storage
  const handleSaveNow = async () => {
    setIsSaving(true);
    setErrorMessage(null);
    try {
      // 1. Save to localStorage immediately as client-side fallback
      localStorage.setItem('saadoun_achour_students_v1', JSON.stringify(students));
      localStorage.setItem('saadoun_achour_records_v1', JSON.stringify(records));
      localStorage.setItem('saadoun_achour_settings_v1', JSON.stringify(settings));
      localStorage.setItem('saadoun_achour_notices_v1', JSON.stringify(notices));

      // 2. Call server disk flush endpoint
      const res = await apiSaveDatabaseNow();
      const timeStr = new Date(res.lastUpdated).toLocaleTimeString('ar-DZ', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });

      onManualSaveSuccess?.(res.lastUpdated);
      setSaveSuccessMessage(`تم حفظ كافة البيانات (${students.length} تلميذ، ${records.length} سجل حضور، ${notices.length} إشعار) على القرص بنجاح في تمام الساعة ${timeStr}`);
      setTimeout(() => setSaveSuccessMessage(null), 5000);
    } catch (err: any) {
      setErrorMessage('تعذر الاتصال بالخادم، تم الحفظ محلياً في المتصفح');
    } finally {
      setIsSaving(false);
    }
  };

  // Full JSON Backup Export
  const handleExportJsonBackup = () => {
    const backupData = {
      version: 2,
      exportDate: new Date().toISOString(),
      schoolName: settings.schoolName,
      settings,
      students,
      records,
      notices,
      stats: {
        totalStudents: students.length,
        totalRecords: records.length,
        totalNotices: notices.length,
      },
    };

    const blob = new Blob([JSON.stringify(backupData, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const dateStr = new Date().toISOString().split('T')[0];
    link.download = `قاعدة_بيانات_${(settings.schoolName || 'متوسطة_سعدون_عاشور').replace(/\s+/g, '_')}_${dateStr}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Import JSON Backup File
  const handleImportJsonFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed && Array.isArray(parsed.students)) {
          onImportFullData({
            students: parsed.students,
            records: Array.isArray(parsed.records) ? parsed.records : [],
            settings: parsed.settings,
            notices: Array.isArray(parsed.notices) ? parsed.notices : [],
          });
          setSaveSuccessMessage(`تم استرجاع قاعدة البيانات بنجاح: ${parsed.students.length} تلميذ`);
          setTimeout(() => setSaveSuccessMessage(null), 4000);
        } else {
          setErrorMessage('الملف غير متطابق مع بنية قاعدة بيانات المؤسسة');
        }
      } catch (err) {
        setErrorMessage('خطأ أثناء قراءة ملف النسخة الاحتياطية');
      }
    };
    reader.readAsText(file);
  };

  // Export Complete Multi-Sheet Excel Backup
  const handleExportExcelMaster = () => {
    const workbook = XLSX.utils.book_new();

    // Sheet 1: Students
    const studentRows = [
      ['رقم التسجيل', 'اللقب والاسم', 'القسم', 'المستوى', 'الجنس', 'تاريخ الميلاد', 'الباركود', 'الولي', 'الهاتف'],
      ...students.map((s) => [
        s.id,
        `${s.lastName} ${s.firstName}`,
        s.classroom,
        s.grade,
        s.gender === 'M' ? 'ذكر' : 'أنثى',
        s.birthDate || '',
        s.barcode,
        s.guardianName,
        s.guardianPhone,
      ]),
    ];
    const studentSheet = XLSX.utils.aoa_to_sheet(studentRows);
    studentSheet['!views'] = [{ RTL: true }];
    XLSX.utils.book_append_sheet(workbook, studentSheet, 'التلاميذ');

    // Sheet 2: Attendance Records
    const recordRows = [
      ['المعرف', 'اسم التلميذ', 'القسم', 'المستوى', 'التاريخ', 'الوقت', 'الحالة', 'دقائق التأخر', 'الوسيلة'],
      ...records.map((r) => [
        r.id,
        r.studentName,
        r.classroom,
        r.grade,
        r.date,
        r.timestamp,
        r.status === 'present' ? 'حاضر' : r.status === 'late' ? 'متأخر' : r.status === 'excused' ? 'مبرر' : 'غائب',
        r.lateMinutes || 0,
        r.device,
      ]),
    ];
    const recordSheet = XLSX.utils.aoa_to_sheet(recordRows);
    recordSheet['!views'] = [{ RTL: true }];
    XLSX.utils.book_append_sheet(workbook, recordSheet, 'سجلات الحضور');

    // Sheet 3: Notices
    const noticeRows = [
      ['رقم المرجع', 'المرحلة', 'اسم التلميذ', 'القسم', 'الولي', 'الهاتف', 'أيام الغياب', 'التاريخ', 'الحالة'],
      ...notices.map((n) => [
        n.referenceNumber,
        n.stage === 'notice_1' ? 'إشعار 1 (اليوم 4)' : n.stage === 'notice_2' ? 'إشعار 2 (+10 أيام)' : 'إعذار رسمي (+15 يوم)',
        n.studentName,
        n.classroom,
        n.guardianName,
        n.guardianPhone,
        n.absenceDaysCount,
        n.dueDate,
        n.status,
      ]),
    ];
    const noticeSheet = XLSX.utils.aoa_to_sheet(noticeRows);
    noticeSheet['!views'] = [{ RTL: true }];
    XLSX.utils.book_append_sheet(workbook, noticeSheet, 'الإشعارات والإعذارات');

    const fileName = `النسخة_الشاملة_Excel_${new Date().toISOString().split('T')[0]}.xlsx`;
    XLSX.writeFile(workbook, fileName);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl space-y-6 relative border border-slate-200 animate-scale-up">
        {/* Header */}
        <div className="flex items-center justify-between border-b pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-slate-700 text-white flex items-center justify-center shadow-xs">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">
                مركز حفظ وإدارة قاعدة البيانات
              </h3>
              <p className="text-xs text-slate-500">
                حفظ دائم متزامن بين الخادم المركزي والذاكرة المحلية مع النسخ الاحتياطي
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Feedback alerts */}
        {saveSuccessMessage && (
          <div className="p-3.5 bg-slate-50 text-slate-900 border border-slate-200 rounded-xl text-xs font-bold flex items-center gap-2 animate-fade-in shadow-2xs">
            <CheckCircle2 className="w-5 h-5 text-slate-600 shrink-0" />
            <span>{saveSuccessMessage}</span>
          </div>
        )}

        {errorMessage && (
          <div className="p-3.5 bg-slate-50 text-slate-900 border border-slate-200 rounded-xl text-xs font-bold flex items-center gap-2 animate-fade-in shadow-2xs">
            <AlertTriangle className="w-5 h-5 text-slate-600 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Real-time Storage Health Box */}
        <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-3">
          <div className="flex items-center justify-between text-xs font-bold text-slate-800">
            <div className="flex items-center gap-2">
              <HardDrive className="w-4 h-4 text-slate-700" />
              <span>حالة التخزين والحفظ الدائم:</span>
            </div>
            <span className="flex items-center gap-1.5 text-slate-700 bg-slate-100/70 px-2.5 py-0.5 rounded-full text-[11px]">
              <span className="w-2 h-2 rounded-full bg-slate-500 animate-pulse" />
              محفوظ ومؤمّن
            </span>
          </div>

          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="bg-white p-3 rounded-xl border border-slate-200">
              <p className="text-xs text-slate-500 font-semibold">التلاميذ المسجلين</p>
              <p className="text-lg font-black text-slate-900 mt-1 font-mono-numbers">
                {students.length}
              </p>
            </div>
            <div className="bg-white p-3 rounded-xl border border-slate-200">
              <p className="text-xs text-slate-500 font-semibold">سجلات الحضور</p>
              <p className="text-lg font-black text-slate-900 mt-1 font-mono-numbers">
                {records.length}
              </p>
            </div>
            <div className="bg-white p-3 rounded-xl border border-slate-200">
              <p className="text-xs text-slate-500 font-semibold">الإشعارات والإعذارات</p>
              <p className="text-lg font-black text-slate-900 mt-1 font-mono-numbers">
                {notices.length}
              </p>
            </div>
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-200">
            <span className="flex items-center gap-1 font-mono-numbers">
              <Clock className="w-3.5 h-3.5 text-slate-400" />
              <span>آخر حفظ مسجل: {lastSavedTime ? new Date(lastSavedTime).toLocaleString('ar-DZ') : 'الآن'}</span>
            </span>
            <span className="text-slate-800 font-semibold">تزامن تلقائي مستمر</span>
          </div>
        </div>

        {/* Action 1: Instant Save Button */}
        <div className="bg-slate-50/60 p-4 rounded-2xl border border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div className="space-y-0.5">
            <h4 className="font-bold text-xs text-slate-950">حفظ البيانات الفوري</h4>
            <p className="text-[11px] text-slate-800">
              يقوم بكتابة وتثبيت كافة السجلات والتعديلات فوراً على قرص الخادم والذاكرة الدائمة
            </p>
          </div>
          <button
            type="button"
            onClick={handleSaveNow}
            disabled={isSaving}
            className="flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-white bg-slate-700 hover:bg-slate-800 active:scale-95 disabled:opacity-50 rounded-xl transition-all cursor-pointer shadow-sm hover:shadow"
          >
            <Save className={`w-4 h-4 ${isSaving ? 'animate-spin' : ''}`} />
            <span>{isSaving ? 'جاري الحفظ...' : 'حفظ البيانات الآن'}</span>
          </button>
        </div>

        {/* Action 2: Backup & Restore Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          {/* JSON Export */}
          <div className="p-4 rounded-2xl border border-slate-200 hover:border-slate-300 transition-colors space-y-2">
            <div className="flex items-center gap-2 font-bold text-slate-900">
              <Download className="w-4 h-4 text-blue-600" />
              <span>تصدير نسخة احتياطية (JSON)</span>
            </div>
            <p className="text-[11px] text-slate-500">
              تنزيل ملف النسخة الاحتياطية الشاملة لحفظه على حاسوبك الشخصي أو ذاكرة USB.
            </p>
            <button
              type="button"
              onClick={handleExportJsonBackup}
              className="w-full mt-2 py-2 px-3 text-center font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-xl transition-colors cursor-pointer"
            >
              تحميل ملف النسخة الاحتياطية
            </button>
          </div>

          {/* JSON Import */}
          <div className="p-4 rounded-2xl border border-slate-200 hover:border-slate-300 transition-colors space-y-2">
            <div className="flex items-center gap-2 font-bold text-slate-900">
              <Upload className="w-4 h-4 text-purple-600" />
              <span>استرجاع نسخة احتياطية (JSON)</span>
            </div>
            <p className="text-[11px] text-slate-500">
              رفع ملف نسخة احتياطية سابقة لاستعادة التلاميذ وسجلات الحضور والإعدادات.
            </p>
            <label className="block w-full mt-2 py-2 px-3 text-center font-bold text-purple-700 bg-purple-50 hover:bg-purple-100 rounded-xl transition-colors cursor-pointer">
              <span>اختيار ملف لاسترجاعه</span>
              <input
                type="file"
                accept=".json"
                onChange={handleImportJsonFile}
                className="hidden"
              />
            </label>
          </div>
        </div>

        {/* Action 3: Master Excel Backup Export */}
        <div className="p-4 rounded-2xl border border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-slate-100 text-slate-800 flex items-center justify-center shrink-0">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-slate-900">تصدير قاعدة البيانات الشاملة إلى Excel</h4>
              <p className="text-[11px] text-slate-500">
                ملف Excel متكامل يضم كافة أوراق العمل (التلاميذ، الحضور، الإشعارات، الإحصائيات)
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={handleExportExcelMaster}
            className="px-4 py-2 text-xs font-bold text-slate-900 bg-slate-50 hover:bg-slate-100 border border-slate-300 rounded-xl transition-all cursor-pointer shadow-2xs"
          >
            تصدير المصنف الشامل
          </button>
        </div>

        {/* Footer: Reset option */}
        <div className="pt-2 border-t flex items-center justify-between text-xs">
          <button
            type="button"
            onClick={() => {
              if (confirm('هل تريد فعلاً استعادة البيانات النموذجية الافتراضية؟ سيتم تحديث السجلات والتلاميذ إلى الحالة الأولية.')) {
                onResetDefaults();
                onClose();
              }
            }}
            className="flex items-center gap-1.5 text-slate-600 hover:text-slate-800 text-[11px] font-bold cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>استعادة البيانات النموذجية الافتراضية</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl cursor-pointer"
          >
            إغلاق النافذة
          </button>
        </div>
      </div>
    </div>
  );
};
