import React from 'react';
import { Student, SchoolSettings } from '../types';
import { BarcodeCard } from './BarcodeCard';
import { Printer, GraduationCap, School } from 'lucide-react';

interface StudentBadgeProps {
  student: Student;
  settings: SchoolSettings;
  size?: 'standard' | 'compact' | 'mini';
  onPrint?: () => void;
  showPrintAction?: boolean;
  isSelected?: boolean;
  onToggleSelect?: () => void;
  className?: string;
}

export const StudentBadge: React.FC<StudentBadgeProps> = ({
  student,
  settings,
  size = 'standard',
  onPrint,
  showPrintAction = false,
  isSelected = false,
  onToggleSelect,
  className = '',
}) => {
  const isFemale = student.gender === 'F';
  const isCompact = size === 'compact';
  const isMini = size === 'mini';

  return (
    <div
      style={{
        pageBreakInside: 'avoid',
        breakInside: 'avoid',
      }}
      className={`printable-student-badge relative group bg-white border rounded-xl shadow-xs overflow-hidden max-w-sm w-full mx-auto print:max-w-none print:w-full print:m-0 print:shadow-none print:border-slate-400 print:rounded-none transition-all ${
        isSelected
          ? 'ring-2 ring-slate-500 border-slate-300 bg-slate-50/10'
          : 'border-slate-300 hover:border-slate-400'
      } ${className}`}
    >
      {/* Official Header Algerian Colors stripe */}
      <div
        className="h-2 bg-gradient-to-r from-slate-600 via-white to-red-600 flex w-full"
        style={{ WebkitPrintColorAdjust: 'exact', printColorAdjust: 'exact' }}
      />

      {/* Select Checkbox (no-print) */}
      {onToggleSelect && (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onToggleSelect();
          }}
          className={`no-print absolute top-3 right-3 z-10 w-6 h-6 rounded-md flex items-center justify-center transition-all cursor-pointer shadow-xs ${
            isSelected
              ? 'bg-slate-600 text-white ring-2 ring-slate-300'
              : 'bg-white/90 text-slate-400 hover:text-slate-700 border border-slate-300'
          }`}
          title={isSelected ? 'إلغاء التحديد' : 'تحديد للحذف بالجملة'}
        >
          <input
            type="checkbox"
            checked={isSelected}
            onChange={() => {}}
            className="w-3.5 h-3.5 accent-slate-600 pointer-events-none"
          />
        </button>
      )}

      {/* Header Institution */}
      <div className={`text-center border-b border-slate-100 bg-slate-50/50 ${isMini ? 'px-2 py-1' : isCompact ? 'px-3 py-1.5' : 'px-4 pt-2.5 pb-2'}`}>
        <p className="text-[9px] text-slate-500 font-medium leading-tight">
          الجمهورية الجزائرية الديمقراطية الشعبية
        </p>
        <p className="text-[9px] text-slate-600 font-medium leading-tight">
          وزارة التربية الوطنية · مديرية التربية لولاية {settings.wilaya}
        </p>
        <div className="mt-0.5 flex items-center justify-center gap-1.5">
          <School className={`${isMini ? 'w-3 h-3' : 'w-3.5 h-3.5'} text-slate-700`} />
          <h4 className={`${isMini ? 'text-[10px]' : 'text-xs'} font-bold text-slate-800`}>
            {settings.schoolName}
          </h4>
        </div>
        <p className="text-[8px] text-slate-700 font-bold mt-0.5">
          بطاقة التلميذ المدرسية · {settings.academicYear}
        </p>
      </div>

      {/* Body Info & Photo */}
      <div className={`flex items-center ${isMini ? 'p-2 gap-2' : isCompact ? 'p-2.5 gap-2.5' : 'p-3.5 gap-3'}`}>
        {/* Student Avatar / Photo */}
        <div className="shrink-0 flex flex-col items-center">
          <div className={`${isMini ? 'w-14 h-18' : isCompact ? 'w-16 h-20' : 'w-18 h-22'} rounded-lg border border-slate-200 overflow-hidden bg-slate-100 flex flex-col items-center justify-center relative shadow-xs`}>
            {student.photoUrl ? (
              <img
                src={student.photoUrl}
                alt={`${student.firstName} ${student.lastName}`}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className={`w-full h-full flex flex-col items-center justify-center p-1 text-center ${isFemale ? 'bg-slate-50 text-slate-700' : 'bg-sky-50 text-sky-700'}`}>
                <GraduationCap className={`${isMini ? 'w-6 h-6' : 'w-7 h-7'} opacity-70 mb-0.5`} />
                <span className="text-[9px] font-bold">
                  {student.firstName[0]} {student.lastName[0]}
                </span>
                <span className="text-[7px] opacity-75">صورة التلميذ</span>
              </div>
            )}
          </div>
          <span className="text-[8px] font-mono-numbers text-slate-400 mt-0.5">
            {student.id}
          </span>
        </div>

        {/* Details List */}
        <div className="flex-1 space-y-0.5 text-xs">
          <div>
            <span className="text-[9px] text-slate-400 block leading-tight">اللقب والاسم:</span>
            <span className={`font-bold text-slate-900 ${isMini ? 'text-xs' : 'text-sm'}`}>
              {student.lastName} {student.firstName}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-1 text-[10px] pt-0.5">
            <div>
              <span className="text-[9px] text-slate-400 block leading-tight">المستوى:</span>
              <span className="font-semibold text-slate-800">
                {student.grade === '1AM' ? 'الأولى متوسط' :
                 student.grade === '2AM' ? 'الثانية متوسط' :
                 student.grade === '3AM' ? 'الثالثة متوسط' : 'الرابعة متوسط'}
              </span>
            </div>
            <div>
              <span className="text-[9px] text-slate-400 block leading-tight">القسم والفوج:</span>
              <span className="font-bold text-slate-800 bg-slate-100 px-1 py-0.2 rounded text-[10px]">
                {student.classroom}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-1 text-[10px] pt-0.5">
            <div>
              <span className="text-[9px] text-slate-400 block leading-tight">تاريخ الميلاد:</span>
              <span className="font-mono-numbers text-slate-700 text-[9px]">
                {student.birthDate}
              </span>
            </div>
            <div>
              <span className="text-[9px] text-slate-400 block leading-tight">رقم التعريف:</span>
              <span className="font-mono-numbers text-slate-600 text-[9px]">
                {student.nationalId}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Barcode Section */}
      <div className={`bg-slate-50 border-t border-slate-100 flex flex-col items-center justify-center ${isMini ? 'px-2 py-1' : isCompact ? 'px-3 py-1.5' : 'px-4 py-2'}`}>
        <BarcodeCard
          value={student.barcode}
          height={isMini ? 26 : isCompact ? 32 : 38}
          className={isMini ? 'w-40' : 'w-48'}
        />
        <div className="w-full flex justify-between items-center text-[7px] text-slate-400 mt-0.5 px-1">
          <span>ختم وتوقيع مديرة المؤسسة</span>
          <span>صالحة للدخول المدرسي فقط</span>
        </div>
      </div>

      {/* Optional Print Action Button (Non-printable) */}
      {showPrintAction && onPrint && (
        <div className="p-2 border-t border-slate-100 bg-white flex justify-end no-print">
          <button
            onClick={onPrint}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            طباعة البطاقة
          </button>
        </div>
      )}
    </div>
  );
};
