import React, { useState, useMemo } from 'react';
import { Student, AttendanceRecord, SchoolSettings, GradeLevel, PeriodId } from '../types';
import {
  BarChart3,
  Users,
  CheckCircle2,
  Clock,
  UserX,
  Printer,
  Calendar,
  Award,
  TrendingUp,
  FileSpreadsheet,
  Trophy,
  AlertTriangle,
  FileText,
  MessageCircle,
  Sparkles,
  ChevronRight,
  School,
  X,
  Send,
  ShieldAlert,
  Search,
  Check,
  Medal
} from 'lucide-react';
import { exportAnalyticsReportToExcel } from '../utils/excelExport';
import { getSettingsPeriods, getPeriodById, matchRecordPeriod } from '../utils/periodHelper';
import { useTheme } from '../context/ThemeContext';

interface AnalyticsReportsProps {
  students: Student[];
  records: AttendanceRecord[];
  settings: SchoolSettings;
  currentSession: 'morning' | 'afternoon';
  currentPeriodId?: string;
  onChangePeriod?: (periodId: PeriodId) => void;
}

export const AnalyticsReports: React.FC<AnalyticsReportsProps> = ({
  students,
  records,
  settings,
  currentSession,
  currentPeriodId = 'm1',
  onChangePeriod,
}) => {
  const { palette } = useTheme();
  const todayStr = new Date().toISOString().split('T')[0];
  const [selectedPeriodFilter, setSelectedPeriodFilter] = useState<string>(
    currentPeriodId || currentSession
  );
  const [activeTab, setActiveTab] = useState<'overview' | 'chronic' | 'ranking' | 'official-print'>('overview');
  const [searchChronicQuery, setSearchChronicQuery] = useState('');
  
  // Official Parent Summons Modal State
  const [summonsStudent, setSummonsStudent] = useState<{
    student: Student;
    absenceCount: number;
    absenceDates: string[];
    lateCount: number;
  } | null>(null);
  const [summonsDate, setSummonsDate] = useState(() => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  });
  const [summonsTime, setSummonsTime] = useState('09:00');
  const [summonsReason, setSummonsReason] = useState('تكرار الغياب غير المبرر طبقاً للمادة 21 من القرار الوزاري رقم 778');

  // Certificate Modal State
  const [certificateClass, setCertificateClass] = useState<{
    classroom: string;
    grade: GradeLevel;
    rate: number;
    punctualityRate: number;
    total?: number;
    studentCount?: number;
  } | null>(null);


  const periods = getSettingsPeriods(settings);

  // Records for today and selected cohort period/session
  const todaySessionRecords = useMemo(() => {
    return records.filter(
      (r) =>
        r.date === todayStr &&
        matchRecordPeriod(r.session || r.periodId || 'm1', selectedPeriodFilter)
    );
  }, [records, todayStr, selectedPeriodFilter]);

  // Total Students
  const totalStudents = students.length;

  // Grade-wise metrics breakdown
  const gradeBreakdown = useMemo(() => {
    const grades: GradeLevel[] = ['1AM', '2AM', '3AM', '4AM'];
    const gradeNames: Record<GradeLevel, string> = {
      '1AM': 'الأولى متوسط (1AM)',
      '2AM': 'الثانية متوسط (2AM)',
      '3AM': 'الثالثة متوسط (3AM)',
      '4AM': 'الرابعة متوسط (4AM - BEM)',
    };

    return grades.map((g) => {
      const gradeStudents = students.filter((s) => s.grade === g);
      const gradeRecords = todaySessionRecords.filter((r) => r.grade === g);
      const present = gradeRecords.filter((r) => r.status === 'present').length;
      const late = gradeRecords.filter((r) => r.status === 'late').length;
      const totalCheckedIn = gradeRecords.length;
      const absent = gradeStudents.length - totalCheckedIn;
      const rate = gradeStudents.length > 0 ? Math.round((totalCheckedIn / gradeStudents.length) * 100) : 0;

      return {
        grade: g,
        name: gradeNames[g],
        total: gradeStudents.length,
        present,
        late,
        absent,
        rate,
      };
    });
  }, [students, todaySessionRecords]);

  // Overall counts
  const presentCount = todaySessionRecords.filter((r) => r.status === 'present').length;
  const lateCount = todaySessionRecords.filter((r) => r.status === 'late').length;
  const totalCheckedIn = todaySessionRecords.length;
  const absentCount = Math.max(0, totalStudents - totalCheckedIn);
  const attendanceRate = totalStudents > 0 ? Math.round((totalCheckedIn / totalStudents) * 100) : 0;
  const punctualityRate = totalCheckedIn > 0 ? Math.round((presentCount / totalCheckedIn) * 100) : 0;

  // Gender breakdown
  const maleStudents = students.filter((s) => s.gender === 'M');
  const femaleStudents = students.filter((s) => s.gender === 'F');

  const maleCheckedIn = todaySessionRecords.filter((r) => {
    const st = students.find((s) => s.id === r.studentId);
    return st?.gender === 'M';
  }).length;

  const femaleCheckedIn = todaySessionRecords.filter((r) => {
    const st = students.find((s) => s.id === r.studentId);
    return st?.gender === 'F';
  }).length;

  // Absentees list for official report
  const absenteesList = useMemo(() => {
    return students.filter((st) => !todaySessionRecords.some((r) => r.studentId === st.id));
  }, [students, todaySessionRecords]);

  // Late pupils list for official report
  const latePupilsList = useMemo(() => {
    return todaySessionRecords.filter((r) => r.status === 'late');
  }, [todaySessionRecords]);

  // Distinct classrooms in the school
  const allClassrooms = useMemo(() => {
    return Array.from(new Set(students.map((s) => s.classroom))).sort();
  }, [students]);

  // Classroom ranking by attendance performance
  const classRanking = useMemo(() => {
    return allClassrooms
      .map((cls) => {
        const classStudents = students.filter((s) => s.classroom === cls);
        const classRecords = todaySessionRecords.filter((r) => r.classroom === cls);
        const present = classRecords.filter((r) => r.status === 'present').length;
        const late = classRecords.filter((r) => r.status === 'late').length;
        const totalChecked = classRecords.length;
        const absent = Math.max(0, classStudents.length - totalChecked);
        const rate = classStudents.length > 0 ? Math.round((totalChecked / classStudents.length) * 100) : 0;
        const punctRate = totalChecked > 0 ? Math.round((present / totalChecked) * 100) : 0;
        const grade = classStudents[0]?.grade || '1AM';

        // Composite discipline score
        const score = Math.round(rate * 0.7 + punctRate * 0.3);

        return {
          classroom: cls,
          grade,
          total: classStudents.length,
          present,
          late,
          absent,
          rate,
          punctualityRate: punctRate,
          score,
        };
      })
      .sort((a, b) => b.rate - a.rate || b.score - a.score);
  }, [allClassrooms, students, todaySessionRecords]);

  // Chronic absentees calculation across all records
  const chronicAbsentees = useMemo(() => {
    // Unique dates recorded in database
    const uniqueDates = Array.from(new Set(records.map((r) => r.date))).sort();
    
    return students
      .map((st) => {
        // Records for this student
        const stRecords = records.filter((r) => r.studentId === st.id);
        const lateRecords = stRecords.filter((r) => r.status === 'late');
        
        // Days where student was recorded as absent or not checked in on school days
        const missedDates: string[] = [];
        uniqueDates.forEach((d) => {
          const rec = stRecords.find((r) => r.date === d);
          if (!rec || rec.status === 'absent') {
            missedDates.push(d);
          }
        });

        const absenceCount = missedDates.length;
        const lateCount = lateRecords.length;

        // Warning severity status according to Algerian legislation
        let warningLevel: 'normal' | 'notice' | 'warning' | 'critical' = 'normal';
        if (absenceCount >= 5) {
          warningLevel = 'critical'; // استدعاء فوري / مهدد بالإحالة على مجلس التأديب
        } else if (absenceCount >= 3) {
          warningLevel = 'warning'; // إنذار كتابي رسمي
        } else if (absenceCount >= 2 || lateCount >= 3) {
          warningLevel = 'notice'; // تنبيه شفوي / إشعار
        }

        return {
          student: st,
          absenceCount,
          absenceDates: missedDates,
          lateCount,
          warningLevel,
        };
      })
      .filter((item) => item.absenceCount >= 2 || item.lateCount >= 3)
      .sort((a, b) => b.absenceCount - a.absenceCount);
  }, [students, records]);

  // Filtered chronic absentees by query
  const filteredChronic = useMemo(() => {
    if (!searchChronicQuery.trim()) return chronicAbsentees;
    const q = searchChronicQuery.trim().toLowerCase();
    return chronicAbsentees.filter(
      (c) =>
        c.student.firstName.toLowerCase().includes(q) ||
        c.student.lastName.toLowerCase().includes(q) ||
        c.student.classroom.toLowerCase().includes(q) ||
        c.student.id.toLowerCase().includes(q)
    );
  }, [chronicAbsentees, searchChronicQuery]);

  const handlePrintReport = () => {
    window.print();
  };

  const handleExportExcelReport = () => {
    exportAnalyticsReportToExcel({
      students,
      records,
      settings,
      session: selectedPeriodFilter,
      date: todayStr,
    });
  };

  // Open WhatsApp warning for chronic absent student
  const openWhatsAppWarning = (student: Student, absenceCount: number) => {
    const cleanPhone = (student.guardianPhone || '').replace(/\D/g, '');
    let intlPhone = cleanPhone;
    if (intlPhone.startsWith('0')) {
      intlPhone = '213' + intlPhone.slice(1);
    }
    const message = `الجمهورية الجزائرية الديمقراطية الشعبية\nوزارة التربية الوطنية - متوسطة سعدون عاشور (عنابة)\n\nإلى ولي أمر التلميذ(ة): ${student.lastName} ${student.firstName} (قسم ${student.classroom})\n\nتحية طيبة،\nنلفت انتباهكم الكريم إلى أن ابنكم/ابنتكم قد سجل(ت) عدد (${absenceCount}) غيابات متكررة غير مبررة خلال الفترة الحالية.\nيرجى التفضل بالتقرب من مكتب مستشارة التربية بالمتوسطة لتسوية الوضعية وتقديم المبررات القانونية، حرصاً على مصلحة التلميذ وتفادياً للإجراءات الإدارية المترتبة عن الانقطاع.\n\nمديرة المؤسسة: بويمة ليلى بن تروش\nمستشارة التربية: حليلو صليحة`;
    window.open(`https://wa.me/${intlPhone}?text=${encodeURIComponent(message)}`, '_blank');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Control Actions */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4 no-print">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-slate-700" />
            <h3 className="font-bold text-slate-900 text-sm sm:text-base">
              لوحة الإحصائيات الشاملة والتقارير الإدارية
            </h3>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-50 text-slate-800 border border-slate-200">
              متوسطة سعدون عاشور
            </span>
          </div>
          <p className="text-xs text-slate-500">
            متابعة دقيقة لمؤشرات الحضور والانضباط، مرصد الغيابات المتكررة، وترتيب الأقسام
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {/* Cohort Period Filter */}
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 shadow-2xs">
            <Clock className="w-4 h-4 text-slate-500 shrink-0" />
            <select
              value={selectedPeriodFilter}
              onChange={(e) => {
                const val = e.target.value;
                setSelectedPeriodFilter(val);
                if (onChangePeriod && (val.startsWith('m') || val.startsWith('a'))) {
                  onChangePeriod(val as PeriodId);
                }
              }}
              className="text-xs font-semibold bg-transparent border-0 focus:ring-0 cursor-pointer text-slate-800"
            >
              <option value="all">كل اليوم (جميع الفترات والأفواج)</option>
              <optgroup label="الفترة الصباحية (3 أفواج)">
                <option value="morning">الفترة الصباحية (كل الأفواج)</option>
                {periods
                  .filter((p) => p.type === 'morning')
                  .map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.startTime})
                    </option>
                  ))}
              </optgroup>
              <optgroup label="الفترة المسائية (3 أفواج)">
                <option value="afternoon">الفترة المسائية (كل الأفواج)</option>
                {periods
                  .filter((p) => p.type === 'afternoon')
                  .map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.startTime})
                    </option>
                  ))}
              </optgroup>
            </select>
          </div>

          <button
            onClick={handleExportExcelReport}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-800 bg-slate-50 hover:bg-slate-100 border border-slate-300 rounded-lg transition-colors cursor-pointer shadow-2xs"
            title="تصدير كشف الإحصائيات ونسب الحضور والغيابات كملف Excel متناسق"
          >
            <FileSpreadsheet className="w-4 h-4 text-slate-700" />
            تصدير الإحصائيات (Excel)
          </button>

          <button
            onClick={handlePrintReport}
            style={{ backgroundColor: palette.primary, color: palette.foreground }}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer shadow-xs hover:opacity-95"
          >
            <Printer className="w-4 h-4" />
            طباعة الكشف الإداري الرسمي
          </button>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2 no-print">
        <button
          type="button"
          onClick={() => setActiveTab('overview')}
          style={activeTab === 'overview' ? { backgroundColor: palette.primary, color: palette.foreground } : {}}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
            activeTab === 'overview'
              ? 'shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>المؤشرات العامة ونسب الحضور</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('chronic')}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
            activeTab === 'chronic'
              ? 'bg-slate-700 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <ShieldAlert className="w-4 h-4" />
          <span>مرصد الغيابات المتكررة والاستدعاءات</span>
          {chronicAbsentees.length > 0 && (
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
              activeTab === 'chronic' ? 'bg-white text-slate-800' : 'bg-slate-100 text-slate-700 font-bold'
            }`}>
              {chronicAbsentees.length}
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('ranking')}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
            activeTab === 'ranking'
              ? 'bg-amber-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Trophy className="w-4 h-4" />
          <span>ترتيب الأقسام وكأس الانضباط</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('official-print')}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
            activeTab === 'official-print'
              ? 'bg-slate-800 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>الكشف الإداري الرسمي للطباعة</span>
        </button>
      </div>

      {/* TAB 1: General Overview & KPIs */}
      {activeTab === 'overview' && (
        <div className="space-y-6 no-print">
          {/* KPI Cards Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 block mb-1">نسبة الحضور الإجمالية</span>
              <div className="flex items-baseline justify-between">
                <span className="text-3xl font-extrabold font-mono-numbers text-slate-900">
                  {attendanceRate}%
                </span>
                <span className="text-xs font-semibold text-slate-800 bg-slate-50 px-2 py-0.5 rounded-full border border-slate-200">
                  {totalCheckedIn} / {totalStudents}
                </span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2 mt-3 overflow-hidden">
                <div
                  className="bg-slate-600 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${attendanceRate}%` }}
                />
              </div>
              <span className="text-[11px] text-slate-400 mt-2 block">
                معدل تواجد التلاميذ بالمؤسسة في الفوج المحدد
              </span>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 block mb-1">معدل الانضباط في الوقت</span>
              <div className="flex items-baseline justify-between">
                <span className="text-3xl font-extrabold font-mono-numbers text-slate-600">
                  {punctualityRate}%
                </span>
                <span className="text-xs font-mono-numbers font-semibold text-slate-700 bg-slate-50 px-2 py-0.5 rounded-md">
                  {presentCount} تلميذ في الموعد
                </span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2 mt-3 overflow-hidden">
                <div
                  className="bg-slate-500 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${punctualityRate}%` }}
                />
              </div>
              <span className="text-[11px] text-slate-400 mt-2 block">
                نسبة الذين دخلوا قبل نهاية حد التأخر المحدد
              </span>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 block mb-1">المتأخرون عن الحصة</span>
              <div className="flex items-baseline justify-between">
                <span className="text-3xl font-extrabold font-mono-numbers text-amber-600">
                  {lateCount}
                </span>
                <span className="text-xs text-amber-800 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
                  تذاكر دخول مسلمة
                </span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2 mt-3 overflow-hidden">
                <div
                  className="bg-amber-500 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${totalStudents > 0 ? (lateCount / totalStudents) * 100 : 0}%` }}
                />
              </div>
              <span className="text-[11px] text-slate-400 mt-2 block">
                دخلوا بعد التوقيت القانوني وحصلوا على تذاكر
              </span>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 block mb-1">إجمالي الغيابات</span>
              <div className="flex items-baseline justify-between">
                <span className="text-3xl font-extrabold font-mono-numbers text-slate-600">
                  {absentCount}
                </span>
                <span className="text-xs text-slate-800 bg-slate-50 px-2 py-0.5 rounded-md border border-slate-200">
                  لم يمسحوا الباركود
                </span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2 mt-3 overflow-hidden">
                <div
                  className="bg-slate-500 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${totalStudents > 0 ? (absentCount / totalStudents) * 100 : 0}%` }}
                />
              </div>
              <span className="text-[11px] text-slate-400 mt-2 block">
                تلاميذ مسجلون كغائبين في انتظار التبرير
              </span>
            </div>
          </div>

          {/* Grade Breakdown and Gender Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Grade breakdown (2 cols) */}
            <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <div>
                  <h4 className="font-bold text-slate-800 text-sm">
                    توزيع الحضور والغيابات حسب المستويات الدراسية
                  </h4>
                  <p className="text-xs text-slate-400">
                    مقارنة معدلات الانضباط بين سنوات التعليم المتوسط الأربعة
                  </p>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold">
                      <th className="py-2.5 px-4">المستوى الدراسي</th>
                      <th className="py-2.5 px-4 text-center">التعداد</th>
                      <th className="py-2.5 px-4 text-center">حاضرون بالموعد</th>
                      <th className="py-2.5 px-4 text-center">متأخرون</th>
                      <th className="py-2.5 px-4 text-center">غائبون</th>
                      <th className="py-2.5 px-4 text-center">نسبة الحضور</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {gradeBreakdown.map((row) => (
                      <tr key={row.grade} className="hover:bg-slate-50/50">
                        <td className="py-3 px-4 font-bold text-slate-800">
                          {row.name}
                        </td>
                        <td className="py-3 px-4 text-center font-mono-numbers font-semibold">
                          {row.total}
                        </td>
                        <td className="py-3 px-4 text-center font-mono-numbers text-slate-700 font-bold">
                          {row.present}
                        </td>
                        <td className="py-3 px-4 text-center font-mono-numbers text-amber-700 font-bold">
                          {row.late}
                        </td>
                        <td className="py-3 px-4 text-center font-mono-numbers text-slate-700 font-bold">
                          {row.absent}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <div className="flex items-center justify-center gap-2">
                            <div className="w-16 bg-slate-100 rounded-full h-1.5 overflow-hidden">
                              <div
                                className={`h-1.5 rounded-full ${
                                  row.rate >= 90
                                    ? 'bg-slate-600'
                                    : row.rate >= 75
                                    ? 'bg-amber-500'
                                    : 'bg-slate-500'
                                }`}
                                style={{ width: `${row.rate}%` }}
                              />
                            </div>
                            <span className="font-mono-numbers font-bold text-xs">
                              {row.rate}%
                            </span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Gender and Discipline summary (1 col) */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4 flex flex-col justify-between">
              <div>
                <h4 className="font-bold text-slate-800 text-sm mb-1">
                  المؤشرات الديموغرافية (الذكور والإناث)
                </h4>
                <p className="text-xs text-slate-400 mb-4">
                  توزيع الحضور اليومي حسب الجنس
                </p>

                <div className="space-y-4">
                  {/* Male */}
                  <div className="p-3 bg-sky-50/60 rounded-xl border border-sky-100">
                    <div className="flex items-center justify-between text-xs font-bold text-sky-950 mb-1">
                      <span>الذكور</span>
                      <span className="font-mono-numbers">
                        {maleCheckedIn} / {maleStudents.length} حاضر
                      </span>
                    </div>
                    <div className="w-full bg-sky-200 rounded-full h-2 overflow-hidden">
                      <div
                        className="bg-sky-600 h-2 rounded-full"
                        style={{
                          width: `${maleStudents.length > 0 ? (maleCheckedIn / maleStudents.length) * 100 : 0}%`,
                        }}
                      />
                    </div>
                    <span className="text-[10px] text-sky-700 font-mono-numbers mt-1 block">
                      نسبة الحضور: {maleStudents.length > 0 ? Math.round((maleCheckedIn / maleStudents.length) * 100) : 0}%
                    </span>
                  </div>

                  {/* Female */}
                  <div className="p-3 bg-slate-50/60 rounded-xl border border-slate-100">
                    <div className="flex items-center justify-between text-xs font-bold text-slate-950 mb-1">
                      <span>الإناث</span>
                      <span className="font-mono-numbers">
                        {femaleCheckedIn} / {femaleStudents.length} حاضرة
                      </span>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                      <div
                        className="bg-slate-500 h-2 rounded-full"
                        style={{
                          width: `${femaleStudents.length > 0 ? (femaleCheckedIn / femaleStudents.length) * 100 : 0}%`,
                        }}
                      />
                    </div>
                    <span className="text-[10px] text-slate-700 font-mono-numbers mt-1 block">
                      نسبة الحضور: {femaleStudents.length > 0 ? Math.round((femaleCheckedIn / femaleStudents.length) * 100) : 0}%
                    </span>
                  </div>
                </div>
              </div>

              {/* Administrative stamp note */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600 space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-slate-800">
                  <School className="w-3.5 h-3.5 text-slate-700" />
                  <span>المسؤولان المشرفان عن الاعتماد:</span>
                </div>
                <p className="text-[11px]">المديرة: <strong>{settings.principalName}</strong></p>
                <p className="text-[11px]">مستشارة التربية: <strong>{settings.counselorName}</strong></p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: Chronic Absentees & Official Parent Summons */}
      {activeTab === 'chronic' && (
        <div className="space-y-4 no-print">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <ShieldAlert className="w-5 h-5 text-slate-600" />
                  <h4 className="font-bold text-slate-900 text-sm sm:text-base">
                    مرصد الغيابات المتكررة والتنبيه المبكر
                  </h4>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  رصد آلي للتلاميذ الذين تجاوزوا حد الغيابات المتكررة (≥ 2 غيابات) لاستدعاء أوليائهم رسمياً وفقاً للتشريع المدرسي
                </p>
              </div>

              {/* Search box */}
              <div className="relative w-full sm:w-64">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchChronicQuery}
                  onChange={(e) => setSearchChronicQuery(e.target.value)}
                  placeholder="بحث باسم التلميذ أو القسم..."
                  className="w-full pr-8 pl-3 py-1.5 text-xs rounded-lg border border-slate-300 bg-slate-50/50"
                />
              </div>
            </div>

            {filteredChronic.length === 0 ? (
              <div className="py-12 text-center text-slate-500 space-y-2">
                <CheckCircle2 className="w-10 h-10 text-slate-500 mx-auto" />
                <p className="font-bold text-sm text-slate-800">لا توجد حالات غياب متكرر حرجة مسجلة</p>
                <p className="text-xs text-slate-400">جميع تلاميذ متوسطة سعدون عاشور في وضعية انضباط مقبولة</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold">
                      <th className="py-3 px-4">رقم التسجيل</th>
                      <th className="py-3 px-4">اسم ولقب التلميذ</th>
                      <th className="py-3 px-4">القسم والمستوى</th>
                      <th className="py-3 px-4 text-center">عدد الغيابات</th>
                      <th className="py-3 px-4 text-center">مرات التأخر</th>
                      <th className="py-3 px-4 text-center">درجة الخطورة</th>
                      <th className="py-3 px-4">ولي الأمر والهاتف</th>
                      <th className="py-3 px-4 text-center">الإجراءات المباشرة</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredChronic.map((item) => {
                      const { student, absenceCount, lateCount, warningLevel } = item;
                      return (
                        <tr key={student.id} className="hover:bg-slate-50/60 transition-colors">
                          <td className="py-3 px-4 font-mono-numbers font-medium text-slate-600">
                            {student.id}
                          </td>
                          <td className="py-3 px-4 font-bold text-slate-900">
                            {student.lastName} {student.firstName}
                          </td>
                          <td className="py-3 px-4 font-semibold text-slate-700">
                            {student.classroom} ({student.grade})
                          </td>
                          <td className="py-3 px-4 text-center">
                            <span className="font-mono-numbers font-extrabold text-sm text-slate-700 bg-slate-50 px-2.5 py-0.5 rounded-full border border-slate-200">
                              {absenceCount} غيابات
                            </span>
                          </td>
                          <td className="py-3 px-4 text-center font-mono-numbers text-amber-700 font-bold">
                            {lateCount}
                          </td>
                          <td className="py-3 px-4 text-center">
                            {warningLevel === 'critical' ? (
                              <span className="text-[11px] font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded border border-slate-300">
                                استدعاء عاجل / مجلس تأديب
                              </span>
                            ) : warningLevel === 'warning' ? (
                              <span className="text-[11px] font-bold text-amber-900 bg-amber-100 px-2 py-0.5 rounded border border-amber-300">
                                إنذار كتابي رسمي
                              </span>
                            ) : (
                              <span className="text-[11px] font-semibold text-blue-900 bg-blue-100 px-2 py-0.5 rounded border border-blue-200">
                                تنبيه أولي
                              </span>
                            )}
                          </td>
                          <td className="py-3 px-4">
                            <div className="text-slate-800 font-medium">{student.guardianName}</div>
                            <div className="font-mono-numbers text-[11px] text-slate-500">
                              {student.guardianPhone}
                            </div>
                          </td>
                          <td className="py-3 px-4 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              {/* Open Official Summons Printout */}
                              <button
                                type="button"
                                onClick={() => setSummonsStudent(item)}
                                className="px-2.5 py-1 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer flex items-center gap-1 shadow-2xs"
                                title="إنشاء وطباعة استدعاء ولي أمر رسمي مع وصل الاستلام"
                              >
                                <Printer className="w-3.5 h-3.5" />
                                <span>استدعاء رسمي</span>
                              </button>

                              {/* WhatsApp Instant Warning */}
                              <button
                                type="button"
                                onClick={() => openWhatsAppWarning(student, absenceCount)}
                                className="p-1.5 text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-300 rounded-lg transition-colors cursor-pointer"
                                title="إرسال إشعار إنذار رسمي عبر تطبيق واتساب لولي الأمر"
                              >
                                <MessageCircle className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: Class Ranking & Golden Class Trophy */}
      {activeTab === 'ranking' && (
        <div className="space-y-6 no-print">
          {/* Top Class Banner (Rank 1 Trophy) */}
          {classRanking.length > 0 && (
            <div className="bg-gradient-to-r from-amber-500 via-amber-600 to-yellow-600 text-white rounded-2xl p-6 shadow-md flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-2xl bg-white/20 backdrop-blur-xs flex items-center justify-center shrink-0 border border-white/30 shadow-inner">
                  <Trophy className="w-9 h-9 text-yellow-100 animate-bounce" />
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-bold uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded-full">
                      كأس الانضباط والمواظبة اليومي
                    </span>
                    <span className="text-xs bg-yellow-400 text-slate-900 px-2 py-0.5 rounded-full font-bold">
                      المرتبة الأولى #1
                    </span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-black">
                    قسم {classRanking[0].classroom} - قسم الشرف والريادة
                  </h3>
                  <p className="text-xs text-white/90 mt-1">
                    حقق أعلى نسبة حضور وانضباط بالمتوسطة بمعدل{' '}
                    <strong className="text-yellow-200 font-mono text-sm">{classRanking[0].rate}%</strong> وبانضباط في المواعيد قدره{' '}
                    <strong className="text-yellow-200 font-mono text-sm">{classRanking[0].punctualityRate}%</strong>
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setCertificateClass(classRanking[0])}
                className="px-4 py-2 text-xs font-bold text-slate-900 bg-white hover:bg-yellow-50 rounded-xl transition-all shadow-sm cursor-pointer flex items-center gap-2 shrink-0"
              >
                <Award className="w-4 h-4 text-amber-600" />
                <span>طباعة شهادة تقدير وانضباط للقسم</span>
              </button>
            </div>
          )}

          {/* Ranking Table */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <h4 className="font-bold text-slate-800 text-sm">
              جدول ترتيب كافة أقسام متوسطة سعدون عاشور حسب الانضباط
            </h4>

            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold">
                    <th className="py-3 px-4 text-center">الرتبة</th>
                    <th className="py-3 px-4">القسم والمستوى</th>
                    <th className="py-3 px-4 text-center">التعداد الإجمالي</th>
                    <th className="py-3 px-4 text-center">الحاضرون</th>
                    <th className="py-3 px-4 text-center">المتأخرون</th>
                    <th className="py-3 px-4 text-center">الغائبون</th>
                    <th className="py-3 px-4 text-center">نسبة الحضور</th>
                    <th className="py-3 px-4 text-center">الانضباط في الموعد</th>
                    <th className="py-3 px-4 text-center">الشهادة والتكريم</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {classRanking.map((cls, index) => {
                    const isFirst = index === 0;
                    const isSecond = index === 1;
                    const isThird = index === 2;

                    return (
                      <tr
                        key={cls.classroom}
                        className={`hover:bg-slate-50/60 transition-colors ${
                          isFirst ? 'bg-amber-50/30' : ''
                        }`}
                      >
                        <td className="py-3 px-4 text-center">
                          {isFirst ? (
                            <span className="w-7 h-7 rounded-full bg-amber-500 text-white font-bold inline-flex items-center justify-center shadow-xs">
                              🥇
                            </span>
                          ) : isSecond ? (
                            <span className="w-7 h-7 rounded-full bg-slate-300 text-slate-800 font-bold inline-flex items-center justify-center">
                              🥈
                            </span>
                          ) : isThird ? (
                            <span className="w-7 h-7 rounded-full bg-amber-700 text-white font-bold inline-flex items-center justify-center">
                              🥉
                            </span>
                          ) : (
                            <span className="font-mono-numbers font-bold text-slate-500">
                              #{index + 1}
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4 font-bold text-slate-900 text-sm">
                          قسم {cls.classroom}
                          <span className="text-[11px] font-normal text-slate-400 mr-1.5">
                            ({cls.grade})
                          </span>
                        </td>
                        <td className="py-3 px-4 text-center font-mono-numbers font-medium">
                          {cls.total} تلميذ
                        </td>
                        <td className="py-3 px-4 text-center font-mono-numbers text-slate-700 font-bold">
                          {cls.present}
                        </td>
                        <td className="py-3 px-4 text-center font-mono-numbers text-amber-700 font-bold">
                          {cls.late}
                        </td>
                        <td className="py-3 px-4 text-center font-mono-numbers text-slate-700 font-bold">
                          {cls.absent}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <span className={`font-mono-numbers font-extrabold text-xs px-2.5 py-1 rounded-full ${
                            cls.rate >= 90
                              ? 'bg-slate-100 text-slate-900 border border-slate-300'
                              : cls.rate >= 75
                              ? 'bg-amber-100 text-amber-900 border border-amber-300'
                              : 'bg-slate-100 text-slate-900 border border-slate-300'
                          }`}>
                            {cls.rate}%
                          </span>
                        </td>
                        <td className="py-3 px-4 text-center font-mono-numbers text-slate-700 font-semibold">
                          {cls.punctualityRate}%
                        </td>
                        <td className="py-3 px-4 text-center">
                          <button
                            type="button"
                            onClick={() => setCertificateClass(cls)}
                            className="px-2 py-1 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1 mx-auto"
                          >
                            <Award className="w-3.5 h-3.5 text-amber-600" />
                            <span>شهادة</span>
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4 or PRINT VIEW: Official Administrative Report */}
      {(activeTab === 'official-print' || activeTab === 'overview') && (
        <div
          id="official-attendance-report"
          className={`${
            activeTab === 'official-print' ? 'block' : 'hidden'
          } print:block bg-white border border-slate-300 p-8 rounded-2xl print:rounded-none print:border-none print:p-0 space-y-6 text-slate-900`}
        >
          {/* Official Ministry Header */}
          <div className="text-center space-y-1 pb-4 border-b-2 border-slate-800">
            <p className="text-xs font-semibold text-slate-700">الجمهورية الجزائرية الديمقراطية الشعبية</p>
            <p className="text-xs font-semibold text-slate-700">
              وزارة التربية الوطنية · مديرية التربية لولاية {settings.wilaya}
            </p>
            <h2 className="text-base font-extrabold text-slate-900 mt-1">{settings.schoolName}</h2>
            <p className="text-xs font-bold text-slate-800">
              مصلحة الاستشارة التربوية · كشف الغياب اليومي وحركة التلاميذ
            </p>
            <div className="flex flex-wrap justify-center items-center gap-6 text-xs text-slate-600 pt-2 font-medium">
              <span>التاريخ: <strong className="font-mono-numbers">{todayStr}</strong></span>
              <span>
                الفترة / الفوج:{' '}
                <strong>
                  {selectedPeriodFilter === 'all'
                    ? 'كامل اليوم (جميع الفترات)'
                    : selectedPeriodFilter === 'morning'
                    ? 'الفترة الصباحية كاملة'
                    : selectedPeriodFilter === 'afternoon'
                    ? 'الفترة المسائية كاملة'
                    : getPeriodById(settings, selectedPeriodFilter).name}
                </strong>
              </span>
              <span>السنة الدراسية: <strong>{settings.academicYear}</strong></span>
            </div>
          </div>

          {/* Certified Statistics Grid */}
          <div className="grid grid-cols-4 gap-2 text-center text-xs border border-slate-400 p-3 rounded-lg bg-slate-50/60 font-medium">
            <div>التعداد الكلي للمؤسسة: <strong className="font-mono-numbers font-bold text-sm block mt-0.5">{totalStudents}</strong></div>
            <div>الحاضرون: <strong className="font-mono-numbers font-bold text-sm text-slate-900 block mt-0.5">{totalCheckedIn}</strong></div>
            <div>المتأخرون: <strong className="font-mono-numbers font-bold text-sm text-amber-900 block mt-0.5">{lateCount}</strong></div>
            <div>الغائبون: <strong className="font-mono-numbers font-bold text-sm text-slate-900 block mt-0.5">{absentCount}</strong></div>
          </div>

          {/* Section 1: Absentees */}
          <div className="space-y-2">
            <div className="flex items-center justify-between bg-slate-100 p-2 rounded border border-slate-300">
              <h4 className="text-xs font-bold text-slate-900">
                أولاً: قائمة التلاميذ الغائبين عن الفوج ({absenteesList.length} تلميذ)
              </h4>
              <span className="text-[11px] font-semibold text-slate-600">
                مطلوب تبرير الغياب عند العودة
              </span>
            </div>

            {absenteesList.length === 0 ? (
              <p className="text-xs text-slate-500 text-center py-4 bg-slate-50 rounded border border-slate-200">
                لا توجد أي غيابات مسجلة في هذا الفوج بحمد الله.
              </p>
            ) : (
              <table className="w-full text-right text-xs border border-slate-400">
                <thead>
                  <tr className="bg-slate-100 border-b border-slate-400 text-slate-800 font-bold">
                    <th className="p-2 border-l border-slate-400 w-10 text-center">الرقم</th>
                    <th className="p-2 border-l border-slate-400 w-28">رقم التسجيل</th>
                    <th className="p-2 border-l border-slate-400">اسم ولقب التلميذ</th>
                    <th className="p-2 border-l border-slate-400 w-20">القسم</th>
                    <th className="p-2 border-l border-slate-400">اسم ولي الأمر</th>
                    <th className="p-2 w-28">هاتف الاتصال</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-300">
                  {absenteesList.map((st, idx) => (
                    <tr key={st.id} className="hover:bg-slate-50">
                      <td className="p-2 border-l border-slate-400 text-center font-mono-numbers">{idx + 1}</td>
                      <td className="p-2 border-l border-slate-400 font-mono-numbers">{st.id}</td>
                      <td className="p-2 border-l border-slate-400 font-bold">{st.lastName} {st.firstName}</td>
                      <td className="p-2 border-l border-slate-400 font-bold">{st.classroom}</td>
                      <td className="p-2 border-l border-slate-400">{st.guardianName}</td>
                      <td className="p-2 font-mono-numbers">{st.guardianPhone}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          {/* Section 2: Late Pupils */}
          <div className="space-y-2">
            <div className="flex items-center justify-between bg-slate-100 p-2 rounded border border-slate-300">
              <h4 className="text-xs font-bold text-slate-900">
                ثانياً: قائمة التلاميذ المتأخرين المسجلين ({latePupilsList.length} تلميذ)
              </h4>
              <span className="text-[11px] font-semibold text-slate-600">
                سُلمت لهم تذاكر دخول قانونية
              </span>
            </div>

            {latePupilsList.length === 0 ? (
              <p className="text-xs text-slate-500 text-center py-4 bg-slate-50 rounded border border-slate-200">
                لا توجد أي حالات تأخر مسجلة.
              </p>
            ) : (
              <table className="w-full text-right text-xs border border-slate-400">
                <thead>
                  <tr className="bg-slate-100 border-b border-slate-400 text-slate-800 font-bold">
                    <th className="p-2 border-l border-slate-400 w-10 text-center">الرقم</th>
                    <th className="p-2 border-l border-slate-400">اسم ولقب التلميذ</th>
                    <th className="p-2 border-l border-slate-400 w-20">القسم</th>
                    <th className="p-2 border-l border-slate-400 w-24">وقت المسح</th>
                    <th className="p-2 border-l border-slate-400 w-24">مدة التأخر</th>
                    <th className="p-2">ملاحظة الاستشارة التربوية</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-300">
                  {latePupilsList.map((rec, idx) => (
                    <tr key={rec.id} className="hover:bg-slate-50">
                      <td className="p-2 border-l border-slate-400 text-center font-mono-numbers">{idx + 1}</td>
                      <td className="p-2 border-l border-slate-400 font-bold">{rec.studentName}</td>
                      <td className="p-2 border-l border-slate-400 font-bold">{rec.classroom}</td>
                      <td className="p-2 border-l border-slate-400 font-mono-numbers">{rec.timestamp}</td>
                      <td className="p-2 border-l border-slate-400 font-bold text-amber-900">+{rec.lateMinutes} دقيقة</td>
                      <td className="p-2">{rec.excuseReason || 'سُلمت له تذكرة دخول'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          {/* Official Signatures Section */}
          <div className="grid grid-cols-2 gap-12 pt-8 text-xs text-center border-t-2 border-slate-800">
            <div>
              <p className="font-bold text-slate-900 mb-12">مستشارة التربية الرئيسية</p>
              <p className="text-xs text-slate-800 font-bold">{settings.counselorName}</p>
              <p className="text-[10px] text-slate-500">خاتم وتوقيع مصلحة الاستشارة</p>
            </div>
            <div>
              <p className="font-bold text-slate-900 mb-12">مديرة المتوسطة</p>
              <p className="text-xs text-slate-800 font-bold">{settings.principalName}</p>
              <p className="text-[10px] text-slate-500">خاتم وتأشيرة إدارة المؤسسة</p>
            </div>
          </div>
        </div>
      )}

      {/* Official Parent Summons Modal (استدعاء ولي أمر رسمي) */}
      {summonsStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full p-6 space-y-4 border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 no-print">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-slate-600" />
                <h3 className="font-bold text-slate-900 text-sm">
                  استدعاء ولي أمر رسمي (إشعار بتكرار الغياب / التأخر)
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSummonsStudent(null)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Config inputs before printing */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs no-print">
              <div>
                <label className="block text-slate-600 font-bold mb-1">تاريخ المقابلة المحدد:</label>
                <input
                  type="date"
                  value={summonsDate}
                  onChange={(e) => setSummonsDate(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                />
              </div>
              <div>
                <label className="block text-slate-600 font-bold mb-1">التوقيت المحدد للحضور:</label>
                <input
                  type="time"
                  value={summonsTime}
                  onChange={(e) => setSummonsTime(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-slate-600 font-bold mb-1">سبب الاستدعاء:</label>
                <input
                  type="text"
                  value={summonsReason}
                  onChange={(e) => setSummonsReason(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                />
              </div>
            </div>

            {/* Official Summons Printable Sheet */}
            <div className="border-2 border-slate-800 p-6 rounded-xl space-y-4 text-slate-900 bg-white text-xs">
              <div className="text-center space-y-1 pb-3 border-b border-slate-400">
                <p className="font-bold">الجمهورية الجزائرية الديمقراطية الشعبية · وزارة التربية الوطنية</p>
                <p className="font-semibold text-[11px]">
                  مديرية التربية لولاية {settings.wilaya} · {settings.schoolName}
                </p>
                <h3 className="text-base font-black text-slate-900 mt-1">
                  استدعاء رسمي لولي أمر تلميذ
                </h3>
                <p className="text-[10px] text-slate-500 font-mono">
                  رقم الوثيقة: CONV-{summonsStudent.student.id}-{Date.now().toString().slice(-4)}
                </p>
              </div>

              <div className="space-y-3 leading-relaxed">
                <p>
                  إلى السيد(ة): <strong>{summonsStudent.student.guardianName}</strong>، ولي أمر التلميذ(ة):{' '}
                  <strong className="text-sm font-bold">{summonsStudent.student.lastName} {summonsStudent.student.firstName}</strong> (المسجل بقسم:{' '}
                  <strong>{summonsStudent.student.classroom}</strong>، رقم التسجيل: <span className="font-mono">{summonsStudent.student.id}</span>).
                </p>

                <p>
                  نظراً لتسجيل غيابات متكررة غير مبررة لابنكم(تكم) بلغت:{' '}
                  <strong className="text-slate-800 text-sm underline font-mono">
                    {summonsStudent.absenceCount} غيابات
                  </strong>{' '}
                  {summonsStudent.absenceDates.length > 0 && (
                    <span className="text-[11px] text-slate-600">
                      (في التواريخ: {summonsStudent.absenceDates.slice(0, 5).join('، ')})
                    </span>
                  )}
                  ، وتأخرات متكررة ({summonsStudent.lateCount} مرات).
                </p>

                <div className="p-3 bg-slate-50 border border-slate-300 rounded-lg">
                  <p className="font-bold">
                    يشرفنا دعوتكم للحضور إلى مقر المؤسسة (مكتب مستشارة التربية):
                  </p>
                  <p className="mt-1">
                    يوم: <strong className="text-slate-900 font-mono">{summonsDate}</strong> على الساعة:{' '}
                    <strong className="text-slate-900 font-mono">{summonsTime}</strong>.
                  </p>
                  <p className="text-[11px] text-slate-600 mt-1">
                    الموضوع: {summonsReason}
                  </p>
                </div>

                <p className="text-[11px] text-slate-600">
                  * نلفت انتباهكم إلى أن الحضور ضروري وإلزامي طبقاً للمادة 21 من القرار الوزاري رقم 778، وحرصاً على مصلحة التلميذ وتفادياً لإجراءات الانقطاع المدرسي.
                </p>
              </div>

              {/* Signatures */}
              <div className="grid grid-cols-2 gap-8 pt-4 border-t border-slate-300 text-center text-xs">
                <div>
                  <p className="font-bold mb-8">مستشارة التربية</p>
                  <p className="font-semibold">{settings.counselorName}</p>
                </div>
                <div>
                  <p className="font-bold mb-8">مديرة المتوسطة</p>
                  <p className="font-semibold">{settings.principalName}</p>
                </div>
              </div>

              {/* Tear-off receipt for parent */}
              <div className="border-t-2 border-dashed border-slate-400 pt-3 mt-4 text-[10px] space-y-1">
                <p className="font-bold text-center">--- وصل استلام استدعاء ولي الأمر (يُعاد للمؤسسة) ---</p>
                <div className="flex justify-between items-center pt-2">
                  <span>اسم التلميذ: {summonsStudent.student.lastName} {summonsStudent.student.firstName} ({summonsStudent.student.classroom})</span>
                  <span>تاريخ الاستلام: ....................</span>
                  <span>توقيع ولي الأمر: ....................</span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-100 no-print">
              <button
                type="button"
                onClick={() => openWhatsAppWarning(summonsStudent.student, summonsStudent.absenceCount)}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-800 bg-slate-50 hover:bg-slate-100 border border-slate-300 rounded-lg cursor-pointer"
              >
                <MessageCircle className="w-4 h-4 text-slate-600" />
                <span>إرسال إشعار فوري عبر واتساب</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>طباعة الاستدعاء الرسمي</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSummonsStudent(null)}
                  className="px-3 py-2 text-xs text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
                >
                  إغلاق
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Class Certificate of Honor Modal (شهادة شرف وانضباط للقسم) */}
      {certificateClass && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full p-6 space-y-4 border border-slate-200">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 no-print">
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-amber-600" />
                <h3 className="font-bold text-slate-900 text-sm">
                  شهادة امتياز وانضباط لقسم {certificateClass.classroom}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setCertificateClass(null)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Certificate Display */}
            <div className="border-4 border-double border-amber-600 p-8 rounded-xl text-center space-y-4 bg-gradient-to-b from-amber-50/40 via-white to-amber-50/30 text-slate-900">
              <div className="space-y-1">
                <p className="text-[11px] font-bold text-slate-600">الجمهورية الجزائرية الديمقراطية الشعبية · وزارة التربية الوطنية</p>
                <p className="text-xs font-bold text-slate-700">مديرية التربية لولاية {settings.wilaya} · {settings.schoolName}</p>
                <div className="w-12 h-1 bg-amber-500 mx-auto my-2 rounded-full" />
                <h2 className="text-xl font-black text-amber-800 tracking-wide">
                  شـــهـادة امـتـيـاز فـي الانـضـبـاط والـمـواظـبـة
                </h2>
              </div>

              <div className="py-2 space-y-2">
                <p className="text-xs text-slate-600">
                  تتشرف إدارة متوسطة سعدون عاشور بمنح هذه الشهادة الشرفية لقسم:
                </p>
                <div className="text-2xl font-black text-slate-900 bg-amber-100/60 py-2 px-6 rounded-xl inline-block border border-amber-300">
                  قسم {certificateClass.classroom} ({certificateClass.grade})
                </div>
                <p className="text-xs text-slate-700 max-w-md mx-auto leading-relaxed pt-2">
                  تقديراً للمواظبة الاستثنائية والانضباط النموذجي وتحقيق نسبة حضور قدرها{' '}
                  <strong className="font-mono text-amber-800 text-sm font-bold">{certificateClass.rate}%</strong> بمعدل انضباط في المواعيد قدره{' '}
                  <strong className="font-mono text-slate-800 text-sm font-bold">{certificateClass.punctualityRate}%</strong>.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-8 pt-6 border-t border-amber-200 text-xs text-center">
                <div>
                  <p className="font-bold text-slate-800 mb-8">مستشارة التربية</p>
                  <p className="font-semibold text-slate-700">{settings.counselorName}</p>
                </div>
                <div>
                  <p className="font-bold text-slate-800 mb-8">مديرة المؤسسة</p>
                  <p className="font-semibold text-slate-700">{settings.principalName}</p>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 no-print">
              <button
                type="button"
                onClick={() => window.print()}
                className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-lg cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>طباعة الشهادة الرسمية</span>
              </button>
              <button
                type="button"
                onClick={() => setCertificateClass(null)}
                className="px-3 py-2 text-xs text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
