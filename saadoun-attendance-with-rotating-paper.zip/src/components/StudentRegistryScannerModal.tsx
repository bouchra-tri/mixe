import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Student } from '../types';
import { soundEffects } from '../utils/barcode';
import {
  DualBarcodeScanner,
  isTorchSupported,
  toggleTorch,
} from '../utils/barcodeScanner';
import {
  matchStudentByBarcode,
  normalizeBarcode,
  getBarcodeCandidates,
} from '../utils/barcodeNormalizer';
import {
  Scan,
  Camera,
  CameraOff,
  Keyboard,
  X,
  CheckCircle2,
  AlertCircle,
  FileText,
  Edit,
  Search,
  Phone,
  Copy,
  Check,
  UserPlus,
  RefreshCw,
  ExternalLink,
  Zap,
  ZapOff,
  History,
  QrCode
} from 'lucide-react';

interface StudentRegistryScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  students: Student[];
  onViewStudentCard: (student: Student) => void;
  onEditStudent: (student: Student) => void;
  onSelectInRegistry: (student: Student) => void;
  onAddNewWithBarcode?: (barcode: string) => void;
}

export const StudentRegistryScannerModal: React.FC<StudentRegistryScannerModalProps> = ({
  isOpen,
  onClose,
  students,
  onViewStudentCard,
  onEditStudent,
  onSelectInRegistry,
  onAddNewWithBarcode,
}) => {
  const [activeTab, setActiveTab] = useState<'laser' | 'camera'>('laser');
  const [manualCode, setManualCode] = useState('');
  const [lastScannedCode, setLastScannedCode] = useState<string | null>(null);
  const [matchedStudent, setMatchedStudent] = useState<Student | null>(null);
  const [scanStatus, setScanStatus] = useState<'idle' | 'success' | 'not_found'>('idle');
  const [scanHistory, setScanHistory] = useState<{ student: Student; time: string }[]>([]);
  const [copiedBarcode, setCopiedBarcode] = useState(false);

  // Camera state
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [availableCameras, setAvailableCameras] = useState<MediaDeviceInfo[]>([]);
  const [selectedCameraId, setSelectedCameraId] = useState<string>('');
  const [torchEnabled, setTorchEnabled] = useState(false);
  const [torchSupported, setTorchSupported] = useState(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const scannerRef = useRef<DualBarcodeScanner | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const barcodeBufferRef = useRef('');
  const lastKeyTimeRef = useRef(0);

  // Focus input when laser tab is active or modal opens
  useEffect(() => {
    if (isOpen) {
      setScanStatus('idle');
      setMatchedStudent(null);
      setLastScannedCode(null);
      setTimeout(() => {
        inputRef.current?.focus();
      }, 150);
    }
  }, [isOpen]);

  // Handle scanned/entered code
  const handleProcessCode = useCallback(
    (rawCode: string) => {
      const trimmed = rawCode.trim();
      if (!trimmed) return;

      setLastScannedCode(trimmed);
      const { student } = matchStudentByBarcode(students, trimmed);

      if (student) {
        soundEffects.playSuccess();
        setMatchedStudent(student);
        setScanStatus('success');
        setScanHistory((prev) => {
          // Avoid duplicate top item
          const filtered = prev.filter((item) => item.student.id !== student.id);
          const timeStr = new Date().toLocaleTimeString('ar-DZ', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
          });
          return [{ student, time: timeStr }, ...filtered.slice(0, 9)];
        });
      } else {
        soundEffects.playError();
        setMatchedStudent(null);
        setScanStatus('not_found');
      }

      setManualCode('');
      // Re-focus input for next scan
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    },
    [students]
  );

  // Global key listener for laser barcode gun (rapid typing detection)
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      // If typing in a regular input other than barcode input, don't hijack unless it looks like rapid barcode gun input
      const now = Date.now();
      const timeDiff = now - lastKeyTimeRef.current;
      lastKeyTimeRef.current = now;

      if (e.key === 'Enter') {
        if (barcodeBufferRef.current.length >= 3) {
          e.preventDefault();
          const code = barcodeBufferRef.current;
          barcodeBufferRef.current = '';
          handleProcessCode(code);
          return;
        }
        barcodeBufferRef.current = '';
        return;
      }

      // If key is printable
      if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
        if (timeDiff < 70) {
          // Fast keystroke from hardware barcode gun
          barcodeBufferRef.current += e.key;
        } else {
          // Reset buffer if delay too long
          barcodeBufferRef.current = e.key;
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, handleProcessCode]);

  // Stop camera stream safely
  const stopCameraStream = useCallback(() => {
    if (scannerRef.current) {
      scannerRef.current.stop();
      scannerRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
    setTorchEnabled(false);
    setTorchSupported(false);
  }, []);

  // Initialize camera list
  useEffect(() => {
    if (isOpen && activeTab === 'camera') {
      DualBarcodeScanner.getVideoDevices().then((devices) => {
        setAvailableCameras(devices);
        if (devices.length > 0 && !selectedCameraId) {
          // Prefer back/environment camera
          const backCam = devices.find(
            (d) =>
              d.label.toLowerCase().includes('back') ||
              d.label.toLowerCase().includes('rear') ||
              d.label.toLowerCase().includes('environment')
          );
          setSelectedCameraId(backCam ? backCam.deviceId : devices[0].deviceId);
        }
      });
    }
  }, [isOpen, activeTab, selectedCameraId]);

  // Start camera scanning
  const startCamera = useCallback(async () => {
    stopCameraStream();
    setCameraError(null);

    try {
      const constraints: MediaStreamConstraints = {
        video: selectedCameraId
          ? { deviceId: { exact: selectedCameraId } }
          : { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();

        const scanner = new DualBarcodeScanner();
        scannerRef.current = scanner;

        await scanner.startScanning(videoRef.current, stream, (text) => {
          handleProcessCode(text);
        });

        setIsCameraActive(true);
        const supported = isTorchSupported(stream);
        setTorchSupported(supported);
      }
    } catch (err: any) {
      console.error('Camera access error:', err);
      setCameraError('تعذر فتح الكاميرا. يرجى التأكد من منح الإذن لاستخدام الكاميرا.');
      setIsCameraActive(false);
    }
  }, [selectedCameraId, stopCameraStream, handleProcessCode]);

  // Handle camera tab activation
  useEffect(() => {
    if (isOpen && activeTab === 'camera') {
      startCamera();
    } else {
      stopCameraStream();
    }
    return () => {
      stopCameraStream();
    };
  }, [isOpen, activeTab, startCamera, stopCameraStream]);

  // Copy barcode to clipboard
  const handleCopyBarcode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedBarcode(true);
    setTimeout(() => setCopiedBarcode(false), 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto no-print">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white p-4 sm:p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/20 border border-blue-400/30 flex items-center justify-center text-blue-300">
              <Scan className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white">مسح بطاقة تلميذ في السجل</h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-500/30 text-blue-200 border border-blue-400/30">
                  بحث فوري
                </span>
              </div>
              <p className="text-xs text-blue-200/80">
                استدعاء بيانات التلميذ وعرض بطاقته فورياً عبر قارئ الباركود أو الكاميرا
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-blue-200 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Selector Tabs */}
        <div className="flex border-b border-slate-200 bg-slate-50/70 p-2 gap-2 text-xs font-semibold">
          <button
            type="button"
            onClick={() => {
              setActiveTab('laser');
              setTimeout(() => inputRef.current?.focus(), 100);
            }}
            className={`flex-1 py-2 px-3 rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeTab === 'laser'
                ? 'bg-white text-blue-900 shadow-xs border border-slate-200'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Keyboard className="w-4 h-4 text-blue-600" />
            <span>قارئ الباركود (مسدس ليزري / لوحة المفاتيح)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('camera')}
            className={`flex-1 py-2 px-3 rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeTab === 'camera'
                ? 'bg-white text-blue-900 shadow-xs border border-slate-200'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Camera className="w-4 h-4 text-slate-600" />
            <span>كاميرا الجهاز (مسح بصري)</span>
          </button>
        </div>

        {/* Body Content */}
        <div className="p-4 sm:p-5 space-y-4">
          {/* Laser Scanner Mode */}
          {activeTab === 'laser' && (
            <div className="space-y-3">
              <div className="p-3.5 bg-blue-50/60 border border-blue-200/80 rounded-xl flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 text-blue-950 font-medium">
                  <span className="relative flex h-2.5 w-2.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-blue-600"></span>
                  </span>
                  <span>القارئ الليزري جاهز: وجّه المسدس نحو الباركود واضغط الزناد للمسح التلقائي</span>
                </div>
                <span className="text-[11px] bg-blue-100/80 text-blue-800 px-2 py-0.5 rounded-md font-mono">
                  Enter Auto-detect
                </span>
              </div>

              {/* Direct Input Form */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleProcessCode(manualCode);
                }}
                className="flex gap-2"
              >
                <div className="relative flex-1">
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none">
                    <Scan className="w-4 h-4" />
                  </div>
                  <input
                    ref={inputRef}
                    type="text"
                    value={manualCode}
                    onChange={(e) => setManualCode(e.target.value)}
                    placeholder="امسح بالمسدس أو اكتب رقم الباركود / المعرف الوطني ثم اضغط بحث..."
                    className="w-full pr-9 pl-3 py-2.5 text-xs font-mono-numbers rounded-xl border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition-all"
                  />
                  {manualCode && (
                    <button
                      type="button"
                      onClick={() => setManualCode('')}
                      className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5 cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={!manualCode.trim()}
                  className="px-4 py-2.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 shrink-0 shadow-2xs"
                >
                  <Search className="w-3.5 h-3.5" />
                  <span>بحث</span>
                </button>
              </form>
            </div>
          )}

          {/* Camera Scanner Mode */}
          {activeTab === 'camera' && (
            <div className="space-y-3">
              {cameraError ? (
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <p className="font-bold">خطأ في فتح الكاميرا:</p>
                    <p>{cameraError}</p>
                    <button
                      type="button"
                      onClick={startCamera}
                      className="mt-2 text-xs font-bold text-slate-700 underline cursor-pointer inline-flex items-center gap-1"
                    >
                      <RefreshCw className="w-3 h-3" /> إعادة المحاولة
                    </button>
                  </div>
                </div>
              ) : (
                <div className="relative aspect-video max-h-56 bg-slate-900 rounded-xl overflow-hidden flex items-center justify-center border border-slate-800 shadow-inner">
                  <video
                    ref={videoRef}
                    playsInline
                    muted
                    className="w-full h-full object-cover"
                  />

                  {/* Scanning Overlay Reticle */}
                  <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                    <div className="w-56 h-36 border-2 border-slate-400/80 rounded-xl relative shadow-lg">
                      <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-slate-300"></div>
                      <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-slate-300"></div>
                      <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-slate-300"></div>
                      <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-slate-300"></div>
                      {/* Animated scanning bar */}
                      <div className="absolute inset-x-2 h-0.5 bg-gradient-to-r from-transparent via-slate-400 to-transparent animate-pulse top-1/2 -translate-y-1/2"></div>
                    </div>
                  </div>

                  {/* Camera Controls Bar Overlay */}
                  <div className="absolute bottom-2 inset-x-2 flex items-center justify-between px-2 py-1 bg-black/50 backdrop-blur-xs rounded-lg text-white text-[11px]">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-slate-400 animate-ping"></span>
                      <span>وجّه الكاميرا نحو باركود البطاقة</span>
                    </div>

                    <div className="flex items-center gap-2">
                      {torchSupported && streamRef.current && (
                        <button
                          type="button"
                          onClick={async () => {
                            if (streamRef.current) {
                              const next = !torchEnabled;
                              const ok = await toggleTorch(streamRef.current, next);
                              if (ok) setTorchEnabled(next);
                            }
                          }}
                          className={`p-1 rounded-md text-xs cursor-pointer ${
                            torchEnabled ? 'bg-amber-400 text-slate-900 font-bold' : 'hover:bg-white/20'
                          }`}
                          title="تشغيل الفلاش"
                        >
                          {torchEnabled ? <Zap className="w-3.5 h-3.5" /> : <ZapOff className="w-3.5 h-3.5" />}
                        </button>
                      )}

                      {availableCameras.length > 1 && (
                        <select
                          value={selectedCameraId}
                          onChange={(e) => setSelectedCameraId(e.target.value)}
                          className="bg-slate-800 text-white text-[10px] px-2 py-0.5 rounded border border-slate-700 cursor-pointer"
                        >
                          {availableCameras.map((cam, idx) => (
                            <option key={cam.deviceId || idx} value={cam.deviceId}>
                              {cam.label || `كاميرا ${idx + 1}`}
                            </option>
                          ))}
                        </select>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Result Section */}
          {scanStatus === 'success' && matchedStudent && (
            <div className="p-4 bg-slate-50/70 border-2 border-slate-500/80 rounded-2xl space-y-3.5 shadow-sm animate-in fade-in zoom-in-95 duration-150">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-slate-600 text-white font-bold flex items-center justify-center text-lg shadow-sm">
                    {matchedStudent.gender === 'F' ? '👧' : '👦'}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-600 text-white flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> تم العثور على التلميذ
                      </span>
                      <span className="text-xs text-slate-500 font-mono-numbers">
                        #{matchedStudent.id}
                      </span>
                    </div>
                    <h4 className="text-base font-bold text-slate-900 mt-0.5">
                      {matchedStudent.lastName} {matchedStudent.firstName}
                    </h4>
                  </div>
                </div>

                <div className="text-left">
                  <span className="inline-block bg-slate-100 text-slate-800 font-bold text-xs px-2.5 py-1 rounded-lg border border-slate-200">
                    قسم {matchedStudent.classroom}
                  </span>
                  <div className="text-[11px] text-slate-500 font-medium mt-1">
                    المستوى: {matchedStudent.grade}
                  </div>
                </div>
              </div>

              {/* Detail fields */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 p-2.5 bg-white/90 rounded-xl border border-slate-100 text-xs">
                <div>
                  <span className="text-[10px] text-slate-500 block">رقم التعريف / الباركود:</span>
                  <div className="flex items-center gap-1 mt-0.5">
                    <span className="font-mono-numbers font-bold text-slate-900">
                      {matchedStudent.barcode}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleCopyBarcode(matchedStudent.barcode)}
                      className="text-slate-400 hover:text-slate-700 p-0.5 cursor-pointer"
                      title="نسخ الباركود"
                    >
                      {copiedBarcode ? (
                        <Check className="w-3 h-3 text-slate-600" />
                      ) : (
                        <Copy className="w-3 h-3" />
                      )}
                    </button>
                  </div>
                </div>

                <div>
                  <span className="text-[10px] text-slate-500 block">الميلاد:</span>
                  <span className="font-mono-numbers font-medium text-slate-800">
                    {matchedStudent.birthDate} ({matchedStudent.birthPlace})
                  </span>
                </div>

                <div>
                  <span className="text-[10px] text-slate-500 block">ولي الأمر:</span>
                  <div className="flex items-center gap-1">
                    <span className="font-medium text-slate-800 truncate">
                      {matchedStudent.guardianName || 'غير مسجل'}
                    </span>
                    {matchedStudent.guardianPhone && (
                      <a
                        href={`tel:${matchedStudent.guardianPhone}`}
                        className="text-blue-600 hover:text-blue-800 p-0.5"
                        title="اتصال بالولي"
                      >
                        <Phone className="w-3 h-3" />
                      </a>
                    )}
                  </div>
                </div>
              </div>

              {/* Action Buttons for this student */}
              <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-200/60">
                <button
                  type="button"
                  onClick={() => onViewStudentCard(matchedStudent)}
                  className="flex-1 min-w-[140px] flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-bold rounded-xl bg-slate-700 hover:bg-slate-800 text-white transition-all shadow-xs cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>عرض البطاقة المدرسية</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    onEditStudent(matchedStudent);
                    onClose();
                  }}
                  className="flex-1 min-w-[130px] flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-bold rounded-xl bg-blue-600 hover:bg-blue-700 text-white transition-all shadow-xs cursor-pointer"
                >
                  <Edit className="w-3.5 h-3.5" />
                  <span>تعديل البيانات</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    onSelectInRegistry(matchedStudent);
                    onClose();
                  }}
                  className="flex-1 min-w-[130px] flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 transition-all border border-slate-300 cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>إظهار في السجل</span>
                </button>
              </div>
            </div>
          )}

          {/* Not Found Section */}
          {scanStatus === 'not_found' && lastScannedCode && (
            <div className="p-4 bg-amber-50 border border-amber-300 rounded-2xl space-y-3 animate-in fade-in duration-150">
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
                  <AlertCircle className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-xs sm:text-sm">
                    لم يُعثر على تلميذ مسجل بهذا الرمز:
                  </h4>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="font-mono-numbers font-bold text-slate-700 bg-white px-2 py-0.5 rounded border border-amber-200 text-xs">
                      {lastScannedCode}
                    </span>
                    <span className="text-[11px] text-slate-500">
                      (المرشحات المعيارية: {getBarcodeCandidates(lastScannedCode).join(' أو ')})
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-600 mt-1">
                    تأكد من أن بطاقة التلميذ مطبوعة ومسجلة في قاعدة البيانات أو قم بإضافة التلميذ الآن.
                  </p>
                </div>
              </div>

              {onAddNewWithBarcode && (
                <div className="pt-1 flex justify-end">
                  <button
                    type="button"
                    onClick={() => {
                      onAddNewWithBarcode(lastScannedCode);
                      onClose();
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-slate-800 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-xl cursor-pointer transition-colors shadow-2xs"
                  >
                    <UserPlus className="w-3.5 h-3.5 text-slate-700" />
                    <span>إضافة تلميذ جديد بهذا الباركود ({lastScannedCode})</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* History of Recent Scans in This Session */}
          {scanHistory.length > 0 && (
            <div className="space-y-2 pt-2 border-t border-slate-100">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="flex items-center gap-1.5 font-semibold text-slate-700">
                  <History className="w-3.5 h-3.5 text-slate-400" />
                  <span>تلاميذ تم مسح بطاقاتهم في هذه الجلسة ({scanHistory.length}):</span>
                </span>
                <button
                  type="button"
                  onClick={() => setScanHistory([])}
                  className="text-[11px] text-slate-400 hover:text-slate-600 underline cursor-pointer"
                >
                  مسح السجل
                </button>
              </div>

              <div className="flex flex-wrap gap-2 max-h-24 overflow-y-auto p-1">
                {scanHistory.map((item, idx) => (
                  <button
                    key={`${item.student.id}-${idx}`}
                    type="button"
                    onClick={() => {
                      setMatchedStudent(item.student);
                      setScanStatus('success');
                      setLastScannedCode(item.student.barcode);
                    }}
                    className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-xs cursor-pointer transition-all ${
                      matchedStudent?.id === item.student.id
                        ? 'bg-blue-50 border-blue-400 text-blue-900 font-bold ring-1 ring-blue-300'
                        : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700'
                    }`}
                  >
                    <span className="font-semibold">
                      {item.student.lastName} {item.student.firstName}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono-numbers">
                      ({item.student.classroom})
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-4 py-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <QrCode className="w-4 h-4 text-slate-400" />
            <span>يدعم معايير Code 128 و QR و EAN والمحارف الفرنسية AZERTY</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
