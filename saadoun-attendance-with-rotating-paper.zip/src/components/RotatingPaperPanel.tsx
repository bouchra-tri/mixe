import React, { useCallback, useEffect, useRef, useState } from 'react';
import { SchoolSettings } from '../types';

/** Same-origin module; its document keeps print rules separate from attendance. */
export function RotatingPaperPanel({ settings }: { settings: SchoolSettings }) {
  const frame = useRef<HTMLIFrameElement>(null);
  const [ready, setReady] = useState(false);
  const [attempt, setAttempt] = useState(0);
  const sendContext = useCallback(() => {
    frame.current?.contentWindow?.postMessage({
      type: 'saadoun:paper-context',
      school: {
        schoolName: settings.schoolName,
        academicYear: settings.academicYear,
        wilaya: settings.wilaya,
      },
    }, window.location.origin);
  }, [settings.schoolName, settings.academicYear, settings.wilaya]);

  useEffect(() => {
    const receive = (event: MessageEvent) => {
      if (event.origin !== window.location.origin || event.source !== frame.current?.contentWindow) return;
      if (event.data?.type === 'saadoun:paper-ready') sendContext();
      if (event.data?.type === 'saadoun:paper-mounted') setReady(true);
    };
    window.addEventListener('message', receive);
    sendContext();
    return () => window.removeEventListener('message', receive);
  }, [sendContext]);

  return (
    <section aria-label="الورقة الدوارة" className="w-full min-w-0 space-y-2">
      <div className="no-print flex flex-wrap items-center justify-between gap-2 px-2 text-xs text-slate-600 dark:text-slate-300">
        <p>بيانات المؤسسة مرتبطة بإعدادات منصة الحضور. احفظ جداول الورقة الدوارة من زر «حفظ كملف».</p>
        <button type="button" onClick={() => { setReady(false); setAttempt(value => value + 1); }}
          className="rounded-lg border border-slate-300 px-3 py-1.5 hover:bg-slate-100 dark:hover:bg-slate-800">
          إعادة تحميل القسم
        </button>
      </div>
      {!ready && <p role="status" className="px-3 py-2 text-sm">جارٍ فتح الورقة الدوارة…</p>}
      <iframe key={attempt} ref={frame} src="/rotating-paper.html" title="إدارة الورقة الدوارة وجداول التوقيت"
        onLoad={sendContext} allow="fullscreen"
        className="w-full rounded-xl border border-slate-200 bg-white dark:border-slate-700"
        style={{ height: 'calc(100dvh - 180px)', minHeight: 640 }} />
    </section>
  );
}
