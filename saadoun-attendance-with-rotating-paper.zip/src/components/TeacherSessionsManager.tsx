import React, { useState, useEffect } from 'react';
import { SchoolSettings, Student, AttendanceRecord, TimetableSession } from '../types';
import { TEACHERS, INITIAL_TIMETABLE_SESSIONS, DAYS_OF_WEEK, TIMETABLE_SLOTS, SUBJECT_INFO, getSchoolDay } from '../data/timetableData';
import { 
  Calendar, 
  Clock, 
  User, 
  BookOpen, 
  School, 
  Search, 
  AlertCircle, 
  CheckCircle2, 
  XCircle, 
  Filter, 
  Printer, 
  Phone, 
  Mail, 
  Sparkles,
  Users,
  FileText
} from 'lucide-react';

interface TeacherSessionsManagerProps {
  settings: SchoolSettings;
  students: Student[];
  records?: AttendanceRecord[];
  onRefreshData?: () => void;
}

export const TeacherSessionsManager: React.FC<TeacherSessionsManagerProps> = ({
  settings,
  students,
  records = [],
  onRefreshData,
}) => {
  const [activeTab, setActiveTab] = useState<'schedules' | 'absences_by_subject' | 'teachers_list'>('schedules');
  const [selectedTeacherId, setSelectedTeacherId] = useState<string>(TEACHERS[0]?.id || '');
  const [selectedDay, setSelectedDay] = useState<string>(getSchoolDay());
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterSubject, setFilterSubject] = useState<string>('all');

  // Load local records if none passed
  const [allRecords, setAllRecords] = useState<AttendanceRecord[]>(records);

  useEffect(() => {
    if (records && records.length > 0) {
      setAllRecords(records);
    } else {
      const stored = localStorage.getItem('saadoun_achour_records_v1');
      if (stored) {
        try {
          setAllRecords(JSON.parse(stored));
        } catch {
          setAllRecords([]);
        }
      }
    }
  }, [records]);

  // Current selected teacher
  const currentTeacher = TEACHERS.find((t) => t.id === selectedTeacherId) || TEACHERS[0];

  // Filtered teachers list
  const filteredTeachers = TEACHERS.filter((t) => {
    const matchesSearch = t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          t.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          t.username.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSubject = filterSubject === 'all' || t.subject === filterSubject;
    return matchesSearch && matchesSubject;
  });

  // Get sessions for selected teacher
  const teacherSessions = INITIAL_TIMETABLE_SESSIONS.filter((s) => s.teacherId === currentTeacher?.id);

  // Subject-wise absence analysis for selectedDate
  // Match attendance records for selectedDate with timetable sessions
  const dateRecords = allRecords.filter((r) => r.date === selectedDate);
  const absentRecords = dateRecords.filter((r) => r.status === 'absent');

  // Group absences by classroom and session
  // For each absent student, determine which subject they missed based on their classroom timetable for selectedDay
  const dayName = getSchoolDay(selectedDate);

  const studentSubjectAbsences = absentRecords.map((rec) => {
    // Find student
    const student = students.find((s) => s.id === rec.studentId || s.barcode === rec.barcode);
    const classroom = student?.classroom || rec.classroom;
    
    // Find timetable sessions for this classroom and day
    const classSessions = INITIAL_TIMETABLE_SESSIONS.filter(
      (s) => s.classroom === classroom && s.day === dayName
    );

    return {
      record: rec,
      student,
      classroom,
      classSessions,
    };
  });

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6" dir="rtl">
      {/* Top Banner Header */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-teal-900 text-white rounded-3xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute left-0 top-0 w-96 h-96 bg-slate-800/20 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5 mb-2">
              <span className="px-3 py-1 bg-slate-800/80 border border-slate-600/40 rounded-full text-xs font-bold text-slate-200">
                {settings.schoolName} · قطاع الأساتذة والتواقيت
              </span>
              <span className="px-3 py-1 bg-amber-500/20 border border-amber-400/40 rounded-full text-xs font-bold text-amber-300">
                35 أستاذاً رسمياً
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              إدارة تواقيت الأساتذة ومتابعة غيابات التلاميذ حسب المواد
            </h1>
            <p className="text-slate-200 text-xs sm:text-sm mt-1 max-w-2xl">
              استعرض الجداول الزمنية الأسبوعية للأساتذة وتعرف بدقة على التلميذ الغائب في أي مادة وحصة دراسية وفق التوقيت الرسمي للمؤسسة.
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={handlePrint}
              className="px-4 py-2.5 bg-white/10 hover:bg-white/20 border border-white/20 rounded-2xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-sm"
            >
              <Printer className="w-4 h-4 text-slate-200" />
              <span>طباعة الجدول</span>
            </button>
            <button
              type="button"
              onClick={onRefreshData}
              className="px-4 py-2.5 bg-slate-600 hover:bg-slate-500 rounded-2xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-md text-white"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>تحديث البيانات</span>
            </button>
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex flex-wrap items-center gap-2 bg-white p-2 rounded-2xl shadow-sm border border-slate-200">
        <button
          type="button"
          onClick={() => setActiveTab('schedules')}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === 'schedules'
              ? 'bg-slate-800 text-white shadow-md'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>تواقيت وجداول الأساتذة</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('absences_by_subject')}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === 'absences_by_subject'
              ? 'bg-slate-800 text-white shadow-md'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>معرفة التلميذ الغائب في أي مادة</span>
          {absentRecords.length > 0 && (
            <span className="bg-slate-500 text-white text-[10px] px-2 py-0.5 rounded-full font-mono">
              {absentRecords.length}
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('teachers_list')}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === 'teachers_list'
              ? 'bg-slate-800 text-white shadow-md'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>قائمة أساتذة المؤسسة ({TEACHERS.length})</span>
        </button>
      </div>

      {/* ================= TAB 1: TEACHER SCHEDULES ================= */}
      {activeTab === 'schedules' && (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar: Teacher Selection */}
          <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-200 lg:col-span-1 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-xs text-slate-800 flex items-center gap-1.5">
                <User className="w-4 h-4 text-slate-700" />
                <span>اختر الأستاذ لعرض جدوله</span>
              </h3>
              <span className="text-[10px] bg-slate-100 px-2 py-0.5 rounded-full font-mono text-slate-600 font-bold">
                {filteredTeachers.length} أستاذ
              </span>
            </div>

            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute right-3 top-2.5 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحث باسم الأستاذ أو المادة..."
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl pr-9 pl-3 py-2 text-slate-800 focus:outline-slate-600"
              />
            </div>

            {/* Subject Filter */}
            <div className="relative">
              <select
                value={filterSubject}
                onChange={(e) => setFilterSubject(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 font-bold cursor-pointer"
              >
                <option value="all">-- كافة المواد الدراسية --</option>
                {Object.keys(SUBJECT_INFO).map((subj) => (
                  <option key={subj} value={subj}>{subj}</option>
                ))}
              </select>
            </div>

            <div className="max-h-[500px] overflow-y-auto space-y-1.5 pr-1">
              {filteredTeachers.map((t) => {
                const isSelected = t.id === selectedTeacherId;
                return (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => setSelectedTeacherId(t.id)}
                    className={`w-full text-right p-3 rounded-2xl transition-all cursor-pointer flex items-center justify-between border ${
                      isSelected
                        ? 'bg-slate-50 border-slate-300 text-slate-950 shadow-xs'
                        : 'bg-white border-slate-100 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div>
                      <div className="font-extrabold text-xs">{t.name}</div>
                      <div className="text-[11px] text-slate-500 flex items-center gap-2 mt-0.5">
                        <span className="font-semibold text-slate-800">{t.subject}</span>
                        <span>·</span>
                        <span>{t.weeklyHours} ساعات أسبوعياً</span>
                      </div>
                    </div>
                    <span className="text-[10px] bg-slate-100 px-2 py-1 rounded-lg font-mono font-bold text-slate-600">
                      {t.assignedClasses.join(', ')}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Main Schedule Grid for Selected Teacher */}
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200 lg:col-span-3 space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-4 border-b border-slate-100 gap-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-900 flex items-center justify-center font-extrabold text-base shadow-inner">
                  {currentTeacher?.name.charAt(2) || 'أ'}
                </div>
                <div>
                  <h2 className="font-extrabold text-base sm:text-lg text-slate-900">
                    {currentTeacher?.name}
                  </h2>
                  <p className="text-xs text-slate-500 flex items-center gap-2 mt-0.5">
                    <span className="font-bold text-slate-800">{currentTeacher?.subject}</span>
                    <span>·</span>
                    <span>الأقسام المسندة: {currentTeacher?.assignedClasses.join('، ')}</span>
                    <span>·</span>
                    <span className="font-mono">({currentTeacher?.weeklyHours} س أسبوعياً)</span>
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 text-xs bg-slate-50 text-slate-900 px-3 py-2 rounded-xl font-bold border border-slate-200">
                <Phone className="w-3.5 h-3.5 text-slate-700" />
                <span className="font-mono">{currentTeacher?.phone}</span>
              </div>
            </div>

            {/* Timetable Matrix */}
            <div className="overflow-x-auto">
              <table className="w-full text-right border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 border-b border-slate-200">
                    <th className="p-3 font-bold rounded-r-xl">اليوم / الحصة</th>
                    {TIMETABLE_SLOTS.map((slot) => (
                      <th key={slot.id} className="p-3 text-center font-bold">
                        <div>{slot.label}</div>
                        <div className="text-[10px] text-slate-400 font-mono">{slot.timeRange}</div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {DAYS_OF_WEEK.map((day) => {
                    return (
                      <tr key={day.key} className="hover:bg-slate-50/80 transition-colors">
                        <td className="p-3 font-bold bg-slate-50/50 text-slate-800 rounded-r-xl">
                          {day.label}
                        </td>
                        {TIMETABLE_SLOTS.map((slot) => {
                          const session = teacherSessions.find(
                            (s) => s.day === day.key && s.slotId === slot.id
                          );

                          return (
                            <td key={slot.id} className="p-2 text-center border-r border-slate-100">
                              {session ? (
                                <div className="p-2 rounded-xl bg-slate-50/80 border border-slate-200 text-slate-950 shadow-2xs space-y-0.5">
                                  <div className="font-extrabold text-[11px] text-slate-900">
                                    {session.classroom}
                                  </div>
                                  <div className="text-[10px] text-slate-600 font-medium">
                                    {session.room}
                                  </div>
                                </div>
                              ) : (
                                <span className="text-slate-300 text-xs">—</span>
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="p-3 bg-slate-50 rounded-2xl text-[11px] text-slate-600 flex items-center justify-between">
              <span>جميع الحصص مسجلة وفق التوقيت الرسمي لمؤسسة سعدون عاشور (عنابة).</span>
              <span className="font-bold text-slate-800">إجمالي الحصص المعروضة: {teacherSessions.length} حصة</span>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 2: ABSENCES BY SUBJECT ================= */}
      {activeTab === 'absences_by_subject' && (
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200 space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div>
              <h2 className="font-extrabold text-base sm:text-lg text-slate-900 flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-slate-700" />
                <span>معرفة التلميذ الغائب في أي مادة وحصة دراسية</span>
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                مطابقة فورية بين سجلات غياب التلاميذ وتواقيت الأساتذة الرسمية حسب اليوم والحصة.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div>
                <label className="block text-[10px] font-bold text-slate-500 mb-1">تاريخ المعاينة:</label>
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="text-xs font-bold bg-slate-50 border border-slate-300 rounded-xl px-3 py-1.5 text-slate-800 font-mono"
                />
              </div>
            </div>
          </div>

          {/* Absence Results Table */}
          {studentSubjectAbsences.length === 0 ? (
            <div className="text-center py-16 bg-slate-50 rounded-3xl border border-dashed border-slate-200 space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-800 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-sm text-slate-800">لا توجد غيابات مسجلة في هذا التاريخ</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                جميع التلاميذ مسجلون كحاضرين أو لم يتم تسجيل غيابات لتاريخ {selectedDate}.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-right border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 border-b border-slate-200">
                    <th className="p-3 font-bold rounded-r-xl">التلميذ</th>
                    <th className="p-3 font-bold">القسم</th>
                    <th className="p-3 font-bold">الحصة / التوقيت</th>
                    <th className="p-3 font-bold">المادة المتضررة</th>
                    <th className="p-3 font-bold">الأستاذ المسؤول</th>
                    <th className="p-3 font-bold rounded-l-xl">الحالة والملاحظة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {studentSubjectAbsences.map(({ record, student, classroom, classSessions }, idx) => {
                    // Match session slot if record has session or time
                    const matchedSession = classSessions.find((s) => s.slotId === record.session) || classSessions[0];
                    const subject = matchedSession?.subject || 'مادة عامة';
                    const teacherName = matchedSession?.teacherName || 'أستاذ القسم';

                    return (
                      <tr key={idx} className="hover:bg-slate-50/80 transition-colors">
                        <td className="p-3 font-extrabold text-slate-900 rounded-r-xl">
                          <div className="flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-slate-500" />
                            <span>{record.studentName}</span>
                          </div>
                          {student?.nationalId && (
                            <span className="text-[10px] text-slate-400 font-mono">ر.ت: {student.nationalId}</span>
                          )}
                        </td>
                        <td className="p-3 font-bold text-slate-900">
                          <span className="px-2.5 py-1 bg-slate-50 border border-slate-200 rounded-lg">
                            {classroom}
                          </span>
                        </td>
                        <td className="p-3 font-mono text-slate-600">
                          {record.session || 'الحصة العامة'} ({record.timestamp})
                        </td>
                        <td className="p-3">
                          <span className="px-2.5 py-1 bg-amber-50 text-amber-900 border border-amber-200 rounded-lg font-bold">
                            {subject}
                          </span>
                        </td>
                        <td className="p-3 font-bold text-slate-800">
                          {teacherName}
                        </td>
                        <td className="p-3 rounded-l-xl">
                          <span className="px-2.5 py-1 bg-slate-50 text-slate-900 border border-slate-200 rounded-lg font-bold">
                            غائب {record.notes ? `(${record.notes})` : ''}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ================= TAB 3: TEACHERS LIST ================= */}
      {activeTab === 'teachers_list' && (
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200 space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div>
              <h2 className="font-extrabold text-base sm:text-lg text-slate-900 flex items-center gap-2">
                <Users className="w-5 h-5 text-slate-700" />
                <span>قائمة أساتذة متوسطة سعدون عاشور وتوزيع الأقسام</span>
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                إجمالي 35 أستاذاً يغطي مختلف المواد والأقسام الدراسية (1م إلى 4م).
              </p>
            </div>

            <div className="w-full sm:w-64">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="بحث سريع عن أستاذ أو مادة..."
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-800"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredTeachers.map((t) => (
              <div
                key={t.id}
                className="bg-slate-50/70 border border-slate-200 rounded-2xl p-4 hover:border-slate-300 transition-all shadow-2xs space-y-3"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-xl bg-slate-800 text-white flex items-center justify-center font-bold text-sm shadow-sm">
                      {t.name.charAt(2)}
                    </div>
                    <div>
                      <h3 className="font-extrabold text-xs sm:text-sm text-slate-900">{t.name}</h3>
                      <span className="text-[11px] font-bold text-slate-800">{t.subject}</span>
                    </div>
                  </div>
                  <span className="text-[10px] bg-white px-2 py-1 rounded-lg border border-slate-200 font-mono font-bold text-slate-600">
                    {t.weeklyHours} ساعة
                  </span>
                </div>

                <div className="space-y-1.5 text-[11px] text-slate-600 pt-2 border-t border-slate-200/60">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-500">الأقسام المسندة:</span>
                    <span className="font-mono font-bold text-slate-800 bg-white px-2 py-0.5 rounded border border-slate-200">
                      {t.assignedClasses.join('، ')}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-500">اسم المستخدم:</span>
                    <span className="font-mono text-slate-900 font-bold">@{t.username}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
