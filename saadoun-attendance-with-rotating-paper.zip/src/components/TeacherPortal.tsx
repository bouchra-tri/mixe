import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  AppUser,
  Student,
  SchoolSettings,
  TeacherAttendanceSession,
  TeacherStudentStatusRecord,
  TeacherAttendanceStatus,
  OfflineAttendanceDraft,
  TimetableSession,
} from '../types';
import {
  TIMETABLE_SLOTS,
  DAYS_OF_WEEK,
  TEACHERS,
  INITIAL_TIMETABLE_SESSIONS,
  getCurrentTeacherSession,
  getTeacherSessions,
  getSchoolDay,
} from '../data/timetableData';
import {
  apiSaveTeacherSession,
  apiGetTeacherSessions,
  apiLogout,
} from '../services/api';
import {
  CheckCircle2,
  XCircle,
  Clock,
  HelpCircle,
  Save,
  Send,
  Wifi,
  WifiOff,
  RefreshCw,
  LogOut,
  AlertTriangle,
  Lock,
  ChevronLeft,
  Search,
  CheckCheck,
  FileText,
  User,
  BookOpen,
  History,
  Calendar,
  MessageSquare,
  Shield,
  MapPin,
  Sparkles,
} from 'lucide-react';

interface TeacherPortalProps {
  user: AppUser;
  allStudents: Student[];
  settings: SchoolSettings;
  onLogout: () => void;
  onRefreshData?: () => void;
}

export type SyncState = 'idle' | 'saving' | 'synced' | 'offline_queued' | 'error';

export const TeacherPortal: React.FC<TeacherPortalProps> = ({
  user,
  allStudents,
  settings,
  onLogout,
  onRefreshData,
}) => {
  // Active Tab: 'record' (تسجيل الحضور) or 'timetable' (جدول توقيتي) or 'history' (سجل تسجيلاتي)
  const [activeTab, setActiveTab] = useState<'record' | 'timetable' | 'history'>('record');

  // Teacher profile and official weekly timetable
  const teacherProfile = useMemo(() => {
    return TEACHERS.find((t) => t.id === user.teacherId || t.username === user.username);
  }, [user.teacherId, user.username]);

  const currentOngoingSession = useMemo(() => {
    const tId = user.teacherId || teacherProfile?.id;
    if (!tId) return undefined;
    return getCurrentTeacherSession(tId, new Date());
  }, [user.teacherId, teacherProfile]);

  const myTimetableSessions = useMemo(() => {
    const tId = user.teacherId || teacherProfile?.id;
    if (!tId) return [];
    return getTeacherSessions(tId);
  }, [user.teacherId, teacherProfile]);

  // Form selections
  const assignedClasses = useMemo(() => {
    return user.assignedClassrooms && user.assignedClassrooms.length > 0
      ? user.assignedClassrooms
      : teacherProfile?.assignedClasses || ['1م1'];
  }, [user.assignedClassrooms, teacherProfile]);

  const [selectedClassroom, setSelectedClassroom] = useState<string>(assignedClasses[0] || '1م1');

  // Timezone-aware today date (Africa/Algiers)
  const todayStr = useMemo(() => {
    try {
      const now = new Date();
      return new Intl.DateTimeFormat('en-CA', {
        timeZone: settings.timezone || 'Africa/Algiers',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
      }).format(now);
    } catch {
      return new Date().toISOString().split('T')[0];
    }
  }, [settings.timezone]);

  const [selectedDate, setSelectedDate] = useState<string>(todayStr);
  const [selectedPeriodId, setSelectedPeriodId] = useState<string>('p1');
  const [selectedSubject, setSelectedSubject] = useState<string>(
    user.assignedSubjects?.[0] || teacherProfile?.subject || 'المادة التعليمية'
  );

  // Active room info for the currently selected session
  const activeRoomInfo = useMemo(() => {
    const day = getSchoolDay(selectedDate);
    const matched = INITIAL_TIMETABLE_SESSIONS.find(
      (s) =>
        (s.classroom === selectedClassroom || s.classroom.replace('AM', 'م') === selectedClassroom) &&
        s.day === day &&
        s.slotId === selectedPeriodId
    );
    return matched?.room;
  }, [selectedClassroom, selectedDate, selectedPeriodId]);

  const jumpToSession = (session: TimetableSession) => {
    setSelectedClassroom(session.classroom);
    setSelectedPeriodId(session.slotId);
    setSelectedSubject(session.subject);
    setSelectedDate(todayStr);
    setActiveTab('record');
  };

  // Student roster for selected class
  const classStudents = useMemo(() => {
    return allStudents.filter((s) => s.classroom === selectedClassroom);
  }, [allStudents, selectedClassroom]);

  // Attendance records map for active editing: studentId -> record
  const [studentStatuses, setStudentStatuses] = useState<Record<string, TeacherStudentStatusRecord>>({});
  const [activeNoteStudentId, setActiveNoteStudentId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Active loaded session metadata (if loading an existing session)
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [activeSessionStatus, setActiveSessionStatus] = useState<'draft' | 'submitted' | 'approved' | 'locked'>('draft');
  const [expectedUpdatedAt, setExpectedUpdatedAt] = useState<string | undefined>(undefined);

  // Sync / Offline status state: 'جارٍ الحفظ' | 'تم الحفظ على الخادم' | 'بانتظار الاتصال' | 'فشل الحفظ'
  const [syncState, setSyncState] = useState<SyncState>('idle');
  const [syncMessage, setSyncMessage] = useState<string>('متصل بالخادم');
  const [lastSavedTime, setLastSavedTime] = useState<string>('');
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);

  // Teacher sessions history
  const [mySessions, setMySessions] = useState<TeacherAttendanceSession[]>([]);
  const [isLoadingSessions, setIsLoadingSessions] = useState<boolean>(false);
  const [historyFilterDate, setHistoryFilterDate] = useState<string>('');

  // Confirmation modal for final submit
  const [isConfirmSubmitOpen, setIsConfirmSubmitOpen] = useState<boolean>(false);
  // Audit trail modal
  const [viewAuditSession, setViewAuditSession] = useState<TeacherAttendanceSession | null>(null);

  // Helper to load offline drafts from localStorage
  const getOfflineDrafts = useCallback((): Record<string, OfflineAttendanceDraft> => {
    try {
      const raw = localStorage.getItem(`saadoun_teacher_drafts_${user.id}`);
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  }, [user.id]);

  const saveOfflineDraft = useCallback(
    (draft: OfflineAttendanceDraft) => {
      try {
        const drafts = getOfflineDrafts();
        drafts[draft.sessionId] = draft;
        localStorage.setItem(`saadoun_teacher_drafts_${user.id}`, JSON.stringify(drafts));
      } catch (e) {
        console.warn('Failed to save offline draft', e);
      }
    },
    [getOfflineDrafts, user.id]
  );

  const removeOfflineDraft = useCallback(
    (sessionId: string) => {
      try {
        const drafts = getOfflineDrafts();
        delete drafts[sessionId];
        localStorage.setItem(`saadoun_teacher_drafts_${user.id}`, JSON.stringify(drafts));
      } catch (e) {
        console.warn('Failed to remove offline draft', e);
      }
    },
    [getOfflineDrafts, user.id]
  );

  // Initialize or reset students list when class changes
  useEffect(() => {
    // If a session already exists for (date, classroom, period), try to find it in mySessions or initialize blank
    const compositeId = `SES-${selectedDate}-${selectedClassroom.replace(/\s+/g, '')}-${selectedPeriodId}`;
    const existing = mySessions.find(
      (s) => s.id === compositeId || (s.date === selectedDate && s.classroom === selectedClassroom && s.periodId === selectedPeriodId)
    );

    if (existing) {
      setActiveSessionId(existing.id);
      setActiveSessionStatus(existing.status);
      setExpectedUpdatedAt(existing.updatedAt);

      const map: Record<string, TeacherStudentStatusRecord> = {};
      existing.records.forEach((r) => {
        map[r.studentId] = r;
      });
      // Fill any missing students as 'unrecorded'
      classStudents.forEach((st) => {
        if (!map[st.id]) {
          map[st.id] = {
            studentId: st.id,
            studentName: `${st.lastName} ${st.firstName}`,
            status: 'unrecorded',
          };
        }
      });
      setStudentStatuses(map);
    } else {
      // Check offline draft
      const drafts = getOfflineDrafts();
      const draft = drafts[compositeId];
      if (draft) {
        setActiveSessionId(draft.sessionId);
        setActiveSessionStatus(draft.status);
        const map: Record<string, TeacherStudentStatusRecord> = {};
        draft.records.forEach((r) => {
          map[r.studentId] = r;
        });
        classStudents.forEach((st) => {
          if (!map[st.id]) {
            map[st.id] = {
              studentId: st.id,
              studentName: `${st.lastName} ${st.firstName}`,
              status: 'unrecorded',
            };
          }
        });
        setStudentStatuses(map);
      } else {
        // Fresh session: all students start UNRECORDED ('غير مسجل')
        setActiveSessionId(compositeId);
        setActiveSessionStatus('draft');
        setExpectedUpdatedAt(undefined);
        const initialMap: Record<string, TeacherStudentStatusRecord> = {};
        classStudents.forEach((st) => {
          initialMap[st.id] = {
            studentId: st.id,
            studentName: `${st.lastName} ${st.firstName}`,
            status: 'unrecorded',
          };
        });
        setStudentStatuses(initialMap);
      }
    }
  }, [selectedClassroom, selectedDate, selectedPeriodId, classStudents, mySessions, getOfflineDrafts]);

  // Load teacher sessions
  const loadMySessions = useCallback(async () => {
    setIsLoadingSessions(true);
    try {
      const data = await apiGetTeacherSessions({ teacherId: user.teacherId || user.id });
      setMySessions(data);
    } catch (e) {
      console.warn('Failed to load teacher sessions:', e);
    } finally {
      setIsLoadingSessions(false);
    }
  }, [user.id, user.teacherId]);

  useEffect(() => {
    loadMySessions();
  }, [loadMySessions]);

  // Online / Offline network event listeners
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setSyncMessage('عادت إشارة الإنترنت - جاري مزامنة المسودات المحفوظة...');
      syncOfflineQueue();
    };
    const handleOffline = () => {
      setIsOnline(false);
      setSyncState('offline_queued');
      setSyncMessage('بانتظار الاتصال (سيتم الحفظ محلياً)');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Sync queued offline drafts when online
  const syncOfflineQueue = async () => {
    const drafts = getOfflineDrafts();
    const draftKeys = Object.keys(drafts);
    if (draftKeys.length === 0) return;

    setSyncState('saving');
    setSyncMessage('جارٍ الحفظ على الخادم...');

    let syncedCount = 0;
    for (const key of draftKeys) {
      const draft = drafts[key];
      try {
        const payload: TeacherAttendanceSession = {
          id: draft.sessionId,
          date: draft.date,
          classroom: draft.classroom,
          grade: draft.grade,
          periodId: draft.periodId,
          periodLabel: draft.periodLabel,
          subject: draft.subject,
          teacherId: draft.teacherId,
          teacherName: draft.teacherName,
          teacherUsername: user.username,
          status: draft.status,
          records: draft.records,
          summary: computeSummary(draft.records),
          createdAt: draft.lastSavedLocal,
          updatedAt: new Date().toISOString(),
          auditTrail: [],
        };
        await apiSaveTeacherSession(payload);
        removeOfflineDraft(key);
        syncedCount++;
      } catch (err) {
        console.warn('Failed to sync draft:', key, err);
      }
    }

    if (syncedCount > 0) {
      setSyncState('synced');
      setSyncMessage(`تم الحفظ على الخادم بنجاح (${syncedCount} مسودة مُزامنة)`);
      loadMySessions();
      onRefreshData?.();
    }
  };

  // Compute summary numbers
  const computeSummary = (records: TeacherStudentStatusRecord[]) => {
    const total = records.length;
    let presentCount = 0;
    let absentCount = 0;
    let lateCount = 0;
    let unrecordedCount = 0;

    records.forEach((r) => {
      if (r.status === 'present') presentCount++;
      else if (r.status === 'absent') absentCount++;
      else if (r.status === 'late') lateCount++;
      else unrecordedCount++;
    });

    return { total, presentCount, absentCount, lateCount, unrecordedCount };
  };

  const currentSummary = useMemo(() => {
    return computeSummary(Object.values(studentStatuses));
  }, [studentStatuses]);

  // Is editing allowed? (Blocked if status is 'locked' or 'approved')
  const isReadOnly = activeSessionStatus === 'locked' || activeSessionStatus === 'approved';

  // Quick Action: Mark all students as present
  const handleMarkAllPresent = () => {
    if (isReadOnly) return;
    setStudentStatuses((prev) => {
      const next = { ...prev };
      Object.keys(next).forEach((id) => {
        next[id] = {
          ...next[id],
          status: 'present',
        };
      });
      return next;
    });
  };

  // Change individual student status
  const handleSetStudentStatus = (studentId: string, status: TeacherAttendanceStatus) => {
    if (isReadOnly) return;
    setStudentStatuses((prev) => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        status,
      },
    }));
  };

  // Update notes or late minutes
  const handleUpdateStudentDetails = (
    studentId: string,
    notes: string,
    lateMinutes?: number
  ) => {
    if (isReadOnly) return;
    setStudentStatuses((prev) => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        notes,
        lateMinutes: lateMinutes !== undefined ? lateMinutes : prev[studentId]?.lateMinutes,
      },
    }));
  };

  // Save session (as draft or submitted)
  const handleSaveSession = async (targetStatus: 'draft' | 'submitted') => {
    const recordsList = Object.values(studentStatuses);
    const summary = computeSummary(recordsList);

    // Rule: Do not allow final submission if unrecorded students remain
    if (targetStatus === 'submitted' && summary.unrecordedCount > 0) {
      alert(`تنبيه: لا يمكن اعتماد السجل النهائي مع وجود ${summary.unrecordedCount} تلميذ بحالة (غير مسجل). يرجى تحديد حالة جميع التلاميذ.`);
      return;
    }

    const slotMeta = TIMETABLE_SLOTS.find((s) => s.id === selectedPeriodId);
    const periodLabel = slotMeta ? `${slotMeta.label} (${slotMeta.timeRange})` : selectedPeriodId;
    const gradeVal = classStudents[0]?.grade || '1AM';
    const compositeId =
      activeSessionId || `SES-${selectedDate}-${selectedClassroom.replace(/\s+/g, '')}-${selectedPeriodId}`;

    const sessionPayload: TeacherAttendanceSession = {
      id: compositeId,
      date: selectedDate,
      classroom: selectedClassroom,
      grade: gradeVal,
      periodId: selectedPeriodId,
      periodLabel,
      subject: selectedSubject,
      teacherId: user.teacherId || user.id,
      teacherName: user.name,
      teacherUsername: user.username,
      status: targetStatus,
      records: recordsList,
      summary,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      auditTrail: [],
    };

    setSyncState('saving');
    setSyncMessage('جارٍ الحفظ على الخادم...');

    try {
      const res = await apiSaveTeacherSession(sessionPayload, expectedUpdatedAt);
      setSyncState('synced');
      setSyncMessage('تم الحفظ على الخادم');
      setLastSavedTime(new Date().toLocaleTimeString('ar-DZ'));
      setActiveSessionStatus(res.session.status);
      setExpectedUpdatedAt(res.session.updatedAt);
      removeOfflineDraft(compositeId);
      loadMySessions();
      onRefreshData?.();
      setIsConfirmSubmitOpen(false);
    } catch (err: any) {
      console.warn('Save failed, saving offline locally:', err);
      // Save offline draft locally
      const offlineDraft: OfflineAttendanceDraft = {
        localId: `LOC-${Date.now()}`,
        sessionId: compositeId,
        date: selectedDate,
        classroom: selectedClassroom,
        grade: gradeVal,
        periodId: selectedPeriodId,
        periodLabel,
        subject: selectedSubject,
        teacherId: user.teacherId || user.id,
        teacherName: user.name,
        records: recordsList,
        status: targetStatus,
        lastSavedLocal: new Date().toISOString(),
        syncState: 'pending',
        errorMessage: err.message,
      };
      saveOfflineDraft(offlineDraft);

      if (!navigator.onLine) {
        setSyncState('offline_queued');
        setSyncMessage('بانتظار الاتصال (محفوظ كمسودة محلية في الهاتف)');
      } else {
        setSyncState('error');
        setSyncMessage(err.message || 'فشل الحفظ - تم الاحتفاظ بنسخة على جهازك');
      }
      setIsConfirmSubmitOpen(false);
    }
  };

  // Load a session from History into the Recorder
  const handleLoadSessionFromHistory = (session: TeacherAttendanceSession) => {
    setSelectedClassroom(session.classroom);
    setSelectedDate(session.date);
    setSelectedPeriodId(session.periodId);
    setSelectedSubject(session.subject);
    setActiveSessionId(session.id);
    setActiveSessionStatus(session.status);
    setExpectedUpdatedAt(session.updatedAt);

    const map: Record<string, TeacherStudentStatusRecord> = {};
    session.records.forEach((r) => {
      map[r.studentId] = r;
    });
    setStudentStatuses(map);
    setActiveTab('record');
  };

  // Filtered students for display
  const filteredStudents = useMemo(() => {
    if (!searchQuery.trim()) return classStudents;
    const q = searchQuery.trim().toLowerCase();
    return classStudents.filter(
      (st) =>
        st.firstName.toLowerCase().includes(q) ||
        st.lastName.toLowerCase().includes(q) ||
        `${st.lastName} ${st.firstName}`.toLowerCase().includes(q) ||
        st.id.toLowerCase().includes(q)
    );
  }, [classStudents, searchQuery]);

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans pb-24 md:pb-8" dir="rtl">
      {/* ---------------- Top Mobile Header ---------------- */}
      <header className="bg-slate-900 text-white shadow-md sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center font-black text-sm text-slate-200">
              <User className="w-5 h-5 text-slate-300" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="font-bold text-sm sm:text-base leading-tight">{user.name}</h1>
                <span className="text-[10px] font-semibold bg-slate-800 text-slate-200 px-1.5 py-0.5 rounded border border-slate-700">
                  أستاذ
                </span>
              </div>
              <p className="text-[11px] text-slate-200 flex items-center gap-1.5 mt-0.5">
                <span>{selectedSubject}</span>
                <span className="text-slate-400">·</span>
                <span>{assignedClasses.length} أقسام مسندة</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onLogout}
              className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-slate-800/80 hover:bg-slate-900/80 text-slate-100 hover:text-white transition-colors cursor-pointer border border-slate-700/60"
              title="تسجيل الخروج"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">خروج</span>
            </button>
          </div>
        </div>

        {/* Real-time Connection / Save Status Bar */}
        <div
          className={`px-4 py-1.5 text-xs flex items-center justify-between transition-colors ${
            syncState === 'saving'
              ? 'bg-amber-600 text-white'
              : syncState === 'synced'
              ? 'bg-slate-800 text-slate-100'
              : syncState === 'offline_queued'
              ? 'bg-orange-700 text-white'
              : syncState === 'error'
              ? 'bg-slate-700 text-white'
              : 'bg-slate-950/60 text-slate-200'
          }`}
        >
          <div className="flex items-center gap-2 max-w-4xl mx-auto w-full justify-between">
            <div className="flex items-center gap-1.5">
              {syncState === 'saving' ? (
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-white" />
              ) : syncState === 'synced' ? (
                <CheckCircle2 className="w-3.5 h-3.5 text-slate-300" />
              ) : !isOnline || syncState === 'offline_queued' ? (
                <WifiOff className="w-3.5 h-3.5 text-orange-200" />
              ) : syncState === 'error' ? (
                <AlertTriangle className="w-3.5 h-3.5 text-slate-200" />
              ) : (
                <Wifi className="w-3.5 h-3.5 text-slate-400" />
              )}
              <span className="font-semibold text-[11px] sm:text-xs">
                {syncState === 'saving'
                  ? 'جارٍ الحفظ على الخادم...'
                  : syncState === 'synced'
                  ? 'تم الحفظ على الخادم'
                  : syncState === 'offline_queued'
                  ? 'بانتظار الاتصال'
                  : syncState === 'error'
                  ? 'فشل الحفظ'
                  : isOnline
                  ? 'متصل بالشبكة'
                  : 'غير متصل'}
              </span>
              {lastSavedTime && syncState === 'synced' && (
                <span className="text-[10px] text-slate-300 font-mono-numbers">
                  ({lastSavedTime})
                </span>
              )}
            </div>

            {/* If offline drafts exist, show count and retry button */}
            {Object.keys(getOfflineDrafts()).length > 0 && (
              <button
                type="button"
                onClick={syncOfflineQueue}
                className="text-[10px] font-bold underline cursor-pointer hover:text-white"
              >
                مزامنة ({Object.keys(getOfflineDrafts()).length}) مسودة
              </button>
            )}
          </div>
        </div>

        {/* Mobile Navigation Tabs: تسجيل الحضور & جدول توقيتي & سجل تسجيلاتي */}
        <div className="max-w-4xl mx-auto px-4 flex border-t border-slate-800/80 bg-slate-950/40">
          <button
            type="button"
            onClick={() => setActiveTab('record')}
            className={`flex-1 py-2.5 text-center text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 border-b-2 transition-all cursor-pointer ${
              activeTab === 'record'
                ? 'border-slate-400 text-white bg-white/5'
                : 'border-transparent text-slate-300 hover:text-white'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>تسجيل الحضور</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('timetable')}
            className={`flex-1 py-2.5 text-center text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 border-b-2 transition-all cursor-pointer ${
              activeTab === 'timetable'
                ? 'border-slate-400 text-white bg-white/5'
                : 'border-transparent text-slate-300 hover:text-white'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>جدول توقيتي</span>
            {myTimetableSessions.length > 0 && (
              <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-slate-700 text-white font-mono-numbers">
                {myTimetableSessions.length}
              </span>
            )}
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveTab('history');
              loadMySessions();
            }}
            className={`flex-1 py-2.5 text-center text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 border-b-2 transition-all cursor-pointer ${
              activeTab === 'history'
                ? 'border-slate-400 text-white bg-white/5'
                : 'border-transparent text-slate-300 hover:text-white'
            }`}
          >
            <History className="w-4 h-4" />
            <span>سجل تسجيلاتي</span>
            {mySessions.length > 0 && (
              <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-slate-700 text-white font-mono-numbers">
                {mySessions.length}
              </span>
            )}
          </button>
        </div>
      </header>

      {/* ---------------- Main Content ---------------- */}
      <main className="max-w-4xl mx-auto w-full px-3 sm:px-4 py-4 flex-1">
        {/* ==================================================== */}
        {/* TAB 1: Attendance Recording (تسجيل الحضور) */}
        {/* ==================================================== */}
        {activeTab === 'record' && (
          <div className="space-y-3.5">
            {/* Live Timetable Session Notification if active */}
            {currentOngoingSession && (
              <div className="bg-gradient-to-r from-slate-600 via-slate-700 to-teal-700 text-white rounded-2xl p-3.5 shadow-md flex items-center justify-between gap-3 animate-fade-in border border-slate-400/30">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
                    <Sparkles className="w-5 h-5 text-amber-300" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-[10px] font-bold bg-white/20 px-1.5 py-0.5 rounded text-slate-100">
                        حصة جارية الآن حسب جدول التوقيت
                      </span>
                      {currentOngoingSession.room && (
                        <span className="text-[10px] bg-slate-900/60 px-1.5 py-0.5 rounded font-bold text-amber-200">
                          {currentOngoingSession.room}
                        </span>
                      )}
                    </div>
                    <p className="font-extrabold text-sm sm:text-base mt-0.5">
                      قسم {currentOngoingSession.classroom} · {currentOngoingSession.subject}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => jumpToSession(currentOngoingSession)}
                  className="px-3.5 py-2 rounded-xl text-xs font-black bg-white text-slate-900 hover:bg-slate-50 active:scale-95 transition-all cursor-pointer shadow-sm shrink-0 flex items-center gap-1"
                >
                  <BookOpen className="w-3.5 h-3.5 text-slate-700" />
                  <span>تسجيل الآن</span>
                </button>
              </div>
            )}
            {/* Session Selector Card */}
            <div className="bg-white rounded-2xl p-3.5 sm:p-4 shadow-xs border border-slate-200">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 sm:gap-3">
                {/* Classroom Selector */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-500 mb-1">
                    القسم المخصص
                  </label>
                  <select
                    value={selectedClassroom}
                    onChange={(e) => setSelectedClassroom(e.target.value)}
                    className="w-full text-xs sm:text-sm font-bold bg-slate-50 border border-slate-300 rounded-xl px-2.5 py-2 text-slate-900 focus:outline-slate-600 cursor-pointer"
                  >
                    {assignedClasses.map((cls) => (
                      <option key={cls} value={cls}>
                        قسم {cls}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Date Picker */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-500 mb-1">التاريخ</label>
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="w-full text-xs sm:text-sm font-bold bg-slate-50 border border-slate-300 rounded-xl px-2.5 py-2 text-slate-900 focus:outline-slate-600 font-mono-numbers cursor-pointer"
                  />
                </div>

                {/* Period Slot */}
                <div className="col-span-2 sm:col-span-1">
                  <label className="block text-[11px] font-bold text-slate-500 mb-1">الحصة</label>
                  <select
                    value={selectedPeriodId}
                    onChange={(e) => setSelectedPeriodId(e.target.value)}
                    className="w-full text-xs sm:text-sm font-bold bg-slate-50 border border-slate-300 rounded-xl px-2.5 py-2 text-slate-900 focus:outline-slate-600 cursor-pointer"
                  >
                    {TIMETABLE_SLOTS.map((slot) => (
                      <option key={slot.id} value={slot.id}>
                        {slot.label} ({slot.timeRange})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Programmed Room / Location Indicator from Timetable */}
              {activeRoomInfo && (
                <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1.5 text-slate-500 font-semibold">
                    <MapPin className="w-3.5 h-3.5 text-slate-600" />
                    <span>القاعة / المخبر المبرمج:</span>
                  </span>
                  <span className="font-bold text-slate-900 bg-slate-50 px-2.5 py-0.5 rounded-lg border border-slate-200 font-mono-numbers">
                    {activeRoomInfo}
                  </span>
                </div>
              )}

              {/* Read-Only Status Banner if locked/approved */}
              {isReadOnly && (
                <div className="mt-3 p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-center gap-2">
                  <Lock className="w-4 h-4 text-amber-600 shrink-0" />
                  <div>
                    <span className="font-bold">
                      {activeSessionStatus === 'locked' ? 'هذا السجل مغلق نهائياً' : 'تم اعتماد هذا السجل من الإدارة'}
                    </span>
                    <span className="block text-[11px] text-amber-700 mt-0.5">
                      السجل للقراءة فقط. اتصل بمدير المؤسسة إذا كان هناك تصحيح مطلوب.
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* Summary Counters Pill Bar */}
            <div className="bg-white rounded-2xl p-3 shadow-xs border border-slate-200">
              <div className="grid grid-cols-4 gap-2 text-center">
                {/* Present */}
                <div className="bg-slate-50 border border-slate-200 rounded-xl py-2 px-1">
                  <span className="block text-[10px] font-bold text-slate-800">حاضر</span>
                  <span className="text-base sm:text-lg font-black text-slate-700 font-mono-numbers">
                    {currentSummary.presentCount}
                  </span>
                </div>

                {/* Absent */}
                <div className="bg-slate-50 border border-slate-200 rounded-xl py-2 px-1">
                  <span className="block text-[10px] font-bold text-slate-800">غائب</span>
                  <span className="text-base sm:text-lg font-black text-slate-700 font-mono-numbers">
                    {currentSummary.absentCount}
                  </span>
                </div>

                {/* Late */}
                <div className="bg-amber-50 border border-amber-200 rounded-xl py-2 px-1">
                  <span className="block text-[10px] font-bold text-amber-800">متأخر</span>
                  <span className="text-base sm:text-lg font-black text-amber-700 font-mono-numbers">
                    {currentSummary.lateCount}
                  </span>
                </div>

                {/* Unrecorded */}
                <div
                  className={`border rounded-xl py-2 px-1 ${
                    currentSummary.unrecordedCount > 0
                      ? 'bg-slate-100 border-slate-300 text-slate-800'
                      : 'bg-slate-100/50 border-slate-300 text-slate-900'
                  }`}
                >
                  <span className="block text-[10px] font-bold">غير مسجل</span>
                  <span className="text-base sm:text-lg font-black font-mono-numbers">
                    {currentSummary.unrecordedCount}
                  </span>
                </div>
              </div>

              {/* Fast Action: Mark All Present & Search */}
              <div className="mt-3 pt-3 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-2.5">
                <div className="relative w-full sm:w-64">
                  <Search className="w-3.5 h-3.5 absolute right-2.5 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="ابحث عن اسم تلميذ..."
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl pr-8 pl-3 py-1.5 text-slate-800 placeholder:text-slate-400 focus:outline-slate-600"
                  />
                </div>

                {!isReadOnly && (
                  <button
                    type="button"
                    onClick={handleMarkAllPresent}
                    className="w-full sm:w-auto px-3 py-1.5 text-xs font-bold text-slate-800 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-2xs"
                  >
                    <CheckCheck className="w-4 h-4 text-slate-600" />
                    <span>تحديد الجميع حاضرًا</span>
                  </button>
                )}
              </div>
            </div>

            {/* Students List */}
            <div className="space-y-2">
              <div className="flex items-center justify-between px-1 text-xs text-slate-500 font-semibold">
                <span>
                  قائمة التلاميذ ({filteredStudents.length} من أصل {classStudents.length})
                </span>
                <span className="text-[11px] text-slate-400">
                  الحالة الأولية: <strong className="text-slate-600">غير مسجل</strong>
                </span>
              </div>

              {filteredStudents.length === 0 ? (
                <div className="bg-white rounded-2xl p-8 text-center border border-slate-200">
                  <User className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs text-slate-500 font-bold">لا يوجد تلاميذ في هذا القسم</p>
                </div>
              ) : (
                filteredStudents.map((student, idx) => {
                  const record = studentStatuses[student.id] || {
                    studentId: student.id,
                    studentName: `${student.lastName} ${student.firstName}`,
                    status: 'unrecorded',
                  };
                  const status = record.status;
                  const isNoteOpen = activeNoteStudentId === student.id;

                  return (
                    <div
                      key={student.id}
                      className={`bg-white rounded-2xl p-3 border transition-all shadow-xs ${
                        status === 'present'
                          ? 'border-slate-200 bg-slate-50/20'
                          : status === 'absent'
                          ? 'border-slate-200 bg-slate-50/20'
                          : status === 'late'
                          ? 'border-amber-200 bg-amber-50/20'
                          : 'border-slate-200'
                      }`}
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                        {/* Student Name & Meta */}
                        <div className="flex items-center gap-2.5">
                          <span className="w-6 h-6 rounded-full bg-slate-100 text-slate-500 text-xs font-mono-numbers font-bold flex items-center justify-center shrink-0">
                            {idx + 1}
                          </span>
                          <div>
                            <h3 className="text-xs sm:text-sm font-bold text-slate-900 leading-tight">
                              {student.lastName} {student.firstName}
                            </h3>
                            <p className="text-[10px] text-slate-400 font-mono-numbers mt-0.5">
                              {student.nationalId || student.id}
                            </p>
                          </div>
                        </div>

                        {/* Status Toggle Buttons (Mobile friendly large touch targets) */}
                        <div className="flex items-center gap-1.5 self-end sm:self-auto w-full sm:w-auto">
                          {/* Present Button */}
                          <button
                            type="button"
                            disabled={isReadOnly}
                            onClick={() => handleSetStudentStatus(student.id, 'present')}
                            className={`flex-1 sm:flex-none px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1 ${
                              status === 'present'
                                ? 'bg-slate-600 text-white shadow-xs'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-50 hover:text-slate-800'
                            }`}
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>حاضر</span>
                          </button>

                          {/* Absent Button */}
                          <button
                            type="button"
                            disabled={isReadOnly}
                            onClick={() => handleSetStudentStatus(student.id, 'absent')}
                            className={`flex-1 sm:flex-none px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1 ${
                              status === 'absent'
                                ? 'bg-slate-600 text-white shadow-xs'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-50 hover:text-slate-800'
                            }`}
                          >
                            <XCircle className="w-3.5 h-3.5" />
                            <span>غائب</span>
                          </button>

                          {/* Late Button */}
                          <button
                            type="button"
                            disabled={isReadOnly}
                            onClick={() => {
                              handleSetStudentStatus(student.id, 'late');
                              setActiveNoteStudentId(student.id);
                            }}
                            className={`flex-1 sm:flex-none px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1 ${
                              status === 'late'
                                ? 'bg-amber-600 text-white shadow-xs'
                                : 'bg-slate-100 text-slate-600 hover:bg-amber-50 hover:text-amber-800'
                            }`}
                          >
                            <Clock className="w-3.5 h-3.5" />
                            <span>متأخر</span>
                          </button>

                          {/* Note Button */}
                          <button
                            type="button"
                            onClick={() =>
                              setActiveNoteStudentId(isNoteOpen ? null : student.id)
                            }
                            className={`p-1.5 rounded-xl text-xs transition-colors cursor-pointer border ${
                              record.notes
                                ? 'bg-indigo-50 border-indigo-200 text-indigo-700 font-bold'
                                : 'bg-slate-50 border-slate-200 text-slate-400 hover:text-slate-600'
                            }`}
                            title="إضافة ملاحظة"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Notes / Late Minutes Drawer */}
                      {isNoteOpen && (
                        <div className="mt-2.5 pt-2.5 border-t border-slate-100 animate-fade-in flex flex-col sm:flex-row gap-2">
                          {status === 'late' && (
                            <div className="w-full sm:w-32">
                              <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                                دقائق التأخر
                              </label>
                              <input
                                type="number"
                                min="1"
                                max="60"
                                value={record.lateMinutes || ''}
                                onChange={(e) =>
                                  handleUpdateStudentDetails(
                                    student.id,
                                    record.notes || '',
                                    parseInt(e.target.value) || 0
                                  )
                                }
                                placeholder="مثلاً 10 د"
                                disabled={isReadOnly}
                                className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-slate-800 font-mono-numbers"
                              />
                            </div>
                          )}

                          <div className="flex-1">
                            <label className="block text-[10px] font-bold text-slate-500 mb-0.5">
                              ملاحظة حول التلميذ
                            </label>
                            <input
                              type="text"
                              value={record.notes || ''}
                              onChange={(e) =>
                                handleUpdateStudentDetails(
                                  student.id,
                                  e.target.value,
                                  record.lateMinutes
                                )
                              }
                              placeholder="أدخل ملاحظة (إذن مسبق، تأخر في النقل...)"
                              disabled={isReadOnly}
                              className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-slate-800"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* ==================================================== */}
        {/* TAB 2: Teacher Weekly Timetable (جدول التوقيت الأسبوعي) */}
        {/* ==================================================== */}
        {activeTab === 'timetable' && (
          <div className="space-y-4">
            {/* Teacher Schedule Overview Card */}
            <div className="bg-white rounded-2xl p-4 shadow-xs border border-slate-200">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-800 flex items-center justify-center font-black text-lg border border-slate-200">
                    <Calendar className="w-6 h-6 text-slate-700" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h2 className="font-extrabold text-base text-slate-900">{user.name}</h2>
                      <span className="text-xs font-bold text-slate-800 bg-slate-50 px-2.5 py-0.5 rounded-lg border border-slate-200">
                        {teacherProfile?.subject || user.assignedSubjects?.[0]}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-1 flex flex-wrap items-center gap-2">
                      <span>الحجم الساعي: <strong>{teacherProfile?.weeklyHours || myTimetableSessions.length} ساعة/أسبوع</strong></span>
                      <span className="text-slate-300">·</span>
                      <span>الأقسام المسندة: <strong className="text-slate-900">{assignedClasses.join('، ')}</strong></span>
                      {teacherProfile?.phone && (
                        <>
                          <span className="text-slate-300">·</span>
                          <span className="font-mono-numbers">هاتف: {teacherProfile.phone}</span>
                        </>
                      )}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center">
                  <button
                    type="button"
                    onClick={() => window.print()}
                    className="px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-xs font-bold text-slate-700 flex items-center gap-1.5 cursor-pointer transition-colors"
                  >
                    <FileText className="w-3.5 h-3.5 text-slate-500" />
                    <span>طباعة التوقيت</span>
                  </button>
                </div>
              </div>

              {/* Current Ongoing Session Banner */}
              {currentOngoingSession && (
                <div className="mt-3.5 p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-slate-600 animate-ping shrink-0" />
                    <span className="text-xs text-slate-900 font-bold">
                      حصة جارية الآن: قسم {currentOngoingSession.classroom} ({currentOngoingSession.subject}) - {currentOngoingSession.room}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => jumpToSession(currentOngoingSession)}
                    className="px-3 py-1 rounded-lg text-xs font-bold bg-slate-700 hover:bg-slate-800 text-white cursor-pointer transition-colors shadow-2xs"
                  >
                    تسجيل الحضور
                  </button>
                </div>
              )}
            </div>

            {/* Weekly Grid */}
            <div className="bg-white rounded-2xl shadow-xs border border-slate-200 overflow-hidden">
              <div className="p-3.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-slate-700" />
                  <span>جدول الحصص الأسبوعي الرسمي (2026-2027)</span>
                </span>
                <span className="text-[11px] text-slate-500">
                  اضغط على أي حصة لتسجيل حضورها مباشرة
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-right border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-800 text-white">
                      <th className="py-2.5 px-3 font-bold border-l border-slate-700 w-24">اليوم</th>
                      {TIMETABLE_SLOTS.map((slot) => (
                        <th key={slot.id} className="py-2 px-1 text-center font-bold border-l border-slate-700 min-w-[95px]">
                          <div className="text-[11px]">{slot.label}</div>
                          <div className="text-[9px] text-slate-300 font-mono-numbers mt-0.5">{slot.timeRange}</div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {DAYS_OF_WEEK.map((day) => {
                      const isToday = getSchoolDay(new Date()) === day.key;
                      return (
                        <tr key={day.key} className={isToday ? 'bg-slate-50/30' : 'hover:bg-slate-50/50'}>
                          <td className="py-3 px-3 font-bold text-slate-800 bg-slate-50/80 border-l border-slate-200">
                            <div className="flex items-center gap-1.5">
                              <span>{day.label}</span>
                              {isToday && (
                                <span className="text-[9px] bg-slate-600 text-white px-1.5 py-0.2 rounded-full font-bold">
                                  اليوم
                                </span>
                              )}
                            </div>
                          </td>
                          {TIMETABLE_SLOTS.map((slot) => {
                            const session = myTimetableSessions.find(
                              (s) => s.day === day.key && s.slotId === slot.id
                            );
                            if (!session) {
                              return (
                                <td key={slot.id} className="py-2.5 px-1.5 text-center text-slate-300 border-l border-slate-100 bg-slate-50/10">
                                  -
                                </td>
                              );
                            }
                            return (
                              <td key={slot.id} className="py-2 px-1.5 border-l border-slate-200/80 text-center">
                                <div className="bg-white border border-slate-300 hover:border-slate-500 rounded-xl p-2 shadow-2xs hover:shadow-xs transition-all flex flex-col justify-between">
                                  <div className="font-black text-slate-900 text-xs">{session.classroom}</div>
                                  <div className="text-[10px] text-slate-600 font-semibold truncate my-0.5">{session.subject}</div>
                                  <div className="text-[9px] font-mono-numbers text-slate-700 bg-slate-100 rounded px-1 py-0.2 inline-block border border-slate-200 mx-auto">
                                    {session.room}
                                  </div>
                                  <button
                                    type="button"
                                    onClick={() => jumpToSession(session)}
                                    className="mt-1.5 w-full py-0.8 text-[10px] font-bold text-slate-800 bg-slate-50 hover:bg-slate-700 hover:text-white border border-slate-200 rounded-lg cursor-pointer transition-colors"
                                  >
                                    تسجيل
                                  </button>
                                </div>
                              </td>
                            );
                          })}
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ==================================================== */}
        {/* TAB 3: My Records (سجل تسجيلاتي) */}
        {/* ==================================================== */}
        {activeTab === 'history' && (
          <div className="space-y-3.5">
            <div className="bg-white rounded-2xl p-4 shadow-xs border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div>
                <h2 className="font-bold text-sm text-slate-900">سجل تسجيلاتي السابقة</h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  جميع حصص الحضور المسجلة من طرفك وإمكانية تعديلها إلى حين اعتمادها من الإدارة
                </p>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <input
                  type="date"
                  value={historyFilterDate}
                  onChange={(e) => setHistoryFilterDate(e.target.value)}
                  className="text-xs bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-slate-800 font-mono-numbers cursor-pointer"
                />
                {historyFilterDate && (
                  <button
                    type="button"
                    onClick={() => setHistoryFilterDate('')}
                    className="text-xs text-slate-500 hover:text-slate-700 underline cursor-pointer"
                  >
                    الكل
                  </button>
                )}
              </div>
            </div>

            {/* Sessions List */}
            {isLoadingSessions ? (
              <div className="bg-white rounded-2xl p-12 text-center border border-slate-200">
                <RefreshCw className="w-6 h-6 animate-spin text-slate-600 mx-auto mb-2" />
                <p className="text-xs text-slate-500 font-bold">جاري تحميل سجلاتك...</p>
              </div>
            ) : mySessions.length === 0 ? (
              <div className="bg-white rounded-2xl p-12 text-center border border-slate-200">
                <History className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                <p className="text-xs text-slate-600 font-bold">لم تسجل أي حصص حضور بعد</p>
                <p className="text-[11px] text-slate-400 mt-1">
                  انتقل إلى تبويب "تسجيل الحضور" لتسجيل حضور حصتك الحالية
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {mySessions
                  .filter((s) => !historyFilterDate || s.date === historyFilterDate)
                  .map((session) => {
                    const isSessionReadOnly =
                      session.status === 'approved' || session.status === 'locked';

                    return (
                      <div
                        key={session.id}
                        className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs hover:border-slate-300 transition-all"
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-sm text-slate-900">
                                قسم {session.classroom}
                              </span>
                              <span className="text-xs text-slate-400">·</span>
                              <span className="text-xs font-semibold text-slate-700">
                                {session.subject}
                              </span>
                              <span className="text-xs text-slate-400">·</span>
                              <span className="text-xs text-slate-500 font-mono-numbers">
                                {session.date}
                              </span>
                            </div>
                            <p className="text-xs text-slate-500 mt-0.5">
                              {session.periodLabel || session.periodId}
                            </p>
                          </div>

                          {/* Status Badge */}
                          <div className="flex items-center gap-2">
                            {session.status === 'approved' ? (
                              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-800 bg-slate-50 px-2.5 py-1 rounded-full border border-slate-200">
                                <CheckCircle2 className="w-3 h-3 text-slate-600" />
                                معتمد من الإدارة
                              </span>
                            ) : session.status === 'locked' ? (
                              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-800 bg-slate-100 px-2.5 py-1 rounded-full border border-slate-300">
                                <Lock className="w-3 h-3 text-slate-600" />
                                مغلق نهائياً
                              </span>
                            ) : session.status === 'submitted' ? (
                              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-blue-800 bg-blue-50 px-2.5 py-1 rounded-full border border-blue-200">
                                <Send className="w-3 h-3 text-blue-600" />
                                معتمد (بانتظار الإغلاق)
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-800 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200">
                                <FileText className="w-3 h-3 text-amber-600" />
                                مسودة
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Metric Counts */}
                        <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                          <div className="flex items-center gap-3 font-mono-numbers">
                            <span className="text-slate-700 font-bold">
                              حاضر: {session.summary.presentCount}
                            </span>
                            <span className="text-slate-700 font-bold">
                              غائب: {session.summary.absentCount}
                            </span>
                            <span className="text-amber-700 font-bold">
                              متأخر: {session.summary.lateCount}
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => setViewAuditSession(session)}
                              className="text-[11px] font-semibold text-slate-500 hover:text-slate-800 flex items-center gap-1 cursor-pointer"
                            >
                              <Shield className="w-3 h-3 text-slate-400" />
                              <span>سجل التدقيق</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => handleLoadSessionFromHistory(session)}
                              className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                                isSessionReadOnly
                                  ? 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                                  : 'bg-slate-700 text-white hover:bg-slate-800 shadow-2xs'
                              }`}
                            >
                              {isSessionReadOnly ? 'عرض السجل' : 'تعديل السجل'}
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
              </div>
            )}
          </div>
        )}
      </main>

      {/* ---------------- Sticky Bottom Action Bar (Mobile First) ---------------- */}
      {activeTab === 'record' && (
        <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md border-t border-slate-200 p-3 z-30 shadow-lg">
          <div className="max-w-4xl mx-auto flex items-center justify-between gap-2.5">
            <div className="text-xs">
              <span className="block font-bold text-slate-900 leading-tight">
                قسم {selectedClassroom} · {selectedSubject}
              </span>
              <span className="text-[11px] text-slate-500 font-mono-numbers">
                حاضر: {currentSummary.presentCount} | غائب: {currentSummary.absentCount}
              </span>
            </div>

            <div className="flex items-center gap-2">
              {/* Save Draft Button */}
              {!isReadOnly && (
                <button
                  type="button"
                  onClick={() => handleSaveSession('draft')}
                  className="px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 transition-all cursor-pointer flex items-center gap-1.5 shadow-2xs"
                >
                  <Save className="w-3.5 h-3.5 text-slate-600" />
                  <span>حفظ كمسودة</span>
                </button>
              )}

              {/* Final Submit Button */}
              {!isReadOnly ? (
                <button
                  type="button"
                  onClick={() => {
                    if (currentSummary.unrecordedCount > 0) {
                      alert(`تنبيه: لا يمكن اعتماد التسجيل النهائي مع وجود ${currentSummary.unrecordedCount} تلميذ بحالة (غير مسجل).`);
                      return;
                    }
                    setIsConfirmSubmitOpen(true);
                  }}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-700 hover:bg-slate-800 active:scale-95 text-white transition-all cursor-pointer flex items-center gap-1.5 shadow-xs"
                >
                  <Send className="w-3.5 h-3.5 text-slate-200" />
                  <span>اعتماد التسجيل النهائي</span>
                </button>
              ) : (
                <span className="text-xs font-bold text-slate-500 flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-100">
                  <Lock className="w-3.5 h-3.5 text-slate-400" />
                  السجل للقراءة فقط
                </span>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ---------------- Final Submit Confirmation Modal ---------------- */}
      {isConfirmSubmitOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-slate-200 text-right animate-scale-up">
            <div className="w-10 h-10 rounded-2xl bg-slate-50 text-slate-700 flex items-center justify-center mx-auto mb-3">
              <CheckCircle2 className="w-6 h-6 text-slate-700" />
            </div>

            <h3 className="font-bold text-base text-slate-900 text-center mb-1">
              تأكيد اعتماد التسجيل النهائي
            </h3>
            <p className="text-xs text-slate-500 text-center mb-4">
              سيتم إرسال السجل للإدارة واعتماده رسمياً. لن يمكنك التعديل عليه بعد إغلاقه من طرف المدير.
            </p>

            <div className="bg-slate-50 rounded-xl p-3 mb-4 space-y-1.5 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">القسم:</span>
                <span className="font-bold text-slate-800">{selectedClassroom}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">التاريخ والحصة:</span>
                <span className="font-bold text-slate-800">
                  {selectedDate} ({selectedPeriodId})
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">عدد الحاضرين:</span>
                <span className="font-bold text-slate-700 font-mono-numbers">
                  {currentSummary.presentCount}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">عدد الغائبين:</span>
                <span className="font-bold text-slate-700 font-mono-numbers">
                  {currentSummary.absentCount}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">عدد المتأخرين:</span>
                <span className="font-bold text-amber-700 font-mono-numbers">
                  {currentSummary.lateCount}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsConfirmSubmitOpen(false)}
                className="flex-1 py-2 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl cursor-pointer"
              >
                إلغاء ومراجعة
              </button>
              <button
                type="button"
                onClick={() => handleSaveSession('submitted')}
                className="flex-1 py-2 text-xs font-bold text-white bg-slate-700 hover:bg-slate-800 rounded-xl cursor-pointer shadow-xs"
              >
                تأكيد وإرسال
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ---------------- Audit Trail Modal ---------------- */}
      {viewAuditSession && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-5 shadow-2xl border border-slate-200 text-right max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-slate-700" />
                <h3 className="font-bold text-sm text-slate-900">سجل التدقيق والتعديلات</h3>
              </div>
              <button
                type="button"
                onClick={() => setViewAuditSession(null)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="py-2 text-xs text-slate-500">
              قسم {viewAuditSession.classroom} · {viewAuditSession.subject} · {viewAuditSession.date}
            </div>

            <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
              {(viewAuditSession.auditTrail || []).map((entry, i) => (
                <div key={entry.id || i} className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs">
                  <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
                    <span className="font-bold text-slate-700">
                      {entry.userName} ({entry.userRole === 'admin' ? 'مدير' : 'أستاذ'})
                    </span>
                    <span className="font-mono-numbers">
                      {new Date(entry.timestamp).toLocaleString('ar-DZ')}
                    </span>
                  </div>
                  <p className="text-slate-800 font-semibold">{entry.details}</p>

                  {entry.changes && entry.changes.length > 0 && (
                    <div className="mt-2 pt-2 border-t border-slate-200/60 space-y-1 text-[11px]">
                      {entry.changes.map((ch, idx) => (
                        <div key={idx} className="flex items-center justify-between text-slate-600">
                          <span>{ch.studentName}:</span>
                          <span className="font-mono-numbers">
                            {ch.oldStatus} ➔ <strong className="text-slate-700">{ch.newStatus}</strong>
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div className="pt-3 border-t border-slate-100 mt-2">
              <button
                type="button"
                onClick={() => setViewAuditSession(null)}
                className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
