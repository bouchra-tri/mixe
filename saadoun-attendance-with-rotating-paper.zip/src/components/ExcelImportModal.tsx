import React, { useState, useRef } from 'react';
import * as XLSX from 'xlsx';
import { Student, GradeLevel } from '../types';
import {
  FileSpreadsheet,
  Upload,
  Download,
  X,
  CheckCircle2,
  AlertTriangle,
  FileCheck,
  HelpCircle,
  Users
} from 'lucide-react';

interface ExcelImportModalProps {
  onClose: () => void;
  onImportStudents: (students: Student[], mode: 'upsert' | 'append' | 'replace') => void;
  currentStudentsCount: number;
  existingStudents?: Student[];
}

export const ExcelImportModal: React.FC<ExcelImportModalProps> = ({
  onClose,
  onImportStudents,
  currentStudentsCount,
  existingStudents = [],
}) => {
  const [file, setFile] = useState<File | null>(null);
  const [parsedStudents, setParsedStudents] = useState<Student[]>([]);
  const [importMode, setImportMode] = useState<'upsert' | 'append' | 'replace'>('upsert');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Template download
  const handleDownloadTemplate = () => {
    const templateData = [
      {
        'اللقب': 'عاشور',
        'الاسم': 'أحمد',
        'الجنس': 'ذكر',
        'المستوى': '1AM',
        'القسم': '1م1',
        'تاريخ الميلاد': '2013-04-12',
        'مكان الميلاد': 'عنابة',
        'رقم التعريف المدرسي': '12102830099',
        'اسم ولي الأمر': 'إبراهيم عاشور',
        'هاتف ولي الأمر': '0661234567',
        'العنوان': 'حي 500 مسكن، عنابة',
        'رمز الباركود (اختياري)': '2026101099',
      },
      {
        'اللقب': 'بن سالم',
        'الاسم': 'سارة',
        'الجنس': 'أنثى',
        'المستوى': '1AM',
        'القسم': '1م1',
        'تاريخ الميلاد': '2013-09-25',
        'مكان الميلاد': 'عنابة',
        'رقم التعريف المدرسي': '12102830100',
        'اسم ولي الأمر': 'عمار بن سالم',
        'هاتف ولي الأمر': '0550123456',
        'العنوان': 'حي النصر',
        'رمز الباركود (اختياري)': '2026101100',
      },
      {
        'اللقب': 'عمراوي',
        'الاسم': 'محمد',
        'الجنس': 'ذكر',
        'المستوى': '2AM',
        'القسم': '2م1',
        'تاريخ الميلاد': '2012-02-18',
        'مكان الميلاد': 'عنابة',
        'رقم التعريف المدرسي': '12002830101',
        'اسم ولي الأمر': 'مصطفى عمراوي',
        'هاتف ولي الأمر': '0772345678',
        'العنوان': 'حي الشهداء',
        'رمز الباركود (اختياري)': '',
      },
      {
        'اللقب': 'رحماني',
        'الاسم': 'إيناس',
        'الجنس': 'أنثى',
        'المستوى': '3AM',
        'القسم': '3م2',
        'تاريخ الميلاد': '2011-11-05',
        'مكان الميلاد': 'سيدي عيسى',
        'رقم التعريف المدرسي': '11902830102',
        'اسم ولي الأمر': 'نور الدين رحماني',
        'هاتف ولي الأمر': '0663456789',
        'العنوان': 'حي الكرامة',
        'رمز الباركود (اختياري)': '',
      },
    ];

    const worksheet = XLSX.utils.json_to_sheet(templateData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'قائمة التلاميذ');

    // Auto set column widths
    worksheet['!cols'] = [
      { wch: 15 }, // اللقب
      { wch: 15 }, // الاسم
      { wch: 8 },  // الجنس
      { wch: 10 }, // المستوى
      { wch: 10 }, // القسم
      { wch: 14 }, // تاريخ الميلاد
      { wch: 14 }, // مكان الميلاد
      { wch: 20 }, // رقم التعريف المدرسي
      { wch: 20 }, // ولي الأمر
      { wch: 15 }, // الهاتف
      { wch: 22 }, // العنوان
      { wch: 22 }, // الباركود
    ];

    XLSX.writeFile(workbook, 'نموذج_استيراد_تلاميذ_متوسطة_سعدون_عاشور.xlsx');
  };

  // Helper to normalize keys
  const normalizeKey = (key: string): string => {
    return key
      .trim()
      .toLowerCase()
      .replace(/[إأآا]/g, 'ا')
      .replace(/[ة]/g, 'ه')
      .replace(/[\-_]/g, ' ');
  };

  // Parse uploaded file
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    setFile(selectedFile);
    setErrorMsg(null);
    setIsProcessing(true);

    const reader = new FileReader();

    reader.onload = (evt) => {
      try {
        const data = evt.target?.result;
        const workbook = XLSX.read(data, { type: 'binary', cellDates: true });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];

        // Parse JSON rows
        const rawRows = XLSX.utils.sheet_to_json<Record<string, any>>(worksheet, { defval: '' });

        if (!rawRows || rawRows.length === 0) {
          setErrorMsg('ملف Excel فارغ أو لا يحتوي على أي صفوف من البيانات.');
          setIsProcessing(false);
          return;
        }

        const validStudents: Student[] = [];

        rawRows.forEach((row, index) => {
          // Normalize row keys
          const normRow: Record<string, any> = {};
          Object.keys(row).forEach((k) => {
            normRow[normalizeKey(k)] = row[k];
          });

          // Extract fields with fallbacks
          const lastName =
            normRow['اللقب'] ||
            normRow['nom'] ||
            normRow['last name'] ||
            normRow['lastname'] ||
            '';

          const firstName =
            normRow['الاسم'] ||
            normRow['prenom'] ||
            normRow['first name'] ||
            normRow['firstname'] ||
            '';

          // Skip completely empty names
          if (!lastName && !firstName) return;

          // Gender
          let gender: 'M' | 'F' = 'M';
          const genderRaw = String(
            normRow['الجنس'] || normRow['sexe'] || normRow['gender'] || ''
          ).trim();
          if (
            genderRaw.includes('أنث') ||
            genderRaw.includes('انث') ||
            genderRaw.toUpperCase() === 'F' ||
            genderRaw.toLowerCase().includes('fille')
          ) {
            gender = 'F';
          }

          // Grade
          let grade: GradeLevel = '1AM';
          const gradeRaw = String(
            normRow['المستوي'] || normRow['المستوى'] || normRow['niveau'] || normRow['grade'] || ''
          ).toUpperCase();

          if (gradeRaw.includes('4') || gradeRaw.includes('رابع')) grade = '4AM';
          else if (gradeRaw.includes('3') || gradeRaw.includes('ثالث')) grade = '3AM';
          else if (gradeRaw.includes('2') || gradeRaw.includes('ثان')) grade = '2AM';
          else grade = '1AM';

          // Classroom
          let classroom = String(
            normRow['القسم'] || normRow['الفوج'] || normRow['classe'] || normRow['classroom'] || ''
          ).trim();
          if (!classroom) {
            classroom = grade === '1AM' ? '1م1' : grade === '2AM' ? '2م1' : grade === '3AM' ? '3م1' : '4م1';
          }

          // Birth Date
          let birthDate = '2013-01-01';
          const rawBirth = normRow['تاريخ الميلاد'] || normRow['تاريخ الازدياد'] || normRow['date naissance'] || normRow['dob'];
          if (rawBirth instanceof Date) {
            birthDate = rawBirth.toISOString().split('T')[0];
          } else if (typeof rawBirth === 'string' && rawBirth.trim()) {
            birthDate = rawBirth.trim();
          }

          // National ID
          const nationalId = String(
            normRow['رقم التعريف المدرسي'] ||
            normRow['رقم التعريف'] ||
            normRow['رقم التسجيل'] ||
            normRow['matricule'] ||
            normRow['nin'] ||
            `1210283${Date.now().toString().slice(-4)}${index}`
          ).trim();

          // Barcode (If not in excel, create a clean 10-digit Code128 standard)
          let barcode = String(
            normRow['رمز الباركود'] ||
            normRow['الباركود'] ||
            normRow['كود بار'] ||
            normRow['code barre'] ||
            normRow['barcode'] ||
            ''
          ).trim();

          if (!barcode) {
            const gradeNum = grade === '1AM' ? '101' : grade === '2AM' ? '202' : grade === '3AM' ? '303' : '404';
            const suffix = (1000 + index + Math.floor(Math.random() * 500)).toString();
            barcode = `2026${gradeNum}${suffix.slice(-3)}`;
          }

          const studentId = `SA-2026-${100 + index + Math.floor(Math.random() * 800)}`;

          validStudents.push({
            id: studentId,
            barcode,
            nationalId,
            firstName: String(firstName).trim(),
            lastName: String(lastName).trim(),
            gender,
            grade,
            classroom,
            birthDate,
            birthPlace: String(normRow['مكان الميلاد'] || 'عنابة').trim(),
            guardianName: String(normRow['اسم ولي الامر'] || normRow['اسم ولي الأمر'] || normRow['الولي'] || normRow['tuteur'] || 'ولي التلميذ').trim(),
            guardianPhone: String(normRow['هاتف ولي الامر'] || normRow['هاتف ولي الأمر'] || normRow['الهاتف'] || normRow['telephone'] || '0660000000').trim(),
            address: String(normRow['العنوان'] || normRow['adresse'] || 'عنابة').trim(),
          });
        });

        if (validStudents.length === 0) {
          setErrorMsg('تعذر العثور على أعمدة صالحة في الملف (تأكد من وجود عمودي "اللقب" و"الاسم").');
          setIsProcessing(false);
          return;
        }

        setParsedStudents(validStudents);
        setIsProcessing(false);
      } catch (err: any) {
        console.error('Error parsing excel:', err);
        setErrorMsg('حدث خطأ أثناء قراءة ملف Excel: ' + (err.message || 'صيغة غير مدعومة'));
        setIsProcessing(false);
      }
    };

    reader.readAsBinaryString(selectedFile);
  };

  const handleConfirmImport = () => {
    if (parsedStudents.length === 0) return;
    onImportStudents(parsedStudents, importMode);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-xl max-w-2xl w-full p-6 space-y-5 border border-slate-200 max-h-[90vh] flex flex-col">
        {/* Top Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-slate-50 text-slate-700 flex items-center justify-center border border-slate-100">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm">
                استيراد أسماء وبيانات التلاميذ من ملف Excel
              </h3>
              <p className="text-xs text-slate-500">
                يدعم ملفات Microsoft Excel (.xlsx, .xls) و ملفات CSV المتوافقة مع رقمنة وزارة التربية
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg cursor-pointer transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto space-y-4 pr-1">
          {/* Download Template Banner */}
          <div className="p-3.5 bg-slate-50/60 border border-slate-200/80 rounded-xl flex items-center justify-between gap-3 text-xs">
            <div className="space-y-0.5">
              <span className="font-bold text-slate-950 block">هل تود استخدام النموذج الجاهز؟</span>
              <span className="text-slate-800 text-[11px] block">
                قم بتحميل ملف Excel معبأ مسبقاً بالأعمدة الرسمية (اللقب، الاسم، المستوى، القسم، إلخ) لتعبئته مباشرة.
              </span>
            </div>
            <button
              type="button"
              onClick={handleDownloadTemplate}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-900 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg transition-colors cursor-pointer shrink-0 shadow-2xs"
            >
              <Download className="w-3.5 h-3.5 text-slate-700" />
              تحميل نموذج Excel فارغ
            </button>
          </div>

          {/* Upload Area */}
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-slate-300 hover:border-slate-500 hover:bg-slate-50/20 rounded-2xl p-6 text-center cursor-pointer transition-all flex flex-col items-center justify-center space-y-2 group"
          >
            <div className="w-12 h-12 rounded-xl bg-slate-100 group-hover:bg-slate-100 group-hover:text-slate-700 text-slate-600 flex items-center justify-center transition-colors">
              <Upload className="w-6 h-6" />
            </div>

            <div>
              <p className="text-xs font-bold text-slate-800">
                {file ? file.name : 'انقر لاختيار ملف Excel أو اسحب الملف وأفلته هنا'}
              </p>
              <p className="text-[11px] text-slate-400 mt-0.5">
                الصيغ المقبولة: XLSX, XLS, CSV
              </p>
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx, .xls, .csv"
              onChange={handleFileChange}
              className="hidden"
            />
          </div>

          {/* Error Message */}
          {errorMsg && (
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-slate-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Parsed Preview Table */}
          {parsedStudents.length > 0 && (
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-slate-600" />
                  <span className="text-xs font-bold text-slate-800">
                    تم استخراج {parsedStudents.length} تلميذ بنجاح من الملف
                  </span>
                </div>
              </div>

              {/* Import Mode Selector Cards */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2">
                <span className="text-xs font-bold text-slate-800 block">
                  اختر طريقة تحديث قاعدة البيانات:
                </span>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5">
                  {/* Upsert Mode */}
                  <label
                    className={`flex items-start gap-2.5 p-2.5 rounded-xl border text-xs cursor-pointer transition-all ${
                      importMode === 'upsert'
                        ? 'bg-slate-50/80 border-slate-400 ring-1 ring-slate-400 text-slate-950 font-medium'
                        : 'bg-white border-slate-200 hover:border-slate-300 text-slate-700'
                    }`}
                  >
                    <input
                      type="radio"
                      name="importMode"
                      value="upsert"
                      checked={importMode === 'upsert'}
                      onChange={() => setImportMode('upsert')}
                      className="mt-0.5 text-slate-600 focus:ring-slate-500"
                    />
                    <div>
                      <div className="font-bold flex items-center gap-1.5 text-slate-900">
                        <span>تحديث ودمج التغييرات</span>
                        <span className="text-[10px] bg-slate-100 text-slate-800 px-1.5 py-0.5 rounded-md font-semibold">
                          موصى به
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-1 leading-snug">
                        تحديث أرقام الهواتف والأقسام للتلاميذ المسجلين وإضافة الجدد دون مسح السجلات
                      </p>
                    </div>
                  </label>

                  {/* Append Mode */}
                  <label
                    className={`flex items-start gap-2.5 p-2.5 rounded-xl border text-xs cursor-pointer transition-all ${
                      importMode === 'append'
                        ? 'bg-slate-50/80 border-slate-400 ring-1 ring-slate-400 text-slate-950 font-medium'
                        : 'bg-white border-slate-200 hover:border-slate-300 text-slate-700'
                    }`}
                  >
                    <input
                      type="radio"
                      name="importMode"
                      value="append"
                      checked={importMode === 'append'}
                      onChange={() => setImportMode('append')}
                      className="mt-0.5 text-slate-600 focus:ring-slate-500"
                    />
                    <div>
                      <div className="font-bold text-slate-900">إضافة الجدد فقط</div>
                      <p className="text-[11px] text-slate-500 mt-1 leading-snug">
                        إضافة التلاميذ الجدد وتخطي أي تلميذ مسجل بالباركود أو التعريف مسبقاً
                      </p>
                    </div>
                  </label>

                  {/* Replace Mode */}
                  <label
                    className={`flex items-start gap-2.5 p-2.5 rounded-xl border text-xs cursor-pointer transition-all ${
                      importMode === 'replace'
                        ? 'bg-amber-50/80 border-amber-400 ring-1 ring-amber-400 text-amber-950 font-medium'
                        : 'bg-white border-slate-200 hover:border-slate-300 text-slate-700'
                    }`}
                  >
                    <input
                      type="radio"
                      name="importMode"
                      value="replace"
                      checked={importMode === 'replace'}
                      onChange={() => setImportMode('replace')}
                      className="mt-0.5 text-amber-600 focus:ring-amber-500"
                    />
                    <div>
                      <div className="font-bold text-slate-900 flex items-center gap-1">
                        <span>استبدال شامل</span>
                        <span className="text-[10px] bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded-md font-semibold">
                          حذف القديم
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-1 leading-snug">
                        تفريغ قائمة التلاميذ السابقة واستبدالها بالكامل بالقائمة الجديدة
                      </p>
                    </div>
                  </label>
                </div>
              </div>

              {/* Preview Table */}
              <div className="border border-slate-200 rounded-xl overflow-hidden max-h-48 overflow-y-auto bg-slate-50/50">
                <table className="w-full text-right text-xs">
                  <thead className="bg-slate-100 text-slate-600 font-semibold sticky top-0">
                    <tr>
                      <th className="py-2 px-3">#</th>
                      <th className="py-2 px-3">اللقب والاسم</th>
                      <th className="py-2 px-3">المستوى</th>
                      <th className="py-2 px-3">القسم</th>
                      <th className="py-2 px-3">الباركود</th>
                      <th className="py-2 px-3">هاتف الولي</th>
                      <th className="py-2 px-3">الحالة المتوقعة</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {parsedStudents.map((st, idx) => {
                      const isExisting = existingStudents.some(
                        (ex) =>
                          (ex.barcode && ex.barcode === st.barcode) ||
                          (ex.nationalId && ex.nationalId === st.nationalId) ||
                          `${ex.lastName.trim()} ${ex.firstName.trim()}`.toLowerCase() ===
                            `${st.lastName.trim()} ${st.firstName.trim()}`.toLowerCase()
                      );
                      return (
                        <tr key={idx} className="hover:bg-white">
                          <td className="py-2 px-3 font-mono-numbers text-slate-400">{idx + 1}</td>
                          <td className="py-2 px-3 font-bold text-slate-900">{st.lastName} {st.firstName}</td>
                          <td className="py-2 px-3 text-slate-600">{st.grade}</td>
                          <td className="py-2 px-3 font-semibold text-slate-800">{st.classroom}</td>
                          <td className="py-2 px-3 font-mono-numbers text-slate-700 font-semibold">{st.barcode}</td>
                          <td className="py-2 px-3 font-mono-numbers text-slate-500">{st.guardianPhone}</td>
                          <td className="py-2 px-3">
                            {isExisting ? (
                              <span className="inline-flex items-center gap-1 text-[10px] bg-blue-50 text-blue-700 border border-blue-200 px-2 py-0.5 rounded-md font-semibold">
                                سيتم تحديث بياناته
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-[10px] bg-slate-50 text-slate-700 border border-slate-200 px-2 py-0.5 rounded-md font-semibold">
                                تلميذ جديد
                              </span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
          <span className="text-[11px] text-slate-400">
            سيتم إنشاء بطاقات الباركود تلقائياً لجميع التلاميذ المستوردين.
          </span>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs text-slate-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="button"
              disabled={parsedStudents.length === 0}
              onClick={handleConfirmImport}
              className={`flex items-center gap-1.5 px-5 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer shadow-xs ${
                parsedStudents.length > 0
                  ? 'bg-slate-700 hover:bg-slate-800 text-white'
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed'
              }`}
            >
              <FileCheck className="w-4 h-4" />
              تأكيد استيراد {parsedStudents.length > 0 ? `(${parsedStudents.length}) تلميذ` : ''}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
