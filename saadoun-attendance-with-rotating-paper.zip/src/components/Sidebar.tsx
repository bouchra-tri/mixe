import React, { useState, useEffect, useRef } from 'react';
import { SchoolSettings, AppUser } from '../types';
import {
  School,
  Scan,
  ClipboardCheck,
  Users,
  BookOpen,
  UserCheck,
  Calendar,
  ShieldAlert,
  BarChart3,
  Settings,
  Database,
  ChevronRight,
  ChevronLeft,
  ChevronDown,
  X,
  User,
  LogOut,
  Palette,
  FileSpreadsheet,
  QrCode,
  Layers,
  GraduationCap,
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

export type ViewType =
  | 'scanner'
  | 'attendance'
  | 'students'
  | 'timetable'
  | 'rotating_paper'
  | 'teacher_sessions'
  | 'monthly'
  | 'notices'
  | 'reports'
  | 'settings';

interface SubMenuItem {
  id: string;
  label: string;
  icon?: React.ComponentType<{ className?: string }>;
  targetView: ViewType;
}

interface NavItem {
  id: ViewType;
  label: string;
  shortLabel?: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: number | string;
  badgeColor?: string;
  category: 'daily' | 'schedules' | 'reports' | 'system';
  subItems?: SubMenuItem[];
}

interface SidebarProps {
  currentView: ViewType;
  onChangeView: (view: ViewType) => void;
  settings: SchoolSettings;
  pendingNoticesCount?: number;
  onOpenDataPersistence?: () => void;
  currentUser?: AppUser | null;
  onOpenLoginModal?: () => void;
  onLogout?: () => void;
  isMobileOpen: boolean;
  onCloseMobile: () => void;
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onChangeView,
  settings,
  pendingNoticesCount = 0,
  onOpenDataPersistence,
  currentUser,
  onOpenLoginModal,
  onLogout,
  isMobileOpen,
  onCloseMobile,
  isCollapsed = false,
  onToggleCollapse,
}) => {
  const { palette, isDark } = useTheme();

  // Category collapsed state - all open by default for maximum accessibility
  const [collapsedCategories, setCollapsedCategories] = useState<Record<string, boolean>>({});

  // Active item refs for automatic scroll-into-view
  const desktopActiveRef = useRef<HTMLButtonElement | null>(null);
  const mobileActiveRef = useRef<HTMLButtonElement | null>(null);
  const desktopScrollContainerRef = useRef<HTMLDivElement | null>(null);
  const mobileScrollContainerRef = useRef<HTMLDivElement | null>(null);

  // Auto-scroll the active item into view when view changes or when mobile drawer opens
  useEffect(() => {
    const targetRef = isMobileOpen ? mobileActiveRef.current : desktopActiveRef.current;
    if (targetRef) {
      const timer = setTimeout(() => {
        targetRef.scrollIntoView({
          behavior: 'smooth',
          block: 'nearest',
          inline: 'nearest',
        });
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [currentView, isMobileOpen]);

  const toggleCategory = (catKey: string) => {
    setCollapsedCategories((prev) => ({
      ...prev,
      [catKey]: !prev[catKey],
    }));
  };

  const navItems: NavItem[] = [
    {
      id: 'scanner',
      label: 'بوابة الدخول (سكانر)',
      shortLabel: 'البوابة',
      icon: Scan,
      category: 'daily',
    },
    {
      id: 'attendance',
      label: 'سجل الحضور اليومي',
      shortLabel: 'الحضور',
      icon: ClipboardCheck,
      category: 'daily',
    },
    {
      id: 'students',
      label: 'شؤون التلاميذ والبطاقات',
      shortLabel: 'التلاميذ',
      icon: Users,
      category: 'daily',
      subItems: [
        { id: 'sub_st_dir', label: 'دليل وسجل التلاميذ', icon: Users, targetView: 'students' },
        { id: 'sub_st_cards', label: 'طباعة بطاقات الباركود', icon: QrCode, targetView: 'students' },
        { id: 'sub_st_import', label: 'استيراد القوائم (Excel)', icon: FileSpreadsheet, targetView: 'students' },
      ],
    },
    {
      id: 'timetable',
      label: 'جداول التوقيت والمواد',
      shortLabel: 'التواقيت',
      icon: BookOpen,
      category: 'schedules',
      subItems: [
        { id: 'sub_tt_classes', label: 'توزيع حصص وتواقيت الأقسام', icon: BookOpen, targetView: 'timetable' },
        { id: 'sub_tt_sessions', label: 'تسجيلات حضور الأساتذة', icon: UserCheck, targetView: 'teacher_sessions' },
      ],
    },
    {
      id: 'rotating_paper',
      label: 'الورقة الدوارة',
      shortLabel: 'الورقة الدوارة',
      icon: FileSpreadsheet,
      category: 'schedules',
    },
    {
      id: 'teacher_sessions',
      label: 'تسجيلات حضور الأساتذة',
      shortLabel: 'الأساتذة',
      icon: UserCheck,
      category: 'schedules',
    },
    {
      id: 'monthly',
      label: 'التقارير وسجلات الشهر',
      shortLabel: 'الشهري',
      icon: Calendar,
      category: 'reports',
      subItems: [
        { id: 'sub_rep_month', label: 'السجل الإجمالي الشهري', icon: Calendar, targetView: 'monthly' },
        { id: 'sub_rep_notices', label: 'مراحل وإشعارات الغياب', icon: ShieldAlert, targetView: 'notices' },
        { id: 'sub_rep_stats', label: 'الإحصاءات والتحليلات البيانية', icon: BarChart3, targetView: 'reports' },
      ],
    },
    {
      id: 'notices',
      label: 'إشعارات ومراحل الغياب',
      shortLabel: 'الإشعارات',
      icon: ShieldAlert,
      badge: pendingNoticesCount > 0 ? pendingNoticesCount : undefined,
      category: 'reports',
    },
    {
      id: 'reports',
      label: 'الإحصائيات والتحليلات',
      shortLabel: 'الإحصاء',
      icon: BarChart3,
      category: 'reports',
    },
    {
      id: 'settings',
      label: 'إعدادات المؤسسة والنظام',
      shortLabel: 'الإعدادات',
      icon: Settings,
      category: 'system',
      subItems: [
        { id: 'sub_set_general', label: 'إعدادات وبيانات المؤسسة', icon: Settings, targetView: 'settings' },
        { id: 'sub_set_theme', label: 'المظهر ونظام الثيمات', icon: Palette, targetView: 'settings' },
      ],
    },
  ];

  const categories = [
    { key: 'daily', title: 'المتابعة اليومية' },
    { key: 'schedules', title: 'التنظيم والتواقيت' },
    { key: 'reports', title: 'التقارير والمتابعة' },
    { key: 'system', title: 'النظام والتحكم' },
  ];

  const renderSidebarContent = (isMobileInstance: boolean) => {
    return (
      <div className="sidebar-outer-container bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 select-none transition-colors duration-150">
        {/* 1. Institution Identity Header (Fixed at top) */}
        <div className="p-4 border-b border-slate-200/80 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/70 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3 overflow-hidden">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center shadow-xs shrink-0 ring-2 ring-black/10 transition-all"
              style={{
                background: `linear-gradient(135deg, ${palette.primary}, ${palette.hover})`,
                color: palette.foreground,
              }}
            >
              <School className="w-5 h-5 text-current" />
            </div>
            {(!isCollapsed || isMobileInstance) && (
              <div className="min-w-0 transition-opacity duration-200">
                <h1 className="font-extrabold text-slate-900 dark:text-white text-sm leading-tight truncate">
                  {settings.schoolName || 'متوسطة سعدون عاشور'}
                </h1>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5 flex items-center gap-1.5">
                  <span className="font-semibold text-slate-800 dark:text-slate-200">
                    {settings.schoolType || 'التعليم المتوسط'}
                  </span>
                  <span className="text-slate-300 dark:text-slate-600">·</span>
                  <span>ولاية {settings.wilaya || 'عنابة'}</span>
                </p>
              </div>
            )}
          </div>

          {/* Mobile Close Button */}
          {isMobileInstance && (
            <button
              type="button"
              onClick={onCloseMobile}
              className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-200/70 dark:hover:bg-slate-800 cursor-pointer transition-colors shrink-0"
              title="إغلاق القائمة"
              aria-label="إغلاق القائمة"
            >
              <X className="w-5 h-5 text-current" />
            </button>
          )}

          {/* Desktop Collapse Toggle */}
          {!isMobileInstance && onToggleCollapse && (
            <button
              type="button"
              onClick={onToggleCollapse}
              className="hidden lg:flex p-1.5 rounded-lg text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-slate-800 cursor-pointer transition-colors shrink-0"
              title={isCollapsed ? 'توسيع القائمة الجانبية' : 'طي القائمة الجانبية'}
              aria-label={isCollapsed ? 'توسيع القائمة الجانبية' : 'طي القائمة الجانبية'}
            >
              {isCollapsed ? (
                <ChevronLeft className="w-4 h-4 text-current" />
              ) : (
                <ChevronRight className="w-4 h-4 text-current" />
              )}
            </button>
          )}
        </div>

        {/* 2. Navigation Items List (Smooth Scrollable Area with min-height: 0 and overscroll containment) */}
        <div
          ref={isMobileInstance ? mobileScrollContainerRef : desktopScrollContainerRef}
          className="flex-1 min-h-0 sidebar-scroll-zone p-3 space-y-4 touch-pan-y pb-6"
          style={{ overscrollBehavior: 'contain' }}
        >
          {categories.map((cat) => {
            const items = navItems.filter((item) => item.category === cat.key);
            if (items.length === 0) return null;
            const isCategoryCollapsed = collapsedCategories[cat.key];

            return (
              <div key={cat.key} className="space-y-1">
                {!isCollapsed || isMobileInstance ? (
                  <button
                    type="button"
                    onClick={() => toggleCategory(cat.key)}
                    className="w-full flex items-center justify-between px-3 py-1 text-[10px] font-bold text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300 uppercase tracking-wider transition-colors cursor-pointer select-none group"
                  >
                    <span>{cat.title}</span>
                    <ChevronDown
                      className={`w-3.5 h-3.5 text-slate-400 transition-transform duration-200 group-hover:text-slate-600 dark:group-hover:text-slate-300 ${
                        isCategoryCollapsed ? '-rotate-90' : 'rotate-0'
                      }`}
                    />
                  </button>
                ) : (
                  <div className="h-2 border-b border-slate-100 dark:border-slate-800 my-1" />
                )}

                {!isCategoryCollapsed && (
                  <div className="space-y-1">
                    {items.map((item) => {
                      const Icon = item.icon;
                      const isActive = currentView === item.id;
                      const hasSubItems = item.subItems && item.subItems.length > 0;
                      const showSubItems = (!isCollapsed || isMobileInstance) && hasSubItems && isActive;

                      return (
                        <div key={item.id} className="space-y-1">
                          <button
                            ref={
                              isActive
                                ? (el) => {
                                    if (isMobileInstance) {
                                      mobileActiveRef.current = el;
                                    } else {
                                      desktopActiveRef.current = el;
                                    }
                                  }
                                : undefined
                            }
                            type="button"
                            onClick={() => {
                              onChangeView(item.id);
                              if (isMobileInstance) {
                                onCloseMobile();
                              }
                            }}
                            title={isCollapsed && !isMobileInstance ? item.label : undefined}
                            className={`w-full flex items-center rounded-xl transition-all cursor-pointer group text-right ${
                              isCollapsed && !isMobileInstance ? 'justify-center p-2.5' : 'gap-3 px-3 py-2.5'
                            } ${
                              isActive
                                ? 'font-bold shadow-xs'
                                : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100/80 dark:hover:bg-slate-800 font-semibold'
                            }`}
                            style={
                              isActive
                                ? {
                                    backgroundColor: palette.primary,
                                    color: palette.foreground,
                                    boxShadow: '0 2px 8px -2px var(--theme-primary-ring)',
                                  }
                                : undefined
                            }
                          >
                            <span
                              className="shrink-0 transition-transform group-hover:scale-105"
                              style={{ color: isActive ? palette.foreground : 'inherit' }}
                            >
                              <Icon className={isCollapsed && !isMobileInstance ? 'w-5 h-5' : 'w-4 h-4'} />
                            </span>

                            {(!isCollapsed || isMobileInstance) && (
                              <span className="flex-1 text-xs truncate">
                                {item.label}
                              </span>
                            )}

                            {item.badge !== undefined && (
                              <span
                                className={`px-1.5 py-0.2 rounded-full text-[10px] font-black shrink-0 ${
                                  isCollapsed && !isMobileInstance ? 'absolute top-1 left-1' : ''
                                }`}
                                style={{
                                  backgroundColor: isActive ? 'rgba(0,0,0,0.2)' : palette.primary,
                                  color: palette.foreground,
                                }}
                              >
                                {item.badge}
                              </span>
                            )}
                          </button>

                          {/* Submenu items expanded when active */}
                          {showSubItems && item.subItems && (
                            <div className="mr-6 space-y-0.5 border-r border-slate-200 dark:border-slate-700/80 pr-2 pt-1 pb-1 animate-in fade-in duration-150">
                              {item.subItems.map((sub) => {
                                const SubIcon = sub.icon || Layers;
                                return (
                                  <button
                                    key={sub.id}
                                    type="button"
                                    onClick={() => {
                                      onChangeView(sub.targetView);
                                      if (isMobileInstance) {
                                        onCloseMobile();
                                      }
                                    }}
                                    className="w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-[11px] font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 hover:bg-slate-100/70 dark:hover:bg-slate-800/60 transition-colors cursor-pointer text-right truncate"
                                  >
                                    <span
                                      className="w-1.5 h-1.5 rounded-full shrink-0"
                                      style={{ backgroundColor: palette.primary }}
                                    />
                                    <span className="truncate">{sub.label}</span>
                                  </button>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* 3. Quick Data Persistence Button (Fixed/Shrink-0) */}
        {onOpenDataPersistence && (
          <div className="p-3 border-t border-slate-200/80 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/40 shrink-0">
            <button
              type="button"
              onClick={onOpenDataPersistence}
              className={`w-full flex items-center justify-center rounded-xl bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200/90 dark:border-slate-700 font-bold transition-all cursor-pointer text-xs shadow-2xs ${
                isCollapsed && !isMobileInstance ? 'p-2.5' : 'gap-2 px-3 py-2.5'
              }`}
              title="فتح مركز حفظ وإدارة قاعدة البيانات"
            >
              <Database className="w-4 h-4 text-current shrink-0" style={{ color: palette.primary }} />
              {(!isCollapsed || isMobileInstance) && <span>حفظ وتثبيت البيانات</span>}
            </button>
          </div>
        )}

        {/* 4. User Profile & System Status Footer (Fixed/Shrink-0) */}
        <div className="p-3 border-t border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900 shrink-0">
          {currentUser ? (
            <div
              className={`flex items-center rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700 ${
                isCollapsed && !isMobileInstance ? 'justify-center p-2' : 'justify-between p-2.5'
              }`}
            >
              <div className="flex items-center gap-2.5 overflow-hidden">
                <div
                  className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0 text-xs font-bold shadow-2xs"
                  style={{ backgroundColor: palette.primary, color: palette.foreground }}
                >
                  <User className="w-4 h-4 text-current" />
                </div>
                {(!isCollapsed || isMobileInstance) && (
                  <div className="min-w-0">
                    <span className="block text-xs font-bold text-slate-900 dark:text-slate-100 leading-tight truncate">
                      {currentUser.name}
                    </span>
                    <span
                      className="text-[10px] font-bold px-1.5 py-0.2 rounded border inline-block mt-0.5"
                      style={{
                        backgroundColor: palette.light,
                        color: palette.primary,
                        borderColor: palette.border,
                      }}
                    >
                      {currentUser.role === 'admin' ? 'المدير العام' : 'أستاذ المادة'}
                    </span>
                  </div>
                )}
              </div>

              {(!isCollapsed || isMobileInstance) && (
                <div className="flex items-center gap-1">
                  {onOpenLoginModal && (
                    <button
                      type="button"
                      onClick={onOpenLoginModal}
                      className="p-1.5 text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-200/70 dark:hover:bg-slate-700 rounded-lg cursor-pointer transition-colors"
                      title="تبديل الحساب"
                    >
                      <User className="w-3.5 h-3.5 text-current" />
                    </button>
                  )}
                  {onLogout && (
                    <button
                      type="button"
                      onClick={onLogout}
                      className="p-1.5 text-slate-600 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg cursor-pointer transition-colors"
                      title="تسجيل الخروج"
                    >
                      <LogOut className="w-3.5 h-3.5 text-current" />
                    </button>
                  )}
                </div>
              )}
            </div>
          ) : (
            onOpenLoginModal && (
              <button
                type="button"
                onClick={onOpenLoginModal}
                className={`w-full flex items-center justify-center rounded-xl font-bold transition-all cursor-pointer text-xs shadow-xs ${
                  isCollapsed && !isMobileInstance ? 'p-2.5' : 'gap-2 px-3 py-2.5'
                }`}
                style={{
                  backgroundColor: palette.primary,
                  color: palette.foreground,
                }}
              >
                <User className="w-4 h-4 text-current" />
                {(!isCollapsed || isMobileInstance) && <span>تسجيل دخول الأساتذة</span>}
              </button>
            )
          )}

          {(!isCollapsed || isMobileInstance) && (
            <div className="mt-2 text-center text-[10px] text-slate-400 dark:text-slate-500 space-y-0.5 border-t border-slate-100 dark:border-slate-800 pt-2">
              <div className="font-mono-numbers">السنة الدراسية {settings.academicYear || '2026-2027'}</div>
              <div className="font-extrabold text-slate-700 dark:text-slate-300">
                صممت المنصة تحت إشراف السيدة : ليلى بن تروش
              </div>
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <>
      {/* 1. Desktop Lateral Sidebar (Sticky & Full Viewport Height with dvh) */}
      <aside
        className={`hidden lg:flex flex-col shrink-0 h-screen h-[100dvh] max-h-screen max-h-[100dvh] sticky top-0 z-40 border-l border-slate-200/90 dark:border-slate-800 bg-white dark:bg-slate-900 transition-all duration-200 ease-in-out shadow-xs select-none overflow-hidden ${
          isCollapsed ? 'w-20' : 'w-64 xl:w-72'
        }`}
      >
        {renderSidebarContent(false)}
      </aside>

      {/* 2. Mobile Drawer Navigation */}
      {isMobileOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex" dir="rtl">
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity animate-fade-in"
            onClick={onCloseMobile}
            aria-label="إغلاق القائمة"
          />

          {/* Drawer Sidebar */}
          <div
            className="relative w-72 max-w-[85vw] h-screen h-[100dvh] max-h-screen max-h-[100dvh] bg-white dark:bg-slate-900 shadow-2xl z-10 animate-slide-in-right flex flex-col overflow-hidden"
            style={{ overscrollBehavior: 'contain' }}
          >
            {renderSidebarContent(true)}
          </div>
        </div>
      )}
    </>
  );
};
