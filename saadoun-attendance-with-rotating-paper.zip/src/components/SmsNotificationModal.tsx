import React, { useState } from 'react';
import { Student, SchoolSettings } from '../types';
import {
  MessageSquare,
  Send,
  Smartphone,
  Copy,
  Check,
  X,
  Users,
  CheckCircle2,
  ExternalLink,
  MessageCircle,
  PhoneCall
} from 'lucide-react';

// Dedicated, recognizable SMS Mobile Application Icon badge
export const SmsAppIcon: React.FC<{ className?: string; size?: number }> = ({ className = 'w-4 h-4', size }) => (
  <span
    style={size ? { width: size, height: size } : undefined}
    className={`inline-flex items-center justify-center rounded-lg bg-linear-to-br from-blue-500 via-blue-600 to-indigo-600 text-white shadow-xs shrink-0 p-0.5 ${className}`}
    title="تطبيق الرسائل القصيرة SMS"
  >
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" className="w-full h-full">
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
      <circle cx="8" cy="10" r="0.8" fill="currentColor" />
      <circle cx="12" cy="10" r="0.8" fill="currentColor" />
      <circle cx="16" cy="10" r="0.8" fill="currentColor" />
    </svg>
  </span>
);

// Convert Algerian local mobile number (05xx, 06xx, 07xx) to international WhatsApp format (213xxxxxxxxx)
export function formatToAlgerianWhatsApp(phone: string): string {
  const digits = phone.replace(/\D/g, '');
  if (digits.startsWith('213')) {
    return digits;
  }
  if (digits.startsWith('0')) {
    return '213' + digits.slice(1);
  }
  if (digits.length === 9) {
    return '213' + digits;
  }
  return digits;
}

// Generate multi-recipient SMS URI compatible with Android, iOS and Desktop messaging apps
export function getBatchSmsUri(phones: string[], message: string): string {
  if (phones.length === 0) return '#';
  const isIOS = typeof navigator !== 'undefined' && /iPad|iPhone|iPod/.test(navigator.userAgent);
  const separator = isIOS ? ';' : ',';
  const prefix = isIOS ? '&body=' : '?body=';
  return `sms:${phones.join(separator)}${prefix}${encodeURIComponent(message)}`;
}

// Generate single-recipient SMS URI
export function getSingleSmsUri(phone: string, message: string): string {
  if (!phone) return '#';
  return `sms:${phone}?body=${encodeURIComponent(message)}`;
}

interface SmsNotificationModalProps {
  student?: Student;
  allAbsentStudents?: Student[];
  date: string;
  session: 'morning' | 'afternoon';
  settings: SchoolSettings;
  initialChannel?: 'sms' | 'whatsapp';
  onClose: () => void;
  onNotificationSent: (studentId: string, message: string, channel: 'sms' | 'whatsapp') => void;
  onBatchNotificationSent?: (studentIds: string[], message: string, channel: 'sms' | 'whatsapp') => void;
}

export const SmsNotificationModal: React.FC<SmsNotificationModalProps> = ({
  student,
  allAbsentStudents,
  date,
  session,
  settings,
  initialChannel = 'whatsapp',
  onClose,
  onNotificationSent,
  onBatchNotificationSent,
}) => {
  const isBatchMode = Boolean(allAbsentStudents && allAbsentStudents.length > 0 && !student);
  const targetStudents = isBatchMode ? (allAbsentStudents || []) : (student ? [student] : []);
  const initialStudent = targetStudents[0];

  const sessionLabel = session === 'morning' ? 'الفترة الصباحية' : 'الفترة المسائية';

  // Selected Channel: 'sms' | 'whatsapp'
  const [channel, setChannel] = useState<'sms' | 'whatsapp'>(initialChannel);

  // Preset templates
  const templates = [
    {
      id: 'absence_day4',
      name: 'إشعار اليوم الرابع من الغياب (المرحلة 1)',
      template: `السلام عليكم، إشعار رسمي من ${settings.schoolName} (${settings.wilaya}):\nنحيطكم علماً بأن التلميذ(ة) {اسم_التلميذ} ({القسم}) قد بلغ اليوم الرابع من الغياب المتتالي دون عذر شرعي.\nيرجى من الولي التقدم العاجل لمصلحة الاستشارة لتبرير الغياب وتفادي الإجراءات التأديبية.`,
    },
    {
      id: 'absence_stage2',
      name: 'إشعار 2 بالغياب بعد أسبوع (المرحلة 2)',
      template: `السلام عليكم، إشعار 2 بالغياب من ${settings.schoolName}:\nبعد انقضاء أسبوع على الغياب وتواصل انقطاع التلميذ(ة) {اسم_التلميذ} ({القسم})، نوجه إليكم إشعار 2 للتنبيه بضرورة الالتحاق الفوري بالمتوسطة لتسوية الوضعية قبل إحالة الملف للإعذار القانوني.`,
    },

    {
      id: 'formal_warning',
      name: 'إعذار رسمي باستئناف الدراسة (بعد 15 يوماً من أول يوم غياب)',
      template: `إعذار رسمي أخير من إدارة ${settings.schoolName}:\nإلى ولي أمر التلميذ(ة) {اسم_التلميذ} ({القسم})، بعد انقضاء مهلة 15 يوماً من تاريخ أول يوم غياب للتلميذ دون مبرر، نلزمكم باستئنافه للدراسة خلال 48 ساعة وإلا سيتم الشطب النهائي من سجلات التمدرس.`,
    },
    {
      id: 'absence',
      name: 'إشعار غياب يومي',
      template: `السلام عليكم ورحمة الله،\nإشعار من ${settings.schoolName} (${settings.wilaya}):\nنحيطكم علماً بغياب ابنكم/ابنتكم {اسم_التلميذ} ({القسم}) عن ${sessionLabel} اليوم ${date}.\nيرجى التقدم لإدارة المؤسسة أو الاتصال لتبرير الغياب حرصاً على مصلحة التلميذ وتفادياً للإجراءات الإدارية.`,
    },
    {
      id: 'urgent',
      name: 'استدعاء عاجل للولي',
      template: `السلام عليكم،\nاستدعاء إداري من ${settings.schoolName} (${settings.wilaya}):\nنرجو من ولي أمر التلميذ(ة) {اسم_التلميذ} ({القسم}) الحضور لمصلحة الاستشارة التربوية بالمؤسسة لأمر إداري وتربوي هام.`,
    },
    {
      id: 'late',
      name: 'تنبيه تأخر متكرر',
      template: `السلام عليكم،\nتنبيه انضباط من ${settings.schoolName}:\nسجل التلميذ(ة) {اسم_التلميذ} ({القسم}) تأخراً عن موعد الدخول الرسمي اليوم. نرجو منكم الحرص والتأكيد عليه بالحضور قبل الساعة 08:00 صباحاً.`,
    },
  ];

  const [selectedTemplateId, setSelectedTemplateId] = useState('absence');
  const [copied, setCopied] = useState(false);
  const [copiedNumbers, setCopiedNumbers] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [batchProgress, setBatchProgress] = useState<{ current: number; total: number } | null>(null);
  const [sendSuccess, setSendSuccess] = useState(false);

  // Generate customized message
  const getPersonalizedMessage = (st: Student) => {
    const rawTemplate = templates.find((t) => t.id === selectedTemplateId)?.template || templates[0].template;
    return rawTemplate
      .replace(/{اسم_التلميذ}/g, `${st.firstName} ${st.lastName}`)
      .replace(/{القسم}/g, st.classroom);
  };

  const [customMessage, setCustomMessage] = useState(() => {
    if (initialStudent) {
      return getPersonalizedMessage(initialStudent);
    }
    return templates[0].template;
  });

  // Handle template switch
  const handleSelectTemplate = (templateId: string) => {
    setSelectedTemplateId(templateId);
    if (initialStudent) {
      const rawTemplate = templates.find((t) => t.id === templateId)?.template || templates[0].template;
      setCustomMessage(
        rawTemplate
          .replace(/{اسم_التلميذ}/g, `${initialStudent.firstName} ${initialStudent.lastName}`)
          .replace(/{القسم}/g, initialStudent.classroom)
      );
    }
  };

  // Copy to clipboard
  const handleCopy = () => {
    navigator.clipboard.writeText(customMessage);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  // Copy all absent student parent numbers
  const handleCopyAllNumbers = () => {
    const numbers = targetStudents.map((s) => s.guardianPhone).filter(Boolean).join(', ');
    navigator.clipboard.writeText(numbers);
    setCopiedNumbers(true);
    setTimeout(() => setCopiedNumbers(false), 2500);
  };

  // WhatsApp International Phone Number
  const whatsappNumber = initialStudent
    ? formatToAlgerianWhatsApp(initialStudent.guardianPhone)
    : '';

  const whatsappDirectUrl = initialStudent
    ? `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(customMessage)}`
    : '#';

  const directSmsUri = initialStudent
    ? getSingleSmsUri(initialStudent.guardianPhone, customMessage)
    : '#';

  // Batch phones list & Batch SMS URI
  const batchPhoneNumbers = targetStudents.map((s) => s.guardianPhone).filter(Boolean);
  const batchSmsUri = getBatchSmsUri(batchPhoneNumbers, customMessage);

  // Launch SMS App in batch mode and optionally record
  const handleLaunchBatchSmsApp = () => {
    try {
      window.location.href = batchSmsUri;
    } catch {
      // Ignore if protocol handler blocked
    }
    if (onBatchNotificationSent) {
      onBatchNotificationSent(
        targetStudents.map((s) => s.id),
        customMessage,
        'sms'
      );
      setSendSuccess(true);
      setTimeout(() => {
        onClose();
      }, 1800);
    }
  };

  // Handle Send or Launch
  const handleSend = async () => {
    setIsSending(true);

    if (isBatchMode && onBatchNotificationSent) {
      const total = targetStudents.length;
      for (let i = 0; i < total; i++) {
        setBatchProgress({ current: i + 1, total });
        await new Promise((r) => setTimeout(r, 200));
      }
      onBatchNotificationSent(
        targetStudents.map((s) => s.id),
        customMessage,
        channel
      );
    } else if (initialStudent) {
      // If WhatsApp single, open WhatsApp safely in new tab
      if (channel === 'whatsapp') {
        try {
          const a = document.createElement('a');
          a.href = whatsappDirectUrl;
          a.target = '_blank';
          a.rel = 'noopener noreferrer';
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
        } catch {
          // Fallback if DOM manipulation fails
        }
      }
      await new Promise((r) => setTimeout(r, 600));
      onNotificationSent(initialStudent.id, customMessage, channel);
    }

    setIsSending(false);
    setSendSuccess(true);
    setTimeout(() => {
      onClose();
    }, 1600);
  };

  // Character calculation
  const charCount = customMessage.length;
  const partsCount = Math.ceil(charCount / 160) || 1;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-xl max-w-xl w-full p-6 space-y-4 border border-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center border transition-colors ${
                channel === 'whatsapp'
                  ? 'bg-slate-50 text-slate-600 border-slate-200'
                  : 'bg-blue-50 text-blue-600 border-blue-200'
              }`}
            >
              {channel === 'whatsapp' ? (
                <MessageCircle className="w-5 h-5 text-slate-600" />
              ) : (
                <SmsAppIcon className="w-6 h-6" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-slate-900 text-sm">
                  {isBatchMode
                    ? `إرسال إشعار غياب جماعي (${targetStudents.length} تلميذ)`
                    : `إشعار ولي التلميذ: ${initialStudent?.lastName} ${initialStudent?.firstName}`}
                </h3>
                {isBatchMode && channel === 'sms' && (
                  <span className="inline-flex items-center gap-1 bg-blue-100 text-blue-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                    <SmsAppIcon className="w-3 h-3" />
                    <span>تطبيق SMS</span>
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500">
                {settings.schoolName} · {settings.wilaya} · {sessionLabel}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Channel Switcher (SMS vs WhatsApp) */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-slate-700 block">
            طريقة إرسال الإشعار:
          </label>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setChannel('whatsapp')}
              className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                channel === 'whatsapp'
                  ? 'border-slate-500 bg-slate-50 text-slate-800 shadow-xs ring-1 ring-slate-500'
                  : 'border-slate-200 bg-slate-50/60 text-slate-600 hover:bg-slate-100'
              }`}
            >
              <MessageCircle className="w-4 h-4 text-slate-600" />
              <span>واتساب (WhatsApp)</span>
              <span className="text-[10px] bg-slate-200/60 text-slate-900 px-1.5 py-0.2 rounded-full font-normal">
                مباشر ومجاني
              </span>
            </button>

            <button
              type="button"
              onClick={() => setChannel('sms')}
              className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                channel === 'sms'
                  ? 'border-blue-500 bg-blue-50 text-blue-800 shadow-xs ring-1 ring-blue-500'
                  : 'border-slate-200 bg-slate-50/60 text-slate-600 hover:bg-slate-100'
              }`}
            >
              <SmsAppIcon className="w-4 h-4" />
              <span>تطبيق الرسائل (SMS)</span>
              <span className="text-[10px] bg-blue-200/60 text-blue-900 px-1.5 py-0.2 rounded-full font-normal">
                تطبيق الهاتف
              </span>
            </button>
          </div>
        </div>

        {/* Recipient Details (Single Mode) */}
        {!isBatchMode && initialStudent && (
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs">
            <div className="space-y-0.5">
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-900">{initialStudent.guardianName}</span>
                <span className="text-[10px] text-slate-500">(ولي التلميذ: {initialStudent.firstName})</span>
              </div>
              <div className="text-slate-500 text-[11px]">
                القسم: <strong className="text-slate-700">{initialStudent.classroom}</strong>
              </div>
            </div>

            <div
              className={`flex items-center gap-1.5 font-mono-numbers font-bold px-2.5 py-1 rounded-lg border ${
                channel === 'whatsapp'
                  ? 'text-slate-800 bg-slate-50 border-slate-200'
                  : 'text-blue-800 bg-blue-50 border-blue-200'
              }`}
            >
              {channel === 'whatsapp' ? (
                <MessageCircle className="w-3.5 h-3.5 text-slate-600" />
              ) : (
                <SmsAppIcon className="w-3.5 h-3.5" />
              )}
              <span>{initialStudent.guardianPhone}</span>
            </div>
          </div>
        )}

        {/* Batch Mode Overview with SMS App trigger */}
        {isBatchMode && (
          <div
            className={`p-3 rounded-xl border text-xs space-y-2.5 ${
              channel === 'sms'
                ? 'bg-blue-50/60 border-blue-200'
                : 'bg-slate-50/60 border-slate-200'
            }`}
          >
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2 font-bold text-slate-900">
                {channel === 'sms' ? (
                  <SmsAppIcon className="w-5 h-5" />
                ) : (
                  <MessageCircle className="w-5 h-5 text-slate-600" />
                )}
                <span>
                  إرسال الغيابات لـ {targetStudents.length} ولي تلميذ غائب
                  {channel === 'sms' ? ' عبر تطبيق الرسائل القصيرة (SMS)' : ' عبر واتساب'}
                </span>
              </div>

              {channel === 'sms' && (
                <button
                  type="button"
                  onClick={handleCopyAllNumbers}
                  className="flex items-center gap-1 text-[11px] font-semibold text-blue-700 bg-white hover:bg-blue-50 border border-blue-200 px-2 py-1 rounded-md transition-colors cursor-pointer"
                  title="نسخ أرقام جميع الأولياء دفعة واحدة"
                >
                  {copiedNumbers ? <Check className="w-3 h-3 text-slate-600" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedNumbers ? 'تم نسخ الأرقام' : `نسخ كل الأرقام (${batchPhoneNumbers.length})`}</span>
                </button>
              )}
            </div>

            {/* Absent Students Pills with mini SMS launchers */}
            <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto pt-0.5">
              {targetStudents.map((st) => (
                <div
                  key={st.id}
                  className="inline-flex items-center gap-1 bg-white border border-slate-200 px-2 py-1 rounded-md text-[10px] text-slate-800 shadow-2xs"
                >
                  <span className="font-bold">{st.lastName} {st.firstName}</span>
                  <span className="text-slate-400">({st.classroom})</span>
                  <span className="font-mono-numbers text-slate-500 mr-0.5">{st.guardianPhone}</span>

                  {channel === 'sms' && st.guardianPhone && (
                    <a
                      href={getSingleSmsUri(st.guardianPhone, getPersonalizedMessage(st))}
                      className="text-blue-600 hover:text-blue-800 p-0.5 rounded hover:bg-blue-50 transition-colors"
                      title={`فتح تطبيق SMS لولي التلميذ ${st.lastName} ${st.firstName}`}
                    >
                      <SmsAppIcon className="w-3 h-3" />
                    </a>
                  )}

                  {channel === 'whatsapp' && st.guardianPhone && (
                    <a
                      href={`https://wa.me/${formatToAlgerianWhatsApp(st.guardianPhone)}?text=${encodeURIComponent(getPersonalizedMessage(st))}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-slate-600 hover:text-slate-800 p-0.5 rounded hover:bg-slate-50 transition-colors"
                      title={`فتح محادثة واتساب لولي التلميذ ${st.lastName} ${st.firstName}`}
                    >
                      <MessageCircle className="w-3 h-3" />
                    </a>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Templates Selector */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-slate-700 block">
            اختر نموذج الرسالة:
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {templates.map((tpl) => (
              <button
                key={tpl.id}
                type="button"
                onClick={() => handleSelectTemplate(tpl.id)}
                className={`p-2.5 rounded-xl border text-right text-xs transition-all cursor-pointer ${
                  selectedTemplateId === tpl.id
                    ? channel === 'whatsapp'
                      ? 'border-slate-500 bg-slate-50/70 font-bold text-slate-950 shadow-2xs'
                      : 'border-blue-500 bg-blue-50/70 font-bold text-blue-950 shadow-2xs'
                    : 'border-slate-200 hover:border-slate-300 text-slate-600'
                }`}
              >
                <span>{tpl.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Message Editor */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <label className="font-semibold text-slate-700">
              نص الرسالة الموجهة للولي:
            </label>
            <div className="flex items-center gap-3 text-[11px] text-slate-400 font-mono-numbers">
              <span>{charCount} حرف</span>
              {channel === 'sms' && (
                <>
                  <span>·</span>
                  <span>{partsCount} رسالة SMS</span>
                </>
              )}
            </div>
          </div>

          <textarea
            rows={4}
            value={customMessage}
            onChange={(e) => setCustomMessage(e.target.value)}
            className="w-full p-3 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent leading-relaxed bg-slate-50/50"
            placeholder="اكتب نص الرسالة هنا..."
          />
        </div>

        {/* Success Alert */}
        {sendSuccess && (
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center gap-2 text-xs text-slate-800 font-bold animate-fade-in">
            <CheckCircle2 className="w-4 h-4 text-slate-600 shrink-0" />
            <span>
              {channel === 'whatsapp'
                ? 'تم فتح وتوثيق إشعار واتساب بنجاح في سجل الغياب!'
                : 'تم إرسال إشعار SMS وتوثيق العملية في سجل الغياب!'}
            </span>
          </div>
        )}

        {/* Batch Progress Bar */}
        {batchProgress && (
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs text-slate-600">
              <span>جارٍ معالجة الإشعارات...</span>
              <span className="font-mono-numbers">{batchProgress.current} / {batchProgress.total}</span>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
              <div
                className={`h-2 rounded-full transition-all duration-300 ${
                  channel === 'whatsapp' ? 'bg-slate-600' : 'bg-blue-600'
                }`}
                style={{ width: `${(batchProgress.current / batchProgress.total) * 100}%` }}
              />
            </div>
          </div>
        )}

        {/* Action Controls */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2.5 pt-3 border-t border-slate-100">
          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
            {/* Copy message button */}
            <button
              type="button"
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
              title="نسخ نص الرسالة"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-slate-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'تم النسخ' : 'نسخ النص'}</span>
            </button>

            {/* BATCH MODE: Direct Open SMS Application with SMS App Icon */}
            {isBatchMode && channel === 'sms' && (
              <a
                href={batchSmsUri}
                onClick={handleLaunchBatchSmsApp}
                className="flex items-center gap-2 px-3.5 py-2 text-xs font-bold text-white bg-linear-to-r from-blue-600 via-indigo-600 to-blue-700 hover:from-blue-700 hover:to-indigo-800 rounded-xl transition-all shadow-xs cursor-pointer active:scale-95"
                title="فتح تطبيق الرسائل القصيرة في هاتفك أو حاسوبك وإرسال نص الغياب لجميع أرقام الأولياء"
              >
                <SmsAppIcon className="w-4 h-4" />
                <span>فتح تطبيق الرسائل SMS للجميع ({batchPhoneNumbers.length})</span>
                <ExternalLink className="w-3.5 h-3.5 opacity-90" />
              </a>
            )}

            {/* SINGLE MODE: Direct Open SMS Application */}
            {!isBatchMode && initialStudent && channel === 'sms' && (
              <a
                href={directSmsUri}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition-colors"
                title="فتح تطبيق الرسائل في الهاتف"
              >
                <SmsAppIcon className="w-3.5 h-3.5" />
                <span>فتح تطبيق SMS</span>
                <ExternalLink className="w-3 h-3 opacity-70" />
              </a>
            )}

            {/* SINGLE MODE: WhatsApp direct link */}
            {!isBatchMode && initialStudent && channel === 'whatsapp' && (
              <a
                href={whatsappDirectUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors"
                title="فتح في واتساب ويب أو التطبيق مباشرة"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>واتساب ويب / الهاتف</span>
              </a>
            )}
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs text-slate-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
            >
              إلغاء
            </button>

            <button
              type="button"
              disabled={isSending || sendSuccess}
              onClick={handleSend}
              className={`flex items-center gap-2 px-5 py-2 text-xs font-bold text-white rounded-xl transition-all cursor-pointer shadow-xs ${
                isSending || sendSuccess
                  ? 'bg-slate-400 cursor-not-allowed'
                  : channel === 'whatsapp'
                  ? 'bg-slate-600 hover:bg-slate-700 active:scale-95'
                  : 'bg-blue-600 hover:bg-blue-700 active:scale-95'
              }`}
            >
              {channel === 'whatsapp' ? (
                <MessageCircle className="w-4 h-4" />
              ) : isBatchMode ? (
                <SmsAppIcon className="w-4 h-4" />
              ) : (
                <Send className="w-4 h-4" />
              )}
              <span>
                {isSending
                  ? 'جارٍ الإرسال...'
                  : isBatchMode
                  ? channel === 'sms'
                    ? `توثيق إرسال SMS للجميع (${targetStudents.length})`
                    : `إرسال للجميع عبر WhatsApp (${targetStudents.length})`
                  : channel === 'whatsapp'
                  ? 'إرسال عبر WhatsApp'
                  : 'إرسال إشعار SMS'}
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
