import React, { useState, useMemo } from 'react';
import { Student, AttendanceRecord, SchoolSettings, GradeLevel, PeriodId } from '../types';
import { SmsNotificationModal, SmsAppIcon } from './SmsNotificationModal';
import {
  Search,
  Filter,
  CheckCircle2,
  Clock,
  UserX,
  FileCheck,
  Download,
  Printer,
  Calendar,
  AlertCircle,
  FileText,
  UserCheck,
  MessageSquare,
  MessageCircle,
  Smartphone,
  Send,
  FileSpreadsheet,
  Sun,
  Moon,
  Layers,
  X,
  BookOpen,
  User,
  MapPin,
} from 'lucide-react';

import { exportAttendanceToExcel } from '../utils/excelExport';
import { getSettingsPeriods, getPeriodById, matchRecordPeriod } from '../utils/periodHelper';
import {
  getAbsentStudentSubjectInfo,
  SUBJECT_INFO,
  getSubjectForClassroom,
  getSchoolDay,
  mapPeriodToSlotId,
} from '../data/timetableData';
import { useTheme } from '../context/ThemeContext';

interface DailyAttendanceProps {
  students: Student[];
  records: AttendanceRecord[];
  settings: SchoolSettings;
  currentSession: 'morning' | 'afternoon';
  currentPeriodId?: string;
  onChangePeriod?: (periodId: PeriodId) => void;
  onAddRecord: (record: AttendanceRecord) => void;
  onUpdateRecord: (record: AttendanceRecord) => void;
  onOpenLateTicket: (record: AttendanceRecord, student: Student) => void;
  onViewStudentCard: (student: Student) => void;
}

export const DailyAttendance: React.FC<DailyAttendanceProps> = ({
  students,
  records,
  settings,
  currentSession,
  currentPeriodId = 'm1',
  onChangePeriod,
  onAddRecord,
  onUpdateRecord,
  onOpenLateTicket,
  onViewStudentCard,
}) => {
  const { palette } = useTheme();
  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [selectedPeriodFilter, setSelectedPeriodFilter] = useState<string>(
    currentPeriodId || currentSession
  );
  const [statusFilter, setStatusFilter] = useState<'all' | 'present' | 'late' | 'absent' | 'excused'>('all');
  const [gradeFilter, setGradeFilter] = useState<string>('all');
  const [classroomFilter, setClassroomFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [excuseModalStudent, setExcuseModalStudent] = useState<Student | null>(null);
  const [excuseReasonInput, setExcuseReasonInput] = useState<string>('شهادة طبية معتمدة');
  const [notificationModal, setNotificationModal] = useState<{
    student?: Student;
    isBatch?: boolean;
    defaultChannel: 'sms' | 'whatsapp';
  } | null>(null);
  const [isCallingSheetOpen, setIsCallingSheetOpen] = useState(false);
  const [feedbackNotice, setFeedbackNotice] = useState<string | null>(null);
  const [subjectModalStudent, setSubjectModalStudent] = useState<{
    student: Student;
    detail: ReturnType<typeof getAbsentStudentSubjectInfo>;
  } | null>(null);

  const periods = getSettingsPeriods(settings);

  // Determine effective period id for creating records
  const effectivePeriodId: string =
    selectedPeriodFilter.startsWith('m') || selectedPeriodFilter.startsWith('a')
      ? selectedPeriodFilter
      : selectedPeriodFilter === 'afternoon'
      ? 'a1'
      : 'm1';

  // Filter records for selected date and session/period
  const sessionRecords = useMemo(() => {
    return records.filter(
      (r) =>
        r.date === selectedDate &&
        matchRecordPeriod(r.session || r.periodId || 'm1', selectedPeriodFilter)
    );
  }, [records, selectedDate, selectedPeriodFilter]);

  // Map students with their attendance status
  const studentsWithStatus = useMemo(() => {
    return students.map((student) => {
      const record = sessionRecords.find((r) => r.studentId === student.id);
      let status: 'present' | 'late' | 'absent' | 'excused' = 'absent';
      if (record) {
        status = record.status;
      }
      return {
        student,
        record,
        status,
      };
    });
  }, [students, sessionRecords]);

  // Available classrooms for filter dropdown
  const availableClassrooms = useMemo(() => {
    const set = new Set<string>();
    students.forEach((s) => {
      if (gradeFilter === 'all' || s.grade === gradeFilter) {
        set.add(s.classroom);
      }
    });
    return Array.from(set).sort();
  }, [students, gradeFilter]);

  // Filtered list
  const filteredList = useMemo(() => {
    return studentsWithStatus.filter(({ student, status }) => {
      const matchesStatus = statusFilter === 'all' || status === statusFilter;
      const matchesGrade = gradeFilter === 'all' || student.grade === gradeFilter;
      const matchesClass = classroomFilter === 'all' || student.classroom === classroomFilter;
      const matchesSearch =
        !searchQuery ||
        student.firstName.includes(searchQuery) ||
        student.lastName.includes(searchQuery) ||
        student.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        student.barcode.includes(searchQuery) ||
        student.classroom.includes(searchQuery);

      return matchesStatus && matchesGrade && matchesClass && matchesSearch;
    });
  }, [studentsWithStatus, statusFilter, gradeFilter, classroomFilter, searchQuery]);

  // Counts
  const presentCount = studentsWithStatus.filter((s) => s.status === 'present').length;
  const lateCount = studentsWithStatus.filter((s) => s.status === 'late').length;
  const absentCount = studentsWithStatus.filter((s) => s.status === 'absent').length;
  const excusedCount = studentsWithStatus.filter((s) => s.status === 'excused').length;
  const totalCount = students.length;

  // Handle Manual Mark Present
  const handleManualMarkPresent = (student: Student) => {
    const now = new Date();
    const timeStr = now.toTimeString().split(' ')[0];
    const newRecord: AttendanceRecord = {
      id: `ATT-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      studentId: student.id,
      barcode: student.barcode,
      studentName: `${student.lastName} ${student.firstName}`,
      grade: student.grade,
      classroom: student.classroom,
      date: selectedDate,
      timestamp: timeStr,
      fullDateTime: now.toISOString(),
      session: effectivePeriodId,
      periodId: effectivePeriodId as PeriodId,
      status: 'present',
      lateMinutes: 0,
      device: 'manual',
      notes: 'تسجيل يدوي بواسطة مستشار التربية',
    };
    onAddRecord(newRecord);
  };

  // Filtered absent count
  const filteredAbsentList = useMemo(() => {
    return filteredList.filter((s) => s.status === 'absent');
  }, [filteredList]);


  // Handle Mark All Filtered Absent as Present
  const handleMarkAllFilteredPresent = () => {
    if (filteredAbsentList.length === 0) return;
    const now = new Date();
    const timeStr = now.toTimeString().split(' ')[0];

    filteredAbsentList.forEach((item, index) => {
      const student = item.student;
      const newRecord: AttendanceRecord = {
        id: `ATT-${Date.now()}-${index}-${Math.floor(Math.random() * 1000)}`,
        studentId: student.id,
        barcode: student.barcode,
        studentName: `${student.lastName} ${student.firstName}`,
        grade: student.grade,
        classroom: student.classroom,
        date: selectedDate,
        timestamp: timeStr,
        fullDateTime: now.toISOString(),
        session: effectivePeriodId,
        periodId: effectivePeriodId as PeriodId,
        status: 'present',
        lateMinutes: 0,
        device: 'manual',
        notes: 'تسجيل جماعي سريع بواسطة مستشار التربية',
      };
      onAddRecord(newRecord);
    });

    setFeedbackNotice(`تم تسجيل حضور جميع التلاميذ (${filteredAbsentList.length} تلميذ) بنجاح.`);
    setTimeout(() => setFeedbackNotice(null), 4000);
  };

  // Handle Excuse Submit
  const handleSaveExcuse = () => {
    if (!excuseModalStudent) return;
    const now = new Date();
    const existing = sessionRecords.find((r) => r.studentId === excuseModalStudent.id);

    if (existing) {
      onUpdateRecord({
        ...existing,
        status: 'excused',
        excuseReason: excuseReasonInput,
      });
    } else {
      const newRecord: AttendanceRecord = {
        id: `ATT-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        studentId: excuseModalStudent.id,
        barcode: excuseModalStudent.barcode,
        studentName: `${excuseModalStudent.lastName} ${excuseModalStudent.firstName}`,
        grade: excuseModalStudent.grade,
        classroom: excuseModalStudent.classroom,
        date: selectedDate,
        timestamp: '08:00:00',
        fullDateTime: now.toISOString(),
        session: effectivePeriodId,
        periodId: effectivePeriodId as PeriodId,
        status: 'excused',
        lateMinutes: 0,
        device: 'manual',
        excuseReason: excuseReasonInput,
      };
      onAddRecord(newRecord);
    }
    setExcuseModalStudent(null);
  };

  // Absent students list for batch notifications
  const absentStudentsList = useMemo(() => {
    return studentsWithStatus
      .filter((s) => s.status === 'absent')
      .map((s) => s.student);
  }, [studentsWithStatus]);

  // Handle single notification sent (SMS or WhatsApp)
  const handleSingleNotificationSent = (
    studentId: string,
    message: string,
    channel: 'sms' | 'whatsapp'
  ) => {
    const existing = sessionRecords.find((r) => r.studentId === studentId);
    const now = new Date();
    const timeStr = now.toTimeString().split(' ')[0];

    if (existing) {
      onUpdateRecord({
        ...existing,
        smsSent: true,
        smsSentAt: timeStr,
        smsMessage: message,
        notificationChannel: channel,
      });
    } else {
      const st = students.find((s) => s.id === studentId);
      if (!st) return;
      const newRecord: AttendanceRecord = {
        id: `ATT-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        studentId: st.id,
        barcode: st.barcode,
        studentName: `${st.lastName} ${st.firstName}`,
        grade: st.grade,
        classroom: st.classroom,
        date: selectedDate,
        timestamp: '08:00:00',
        fullDateTime: now.toISOString(),
        session: effectivePeriodId,
        periodId: effectivePeriodId as PeriodId,
        status: 'absent',
        lateMinutes: 0,
        device: 'manual',
        smsSent: true,
        smsSentAt: timeStr,
        smsMessage: message,
        notificationChannel: channel,
      };
      onAddRecord(newRecord);
    }
  };

  // Handle batch notification sent (SMS or WhatsApp)
  const handleBatchNotificationSent = (
    studentIds: string[],
    message: string,
    channel: 'sms' | 'whatsapp'
  ) => {
    const now = new Date();
    const timeStr = now.toTimeString().split(' ')[0];

    studentIds.forEach((id) => {
      const existing = sessionRecords.find((r) => r.studentId === id);
      if (existing) {
        onUpdateRecord({
          ...existing,
          smsSent: true,
          smsSentAt: timeStr,
          smsMessage: message,
          notificationChannel: channel,
        });
      } else {
        const st = students.find((s) => s.id === id);
        if (!st) return;
        const newRecord: AttendanceRecord = {
          id: `ATT-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          studentId: st.id,
          barcode: st.barcode,
          studentName: `${st.lastName} ${st.firstName}`,
          grade: st.grade,
          classroom: st.classroom,
          date: selectedDate,
          timestamp: '08:00:00',
          fullDateTime: now.toISOString(),
          session: effectivePeriodId,
          periodId: effectivePeriodId as PeriodId,
          status: 'absent',
          lateMinutes: 0,
          device: 'manual',
          smsSent: true,
          smsSentAt: timeStr,
          smsMessage: message,
          notificationChannel: channel,
        };
        onAddRecord(newRecord);
      }
    });
  };

  // Excel Export with Algerian institutional header and RTL layout
  const handleExportExcel = () => {
    if (filteredList.length === 0) {
      alert('لا توجد سجلات حضور مسجلة للتصدير حالياً.');
      return;
    }

    exportAttendanceToExcel(filteredList, settings, {
      selectedDate,
      selectedSession: effectivePeriodId.startsWith('a') ? 'afternoon' : 'morning',
      selectedPeriod: selectedPeriodFilter,
      filterClassroom: classroomFilter,
      filterGrade: gradeFilter,
      filterStatus: statusFilter,
    });
  };

  // Official Print
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-5">
      {/* Filters & Date Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4 no-print">
        <div className="flex flex-wrap items-center gap-3">
          {/* Date Picker */}
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-slate-500" />
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="text-xs font-mono-numbers px-2.5 py-1.5 rounded-lg border border-slate-300 bg-slate-50 focus:ring-1 focus:ring-slate-500 cursor-pointer"
            />
          </div>

          {/* Cohort & Period Filter Selector */}
          <div className="flex items-center gap-1.5 bg-slate-100/90 rounded-lg p-1 border border-slate-200">
            <Clock className="w-3.5 h-3.5 text-slate-500 mr-1" />
            <select
              value={selectedPeriodFilter}
              onChange={(e) => {
                const val = e.target.value;
                setSelectedPeriodFilter(val);
                if (onChangePeriod && (val.startsWith('m') || val.startsWith('a'))) {
                  onChangePeriod(val as PeriodId);
                }
              }}
              className="text-xs font-semibold bg-white border border-slate-200 rounded-md py-1 px-2.5 text-slate-800 shadow-2xs focus:ring-1 focus:ring-slate-500 cursor-pointer"
            >
              <option value="all">كل اليوم (جميع الفترات والأفواج)</option>
              <optgroup label="الفترة الصباحية (3 أفواج)">
                <option value="morning">الفترة الصباحية (كل الأفواج)</option>
                {periods
                  .filter((p) => p.type === 'morning')
                  .map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} (الدخول: {p.startTime})
                    </option>
                  ))}
              </optgroup>
              <optgroup label="الفترة المسائية (3 أفواج)">
                <option value="afternoon">الفترة المسائية (كل الأفواج)</option>
                {periods
                  .filter((p) => p.type === 'afternoon')
                  .map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} (الدخول: {p.startTime})
                    </option>
                  ))}
              </optgroup>
            </select>
          </div>

          {/* Grade Selector */}
          <select
            value={gradeFilter}
            onChange={(e) => {
              setGradeFilter(e.target.value);
              setClassroomFilter('all');
            }}
            className="text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white cursor-pointer"
          >
            <option value="all">كل المستويات الدراسية</option>
            <option value="1AM">الأولى متوسط (1AM)</option>
            <option value="2AM">الثانية متوسط (2AM)</option>
            <option value="3AM">الثالثة متوسط (3AM)</option>
            <option value="4AM">الرابعة متوسط (4AM)</option>
          </select>

          {/* Classroom Selector */}
          <select
            value={classroomFilter}
            onChange={(e) => setClassroomFilter(e.target.value)}
            className="text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white cursor-pointer"
          >
            <option value="all">كل الأقسام</option>
            {availableClassrooms.map((cls) => (
              <option key={cls} value={cls}>
                قسم {cls}
              </option>
            ))}
          </select>
        </div>

        {/* Actions Export & Print & Batch Notifications (WhatsApp & SMS) */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Quick Mark All Filtered Present */}
          {filteredAbsentList.length > 0 && (
            <button
              onClick={handleMarkAllFilteredPresent}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg transition-all cursor-pointer shadow-2xs hover:shadow-xs active:scale-98"
              title="تسجيل حضور جميع التلاميذ الغائبين في الفلتر الحالي بنقرة واحدة"
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-slate-700" />
              <span>تسجيل حضور كل المعروضين ({filteredAbsentList.length})</span>
            </button>
          )}

          {absentCount > 0 && (
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setNotificationModal({ isBatch: true, defaultChannel: 'whatsapp' })}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-800 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors cursor-pointer shadow-2xs"
                title="إرسال إشعار عبر واتساب لجميع أولياء التلاميذ الغائبين دفعة واحدة"
              >
                <MessageCircle className="w-3.5 h-3.5 text-slate-600" />
                <span>إشعار واتساب ({absentCount})</span>
              </button>
              <button
                onClick={() => setNotificationModal({ isBatch: true, defaultChannel: 'sms' })}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-900 bg-blue-50/90 hover:bg-blue-100 border border-blue-300 rounded-lg transition-all cursor-pointer shadow-2xs hover:shadow-xs active:scale-98"
                title="فتح تطبيق SMS لإرسال الغيابات لجميع أولياء التلاميذ الغائبين دفعة واحدة"
              >
                <SmsAppIcon className="w-4 h-4" />
                <span>تطبيق SMS للغائبين ({absentCount})</span>
              </button>
            </div>
          )}

          <button
            onClick={() => setIsCallingSheetOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg transition-colors cursor-pointer shadow-2xs"
            title="طباعة استمارة المناداة الورقية الرسمية للقسم للأساتذة والمشرفين"
          >
            <FileText className="w-3.5 h-3.5 text-slate-700" />
            <span>ورقة مناداة القسم (A4)</span>
          </button>

          <button
            onClick={handleExportExcel}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-800 bg-slate-50 hover:bg-slate-100 border border-slate-300 rounded-lg transition-colors cursor-pointer shadow-2xs"
            title="تصدير كشف الحضور والغياب اليومي كملف Excel متناسق ومنسق رسمياً"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-slate-700" />
            تصدير (Excel)
          </button>
          <button
            onClick={handlePrint}
            style={{ backgroundColor: palette.primary, color: palette.foreground }}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer shadow-xs hover:opacity-95"
          >
            <Printer className="w-3.5 h-3.5" />
            طباعة الكشف
          </button>
        </div>
      </div>

      {/* Real-time Feedback Banner */}
      {feedbackNotice && (
        <div className="bg-slate-600 text-white text-xs px-4 py-2 rounded-xl flex items-center justify-between shadow-xs animate-in fade-in duration-200 no-print">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-slate-200" />
            <span className="font-semibold">{feedbackNotice}</span>
          </div>
          <button onClick={() => setFeedbackNotice(null)} className="p-1 hover:bg-slate-700 rounded-md">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Status Segmented Tabs Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 no-print">
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl text-xs font-medium">
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 ${
              statusFilter === 'all'
                ? 'bg-white text-slate-900 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Layers className="w-3.5 h-3.5 text-slate-500" />
            <span>الكل</span>
            <span className="font-mono-numbers text-[10px] bg-slate-200 px-1.5 py-0.2 rounded-full">
              {totalCount}
            </span>
          </button>

          <button
            onClick={() => setStatusFilter('present')}
            className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 ${
              statusFilter === 'present'
                ? 'bg-slate-600 text-white shadow-xs font-bold'
                : 'text-slate-700 hover:text-slate-900'
            }`}
          >
            <CheckCircle2 className={`w-3.5 h-3.5 ${statusFilter === 'present' ? 'text-white' : 'text-slate-600'}`} />
            <span>الحاضرون</span>
            <span className={`font-mono-numbers text-[10px] px-1.5 py-0.2 rounded-full ${
              statusFilter === 'present' ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-800'
            }`}>
              {presentCount}
            </span>
          </button>

          <button
            onClick={() => setStatusFilter('late')}
            className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 ${
              statusFilter === 'late'
                ? 'bg-amber-600 text-white shadow-xs font-bold'
                : 'text-amber-700 hover:text-amber-900'
            }`}
          >
            <Clock className={`w-3.5 h-3.5 ${statusFilter === 'late' ? 'text-white' : 'text-amber-600'}`} />
            <span>المتأخرون</span>
            <span className={`font-mono-numbers text-[10px] px-1.5 py-0.2 rounded-full ${
              statusFilter === 'late' ? 'bg-white/20 text-white' : 'bg-amber-100 text-amber-800'
            }`}>
              {lateCount}
            </span>
          </button>

          <button
            onClick={() => setStatusFilter('absent')}
            className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 ${
              statusFilter === 'absent'
                ? 'bg-slate-600 text-white shadow-xs font-bold'
                : 'text-slate-700 hover:text-slate-900'
            }`}
          >
            <UserX className={`w-3.5 h-3.5 ${statusFilter === 'absent' ? 'text-white' : 'text-slate-600'}`} />
            <span>الغائبون</span>
            <span className={`font-mono-numbers text-[10px] px-1.5 py-0.2 rounded-full ${
              statusFilter === 'absent' ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-800'
            }`}>
              {absentCount}
            </span>
          </button>

          <button
            onClick={() => setStatusFilter('excused')}
            className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 ${
              statusFilter === 'excused'
                ? 'bg-blue-600 text-white shadow-xs font-bold'
                : 'text-blue-700 hover:text-blue-900'
            }`}
          >
            <FileCheck className={`w-3.5 h-3.5 ${statusFilter === 'excused' ? 'text-white' : 'text-blue-600'}`} />
            <span>مبررون</span>
            <span className={`font-mono-numbers text-[10px] px-1.5 py-0.2 rounded-full ${
              statusFilter === 'excused' ? 'bg-white/20 text-white' : 'bg-blue-100 text-blue-800'
            }`}>
              {excusedCount}
            </span>
          </button>
        </div>

        {/* Live Search */}
        <div className="relative min-w-[240px]">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="بحث بالاسم أو رقم الباركود..."
            className="w-full pr-8 pl-3 py-1.5 text-xs rounded-lg border border-slate-300 bg-white"
          />
        </div>
      </div>

      {/* Printable Official Header (Shows only when printing) */}
      <div className="hidden print:block text-center pb-4 mb-4 border-b border-slate-400">
        <p className="text-xs">الجمهورية الجزائرية الديمقراطية الشعبية · وزارة التربية الوطنية</p>
        <p className="text-xs font-medium">مديرية التربية لولاية {settings.wilaya} · {settings.schoolName}</p>
        <h2 className="text-lg font-bold mt-1">
          سجل الحضور والغيابات اليومي - {
            selectedPeriodFilter === 'all'
              ? 'كامل اليوم (جميع الفترات والأفواج)'
              : selectedPeriodFilter === 'morning'
              ? 'الفترة الصباحية (كل الأفواج)'
              : selectedPeriodFilter === 'afternoon'
              ? 'الفترة المسائية (كل الأفواج)'
              : getPeriodById(settings, selectedPeriodFilter).name
          }
        </h2>
        <p className="text-xs font-mono-numbers mt-0.5">التاريخ: {selectedDate}</p>
      </div>

      {/* Main Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold">
                <th className="py-3 px-4">رقم التسجيل</th>
                <th className="py-3 px-4">اللقب والاسم</th>
                <th className="py-3 px-4">المستوى والقسم</th>
                <th className="py-3 px-4">رمز الباركود</th>
                <th className="py-3 px-4">حالة الحضور</th>
                <th className="py-3 px-4">وقت الدخول</th>
                <th className="py-3 px-4">ولي الأمر والهاتف</th>
                <th className="py-3 px-4 text-center no-print">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredList.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    لا توجد سجلات مطابقة للبحث أو التصفية المحددة.
                  </td>
                </tr>
              ) : (
                filteredList.map(({ student, record, status }) => {
                  return (
                    <tr
                      key={student.id}
                      className="hover:bg-slate-50/60 transition-colors"
                    >
                      {/* ID */}
                      <td className="py-3 px-4 font-mono-numbers font-medium text-slate-600">
                        {student.id}
                      </td>

                      {/* Name */}
                      <td className="py-3 px-4 font-bold text-slate-900">
                        {student.lastName} {student.firstName}
                      </td>

                      {/* Grade & Class */}
                      <td className="py-3 px-4">
                        <span className="bg-slate-100 text-slate-800 font-bold px-2 py-0.5 rounded text-[11px]">
                          {student.classroom}
                        </span>
                        <span className="text-slate-400 text-[10px] mr-1.5">
                          ({student.grade})
                        </span>
                      </td>

                      {/* Barcode */}
                      <td className="py-3 px-4 font-mono-numbers text-slate-500">
                        {student.barcode}
                      </td>

                      {/* Status */}
                      <td className="py-3 px-4">
                        {status === 'present' && (
                          <span className="inline-flex items-center gap-1 text-slate-700 bg-slate-50 px-2 py-0.5 rounded-full font-semibold text-[11px]">
                            <CheckCircle2 className="w-3 h-3" />
                            حاضر في الموعد
                          </span>
                        )}
                        {status === 'late' && (
                          <span className="inline-flex items-center gap-1 text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full font-semibold text-[11px]">
                            <Clock className="w-3 h-3" />
                            متأخر (+{record?.lateMinutes}د)
                          </span>
                        )}
                        {status === 'absent' && (() => {
                          const absentDetail = getAbsentStudentSubjectInfo(student, {
                            date: selectedDate,
                            periodId: effectivePeriodId,
                          });
                          const subjectStyle = absentDetail?.subject ? SUBJECT_INFO[absentDetail.subject] : null;

                          return (
                            <div className="flex flex-col gap-1 items-start">
                              <span className="inline-flex items-center gap-1 text-slate-700 bg-slate-50 px-2 py-0.5 rounded-full font-semibold text-[11px]">
                                <UserX className="w-3 h-3" />
                                غائب
                              </span>

                              {absentDetail && (
                                <button
                                  type="button"
                                  onClick={() => setSubjectModalStudent({ student, detail: absentDetail })}
                                  className={`inline-flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.5 rounded border transition-all hover:scale-105 cursor-pointer text-right ${
                                    subjectStyle
                                      ? `${subjectStyle.bg} ${subjectStyle.text} ${subjectStyle.border}`
                                      : 'bg-slate-100 text-slate-800 border-slate-200'
                                  }`}
                                  title={`المادة: ${absentDetail.subject} • الأستاذ: ${absentDetail.teacherName} • القاعة: ${absentDetail.room} (انقر لعرض التفاصيل)`}
                                >
                                  <BookOpen className="w-2.5 h-2.5 shrink-0" />
                                  <span className="truncate max-w-[110px]">{absentDetail.subject}</span>
                                </button>
                              )}

                              {record?.smsSent && (
                                <span
                                  className={`inline-flex items-center gap-1 text-[10px] font-bold mt-0.5 ${
                                    record.notificationChannel === 'whatsapp'
                                      ? 'text-slate-700'
                                      : 'text-blue-700'
                                  }`}
                                >
                                  <CheckCircle2 className="w-2.5 h-2.5" />
                                  {record.notificationChannel === 'whatsapp'
                                    ? 'أُشعر عبر واتساب'
                                    : 'أُرسل SMS للولي'}
                                </span>
                              )}
                            </div>
                          );
                        })()}
                        {status === 'excused' && (
                          <span className="inline-flex items-center gap-1 text-blue-700 bg-blue-50 px-2 py-0.5 rounded-full font-semibold text-[11px]">
                            <FileCheck className="w-3 h-3" />
                            غياب مبرر
                          </span>
                        )}
                      </td>

                      {/* Scan Time */}
                      <td className="py-3 px-4 font-mono-numbers text-slate-700">
                        {record?.timestamp ? record.timestamp : '—'}
                      </td>

                      {/* Guardian */}
                      <td className="py-3 px-4 text-slate-600">
                        <div>{student.guardianName}</div>
                        <div className="flex items-center gap-1.5 font-mono-numbers text-[10px] text-slate-500 mt-0.5">
                          <span>{student.guardianPhone}</span>
                          {status === 'absent' && (
                            <div className="flex items-center gap-0.5 mr-1">
                              <button
                                onClick={() => setNotificationModal({ student, defaultChannel: 'whatsapp' })}
                                className="p-1 text-slate-600 hover:text-slate-800 hover:bg-slate-50 rounded cursor-pointer transition-colors"
                                title="إشعار الولي عبر واتساب"
                              >
                                <MessageCircle className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => setNotificationModal({ student, defaultChannel: 'sms' })}
                                className="p-1 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded cursor-pointer transition-colors"
                                title="إشعار الولي عبر تطبيق الرسائل SMS"
                              >
                                <SmsAppIcon className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          )}
                        </div>
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-center no-print">
                        <div className="flex items-center justify-center gap-1.5">
                          {status === 'absent' && (
                            <>
                              {/* WhatsApp Button */}
                              <button
                                onClick={() => setNotificationModal({ student, defaultChannel: 'whatsapp' })}
                                className={`flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold rounded-lg transition-colors cursor-pointer ${
                                  record?.smsSent && record?.notificationChannel === 'whatsapp'
                                    ? 'bg-slate-50 text-slate-700 border border-slate-200 hover:bg-slate-100'
                                    : 'bg-slate-600 hover:bg-slate-700 text-white shadow-2xs'
                                }`}
                                title="إشعار الولي عبر WhatsApp"
                              >
                                <MessageCircle className="w-3 h-3" />
                                <span>{record?.smsSent && record?.notificationChannel === 'whatsapp' ? 'أُرسل واتساب' : 'إشعار واتساب'}</span>
                              </button>

                              {/* SMS Button */}
                              <button
                                onClick={() => setNotificationModal({ student, defaultChannel: 'sms' })}
                                className={`flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold rounded-lg transition-colors cursor-pointer ${
                                  record?.smsSent && record?.notificationChannel === 'sms'
                                    ? 'bg-blue-50 text-blue-700 border border-blue-200 hover:bg-blue-100'
                                    : 'bg-blue-600 hover:bg-blue-700 text-white shadow-2xs'
                                }`}
                                title="إشعار الولي برسالة SMS"
                              >
                                <MessageSquare className="w-3 h-3" />
                                <span>{record?.smsSent && record?.notificationChannel === 'sms' ? 'أُرسل SMS' : 'إشعار SMS'}</span>
                              </button>

                              <button
                                onClick={() => handleManualMarkPresent(student)}
                                className="px-2 py-1 text-[11px] font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 rounded transition-colors cursor-pointer"
                                title="تسجيل حضور استثنائي"
                              >
                                تسجيل حضور
                              </button>
                              <button
                                onClick={() => setExcuseModalStudent(student)}
                                className="px-2 py-1 text-[11px] font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded transition-colors cursor-pointer"
                                title="تبرير الغياب"
                              >
                                تبرير
                              </button>
                            </>
                          )}

                          {status === 'late' && record && (
                            <button
                              onClick={() => onOpenLateTicket(record, student)}
                              className="px-2 py-1 text-[11px] font-medium text-amber-800 bg-amber-50 hover:bg-amber-100 rounded transition-colors cursor-pointer"
                              title="طباعة تذكرة الدخول للحصة"
                            >
                              تذكرة التأخر
                            </button>
                          )}

                          <button
                            onClick={() => onViewStudentCard(student)}
                            className="p-1 text-slate-400 hover:text-slate-700 rounded transition-colors cursor-pointer"
                            title="عرض بطاقة التلميذ"
                          >
                            <FileText className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Excuse Modal */}
      {excuseModalStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-5 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-800 text-sm">
                تسجيل تبرير غياب للتلميذ
              </h3>
              <button
                onClick={() => setExcuseModalStudent(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>

            <div className="text-xs text-slate-600 space-y-1">
              <p>
                التلميذ: <strong>{excuseModalStudent.lastName} {excuseModalStudent.firstName}</strong>
              </p>
              <p>
                القسم: <strong>{excuseModalStudent.classroom}</strong> · التاريخ: <strong className="font-mono-numbers">{selectedDate}</strong>
              </p>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-700 block">
                سبب التبرير القانوني / نوع الوثيقة:
              </label>
              <select
                value={excuseReasonInput}
                onChange={(e) => setExcuseReasonInput(e.target.value)}
                className="w-full text-xs p-2 rounded-lg border border-slate-300 bg-white"
              >
                <option value="شهادة طبية معتمدة">شهادة طبية معتمدة (Certificat médical)</option>
                <option value="إشعار وحضور ولي الأمر">إشعار وحضور ولي الأمر إلى المؤسسة</option>
                <option value="ترخيص وظرف عائلي قاهر">ترخيص وظرف عائلي قاهر</option>
                <option value="مشاركة في تظاهرة مدرسية / رياضية">مشاركة في تظاهرة مدرسية / رياضية رسمية</option>
                <option value="استدعاء إداري / قضائي">استدعاء إداري / قضائي رسمي</option>
              </select>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setExcuseModalStudent(null)}
                className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
              >
                إلغاء
              </button>
              <button
                onClick={handleSaveExcuse}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors cursor-pointer"
              >
                حفظ التبرير
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Notification Modal (WhatsApp or SMS) */}
      {notificationModal && (
        <SmsNotificationModal
          student={notificationModal.student}
          allAbsentStudents={notificationModal.isBatch ? absentStudentsList : undefined}
          initialChannel={notificationModal.defaultChannel}
          date={selectedDate}
          session={effectivePeriodId.startsWith('a') ? 'afternoon' : 'morning'}
          settings={settings}
          onClose={() => setNotificationModal(null)}
          onNotificationSent={handleSingleNotificationSent}
          onBatchNotificationSent={handleBatchNotificationSent}
        />
      )}

      {/* Classroom Call-Sheet Modal (استمارة المناداة الورقية الرسمية للقسم) */}
      {isCallingSheetOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full p-6 space-y-4 border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 no-print">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-slate-700" />
                <h3 className="font-bold text-slate-900 text-sm">
                  استمارة المناداة وحصر الغيابات الميدانية (A4)
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="flex items-center gap-1.5 px-4 py-1.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>طباعة الاستمارة</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsCallingSheetOpen(false)}
                  className="text-slate-400 hover:text-slate-600 p-1 rounded-lg cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Calling Sheet Printable Sheet */}
            <div className="border border-slate-400 p-6 rounded-xl space-y-4 text-slate-900 bg-white text-xs">
              <div className="text-center space-y-1 pb-3 border-b-2 border-slate-800">
                <p className="font-bold text-xs">الجمهورية الجزائرية الديمقراطية الشعبية · وزارة التربية الوطنية</p>
                <p className="font-semibold text-[11px]">
                  مديرية التربية لولاية {settings.wilaya} · {settings.schoolName}
                </p>
                <h3 className="text-base font-black text-slate-900 mt-1">
                  استمارة المناداة وحصر الحضور والغيابات الميدانية
                </h3>
                <div className="flex flex-wrap justify-center items-center gap-6 pt-2 font-medium text-slate-700 text-xs">
                  <span>القسم:{' '}
                    <strong className="text-sm font-bold text-slate-900">
                      {classroomFilter === 'all' ? 'جميع الأقسام' : `قسم ${classroomFilter}`}
                    </strong>
                  </span>
                  <span>المستوى: <strong>{gradeFilter === 'all' ? 'الكل' : gradeFilter}</strong></span>
                  <span>التاريخ: <strong className="font-mono">{selectedDate}</strong></span>
                  <span>السنة الدراسية: <strong>{settings.academicYear}</strong></span>
                </div>
                <div className="flex justify-between items-center pt-2 text-[11px] text-slate-600 border-t border-slate-200 mt-2 px-2">
                  <span>اسم الأستاذ(ة): ............................................</span>
                  <span>المادة: ............................................</span>
                  <span>توقيت الحصة: ............................................</span>
                </div>
              </div>

              {/* Pupils Call Table with check boxes for periods */}
              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs border border-slate-400 border-collapse">
                  <thead>
                    <tr className="bg-slate-100 border-b border-slate-400 font-bold text-slate-800 text-[11px]">
                      <th className="p-1.5 border-l border-slate-400 text-center w-8">رقم</th>
                      <th className="p-1.5 border-l border-slate-400 w-24">رقم التسجيل</th>
                      <th className="p-1.5 border-l border-slate-400">اسم ولقب التلميذ</th>
                      <th className="p-1.5 border-l border-slate-400 w-16 text-center">القسم</th>
                      <th className="p-1.5 border-l border-slate-400 text-center w-14">08:00</th>
                      <th className="p-1.5 border-l border-slate-400 text-center w-14">09:00</th>
                      <th className="p-1.5 border-l border-slate-400 text-center w-14">10:00</th>
                      <th className="p-1.5 border-l border-slate-400 text-center w-14">11:00</th>
                      <th className="p-1.5 border-l border-slate-400 text-center w-14">13:00</th>
                      <th className="p-1.5 border-l border-slate-400 text-center w-14">14:00</th>
                      <th className="p-1.5 border-l border-slate-400 text-center w-14">15:00</th>
                      <th className="p-1.5 text-center">ملاحظات الأستاذ</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-300">
                    {filteredList.map((item, idx) => {
                      const st = item.student;

                      return (
                        <tr key={st.id} className="hover:bg-slate-50">
                          <td className="p-1.5 border-l border-slate-400 text-center font-mono-numbers">{idx + 1}</td>
                          <td className="p-1.5 border-l border-slate-400 font-mono-numbers">{st.id}</td>
                          <td className="p-1.5 border-l border-slate-400 font-bold">{st.lastName} {st.firstName}</td>
                          <td className="p-1.5 border-l border-slate-400 text-center font-semibold">{st.classroom}</td>
                          <td className="p-1.5 border-l border-slate-400 text-center"><span className="inline-block w-4 h-4 border border-slate-400 rounded-xs" /></td>
                          <td className="p-1.5 border-l border-slate-400 text-center"><span className="inline-block w-4 h-4 border border-slate-400 rounded-xs" /></td>
                          <td className="p-1.5 border-l border-slate-400 text-center"><span className="inline-block w-4 h-4 border border-slate-400 rounded-xs" /></td>
                          <td className="p-1.5 border-l border-slate-400 text-center"><span className="inline-block w-4 h-4 border border-slate-400 rounded-xs" /></td>
                          <td className="p-1.5 border-l border-slate-400 text-center"><span className="inline-block w-4 h-4 border border-slate-400 rounded-xs" /></td>
                          <td className="p-1.5 border-l border-slate-400 text-center"><span className="inline-block w-4 h-4 border border-slate-400 rounded-xs" /></td>
                          <td className="p-1.5 border-l border-slate-400 text-center"><span className="inline-block w-4 h-4 border border-slate-400 rounded-xs" /></td>
                          <td className="p-1.5 text-center text-slate-400 text-[10px]">....................</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Signatures */}
              <div className="grid grid-cols-2 gap-8 pt-4 border-t border-slate-400 text-center text-xs">
                <div>
                  <p className="font-bold mb-6">توقيع أستاذ(ة) المادة</p>
                  <p className="text-[11px] text-slate-500">التأشيرة بعد نهاية الحصة وإرجاع الورقة للاستشارة</p>
                </div>
                <div>
                  <p className="font-bold mb-6">مستشارة التربية</p>
                  <p className="font-bold">{settings.counselorName}</p>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 no-print">
              <button
                type="button"
                onClick={() => window.print()}
                className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>طباعة الاستمارة الآن</span>
              </button>
              <button
                type="button"
                onClick={() => setIsCallingSheetOpen(false)}
                className="px-3 py-2 text-xs text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Absent Student Missed Subject Details */}
      {subjectModalStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Header */}
            <div className="p-4 sm:p-5 bg-gradient-to-l from-slate-900 to-slate-800 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-slate-500/20 text-slate-300 flex items-center justify-center border border-slate-400/30">
                  <BookOpen className="w-5 h-5 text-slate-300" />
                </div>
                <div>
                  <h3 className="font-bold text-sm sm:text-base">
                    بيانات المادة والأستاذ للتلميذ الغائب
                  </h3>
                  <p className="text-xs text-slate-300">
                    قسم {subjectModalStudent.student.classroom} • {subjectModalStudent.detail?.timeRange}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSubjectModalStudent(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700/50 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content */}
            <div className="p-5 space-y-4 text-xs text-right">
              {/* Student Identity */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
                <div>
                  <div className="font-black text-slate-900 text-sm">
                    {subjectModalStudent.student.lastName} {subjectModalStudent.student.firstName}
                  </div>
                  <div className="text-slate-500 text-[11px] font-mono-numbers mt-0.5">
                    رقم التسجيل: {subjectModalStudent.student.id} | المستوى: {subjectModalStudent.student.grade}
                  </div>
                </div>
                <span className="bg-slate-100 text-slate-800 font-bold px-2.5 py-1 rounded-lg">
                  غائب
                </span>
              </div>

              {/* Missed Class Highlights */}
              <div className="p-4 bg-slate-50/70 border border-slate-200 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 font-medium">المادة التي غاب عنها:</span>
                  <span className="font-black text-sm text-slate-950 bg-white border border-slate-300 px-3 py-1 rounded-lg shadow-2xs">
                    {subjectModalStudent.detail?.subject}
                  </span>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-200/60">
                  <span className="text-slate-500 font-medium">الأستاذ المكلف بالحصة:</span>
                  <span className="font-bold text-slate-900 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-slate-700" />
                    <span>{subjectModalStudent.detail?.teacherName}</span>
                  </span>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-200/60">
                  <span className="text-slate-500 font-medium">القاعة / المخبر:</span>
                  <span className="font-bold text-slate-900 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-amber-600" />
                    <span>{subjectModalStudent.detail?.room}</span>
                  </span>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-200/60">
                  <span className="text-slate-500 font-medium">التوقيت الساعي:</span>
                  <span className="font-mono-numbers font-bold text-slate-800">
                    {subjectModalStudent.detail?.timeRange}
                  </span>
                </div>
              </div>

              {/* Notice snippet for official report */}
              <div className="text-[11px] text-slate-500 bg-slate-50 p-3 rounded-xl border border-slate-200 leading-relaxed">
                يتم تسجيل هذه المعلومة في سجل غيابات الحصة وتسليم استمارة التبليغ لأستاذ المادة للتأشير عليها وحفظ حقوق التلميذ والأستاذ وفق المنشور الوزاري للغيابات.
              </div>
            </div>

            {/* Actions */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => {
                  setNotificationModal({
                    student: subjectModalStudent.student,
                    defaultChannel: 'whatsapp',
                  });
                  setSubjectModalStudent(null);
                }}
                className="px-3 py-2 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>إشعار الولي</span>
              </button>

              <button
                type="button"
                onClick={() => setSubjectModalStudent(null)}
                className="px-4 py-2 text-xs font-bold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
