import React, { useState, useRef, useEffect } from 'react';
import { useTheme } from '../context/ThemeContext';
import { THEME_PRESETS } from '../utils/themeManager';
import { ThemeColorId } from '../types/theme';
import { Palette, Sun, Moon, Laptop, Check, RotateCcw } from 'lucide-react';

interface ThemeQuickMenuProps {
  onThemeSavedToSettings?: (color: ThemeColorId, customHex?: string, mode?: string) => void;
}

export const ThemeQuickMenu: React.FC<ThemeQuickMenuProps> = ({ onThemeSavedToSettings }) => {
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement | null>(null);
  const { config, palette, isDark, setColor, setMode, resetDefault } = useTheme();

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelectColor = (id: ThemeColorId) => {
    setColor(id);
    onThemeSavedToSettings?.(id, config.customHex, config.mode);
  };

  const handleToggleMode = () => {
    const nextMode = isDark ? 'light' : 'dark';
    setMode(nextMode);
    onThemeSavedToSettings?.(config.color, config.customHex, nextMode);
  };

  return (
    <div className="relative" ref={menuRef}>
      <button
        type="button"
        onClick={() => setIsOpen((prev) => !prev)}
        className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-bold rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 transition-all cursor-pointer shadow-2xs"
        title="تغيير مظهر وألوان المنصة"
      >
        <span
          className="w-3.5 h-3.5 rounded-full shrink-0 shadow-2xs"
          style={{ backgroundColor: palette.primary }}
        />
        <Palette className="w-3.5 h-3.5 text-slate-600 dark:text-slate-300" />
        <span className="hidden xl:inline text-[11px]">{palette.nameAr}</span>
      </button>

      {isOpen && (
        <div
          className="absolute left-0 mt-2 w-72 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 p-3.5 z-50 animate-scale-up text-right space-y-3.5"
          dir="rtl"
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
            <span className="text-xs font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
              <Palette className="w-3.5 h-3.5 text-slate-500" />
              <span>المظهر والألوان</span>
            </span>

            {/* Quick Dark Mode Toggle */}
            <button
              type="button"
              onClick={handleToggleMode}
              className="p-1.5 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer transition-colors flex items-center gap-1 text-[11px]"
              title={isDark ? 'التحويل للوضع الفاتح' : 'التحويل للوضع الداكن'}
            >
              {isDark ? (
                <>
                  <Sun className="w-3.5 h-3.5 text-amber-500" />
                  <span className="text-[10px]">نهار</span>
                </>
              ) : (
                <>
                  <Moon className="w-3.5 h-3.5 text-indigo-500" />
                  <span className="text-[10px]">ليل</span>
                </>
              )}
            </button>
          </div>

          {/* Color Palettes Grid */}
          <div>
            <span className="block text-[11px] font-bold text-slate-500 dark:text-slate-400 mb-2">
              اختر لون المنصة الموحد:
            </span>
            <div className="grid grid-cols-4 gap-2">
              {Object.values(THEME_PRESETS).map((p) => {
                const isSelected = config.color === p.id;
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => handleSelectColor(p.id)}
                    className={`flex flex-col items-center gap-1 p-2 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'border-slate-900 dark:border-white ring-2 bg-slate-50 dark:bg-slate-800'
                        : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 bg-white dark:bg-slate-800/40'
                    }`}
                  >
                    <span
                      className="w-5 h-5 rounded-full flex items-center justify-center text-white shadow-2xs"
                      style={{ backgroundColor: p.primary }}
                    >
                      {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                    </span>
                    <span className="text-[10px] font-bold text-slate-800 dark:text-slate-200 truncate w-full text-center">
                      {p.nameAr.split(' ')[0]}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Custom color & Reset */}
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px]">
            <label className="flex items-center gap-1.5 cursor-pointer text-slate-600 dark:text-slate-300 hover:text-slate-900">
              <span
                className="w-4 h-4 rounded border border-slate-300 shadow-2xs inline-block"
                style={{ backgroundColor: palette.primary }}
              />
              <span className="font-semibold">تخصيص حر</span>
              <input
                type="color"
                value={palette.primary}
                onChange={(e) => {
                  setColor('custom', e.target.value);
                  onThemeSavedToSettings?.('custom', e.target.value, config.mode);
                }}
                className="opacity-0 w-0 h-0 absolute"
              />
            </label>

            <button
              type="button"
              onClick={() => {
                resetDefault();
                onThemeSavedToSettings?.('emerald', undefined, 'light');
              }}
              className="text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              <span>استعادة الأصلي</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
