import React, { useState, useEffect, useRef } from 'react';
import { SchoolSettings, PeriodId } from '../types';
import {
  School,
  Clock,
  Sun,
  Moon,
  RefreshCw,
  ChevronDown,
  Check,
  Calendar,
  ShieldAlert,
  Database,
  BarChart3,
  BookOpen,
  UserCheck,
  User,
  LogOut,
  Scan,
  ClipboardCheck,
  Users,
  Settings,
} from 'lucide-react';
import { getSettingsPeriods, getPeriodById } from '../utils/periodHelper';
import { AppUser } from '../types';

import { ViewType, Sidebar } from './Sidebar';
import { TopBar } from './TopBar';

export { Sidebar, TopBar };
export type { ViewType };

interface HeaderProps {
  currentView: ViewType;
  onChangeView: (view: ViewType) => void;
  settings: SchoolSettings;
  currentSession: 'morning' | 'afternoon';
  onToggleSession: () => void;
  currentPeriodId?: string;
  onChangePeriod?: (periodId: PeriodId) => void;
  syncStatus?: 'connected' | 'reconnecting' | 'offline';
  isSyncing?: boolean;
  onManualSync?: () => void;
  lastSyncTime?: string;
  pendingNoticesCount?: number;
  onOpenDataPersistence?: () => void;
  currentUser?: AppUser | null;
  onOpenLoginModal?: () => void;
  onLogout?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onChangeView,
  settings,
  currentSession,
  onToggleSession,
  currentPeriodId = 'm1',
  onChangePeriod,
  syncStatus = 'connected',
  isSyncing = false,
  onManualSync,
  lastSyncTime,
  pendingNoticesCount = 0,
  onOpenDataPersistence,
  currentUser,
  onOpenLoginModal,
  onLogout,
}) => {
  const [timeStr, setTimeStr] = useState<string>('');
  const [isPeriodMenuOpen, setIsPeriodMenuOpen] = useState(false);
  const periodMenuRef = useRef<HTMLDivElement | null>(null);

  const periods = getSettingsPeriods(settings);
  const activePeriod = getPeriodById(settings, currentPeriodId);

  useEffect(() => {
    const update = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString('ar-DZ', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: false,
        })
      );
    };
    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, []);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (periodMenuRef.current && !periodMenuRef.current.contains(event.target as Node)) {
        setIsPeriodMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const morningPeriods = periods.filter((p) => p.type === 'morning');
  const afternoonPeriods = periods.filter((p) => p.type === 'afternoon');

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16 gap-3">
          {/* Zone 1: School Identity */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-10 h-10 rounded-xl bg-slate-800 text-white flex items-center justify-center shadow-xs">
              <School className="w-5 h-5 text-slate-100" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-bold text-slate-900 text-sm sm:text-base leading-tight">
                  {settings.schoolName || 'متوسطة سعدون عاشور'}
                </h1>
                <span className="hidden sm:inline-block text-[11px] font-semibold text-slate-800 bg-slate-50 px-2 py-0.5 rounded border border-slate-200">
                  {settings.schoolType || 'التعليم المتوسط'}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 flex items-center gap-1.5 mt-0.5">
                <span>مديرية التربية لولاية {settings.wilaya || 'عنابة'}</span>
                <span className="text-slate-300">·</span>
                <span className="font-mono-numbers">{settings.academicYear || '2026-2027'}</span>
              </p>
            </div>
          </div>

          {/* Zone 2: Navigation Links with Lateral Icons */}
          <nav className="hidden xl:flex items-center gap-1 border border-slate-200 bg-slate-50 p-1 rounded-xl text-xs font-semibold text-slate-600">
            <button
              onClick={() => onChangeView('scanner')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                currentView === 'scanner'
                  ? 'bg-white text-slate-950 font-bold shadow-xs'
                  : 'hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Scan className="w-3.5 h-3.5 text-slate-700" />
              <span>بوابة الدخول</span>
            </button>
            <button
              onClick={() => onChangeView('attendance')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                currentView === 'attendance'
                  ? 'bg-white text-slate-950 font-bold shadow-xs'
                  : 'hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <ClipboardCheck className="w-3.5 h-3.5 text-slate-700" />
              <span>سجل الحضور اليومي</span>
            </button>
            <button
              onClick={() => onChangeView('students')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                currentView === 'students'
                  ? 'bg-white text-slate-950 font-bold shadow-xs'
                  : 'hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Users className="w-3.5 h-3.5 text-slate-700" />
              <span>شؤون التلاميذ</span>
            </button>
            <button
              onClick={() => onChangeView('timetable')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                currentView === 'timetable'
                  ? 'bg-white text-slate-950 font-bold shadow-xs'
                  : 'hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5 text-blue-700" />
              <span>جداول التوقيت والمواد</span>
            </button>
            <button
              onClick={() => onChangeView('teacher_sessions')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                currentView === 'teacher_sessions'
                  ? 'bg-white text-slate-950 font-bold shadow-xs'
                  : 'hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <UserCheck className="w-3.5 h-3.5 text-slate-700" />
              <span>تسجيلات الأساتذة</span>
            </button>
            <button
              onClick={() => onChangeView('monthly')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                currentView === 'monthly'
                  ? 'bg-white text-slate-950 font-bold shadow-xs'
                  : 'hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Calendar className="w-3.5 h-3.5 text-slate-700" />
              <span>التقارير الشهرية</span>
            </button>
            <button
              onClick={() => onChangeView('notices')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 relative ${
                currentView === 'notices'
                  ? 'bg-white text-amber-950 font-bold shadow-xs'
                  : 'hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <ShieldAlert className="w-3.5 h-3.5 text-amber-600" />
              <span>إشعارات الغياب</span>
              {pendingNoticesCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] font-black bg-slate-600 text-white animate-pulse">
                  {pendingNoticesCount}
                </span>
              )}
            </button>
            <button
              onClick={() => onChangeView('reports')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                currentView === 'reports'
                  ? 'bg-white text-slate-950 font-bold shadow-xs'
                  : 'hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5 text-teal-700" />
              <span>الإحصائيات</span>
            </button>
            <button
              onClick={() => onChangeView('settings')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                currentView === 'settings'
                  ? 'bg-white text-slate-950 font-bold shadow-xs'
                  : 'hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Settings className="w-3.5 h-3.5 text-slate-600" />
              <span>الإعدادات</span>
            </button>
          </nav>

          {/* Zone 3: Data Persistence Button, Sync, Period & Clock */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Direct Data Persistence / Save Button */}
            {onOpenDataPersistence && (
              <button
                type="button"
                onClick={onOpenDataPersistence}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-slate-700 hover:bg-slate-800 active:scale-95 rounded-xl shadow-xs transition-all cursor-pointer"
                title="فتح مركز حفظ وإدارة قاعدة البيانات"
              >
                <Database className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">حفظ البيانات</span>
              </button>
            )}

            {/* Live Server Sync Status */}
            <div
              className={`flex items-center gap-1.5 px-2.5 py-1 text-[11px] rounded-lg border transition-all ${
                syncStatus === 'connected'
                  ? 'bg-slate-50 text-slate-900 border-slate-200'
                  : syncStatus === 'reconnecting'
                  ? 'bg-amber-50 text-amber-900 border-amber-200'
                  : 'bg-slate-50 text-slate-900 border-slate-200'
              }`}
              title={
                syncStatus === 'connected'
                  ? `متصل بالخادم المركزي مباشرة - آخر مزامنة: ${lastSyncTime || 'الآن'}`
                  : 'جاري محاولة إعادة الاتصال بالخادم...'
              }
            >
              <span className="relative flex h-2 w-2">
                {syncStatus === 'connected' && (
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-slate-400 opacity-75"></span>
                )}
                <span
                  className={`relative inline-flex rounded-full h-2 w-2 ${
                    syncStatus === 'connected'
                      ? 'bg-slate-600'
                      : syncStatus === 'reconnecting'
                      ? 'bg-amber-500'
                      : 'bg-slate-500'
                  }`}
                ></span>
              </span>

              <span className="font-semibold hidden lg:inline">
                {syncStatus === 'connected'
                  ? 'مزامنة حية'
                  : syncStatus === 'reconnecting'
                  ? 'إعادة اتصال'
                  : 'غير متصل'}
              </span>

              {onManualSync && (
                <button
                  type="button"
                  onClick={onManualSync}
                  className="p-0.5 text-slate-500 hover:text-slate-900 cursor-pointer rounded transition-colors"
                  title="مزامنة التحديثات فوراً من الخادم"
                >
                  <RefreshCw
                    className={`w-3 h-3 ${isSyncing ? 'animate-spin text-slate-600' : ''}`}
                  />
                </button>
              )}
            </div>

            {/* Period Multi-Cohort Switcher Dropdown */}
            <div className="relative" ref={periodMenuRef}>
              <button
                type="button"
                onClick={() => setIsPeriodMenuOpen((prev) => !prev)}
                className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-bold rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 transition-colors cursor-pointer text-slate-800 shadow-2xs whitespace-nowrap"
                title="تحديد فترة دخول الفوج"
              >
                {activePeriod.type === 'morning' ? (
                  <Sun className="w-3.5 h-3.5 text-amber-600" />
                ) : (
                  <Moon className="w-3.5 h-3.5 text-indigo-600" />
                )}
                <span className="hidden md:inline">{activePeriod.shortName || activePeriod.name}</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {isPeriodMenuOpen && (
                <div className="absolute left-0 mt-1.5 w-72 bg-white rounded-xl shadow-xl border border-slate-200 p-2 z-50 animate-scale-up text-right">
                  <div className="px-2 py-1.5 text-[11px] font-bold text-slate-400 border-b border-slate-100 flex items-center justify-between">
                    <span>فترات دخول الأفواج</span>
                    <span className="text-[10px] text-slate-700">6 فترات زمنية</span>
                  </div>

                  <div className="py-1">
                    <div className="px-2 py-1 text-[10px] font-bold text-amber-800 bg-amber-50/70 rounded mb-1 flex items-center gap-1">
                      <Sun className="w-3 h-3" />
                      <span>الفترات الصباحية (3 أفواج)</span>
                    </div>
                    <div className="space-y-0.5">
                      {morningPeriods.map((p) => {
                        const isSelected = p.id === currentPeriodId;
                        return (
                          <button
                            key={p.id}
                            type="button"
                            onClick={() => {
                              onChangePeriod?.(p.id);
                              setIsPeriodMenuOpen(false);
                            }}
                            className={`w-full text-right px-2.5 py-1.5 text-xs rounded-lg flex items-center justify-between transition-colors cursor-pointer ${
                              isSelected
                                ? 'bg-slate-50 text-slate-950 font-bold border border-slate-200'
                                : 'hover:bg-slate-50 text-slate-700'
                            }`}
                          >
                            <span className="truncate">{p.name}</span>
                            {isSelected && <Check className="w-3.5 h-3.5 text-slate-700 shrink-0" />}
                          </button>
                        );
                      })}
                    </div>

                    <div className="px-2 py-1 text-[10px] font-bold text-indigo-800 bg-indigo-50/70 rounded my-1 flex items-center gap-1">
                      <Moon className="w-3 h-3" />
                      <span>الفترات المسائية (3 أفواج)</span>
                    </div>
                    <div className="space-y-0.5">
                      {afternoonPeriods.map((p) => {
                        const isSelected = p.id === currentPeriodId;
                        return (
                          <button
                            key={p.id}
                            type="button"
                            onClick={() => {
                              onChangePeriod?.(p.id);
                              setIsPeriodMenuOpen(false);
                            }}
                            className={`w-full text-right px-2.5 py-1.5 text-xs rounded-lg flex items-center justify-between transition-colors cursor-pointer ${
                              isSelected
                                ? 'bg-slate-50 text-slate-950 font-bold border border-slate-200'
                                : 'hover:bg-slate-50 text-slate-700'
                            }`}
                          >
                            <span className="truncate">{p.name}</span>
                            {isSelected && <Check className="w-3.5 h-3.5 text-slate-700 shrink-0" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Live Clock */}
            <div className="hidden sm:flex items-center gap-1.5 text-xs font-mono-numbers font-bold text-slate-800 bg-slate-100 px-3 py-1.5 rounded-lg border border-slate-200">
              <Clock className="w-3.5 h-3.5 text-slate-500" />
              <span>{timeStr || '--:--:--'}</span>
            </div>

            {/* User Identity / Switcher */}
            {currentUser ? (
              <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 px-2 sm:px-2.5 py-1 rounded-xl">
                <div className="w-6 h-6 rounded-lg bg-slate-800 text-white flex items-center justify-center text-xs font-bold shrink-0">
                  <User className="w-3.5 h-3.5 text-slate-100" />
                </div>
                <div className="hidden lg:block text-right">
                  <span className="block text-[11px] font-bold text-slate-800 leading-tight truncate max-w-[120px]">
                    {currentUser.name}
                  </span>
                  <span className="text-[10px] text-slate-700 font-semibold">
                    {currentUser.role === 'admin' ? 'المدير' : 'أستاذ'}
                  </span>
                </div>
                {onOpenLoginModal && (
                  <button
                    type="button"
                    onClick={onOpenLoginModal}
                    className="px-1.5 py-0.5 text-slate-500 hover:text-slate-900 rounded-md cursor-pointer text-[10px] font-semibold hover:bg-slate-200/60"
                    title="تبديل المستخدم"
                  >
                    تبديل
                  </button>
                )}
                {onLogout && (
                  <button
                    type="button"
                    onClick={onLogout}
                    className="p-1 text-slate-500 hover:text-slate-700 rounded-md cursor-pointer hover:bg-slate-50"
                    title="تسجيل الخروج"
                  >
                    <LogOut className="w-3 h-3" />
                  </button>
                )}
              </div>
            ) : (
              onOpenLoginModal && (
                <button
                  type="button"
                  onClick={onOpenLoginModal}
                  className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-bold text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-xl transition-all cursor-pointer shadow-2xs"
                >
                  <User className="w-3.5 h-3.5" />
                  <span>دخول الأساتذة</span>
                </button>
              )
            )}
          </div>
        </div>

        {/* Medium and Mobile Navigation bar */}
        <div className="xl:hidden flex items-center py-2 border-t border-slate-100 text-xs overflow-x-auto gap-1 no-scrollbar">
          <button
            onClick={() => onChangeView('scanner')}
            className={`whitespace-nowrap px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 ${
              currentView === 'scanner' ? 'font-bold text-slate-900 bg-slate-50' : 'text-slate-600'
            }`}
          >
            <Scan className="w-3.5 h-3.5 text-slate-700" />
            <span>بوابة الدخول</span>
          </button>
          <button
            onClick={() => onChangeView('attendance')}
            className={`whitespace-nowrap px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 ${
              currentView === 'attendance' ? 'font-bold text-slate-900 bg-slate-50' : 'text-slate-600'
            }`}
          >
            <ClipboardCheck className="w-3.5 h-3.5 text-slate-700" />
            <span>سجل الحضور</span>
          </button>
          <button
            onClick={() => onChangeView('students')}
            className={`whitespace-nowrap px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 ${
              currentView === 'students' ? 'font-bold text-slate-900 bg-slate-50' : 'text-slate-600'
            }`}
          >
            <Users className="w-3.5 h-3.5 text-slate-700" />
            <span>شؤون التلاميذ</span>
          </button>
          <button
            onClick={() => onChangeView('timetable')}
            className={`whitespace-nowrap px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 ${
              currentView === 'timetable' ? 'font-bold text-slate-900 bg-slate-50' : 'text-slate-600'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5 text-blue-700" />
            <span>جداول التوقيت</span>
          </button>
          <button
            onClick={() => onChangeView('teacher_sessions')}
            className={`whitespace-nowrap px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 ${
              currentView === 'teacher_sessions' ? 'font-bold text-slate-900 bg-slate-50' : 'text-slate-600'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5 text-slate-700" />
            <span>تسجيلات الأساتذة</span>
          </button>
          <button
            onClick={() => onChangeView('monthly')}
            className={`whitespace-nowrap px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 ${
              currentView === 'monthly' ? 'font-bold text-slate-900 bg-slate-50' : 'text-slate-600'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>التقارير الشهرية</span>
          </button>
          <button
            onClick={() => onChangeView('notices')}
            className={`whitespace-nowrap px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 ${
              currentView === 'notices' ? 'font-bold text-amber-900 bg-amber-50' : 'text-slate-600'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5 text-amber-600" />
            <span>إشعارات الغياب</span>
            {pendingNoticesCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-slate-600 text-white">
                {pendingNoticesCount}
              </span>
            )}
          </button>
          <button
            onClick={() => onChangeView('reports')}
            className={`whitespace-nowrap px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 ${
              currentView === 'reports' ? 'font-bold text-slate-900 bg-slate-50' : 'text-slate-600'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5 text-blue-700" />
            <span>الإحصائيات</span>
          </button>
          <button
            onClick={() => onChangeView('settings')}
            className={`whitespace-nowrap px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 ${
              currentView === 'settings' ? 'font-bold text-slate-900 bg-slate-50' : 'text-slate-600'
            }`}
          >
            <Settings className="w-3.5 h-3.5 text-slate-700" />
            <span>الإعدادات</span>
          </button>
        </div>
      </div>
    </header>
  );
};
