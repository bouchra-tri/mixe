import React, { useState, useMemo, useEffect } from 'react';
import { createPortal } from 'react-dom';
import * as XLSX from 'xlsx';
import { Student, SchoolSettings, GradeLevel } from '../types';
import { StudentBadge } from './StudentBadge';
import { ExcelImportModal } from './ExcelImportModal';
import { StudentRegistryScannerModal } from './StudentRegistryScannerModal';
import { normalizeBarcode } from '../utils/barcodeNormalizer';

import { soundEffects } from '../utils/barcode';
import { exportStudentsToExcel } from '../utils/excelExport';
import { useTheme } from '../context/ThemeContext';
import {
  UserPlus,
  Search,
  Printer,
  Edit,
  Trash2,
  FileText,
  X,
  Check,
  GraduationCap,
  Users,
  Grid,
  List,
  FileSpreadsheet,
  AlertTriangle,
  CheckSquare,
  Square,
  AlertCircle,
  CheckCheck,
  RefreshCw,
  ArrowRightLeft,
  Download,
  Database,
  Calendar,
  PhoneCall,
  Activity,
  Save,
  Scan,
  QrCode,
  Camera
} from 'lucide-react';

interface StudentManagementProps {
  students: Student[];
  settings: SchoolSettings;
  onAddStudent: (student: Student) => void;
  onUpdateStudent: (student: Student) => void;
  onDeleteStudent: (id: string) => void;
  onDeleteMultipleStudents?: (ids: string[]) => void;
  onViewStudentCard: (student: Student) => void;
  onImportExcelStudents?: (imported: Student[], mode: 'upsert' | 'append' | 'replace') => void;
  onBulkTransferStudents?: (studentIds: string[], newClassroom: string, newGrade?: GradeLevel) => void;
  dbLastUpdated?: string;
  onForceSyncDatabase?: () => void;
  studentToEdit?: Student | null;
  onClearStudentToEdit?: () => void;
}

export const StudentManagement: React.FC<StudentManagementProps> = ({
  students,
  settings,
  onAddStudent,
  onUpdateStudent,
  onDeleteStudent,
  onDeleteMultipleStudents,
  onViewStudentCard,
  onImportExcelStudents,
  onBulkTransferStudents,
  dbLastUpdated,
  onForceSyncDatabase,
  studentToEdit,
  onClearStudentToEdit,
}) => {
  const { palette } = useTheme();
  const [searchQuery, setSearchQuery] = useState('');
  const [gradeFilter, setGradeFilter] = useState<string>('all');
  const [classroomFilter, setClassroomFilter] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isExcelModalOpen, setIsExcelModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [isBatchPrintModalOpen, setIsBatchPrintModalOpen] = useState(false);
  const [batchPrintScope, setBatchPrintScope] = useState<'all' | 'classroom' | 'grade' | 'selected'>('all');
  const [batchClassroom, setBatchClassroom] = useState<string>('all');
  const [batchGrade, setBatchGrade] = useState<string>('all');
  const [cardsPerPage, setCardsPerPage] = useState<number>(6);

  // Registry Scanner Modal state
  const [isScanModalOpen, setIsScanModalOpen] = useState(false);
  const [isScanningForForm, setIsScanningForForm] = useState(false);

  // Bulk Classroom / Grade Transfer Modal state
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [transferScope, setTransferScope] = useState<'selected' | 'classroom' | 'filtered'>('selected');
  const [transferSourceClassroom, setTransferSourceClassroom] = useState<string>('all');
  const [transferTargetClassroom, setTransferTargetClassroom] = useState<string>('');
  const [transferTargetGrade, setTransferTargetGrade] = useState<GradeLevel | ''>('');
  const [isCustomClassroom, setIsCustomClassroom] = useState(false);

  // Bulk Selection and Bulk Deletion States
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [isBulkDeleteModalOpen, setIsBulkDeleteModalOpen] = useState(false);
  const [bulkDeleteTargetScope, setBulkDeleteTargetScope] = useState<'selected' | 'filtered' | 'classroom' | 'all'>('selected');
  const [bulkDeleteClassroom, setBulkDeleteClassroom] = useState<string>('all');
  const [bulkDeleteConfirmCheck, setBulkDeleteConfirmCheck] = useState(false);
  const [feedbackMessage, setFeedbackMessage] = useState<string | null>(null);
  const [modalSearchQuery, setModalSearchQuery] = useState('');

  // Form State for Add / Edit
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    gender: 'M' as 'M' | 'F',
    grade: '1AM' as GradeLevel,
    classroom: '1م1',
    birthDate: '2013-01-01',
    birthPlace: 'عنابة',
    nationalId: '',
    guardianName: '',
    guardianPhone: '',
    address: '',
    notes: '',
  });

  // Extract unique classrooms
  const availableClassrooms = useMemo(() => {
    const set = new Set<string>();
    students.forEach((s) => set.add(s.classroom));
    return Array.from(set).sort();
  }, [students]);

  // Filter students
  const filteredStudents = useMemo(() => {
    return students.filter((s) => {
      const matchesGrade = gradeFilter === 'all' || s.grade === gradeFilter;
      const matchesClass = classroomFilter === 'all' || s.classroom === classroomFilter;
      const matchesSearch =
        !searchQuery ||
        s.firstName.includes(searchQuery) ||
        s.lastName.includes(searchQuery) ||
        s.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.barcode.includes(searchQuery) ||
        s.guardianPhone.includes(searchQuery);

      return matchesGrade && matchesClass && matchesSearch;
    });
  }, [students, gradeFilter, classroomFilter, searchQuery]);

  // Handle open add modal
  const handleOpenAddModal = () => {
    const nextNum = students.length + 101;
    setFormData({
      firstName: '',
      lastName: '',
      gender: 'M',
      grade: '1AM',
      classroom: '1م1',
      birthDate: '2013-05-15',
      birthPlace: 'عنابة',
      nationalId: `1210283${nextNum}`,
      guardianName: '',
      guardianPhone: '066',
      address: 'عنابة',
      notes: '',
    });
    setEditingStudent(null);
    setIsAddModalOpen(true);
  };

  // Handle open edit
  const handleOpenEdit = (student: Student) => {
    setEditingStudent(student);
    setFormData({
      firstName: student.firstName,
      lastName: student.lastName,
      gender: student.gender,
      grade: student.grade,
      classroom: student.classroom,
      birthDate: student.birthDate,
      birthPlace: student.birthPlace || '',
      nationalId: student.nationalId,
      guardianName: student.guardianName,
      guardianPhone: student.guardianPhone,
      address: student.address || '',
      notes: student.notes || '',
    });
    setIsAddModalOpen(true);
  };

  // Automatically open edit modal when triggered externally
  useEffect(() => {
    if (studentToEdit) {
      handleOpenEdit(studentToEdit);
      onClearStudentToEdit?.();
    }
  }, [studentToEdit]);

  // Handler when a student is selected from Scanner Modal
  const handleSelectInRegistry = (student: Student) => {
    setSearchQuery(student.barcode || student.lastName);
    setGradeFilter('all');
    setClassroomFilter('all');
    setFeedbackMessage(`تم تحديد التلميذ ${student.lastName} ${student.firstName} (${student.classroom}) في السجل.`);
    setTimeout(() => setFeedbackMessage(null), 4000);
  };

  // Handler when user chooses to add a new student with scanned barcode
  const handleAddNewWithBarcode = (scannedBarcode: string) => {
    const nextNum = students.length + 101;
    const normalized = normalizeBarcode(scannedBarcode);
    setFormData({
      firstName: '',
      lastName: '',
      gender: 'M',
      grade: '1AM',
      classroom: '1م1',
      birthDate: '2013-05-15',
      birthPlace: 'عنابة',
      nationalId: normalized || scannedBarcode,
      guardianName: '',
      guardianPhone: '066',
      address: 'عنابة',
      notes: '',
    });
    setEditingStudent(null);
    setIsAddModalOpen(true);
    setFeedbackMessage(`تم فتح استمارة التسجيل برقم الباركود الممسوح: ${normalized || scannedBarcode}`);
    setTimeout(() => setFeedbackMessage(null), 4000);
  };

  // Keyboard listener for laser gun when scanning for form
  useEffect(() => {
    if (!isScanningForForm) return;

    let formBuffer = '';
    let formLastTime = Date.now();

    const handleFormScanKeyDown = (e: KeyboardEvent) => {
      const now = Date.now();
      const diff = now - formLastTime;
      formLastTime = now;

      if (e.key === 'Enter') {
        if (formBuffer.length >= 3) {
          e.preventDefault();
          const cleanCode = normalizeBarcode(formBuffer);
          setFormData((prev) => ({
            ...prev,
            nationalId: cleanCode || formBuffer,
          }));
          soundEffects.playSuccess();
          setIsScanningForForm(false);
          setFeedbackMessage(`تم التقاط رقم الباركود: ${cleanCode || formBuffer}`);
          setTimeout(() => setFeedbackMessage(null), 3500);
        }
        formBuffer = '';
        return;
      }

      if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
        if (diff < 75) {
          formBuffer += e.key;
        } else {
          formBuffer = e.key;
        }
      }
    };

    window.addEventListener('keydown', handleFormScanKeyDown);
    return () => {
      window.removeEventListener('keydown', handleFormScanKeyDown);
    };
  }, [isScanningForForm]);

  // Handle submit form with reactive database feedback
  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.firstName || !formData.lastName) return;

    if (editingStudent) {
      const updated: Student = {
        ...editingStudent,
        ...formData,
      };
      onUpdateStudent(updated);
      setFeedbackMessage(`تم تحديث بيانات التلميذ "${updated.lastName} ${updated.firstName}" وحفظ التغييرات في قاعدة البيانات فورياً.`);
    } else {
      const randomSuffix = Math.floor(1000 + Math.random() * 9000);
      const gradeNum = formData.grade === '1AM' ? '101' : formData.grade === '2AM' ? '202' : formData.grade === '3AM' ? '303' : '404';
      const newBarcode = `2026${gradeNum}${randomSuffix.toString().slice(0, 3)}`;

      const newStudent: Student = {
        id: `SA-2026-${Math.floor(100 + Math.random() * 900)}`,
        barcode: newBarcode,
        ...formData,
      };
      onAddStudent(newStudent);
      setFeedbackMessage(`تمت إضافة التلميذ "${newStudent.lastName} ${newStudent.firstName}" وتحديث قاعدة البيانات بنجاح.`);
    }

    setTimeout(() => {
      setFeedbackMessage(null);
    }, 4500);

    setIsAddModalOpen(false);
  };

  // Export current students roster to Excel with institutional header & RTL
  const handleExportStudentsToExcel = () => {
    const isFiltered = classroomFilter !== 'all' || gradeFilter !== 'all' || !!searchQuery.trim();
    const targetStudents = isFiltered ? filteredStudents : students;

    if (targetStudents.length === 0) {
      alert('لا توجد بيانات تلاميذ مسجلة للتصدير حالياً.');
      return;
    }

    exportStudentsToExcel(targetStudents, settings, {
      filterClassroom: classroomFilter,
      filterGrade: gradeFilter,
      isFiltered,
    });

    setFeedbackMessage(`تم تصدير ملف Excel متناسق بنجاح (${targetStudents.length} تلميذ).`);
    setTimeout(() => setFeedbackMessage(null), 4000);
  };

  // Export full JSON backup of students
  const handleExportJsonBackup = () => {
    const backupData = {
      version: '1.0',
      schoolName: settings.schoolName,
      academicYear: settings.academicYear,
      exportTimestamp: new Date().toISOString(),
      studentsCount: students.length,
      classroomsCount: availableClassrooms.length,
      students,
    };
    const blob = new Blob([JSON.stringify(backupData, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `نسخة_احتياطية_قاعدة_التلاميذ_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setFeedbackMessage('تم حفظ نسخة احتياطية كاملة لقاعدة بيانات التلاميذ.');
    setTimeout(() => setFeedbackMessage(null), 4000);
  };

  // Force reactive sync from memory
  const handleForceSync = () => {
    onForceSyncDatabase?.();
    setFeedbackMessage('تمت إعادة مزامنة وتحديث قاعدة بيانات التلاميذ في الذاكرة بنجاح.');
    setTimeout(() => setFeedbackMessage(null), 3500);
  };

  // Target students for bulk classroom transfer
  const targetStudentsToTransfer = useMemo(() => {
    if (transferScope === 'selected') {
      return students.filter((s) => selectedIds.has(s.id));
    }
    if (transferScope === 'classroom') {
      return transferSourceClassroom === 'all'
        ? students
        : students.filter((s) => s.classroom === transferSourceClassroom);
    }
    if (transferScope === 'filtered') {
      return filteredStudents;
    }
    return [];
  }, [students, filteredStudents, selectedIds, transferScope, transferSourceClassroom]);

  const handleOpenTransferModal = (scope?: 'selected' | 'classroom' | 'filtered') => {
    if (scope) {
      setTransferScope(scope);
    } else if (selectedIds.size > 0) {
      setTransferScope('selected');
    } else if (classroomFilter !== 'all') {
      setTransferScope('classroom');
      setTransferSourceClassroom(classroomFilter);
    } else {
      setTransferScope('filtered');
    }
    setTransferTargetClassroom(availableClassrooms[0] || '1م1');
    setTransferTargetGrade('');
    setIsCustomClassroom(false);
    setIsTransferModalOpen(true);
  };

  const handleOpenBatchPrintModal = (preferredScope?: 'all' | 'classroom' | 'grade' | 'selected') => {
    if (preferredScope) {
      setBatchPrintScope(preferredScope);
      if (preferredScope === 'classroom' && classroomFilter !== 'all') {
        setBatchClassroom(classroomFilter);
      } else if (preferredScope === 'grade' && gradeFilter !== 'all') {
        setBatchGrade(gradeFilter);
      }
    } else if (selectedIds.size > 0) {
      setBatchPrintScope('selected');
    } else if (classroomFilter !== 'all') {
      setBatchPrintScope('classroom');
      setBatchClassroom(classroomFilter);
    } else if (gradeFilter !== 'all') {
      setBatchPrintScope('grade');
      setBatchGrade(gradeFilter);
    } else {
      setBatchPrintScope('all');
    }
    setIsBatchPrintModalOpen(true);
  };


  const handleExecuteTransfer = () => {
    const finalClassroom = transferTargetClassroom.trim();
    if (!finalClassroom) return;
    const ids = targetStudentsToTransfer.map((s) => s.id);
    if (ids.length === 0) return;

    if (onBulkTransferStudents) {
      onBulkTransferStudents(ids, finalClassroom, transferTargetGrade || undefined);
    } else {
      ids.forEach((id) => {
        const student = students.find((s) => s.id === id);
        if (student) {
          onUpdateStudent({
            ...student,
            classroom: finalClassroom,
            grade: transferTargetGrade || student.grade,
          });
        }
      });
    }

    setIsTransferModalOpen(false);
    setFeedbackMessage(`تم بنجاح ترحيل وتحديث بيانات ${ids.length} تلميذ إلى قسم ${finalClassroom}.`);
    setTimeout(() => setFeedbackMessage(null), 4500);
  };

  // Formatted last updated timestamp
  const formattedLastUpdated = useMemo(() => {
    if (!dbLastUpdated) return 'اليوم';
    try {
      const d = new Date(dbLastUpdated);
      return d.toLocaleTimeString('ar-DZ', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });
    } catch {
      return 'اليوم';
    }
  }, [dbLastUpdated]);

  // Batch Print Students List with scopes
  const printStudents = useMemo(() => {
    if (batchPrintScope === 'selected') {
      return students.filter((s) => selectedIds.has(s.id));
    }
    if (batchPrintScope === 'classroom') {
      return batchClassroom === 'all'
        ? students
        : students.filter((s) => s.classroom === batchClassroom);
    }
    if (batchPrintScope === 'grade') {
      return batchGrade === 'all'
        ? students
        : students.filter((s) => s.grade === batchGrade);
    }
    return students;
  }, [students, batchPrintScope, batchClassroom, batchGrade, selectedIds]);

  const barcodeIssues = useMemo(() => {
    const counts = new Map<string, number>();
    const missing: Student[] = [];
    const duplicates: Student[] = [];

    printStudents.forEach((st) => {
      if (!st.barcode || !st.barcode.trim()) {
        missing.push(st);
      } else {
        counts.set(st.barcode, (counts.get(st.barcode) || 0) + 1);
      }
    });

    printStudents.forEach((st) => {
      if (st.barcode && (counts.get(st.barcode) || 0) > 1) {
        if (!duplicates.some((d) => d.id === st.id)) {
          duplicates.push(st);
        }
      }
    });

    return { missing, duplicates };
  }, [printStudents]);

  const totalPages = Math.ceil(printStudents.length / cardsPerPage) || 1;
  const paginatedPages = useMemo(() => {
    const pages: Student[][] = [];
    for (let i = 0; i < printStudents.length; i += cardsPerPage) {
      pages.push(printStudents.slice(i, i + cardsPerPage));
    }
    return pages;
  }, [printStudents, cardsPerPage]);

  useEffect(() => {
    const handleAfterPrint = () => {
      document.body.classList.remove('printing-batch-cards');
    };
    window.addEventListener('afterprint', handleAfterPrint);
    return () => {
      window.removeEventListener('afterprint', handleAfterPrint);
    };
  }, []);

  // Multi-selection calculations
  const allVisibleSelected =
    filteredStudents.length > 0 &&
    filteredStudents.every((s) => selectedIds.has(s.id));
  const someVisibleSelected =
    filteredStudents.some((s) => selectedIds.has(s.id)) && !allVisibleSelected;

  const handleToggleSelectOne = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleToggleSelectAllVisible = () => {
    if (allVisibleSelected) {
      setSelectedIds((prev) => {
        const next = new Set(prev);
        filteredStudents.forEach((s) => next.delete(s.id));
        return next;
      });
    } else {
      setSelectedIds((prev) => {
        const next = new Set(prev);
        filteredStudents.forEach((s) => next.add(s.id));
        return next;
      });
    }
  };

  const handleSelectAllInSchool = () => {
    setSelectedIds(new Set(students.map((s) => s.id)));
  };

  const handleClearSelection = () => {
    setSelectedIds(new Set());
  };

  // Determine target students for bulk deletion based on scope
  const targetStudentsToDelete = useMemo(() => {
    if (bulkDeleteTargetScope === 'selected') {
      return students.filter((s) => selectedIds.has(s.id));
    }
    if (bulkDeleteTargetScope === 'filtered') {
      return filteredStudents;
    }
    if (bulkDeleteTargetScope === 'classroom') {
      return bulkDeleteClassroom === 'all'
        ? students
        : students.filter((s) => s.classroom === bulkDeleteClassroom);
    }
    if (bulkDeleteTargetScope === 'all') {
      return students;
    }
    return [];
  }, [students, filteredStudents, selectedIds, bulkDeleteTargetScope, bulkDeleteClassroom]);

  const modalFilteredStudents = useMemo(() => {
    if (!modalSearchQuery.trim()) return targetStudentsToDelete;
    const q = modalSearchQuery.toLowerCase().trim();
    return targetStudentsToDelete.filter(
      (s) =>
        s.firstName.toLowerCase().includes(q) ||
        s.lastName.toLowerCase().includes(q) ||
        s.id.toLowerCase().includes(q) ||
        s.classroom.toLowerCase().includes(q) ||
        s.barcode.toLowerCase().includes(q)
    );
  }, [targetStudentsToDelete, modalSearchQuery]);

  const handleOpenBulkDeleteModal = (preferredScope?: 'selected' | 'filtered' | 'classroom' | 'all') => {
    if (preferredScope) {
      setBulkDeleteTargetScope(preferredScope);
    } else if (selectedIds.size > 0) {
      setBulkDeleteTargetScope('selected');
    } else if (classroomFilter !== 'all') {
      setBulkDeleteTargetScope('classroom');
      setBulkDeleteClassroom(classroomFilter);
    } else {
      setBulkDeleteTargetScope('filtered');
    }
    setBulkDeleteConfirmCheck(false);
    setModalSearchQuery('');
    setIsBulkDeleteModalOpen(true);
  };

  const handleExecuteBulkDelete = () => {
    const idsToDelete = targetStudentsToDelete.map((s) => s.id);
    if (idsToDelete.length === 0) return;

    if (onDeleteMultipleStudents) {
      onDeleteMultipleStudents(idsToDelete);
    } else {
      idsToDelete.forEach((id) => onDeleteStudent(id));
    }

    setSelectedIds((prev) => {
      const next = new Set(prev);
      idsToDelete.forEach((id) => next.delete(id));
      return next;
    });

    setIsBulkDeleteModalOpen(false);
    setBulkDeleteConfirmCheck(false);
    setFeedbackMessage(`تم بنجاح مسح ${idsToDelete.length} تلميذ وسجلاتهم المرتبطة.`);
    setTimeout(() => {
      setFeedbackMessage(null);
    }, 4500);
  };

  return (
    <div className="student-management-root space-y-4">
      {/* Interactive Screen UI (completely hidden during print) */}
      <div className="student-management-screen-ui space-y-4 no-print">
        {/* Feedback banner */}
      {feedbackMessage && (
        <div className="bg-slate-50 border border-slate-200 text-slate-800 px-4 py-3 rounded-xl text-xs flex items-center justify-between shadow-2xs animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCheck className="w-4 h-4 text-slate-600" />
            <span className="font-semibold">{feedbackMessage}</span>
          </div>
          <button
            onClick={() => setFeedbackMessage(null)}
            className="text-slate-500 hover:text-slate-700 cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Real-time Updatable Database Status Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-950 text-white rounded-2xl p-4 sm:p-5 shadow-xs border border-slate-700/60 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 no-print">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-slate-500/20 border border-slate-400/30 flex items-center justify-center text-slate-400">
              <Database className="w-4 h-4" />
            </div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold tracking-tight text-white">قاعدة بيانات التلاميذ</h2>
              <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-500/20 text-slate-300 border border-slate-500/30">
                <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-pulse"></span>
                قابلة للتحديث الفوري ومتزامنة
              </span>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-3 text-xs text-slate-300 pr-1">
            <span className="flex items-center gap-1">
              <Users className="w-3.5 h-3.5 text-slate-400" />
              <strong className="text-white font-mono-numbers">{students.length}</strong> تلميذ مسجل
            </span>
            <span className="text-slate-600">·</span>
            <span className="flex items-center gap-1">
              <GraduationCap className="w-3.5 h-3.5 text-slate-400" />
              <strong className="text-white font-mono-numbers">{availableClassrooms.length}</strong> أفواج دراسية
            </span>
            <span className="text-slate-600">·</span>
            <span className="flex items-center gap-1 text-slate-300">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              آخر تحديث مسجل: <span className="font-mono-numbers text-slate-300">{formattedLastUpdated}</span>
            </span>
          </div>
        </div>

        {/* Database Quick Actions */}
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          <button
            type="button"
            onClick={() => setIsScanModalOpen(true)}
            className="flex-1 md:flex-initial flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl bg-blue-700/90 hover:bg-blue-600 text-white transition-all shadow-xs cursor-pointer border border-blue-500/50"
            title="مسح واستدعاء بطاقة تلميذ فورياً بالباركود أو الكاميرا"
          >
            <Scan className="w-3.5 h-3.5 text-blue-200" />
            مسح بطاقة
          </button>

          <button
            type="button"
            onClick={() => setIsExcelModalOpen(true)}
            className="flex-1 md:flex-initial flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl bg-slate-600 hover:bg-slate-500 text-white transition-all shadow-xs cursor-pointer"
            title="تحديث ودمج التغييرات من ملف إكسيل الرقمنة"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            تحديث القاعدة (إكسل)
          </button>

          <button
            type="button"
            onClick={() => handleOpenTransferModal()}
            className="flex-1 md:flex-initial flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl bg-slate-700/80 hover:bg-slate-600 text-slate-100 transition-all border border-slate-600 cursor-pointer"
            title="نقل وترحيل أفواج التلاميذ وتحديث أقسامهم"
          >
            <ArrowRightLeft className="w-3.5 h-3.5 text-blue-300" />
            ترحيل الأقسام
          </button>

          <button
            type="button"
            onClick={handleExportStudentsToExcel}
            className="flex-1 md:flex-initial flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 transition-all border border-slate-700 cursor-pointer"
            title="تصدير قائمة التلاميذ كاملة بصيغة Excel"
          >
            <Download className="w-3.5 h-3.5 text-slate-400" />
            تصدير إكسل
          </button>

          <button
            type="button"
            onClick={handleExportJsonBackup}
            className="flex-1 md:flex-initial flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 transition-all border border-slate-700 cursor-pointer"
            title="حفظ نسخة احتياطية JSON"
          >
            <Save className="w-3.5 h-3.5 text-blue-400" />
            نسخة احتياطية
          </button>

          <button
            type="button"
            onClick={handleForceSync}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-700/60 rounded-xl transition-colors cursor-pointer"
            title="إعادة مزامنة الذاكرة والتحديث الفوري"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Top Filter and Actions Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4 no-print">
        <div className="flex flex-wrap items-center gap-3">
          {/* Grade filter */}
          <select
            value={gradeFilter}
            onChange={(e) => setGradeFilter(e.target.value)}
            className="text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white cursor-pointer"
          >
            <option value="all">كل المستويات الدراسية</option>
            <option value="1AM">الأولى متوسط (1AM)</option>
            <option value="2AM">الثانية متوسط (2AM)</option>
            <option value="3AM">الثالثة متوسط (3AM)</option>
            <option value="4AM">الرابعة متوسط (4AM)</option>
          </select>

          {/* Classroom filter */}
          <select
            value={classroomFilter}
            onChange={(e) => setClassroomFilter(e.target.value)}
            className="text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white cursor-pointer"
          >
            <option value="all">كل الأقسام</option>
            {availableClassrooms.map((cls) => (
              <option key={cls} value={cls}>
                قسم {cls}
              </option>
            ))}
          </select>

          {/* Search box with inline barcode scanner trigger */}
          <div className="relative min-w-[220px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="بحث بالاسم أو الهاتف أو الباركود..."
              className="w-full pr-8 pl-8 py-1.5 text-xs rounded-lg border border-slate-300 bg-white"
            />
            <button
              type="button"
              onClick={() => setIsScanModalOpen(true)}
              className="absolute left-2 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-blue-700 hover:bg-slate-100 rounded cursor-pointer transition-colors"
              title="مسح بطاقة تلميذ بالباركود"
            >
              <Scan className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-2">
          {/* View toggle */}
          <div className="flex items-center p-0.5 bg-slate-100 rounded-lg">
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                viewMode === 'table' ? 'bg-white shadow-2xs text-slate-900' : 'text-slate-500'
              }`}
              title="عرض جدولي"
            >
              <List className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('cards')}
              className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                viewMode === 'cards' ? 'bg-white shadow-2xs text-slate-900' : 'text-slate-500'
              }`}
              title="عرض البطاقات"
            >
              <Grid className="w-4 h-4" />
            </button>
          </div>

          {/* Direct Barcode & QR Scanner in Registry */}
          <button
            type="button"
            onClick={() => setIsScanModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-blue-900 bg-blue-50 hover:bg-blue-100 border border-blue-300 rounded-lg transition-colors cursor-pointer shadow-2xs"
            title="مسح بطاقة تلميذ بالمسدس الليزري أو الكاميرا للبحث الفوري وعرض بطاقته"
          >
            <Scan className="w-3.5 h-3.5 text-blue-700" />
            <span>مسح بطاقة تلميذ</span>
          </button>

          <button
            onClick={() => setIsExcelModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-800 bg-slate-50 hover:bg-slate-100 border border-slate-300 rounded-lg transition-colors cursor-pointer shadow-2xs"
            title="استيراد قائمة أسماء التلاميذ من ملف إكسيل (.xlsx / .xls / .csv)"
          >
            <FileSpreadsheet className="w-4 h-4 text-slate-700" />
            استيراد من Excel
          </button>

          <button
            onClick={() => handleOpenBatchPrintModal('all')}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer shadow-xs"
            title="طباعة بطاقات جميع تلاميذ المؤسسة دون استثناء على ورق A4"
          >
            <Printer className="w-3.5 h-3.5 text-slate-400" />
            <span>طباعة كل البطاقات (A4)</span>
            <span className="bg-slate-700 text-white text-[10px] px-1.5 py-0.2 rounded-full font-mono">
              {students.length}
            </span>
          </button>

          {classroomFilter !== 'all' && (
            <button
              onClick={() => handleOpenBatchPrintModal('classroom')}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg transition-colors cursor-pointer shadow-2xs"
              title={`طباعة بطاقات قسم ${classroomFilter} فقط على ورق A4`}
            >
              <Printer className="w-3.5 h-3.5 text-slate-700" />
              <span>بطاقات قسم {classroomFilter}</span>
              <span className="bg-slate-700 text-white text-[10px] px-1.5 py-0.2 rounded-full font-mono">
                {students.filter((s) => s.classroom === classroomFilter).length}
              </span>
            </button>
          )}

          {/* Bulk delete trigger button */}
          <button
            onClick={() => handleOpenBulkDeleteModal()}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer shadow-2xs border ${
              selectedIds.size > 0
                ? 'bg-slate-600 hover:bg-slate-700 text-white border-slate-700'
                : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
            }`}
            title="مسح التلاميذ بالجملة أو مسح قسم كامل"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>مسح بالجملة</span>
            {selectedIds.size > 0 && (
              <span className="bg-white text-slate-700 text-[10px] px-1.5 py-0.5 rounded-full font-bold">
                {selectedIds.size}
              </span>
            )}
          </button>

          <button
            onClick={handleOpenAddModal}
            style={{ backgroundColor: palette.primary, color: palette.foreground }}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer shadow-xs hover:opacity-95"
          >
            <UserPlus className="w-3.5 h-3.5" />
            إضافة تلميذ جديد
          </button>
        </div>
      </div>

      {/* Floating / Sticky Bulk Action Bar when items are selected */}
      {selectedIds.size > 0 && (
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs animate-in fade-in duration-200 no-print">
          <div className="flex flex-wrap items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-slate-600 text-white flex items-center justify-center font-bold text-xs shadow-2xs">
              {selectedIds.size}
            </span>
            <span className="font-bold text-slate-900">
              تم تحديد {selectedIds.size} من أصل {students.length} تلميذ
            </span>
            <span className="text-slate-300">|</span>
            {!allVisibleSelected && (
              <button
                type="button"
                onClick={handleToggleSelectAllVisible}
                className="text-slate-700 hover:text-slate-800 underline font-semibold cursor-pointer"
              >
                تحديد جميع المعروضين في الجدول ({filteredStudents.length})
              </button>
            )}
            {selectedIds.size < students.length && (
              <button
                type="button"
                onClick={handleSelectAllInSchool}
                className="text-blue-700 hover:text-blue-800 underline font-semibold cursor-pointer mr-1"
              >
                تحديد كل تلاميذ المؤسسة ({students.length})
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleClearSelection}
              className="px-2.5 py-1 text-slate-600 hover:bg-white rounded-lg border border-slate-300 transition-colors cursor-pointer"
            >
              إلغاء التحديد
            </button>
            <button
              type="button"
              onClick={() => handleOpenBatchPrintModal('selected')}
              className="flex items-center gap-1.5 px-3 py-1.5 text-slate-800 bg-white hover:bg-slate-100 rounded-lg font-bold border border-slate-300 shadow-2xs transition-colors cursor-pointer"
              title="طباعة بطاقات التلاميذ المحددين فقط"
            >
              <Printer className="w-3.5 h-3.5 text-slate-700" />
              طباعة بطاقات المحددين ({selectedIds.size})
            </button>
            <button
              type="button"
              onClick={() => handleOpenTransferModal('selected')}
              className="flex items-center gap-1.5 px-3 py-1.5 text-slate-800 bg-white hover:bg-slate-100 rounded-lg font-bold border border-slate-300 shadow-2xs transition-colors cursor-pointer"
            >
              <ArrowRightLeft className="w-3.5 h-3.5 text-blue-600" />
              ترحيل المحددين ({selectedIds.size})
            </button>
            <button
              type="button"
              onClick={() => handleOpenBulkDeleteModal('selected')}
              className="flex items-center gap-1.5 px-3 py-1.5 text-white bg-slate-600 hover:bg-slate-700 rounded-lg font-bold shadow-xs transition-colors cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              مسح المحددين بالجملة ({selectedIds.size})
            </button>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      {viewMode === 'table' ? (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold">
                  <th className="py-3 px-3 w-10 text-center">
                    <input
                      type="checkbox"
                      checked={allVisibleSelected}
                      ref={(input) => {
                        if (input) input.indeterminate = someVisibleSelected;
                      }}
                      onChange={handleToggleSelectAllVisible}
                      className="w-4 h-4 rounded text-slate-600 accent-slate-600 cursor-pointer"
                      title={allVisibleSelected ? 'إلغاء تحديد المعروضين' : 'تحديد جميع المعروضين'}
                    />
                  </th>
                  <th className="py-3 px-4">رقم التسجيل</th>
                  <th className="py-3 px-4">اللقب والاسم</th>
                  <th className="py-3 px-4">المستوى والقسم</th>
                  <th className="py-3 px-4">الجنس</th>
                  <th className="py-3 px-4">تاريخ الميلاد</th>
                  <th className="py-3 px-4">رمز الباركود</th>
                  <th className="py-3 px-4">ولي الأمر والهاتف</th>
                  <th className="py-3 px-4 text-center">الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredStudents.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="py-12 text-center text-slate-400">
                      لم يتم العثور على أي تلميذ مطابق.
                    </td>
                  </tr>
                ) : (
                  filteredStudents.map((st) => {
                    const isSelected = selectedIds.has(st.id);
                    return (
                      <tr
                        key={st.id}
                        className={`transition-colors ${
                          isSelected ? 'bg-slate-50/60 font-medium' : 'hover:bg-slate-50/60'
                        }`}
                      >
                        <td className="py-3 px-3 text-center">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => handleToggleSelectOne(st.id)}
                            className="w-4 h-4 rounded text-slate-600 accent-slate-600 cursor-pointer"
                          />
                        </td>
                        <td className="py-3 px-4 font-mono-numbers font-medium text-slate-600">
                          {st.id}
                        </td>
                        <td className="py-3 px-4 font-bold text-slate-900">
                          {st.lastName} {st.firstName}
                        </td>
                        <td className="py-3 px-4">
                          <span className="bg-slate-100 font-bold px-2 py-0.5 rounded text-[11px] text-slate-800">
                            {st.classroom}
                          </span>
                          <span className="text-slate-400 text-[10px] mr-1.5">
                            ({st.grade})
                          </span>
                        </td>
                        <td className="py-3 px-4 text-slate-600">
                          {st.gender === 'M' ? 'ذكر' : 'أنثى'}
                        </td>
                        <td className="py-3 px-4 font-mono-numbers text-slate-600">
                          {st.birthDate}
                        </td>
                        <td className="py-3 px-4 font-mono-numbers text-slate-800 font-semibold">
                          {st.barcode}
                        </td>
                        <td className="py-3 px-4 text-slate-600">
                          <div>{st.guardianName}</div>
                          <div className="font-mono-numbers text-[10px] text-slate-400">
                            {st.guardianPhone}
                          </div>
                        </td>
                        <td className="py-3 px-4 text-center">
                          <div className="flex items-center justify-center gap-1">
                            <button
                              onClick={() => onViewStudentCard(st)}
                              className="p-1.5 text-slate-700 hover:bg-slate-50 rounded transition-colors cursor-pointer"
                              title="عرض وطباعة بطاقة التلميذ"
                            >
                              <FileText className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleOpenEdit(st)}
                              className="p-1.5 text-blue-700 hover:bg-blue-50 rounded transition-colors cursor-pointer"
                              title="تعديل بيانات التلميذ"
                            >
                              <Edit className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => {
                                if (confirm(`هل أنت متأكد من حذف التلميذ: ${st.firstName} ${st.lastName}؟`)) {
                                  onDeleteStudent(st.id);
                                }
                              }}
                              className="p-1.5 text-slate-600 hover:bg-slate-50 rounded transition-colors cursor-pointer"
                              title="حذف"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredStudents.map((st) => (
            <StudentBadge
              key={st.id}
              student={st}
              settings={settings}
              showPrintAction={true}
              isSelected={selectedIds.has(st.id)}
              onToggleSelect={() => handleToggleSelectOne(st.id)}
              onPrint={() => onViewStudentCard(st)}
            />
          ))}
        </div>
      )}
      </div>

      {/* Add / Edit Student Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full p-6 space-y-4 border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-bold text-slate-800 text-sm">
                {editingStudent ? 'تعديل بيانات التلميذ' : 'تسجيل تلميذ جديد بالمتوسطة'}
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmitForm} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">الاسم:</label>
                  <input
                    type="text"
                    required
                    value={formData.firstName}
                    onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-slate-500"
                    placeholder="مثال: أيوب"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">اللقب:</label>
                  <input
                    type="text"
                    required
                    value={formData.lastName}
                    onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-slate-500"
                    placeholder="مثال: بن سالم"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">الجنس:</label>
                  <select
                    value={formData.gender}
                    onChange={(e) => setFormData({ ...formData, gender: e.target.value as 'M' | 'F' })}
                    className="w-full p-2 border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="M">ذكر</option>
                    <option value="F">أنثى</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">المستوى:</label>
                  <select
                    value={formData.grade}
                    onChange={(e) => setFormData({ ...formData, grade: e.target.value as GradeLevel })}
                    className="w-full p-2 border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="1AM">1 متوسط (1AM)</option>
                    <option value="2AM">2 متوسط (2AM)</option>
                    <option value="3AM">3 متوسط (3AM)</option>
                    <option value="4AM">4 متوسط (4AM)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">القسم والفوج:</label>
                  <input
                    type="text"
                    required
                    value={formData.classroom}
                    onChange={(e) => setFormData({ ...formData, classroom: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                    placeholder="1م1"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">تاريخ الميلاد:</label>
                  <input
                    type="date"
                    required
                    value={formData.birthDate}
                    onChange={(e) => setFormData({ ...formData, birthDate: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg font-mono-numbers"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">مكان الميلاد:</label>
                  <input
                    type="text"
                    value={formData.birthPlace}
                    onChange={(e) => setFormData({ ...formData, birthPlace: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                    placeholder="عنابة"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">اسم ولي الأمر:</label>
                  <input
                    type="text"
                    required
                    value={formData.guardianName}
                    onChange={(e) => setFormData({ ...formData, guardianName: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                    placeholder="اسم الأب أو الولي"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">هاتف ولي الأمر:</label>
                  <input
                    type="text"
                    required
                    value={formData.guardianPhone}
                    onChange={(e) => setFormData({ ...formData, guardianPhone: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg font-mono-numbers"
                    placeholder="0661234567"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-slate-700 font-semibold text-xs">
                    رقم التعريف المدرسي الوطني / الباركود:
                  </label>
                  <span className="text-[11px] text-slate-400">
                    يمكن إدخال الرقم يدوياً أو مسحه بالمسدس الليزري
                  </span>
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    required
                    value={formData.nationalId}
                    onChange={(e) => setFormData({ ...formData, nationalId: e.target.value })}
                    className="flex-1 p-2 border border-slate-300 rounded-lg font-mono-numbers text-xs"
                    placeholder="12102830001"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      setIsScanningForForm(!isScanningForForm);
                    }}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-lg border flex items-center gap-1.5 transition-all cursor-pointer shrink-0 ${
                      isScanningForForm
                        ? 'bg-amber-100 text-amber-900 border-amber-300 ring-2 ring-amber-200 animate-pulse'
                        : 'bg-blue-50 hover:bg-blue-100 text-blue-800 border-blue-200'
                    }`}
                    title="المسح المباشر بالمسدس الليزري لتعبئة رقم الباركود"
                  >
                    <Scan className="w-3.5 h-3.5 text-blue-700" />
                    <span>{isScanningForForm ? 'القارئ بانتظار المسح...' : 'مسح بالباركود'}</span>
                  </button>
                </div>
                {isScanningForForm && (
                  <p className="text-[11px] text-amber-700 mt-1 font-medium flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping"></span>
                    وجّه مسدس الباركود نحو بطاقة التلميذ واضغط الزر لإدخال الرقم تلقائياً.
                  </p>
                )}
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 font-semibold text-white bg-slate-700 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer shadow-xs"
                >
                  {editingStudent ? 'حفظ التعديلات' : 'إضافة التلميذ وتوليد الباركود'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Excel Import Modal */}

      {isExcelModalOpen && (
        <ExcelImportModal
          onClose={() => setIsExcelModalOpen(false)}
          currentStudentsCount={students.length}
          existingStudents={students}
          onImportStudents={(imported, mode) => {
            if (onImportExcelStudents) {
              onImportExcelStudents(imported, mode);
              setFeedbackMessage(
                mode === 'upsert'
                  ? `تم دمج وتحديث بيانات ${imported.length} تلميذ في قاعدة البيانات بنجاح ومزامنة التغييرات فورياً!`
                  : mode === 'replace'
                  ? `تم استبدال قاعدة بيانات التلاميذ بالكامل (${imported.length} تلميذ).`
                  : `تمت إضافة ${imported.length} تلميذ جديد إلى قاعدة البيانات.`
              );
              setTimeout(() => setFeedbackMessage(null), 5000);
            }
          }}
        />
      )}

      {/* Bulk Delete Students Confirmation Modal */}
      {isBulkDeleteModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full p-6 space-y-4 border border-slate-200">
            {/* Header */}
            <div className="flex items-start justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center shrink-0">
                  <AlertTriangle className="w-5 h-5 text-slate-600" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-base">
                    مسح التلاميذ بالجملة (حذف نهائي)
                  </h3>
                  <p className="text-xs text-slate-500">
                    تحديد نطاق المسح وحذف التلاميذ وسجلات الحضور والغياب المرتبطة
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsBulkDeleteModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Scope Selection */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-700">
                اختر نطاق المسح المطلوب:
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {/* Option 1: Selected */}
                <button
                  type="button"
                  onClick={() => setBulkDeleteTargetScope('selected')}
                  className={`p-2.5 rounded-xl border text-right transition-all cursor-pointer flex items-center justify-between ${
                    bulkDeleteTargetScope === 'selected'
                      ? 'border-slate-500 bg-slate-50/50 text-slate-900 ring-1 ring-slate-400'
                      : 'border-slate-200 hover:border-slate-300 text-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${bulkDeleteTargetScope === 'selected' ? 'border-slate-600 bg-slate-600' : 'border-slate-300'}`}>
                      {bulkDeleteTargetScope === 'selected' && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                    </span>
                    <span className="font-semibold">المحددين يدوياً</span>
                  </div>
                  <span className="font-bold text-xs bg-white/80 px-2 py-0.5 rounded-md border border-slate-200">
                    {selectedIds.size} تلميذ
                  </span>
                </button>

                {/* Option 2: Filtered visible */}
                <button
                  type="button"
                  onClick={() => setBulkDeleteTargetScope('filtered')}
                  className={`p-2.5 rounded-xl border text-right transition-all cursor-pointer flex items-center justify-between ${
                    bulkDeleteTargetScope === 'filtered'
                      ? 'border-slate-500 bg-slate-50/50 text-slate-900 ring-1 ring-slate-400'
                      : 'border-slate-200 hover:border-slate-300 text-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${bulkDeleteTargetScope === 'filtered' ? 'border-slate-600 bg-slate-600' : 'border-slate-300'}`}>
                      {bulkDeleteTargetScope === 'filtered' && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                    </span>
                    <span className="font-semibold">المعروضين بالفلتر الحالي</span>
                  </div>
                  <span className="font-bold text-xs bg-white/80 px-2 py-0.5 rounded-md border border-slate-200">
                    {filteredStudents.length} تلميذ
                  </span>
                </button>

                {/* Option 3: By classroom */}
                <div
                  className={`p-2.5 rounded-xl border text-right transition-all ${
                    bulkDeleteTargetScope === 'classroom'
                      ? 'border-slate-500 bg-slate-50/50 text-slate-900 ring-1 ring-slate-400'
                      : 'border-slate-200 text-slate-700'
                  }`}
                >
                  <div
                    onClick={() => setBulkDeleteTargetScope('classroom')}
                    className="flex items-center justify-between cursor-pointer mb-1.5"
                  >
                    <div className="flex items-center gap-2">
                      <span className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${bulkDeleteTargetScope === 'classroom' ? 'border-slate-600 bg-slate-600' : 'border-slate-300'}`}>
                        {bulkDeleteTargetScope === 'classroom' && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                      </span>
                      <span className="font-semibold">تلاميذ قسم محدد:</span>
                    </div>
                  </div>
                  <select
                    value={bulkDeleteClassroom}
                    onChange={(e) => {
                      setBulkDeleteClassroom(e.target.value);
                      setBulkDeleteTargetScope('classroom');
                    }}
                    className="w-full text-xs p-1.5 bg-white border border-slate-300 rounded-lg cursor-pointer"
                  >
                    <option value="all">كل الأقسام</option>
                    {availableClassrooms.map((cls) => (
                      <option key={cls} value={cls}>
                        قسم {cls} ({students.filter((s) => s.classroom === cls).length} تلميذ)
                      </option>
                    ))}
                  </select>
                </div>

                {/* Option 4: All students in school */}
                <button
                  type="button"
                  onClick={() => setBulkDeleteTargetScope('all')}
                  className={`p-2.5 rounded-xl border text-right transition-all cursor-pointer flex items-center justify-between ${
                    bulkDeleteTargetScope === 'all'
                      ? 'border-slate-500 bg-slate-50/50 text-slate-900 ring-1 ring-slate-400'
                      : 'border-slate-200 hover:border-slate-300 text-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${bulkDeleteTargetScope === 'all' ? 'border-slate-600 bg-slate-600' : 'border-slate-300'}`}>
                      {bulkDeleteTargetScope === 'all' && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                    </span>
                    <span className="font-semibold">كل تلاميذ المؤسسة</span>
                  </div>
                  <span className="font-bold text-xs bg-slate-100 text-slate-800 px-2 py-0.5 rounded-md">
                    {students.length} تلميذ
                  </span>
                </button>
              </div>
            </div>

            {/* Targeted Students Preview */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700">
                  قائمة التلاميذ المعنيين بالحذف ({targetStudentsToDelete.length} تلميذ):
                </span>
                {targetStudentsToDelete.length > 5 && (
                  <div className="relative w-44">
                    <Search className="w-3 h-3 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={modalSearchQuery}
                      onChange={(e) => setModalSearchQuery(e.target.value)}
                      placeholder="تصفية بالقائمة..."
                      className="w-full pr-7 pl-2 py-1 text-[11px] rounded-lg border border-slate-200 bg-slate-50"
                    />
                  </div>
                )}
              </div>

              <div className="max-h-44 overflow-y-auto border border-slate-200 rounded-xl divide-y divide-slate-100 bg-slate-50/50 text-xs">
                {targetStudentsToDelete.length === 0 ? (
                  <div className="p-6 text-center text-slate-400">
                    لا يوجد أي تلميذ محدد للحذف وفق هذا الخيار.
                  </div>
                ) : modalFilteredStudents.length === 0 ? (
                  <div className="p-4 text-center text-slate-400">
                    لا توجد نتائج مطابقة لبحثك في القائمة المعنية.
                  </div>
                ) : (
                  modalFilteredStudents.map((st) => (
                    <div key={st.id} className="p-2 flex items-center justify-between hover:bg-slate-100/70">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-800">
                          {st.lastName} {st.firstName}
                        </span>
                        <span className="font-mono-numbers text-[10px] text-slate-400">
                          ({st.id})
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="bg-slate-200 text-slate-700 text-[10px] px-1.5 py-0.5 rounded font-semibold">
                          {st.classroom}
                        </span>
                        <span className="font-mono-numbers text-[10px] text-slate-800">
                          {st.barcode}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Warning Message Box */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex items-start gap-2.5 text-xs text-slate-800">
              <AlertCircle className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="font-bold">تحذير مهم لا رجعة فيه:</p>
                <p className="text-[11px] text-slate-700 leading-relaxed">
                  سيتم مسح بيانات هؤلاء التلاميذ ({targetStudentsToDelete.length} تلميذ) بشكل نهائي من قاعدة البيانات، بالإضافة إلى بطاقاتهم وكافة سجلات الحضور والغياب الخاصة بهم.
                </p>
              </div>
            </div>

            {/* Confirmation Checkbox */}
            <div className="pt-1">
              <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-800 select-none">
                <input
                  type="checkbox"
                  checked={bulkDeleteConfirmCheck}
                  onChange={(e) => setBulkDeleteConfirmCheck(e.target.checked)}
                  className="w-4 h-4 rounded text-slate-600 accent-slate-600 cursor-pointer"
                />
                <span>أؤكد إدراكي بأن هذا الإجراء نهائي ولا يمكن التراجع عنه بعد تنفيذه</span>
              </label>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsBulkDeleteModalOpen(false)}
                className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
              >
                إلغاء وتراجع
              </button>
              <button
                type="button"
                disabled={targetStudentsToDelete.length === 0 || !bulkDeleteConfirmCheck}
                onClick={handleExecuteBulkDelete}
                className="flex items-center gap-2 px-5 py-2 text-xs font-bold text-white bg-slate-600 hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl shadow-xs transition-colors cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
                تأكيد مسح ({targetStudentsToDelete.length}) تلميذ نهائياً
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bulk Classroom / Grade Transfer and Database Update Modal */}
      {isTransferModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full p-6 space-y-4 border border-blue-200">
            {/* Header */}
            <div className="flex items-start justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center shrink-0">
                  <ArrowRightLeft className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-base">
                    ترحيل ونقل التلاميذ وتحديث الأقسام
                  </h3>
                  <p className="text-xs text-slate-500">
                    نقل وتحديث أفواج وأقسام التلاميذ بشكل جماعي ومزامنة التغييرات فورياً
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsTransferModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scope Selection */}
            <div className="space-y-2">
              <span className="text-xs font-bold text-slate-700 block">
                اختر التلاميذ المعنيين بالنقل:
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                <button
                  type="button"
                  disabled={selectedIds.size === 0}
                  onClick={() => setTransferScope('selected')}
                  className={`p-2.5 rounded-xl border text-right transition-all flex flex-col justify-between cursor-pointer ${
                    transferScope === 'selected'
                      ? 'bg-blue-50 border-blue-400 ring-1 ring-blue-400 text-blue-950 font-bold'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700 disabled:opacity-40 disabled:cursor-not-allowed'
                  }`}
                >
                  <span className="font-semibold text-xs">المحددين حالياً</span>
                  <span className="font-bold text-blue-700 mt-1">{selectedIds.size} تلميذ</span>
                </button>

                <button
                  type="button"
                  onClick={() => setTransferScope('classroom')}
                  className={`p-2.5 rounded-xl border text-right transition-all flex flex-col justify-between cursor-pointer ${
                    transferScope === 'classroom'
                      ? 'bg-blue-50 border-blue-400 ring-1 ring-blue-400 text-blue-950 font-bold'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <span className="font-semibold text-xs">قسم كامل</span>
                  <span className="font-bold text-slate-600 mt-1">تحديد فوج</span>
                </button>

                <button
                  type="button"
                  onClick={() => setTransferScope('filtered')}
                  className={`p-2.5 rounded-xl border text-right transition-all flex flex-col justify-between cursor-pointer ${
                    transferScope === 'filtered'
                      ? 'bg-blue-50 border-blue-400 ring-1 ring-blue-400 text-blue-950 font-bold'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <span className="font-semibold text-xs">نتائج الفلترة</span>
                  <span className="font-bold text-slate-600 mt-1">{filteredStudents.length} تلميذ</span>
                </button>
              </div>

              {transferScope === 'classroom' && (
                <div className="pt-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    اختر القسم المراد نقل تلاميذه:
                  </label>
                  <select
                    value={transferSourceClassroom}
                    onChange={(e) => setTransferSourceClassroom(e.target.value)}
                    className="w-full text-xs p-2 rounded-lg border border-slate-300 bg-white"
                  >
                    <option value="all">اختر قسماً...</option>
                    {availableClassrooms.map((cls) => (
                      <option key={cls} value={cls}>
                        قسم {cls} ({students.filter((s) => s.classroom === cls).length} تلميذ)
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>

            {/* Destination Classroom and Optional Grade */}
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <span className="text-xs font-bold text-slate-800 block">
                الوجهة الجديدة للتلاميذ:
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    القسم الجديد:
                  </label>
                  {!isCustomClassroom ? (
                    <div className="space-y-1">
                      <select
                        value={transferTargetClassroom}
                        onChange={(e) => setTransferTargetClassroom(e.target.value)}
                        className="w-full p-2 border border-slate-300 rounded-lg bg-white"
                      >
                        {availableClassrooms.map((cls) => (
                          <option key={cls} value={cls}>
                            قسم {cls}
                          </option>
                        ))}
                      </select>
                      <button
                        type="button"
                        onClick={() => {
                          setIsCustomClassroom(true);
                          setTransferTargetClassroom('');
                        }}
                        className="text-[11px] text-blue-600 hover:underline cursor-pointer"
                      >
                        + كتابة اسم قسم جديد غير موجود
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-1">
                      <input
                        type="text"
                        value={transferTargetClassroom}
                        onChange={(e) => setTransferTargetClassroom(e.target.value)}
                        placeholder="مثلاً: 1م3 أو 2م4"
                        className="w-full p-2 border border-slate-300 rounded-lg bg-white"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          setIsCustomClassroom(false);
                          setTransferTargetClassroom(availableClassrooms[0] || '1م1');
                        }}
                        className="text-[11px] text-slate-500 hover:underline cursor-pointer"
                      >
                        العودة للأقسام الموجودة
                      </button>
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    المستوى الدراسي (اختياري للترقية):
                  </label>
                  <select
                    value={transferTargetGrade}
                    onChange={(e) => setTransferTargetGrade(e.target.value as GradeLevel | '')}
                    className="w-full p-2 border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="">الإبقاء على المستوى الحالي للتلميذ</option>
                    <option value="1AM">الأولى متوسط (1AM)</option>
                    <option value="2AM">الثانية متوسط (2AM)</option>
                    <option value="3AM">الثالثة متوسط (3AM)</option>
                    <option value="4AM">الرابعة متوسط (4AM)</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Preview */}
            <div className="text-xs text-slate-600 bg-blue-50/70 border border-blue-100 rounded-xl p-3 flex items-center justify-between">
              <span>عدد التلاميذ المعنيين بالنقل وتحديث البيانات:</span>
              <strong className="text-blue-900 font-bold text-sm font-mono-numbers">
                {targetStudentsToTransfer.length} تلميذ
              </strong>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsTransferModalOpen(false)}
                className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="button"
                disabled={targetStudentsToTransfer.length === 0 || !transferTargetClassroom.trim()}
                onClick={handleExecuteTransfer}
                className="flex items-center gap-2 px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl shadow-xs transition-colors cursor-pointer"
              >
                <Check className="w-4 h-4" />
                تأكيد ترحيل وتحديث بيانات ({targetStudentsToTransfer.length}) تلميذ
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Student Registry Barcode & Camera Scanner Modal */}
      <StudentRegistryScannerModal
        isOpen={isScanModalOpen}
        onClose={() => setIsScanModalOpen(false)}
        students={students}
        onViewStudentCard={onViewStudentCard}
        onEditStudent={handleOpenEdit}
        onSelectInRegistry={handleSelectInRegistry}
        onAddNewWithBarcode={handleAddNewWithBarcode}
      />

      {/* Batch Print Preview Modal (A4 Badges) via Portal */}
      {isBatchPrintModalOpen &&
        createPortal(
          <div className="batch-print-dialog-overlay fixed inset-0 z-[100] flex flex-col bg-slate-950/85 backdrop-blur-sm overflow-hidden">
            {/* Modal Header (no-print) */}
            <div className="no-print bg-slate-900 border-b border-slate-800 text-white px-6 py-4 flex items-center justify-between shadow-md shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-slate-800 text-slate-300 flex items-center justify-center border border-slate-700">
                  <Printer className="w-5 h-5 text-slate-300" />
                </div>
                <div>
                  <h2 className="font-bold text-base text-white">معاينة وطباعة بطاقات التلاميذ (A4)</h2>
                  <p className="text-xs text-slate-400">
                    إجمالي التلاميذ المعنيين: <strong className="text-white font-mono">{printStudents.length}</strong> | عدد صفحات A4: <strong className="text-white font-mono">{totalPages}</strong>
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                {/* Scope selector */}
                <div className="flex items-center gap-1.5 bg-slate-800 p-1 rounded-xl border border-slate-700 text-xs">
                  <button
                    type="button"
                    onClick={() => setBatchPrintScope('all')}
                    className={`px-3 py-1.5 rounded-lg font-semibold transition-colors cursor-pointer ${batchPrintScope === 'all' ? 'bg-slate-700 text-white shadow-xs' : 'text-slate-400 hover:text-white'}`}
                  >
                    الكل ({students.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setBatchPrintScope('classroom')}
                    className={`px-3 py-1.5 rounded-lg font-semibold transition-colors cursor-pointer ${batchPrintScope === 'classroom' ? 'bg-slate-700 text-white shadow-xs' : 'text-slate-400 hover:text-white'}`}
                  >
                    حسب القسم
                  </button>
                  <button
                    type="button"
                    onClick={() => setBatchPrintScope('grade')}
                    className={`px-3 py-1.5 rounded-lg font-semibold transition-colors cursor-pointer ${batchPrintScope === 'grade' ? 'bg-slate-700 text-white shadow-xs' : 'text-slate-400 hover:text-white'}`}
                  >
                    حسب المستوى
                  </button>
                  <button
                    type="button"
                    disabled={selectedIds.size === 0}
                    onClick={() => setBatchPrintScope('selected')}
                    className={`px-3 py-1.5 rounded-lg font-semibold transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${batchPrintScope === 'selected' ? 'bg-slate-700 text-white shadow-xs' : 'text-slate-400 hover:text-white'}`}
                  >
                    المحددين ({selectedIds.size})
                  </button>
                </div>

                {/* Cards per page selector */}
                <div className="flex items-center gap-1.5 bg-slate-800 p-1 rounded-xl border border-slate-700 text-xs">
                  <span className="text-slate-400 px-2">في الصفحة:</span>
                  {[4, 6, 8].map((num) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => setCardsPerPage(num as 4 | 6 | 8)}
                      className={`w-8 h-8 rounded-lg font-bold transition-colors cursor-pointer flex items-center justify-center ${cardsPerPage === num ? 'bg-slate-700 text-white shadow-xs' : 'text-slate-400 hover:text-white'}`}
                    >
                      {num}
                    </button>
                  ))}
                </div>

                {/* Print / Save PDF Button */}
                <button
                  type="button"
                  disabled={printStudents.length === 0}
                  onClick={() => {
                    document.body.classList.add('printing-batch-cards');
                    setTimeout(() => {
                      window.print();
                      setTimeout(() => {
                        document.body.classList.remove('printing-batch-cards');
                      }, 1200);
                    }, 400);
                  }}
                  className="flex items-center gap-2 px-5 py-2 text-xs font-bold text-white bg-slate-700 hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl shadow-md transition-all cursor-pointer border border-slate-600"
                >
                  <Printer className="w-4 h-4" />
                  طباعة / حفظ PDF ({printStudents.length})
                </button>

                {/* Close */}
                <button
                  type="button"
                  onClick={() => {
                    document.body.classList.remove('printing-batch-cards');
                    setIsBatchPrintModalOpen(false);
                  }}
                  className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Secondary Bar for Scope Options */}
            {batchPrintScope === 'classroom' && (
              <div className="no-print bg-slate-900/95 border-b border-slate-800 px-6 py-2.5 flex items-center gap-3 text-xs text-slate-300 shrink-0">
                <span className="font-semibold">اختر القسم:</span>
                <select
                  value={batchClassroom}
                  onChange={(e) => setBatchClassroom(e.target.value)}
                  className="bg-slate-800 text-white px-3 py-1.5 rounded-lg border border-slate-700 cursor-pointer"
                >
                  <option value="all">كل الأقسام ({students.length})</option>
                  {availableClassrooms.map((cls) => (
                    <option key={cls} value={cls}>
                      قسم {cls} ({students.filter((s) => s.classroom === cls).length} تلميذ)
                    </option>
                  ))}
                </select>
              </div>
            )}

            {batchPrintScope === 'grade' && (
              <div className="no-print bg-slate-900/95 border-b border-slate-800 px-6 py-2.5 flex items-center gap-3 text-xs text-slate-300 shrink-0">
                <span className="font-semibold">اختر المستوى الدراسي:</span>
                <select
                  value={batchGrade}
                  onChange={(e) => setBatchGrade(e.target.value)}
                  className="bg-slate-800 text-white px-3 py-1.5 rounded-lg border border-slate-700 cursor-pointer"
                >
                  <option value="all">كل المستويات</option>
                  <option value="1AM">الأولى متوسط (1AM)</option>
                  <option value="2AM">الثانية متوسط (2AM)</option>
                  <option value="3AM">الثالثة متوسط (3AM)</option>
                  <option value="4AM">الرابعة متوسط (4AM)</option>
                </select>
              </div>
            )}

            {/* Barcode Warning Notification */}
            {(barcodeIssues.missing.length > 0 || barcodeIssues.duplicates.length > 0) && (
              <div className="no-print bg-amber-950/50 border-b border-amber-800/60 text-amber-200 px-6 py-2 text-xs flex items-center justify-between shrink-0">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>
                    {barcodeIssues.missing.length > 0 && `تنبيه: يوجد ${barcodeIssues.missing.length} تلميذ بدون باركود. `}
                    {barcodeIssues.duplicates.length > 0 && `تنبيه: يوجد ${barcodeIssues.duplicates.length} تلميذ برمز باركود مكرر.`}
                  </span>
                </div>
                <span className="text-[11px] text-amber-300/80">يرجى مراجعة بيانات التلاميذ المتأثرين لضمان جودة البطاقات المطبوعة.</span>
              </div>
            )}

            {/* Modal Scrollable Preview Content */}
            <div className="batch-print-dialog-scroll flex-1 overflow-y-auto p-8 bg-slate-900/95 flex flex-col items-center">
              {printStudents.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-64 text-slate-400 space-y-3">
                  <AlertCircle className="w-10 h-10 text-slate-500" />
                  <p className="font-bold text-sm">لا توجد أي بطاقات مطابقة للنطاق المحدد حالياً.</p>
                  <button
                    type="button"
                    onClick={() => setBatchPrintScope('all')}
                    className="px-4 py-2 bg-slate-800 text-white rounded-xl text-xs font-semibold hover:bg-slate-700 cursor-pointer"
                  >
                    عرض كل التلاميذ
                  </button>
                </div>
              ) : (
                <div className="w-full max-w-[210mm] space-y-8">
                  {paginatedPages.map((pageStudents, pageIndex) => (
                    <div
                      key={pageIndex}
                      className="batch-print-page bg-white text-slate-900 p-6 rounded-2xl shadow-2xl border border-slate-300 relative box-border"
                      style={{
                        width: '210mm',
                        minHeight: '297mm',
                        margin: '0 auto',
                        pageBreakAfter: 'always',
                        breakAfter: 'page',
                      }}
                    >
                      {/* Page Header */}
                      <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-6 text-xs text-slate-500">
                        <span className="font-bold text-slate-800">
                          {settings.schoolName} · بطاقات التلاميذ المدرسية
                        </span>
                        <span className="font-mono-numbers">
                          صفحة {pageIndex + 1} من {totalPages} (إجمالي: {printStudents.length} بطاقة)
                        </span>
                      </div>

                      {/* Grid of badges */}
                      <div
                        className={`grid ${
                          cardsPerPage === 4
                            ? 'grid-cols-2 gap-6'
                            : cardsPerPage === 6
                            ? 'grid-cols-2 gap-4'
                            : 'grid-cols-2 gap-3'
                        }`}
                      >
                        {pageStudents.map((st) => (
                          <div key={st.id} className="batch-card-print-item flex justify-center">
                            <StudentBadge
                              student={st}
                              settings={settings}
                              size={cardsPerPage === 8 ? 'mini' : cardsPerPage === 6 ? 'compact' : 'standard'}
                              showPrintAction={false}
                              isSelected={false}
                              onToggleSelect={undefined}
                            />
                          </div>
                        ))}
                      </div>

                      {/* Page Footer */}
                      <div className="absolute bottom-4 left-6 right-6 flex items-center justify-between text-[9px] text-slate-400 border-t border-slate-100 pt-2">
                        <span>الجمهورية الجزائرية الديمقراطية الشعبية · وزارة التربية الوطنية</span>
                        <span className="font-mono-numbers">الصفحة {pageIndex + 1}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>,
          document.body
        )}
    </div>
  );
};
