import React, { useState, useMemo } from 'react';
import {
  Student,
  AttendanceRecord,
  SchoolSettings,
  AbsenceNotice,
  AbsenceNoticeStage,
  NoticeDeliveryChannel,
  NoticeStatus,
  GradeLevel,
} from '../types';
import {
  STAGE_CONFIG,
  evaluateNoticeEligibility,
  calculateStudentAbsenceStats,
  createNewNotice,
  generateNoticeSmsText,
  generateNoticeWhatsAppText,
} from '../utils/noticeEngine';
import { formatToAlgerianWhatsApp, getSingleSmsUri } from './SmsNotificationModal';
import { exportAbsenceNoticesToExcel } from '../utils/excelExport';
import {
  AlertTriangle,
  Bell,
  CheckCircle2,
  Clock,
  ExternalLink,
  FileCheck,
  FileSpreadsheet,
  FileText,
  Filter,
  MessageCircle,
  MessageSquare,
  Phone,
  Printer,
  RefreshCw,
  Search,
  Send,
  ShieldAlert,
  Sparkles,
  UserCheck,
  UserX,
  X,
  ChevronRight,
  School
} from 'lucide-react';

interface AbsenceNoticesManagerProps {
  students: Student[];
  records: AttendanceRecord[];
  settings: SchoolSettings;
  notices: AbsenceNotice[];
  onSaveNotice: (notice: AbsenceNotice) => void;
  onBulkSaveNotices?: (notices: AbsenceNotice[]) => void;
  onDeleteNotice?: (id: string) => void;
  onAddTestAbsenceRecord?: (studentId: string, daysToAdd: number, baseStage: AbsenceNoticeStage) => void;
}

export const AbsenceNoticesManager: React.FC<AbsenceNoticesManagerProps> = ({
  students,
  records,
  settings,
  notices,
  onSaveNotice,
  onBulkSaveNotices,
  onDeleteNotice,
  onAddTestAbsenceRecord,
}) => {
  const todayStr = new Date().toISOString().split('T')[0];

  // Active filter tab
  const [stageFilter, setStageFilter] = useState<'all' | AbsenceNoticeStage>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | NoticeStatus>('all');
  const [selectedGrade, setSelectedGrade] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Printable Notice Modal
  const [activePrintNotice, setActivePrintNotice] = useState<AbsenceNotice | null>(null);

  // Excuse / Justification Modal
  const [justifyingNotice, setJustifyingNotice] = useState<AbsenceNotice | null>(null);
  const [excuseText, setExcuseText] = useState<string>('شهادة طبية معتمدة من طبيب الصحة المدرسية');

  // Success Feedback Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Run automated scan across all students to identify who needs notices
  const pendingEvaluationList = useMemo(() => {
    const list: {
      student: Student;
      eligibleStage: AbsenceNoticeStage | null;
      currentAbsenceDays: number;
      reason: string;
      existingNotices: AbsenceNotice[];
    }[] = [];

    students.forEach((student) => {
      const studentNotices = notices.filter((n) => n.studentId === student.id);
      const evalResult = evaluateNoticeEligibility(student, records, studentNotices);

      // If eligible for a new notice that hasn't been created yet
      if (evalResult.eligibleStage) {
        const alreadyHasThisStage = studentNotices.some((n) => n.stage === evalResult.eligibleStage);
        if (!alreadyHasThisStage) {
          list.push({
            student,
            eligibleStage: evalResult.eligibleStage,
            currentAbsenceDays: evalResult.currentAbsenceDays,
            reason: evalResult.reason,
            existingNotices: studentNotices,
          });
        }
      }
    });

    return list;
  }, [students, records, notices]);

  // Overall Statistics Counters
  const stats = useMemo(() => {
    const stage1Count = notices.filter((n) => n.stage === 'notice_1').length;
    const stage2Count = notices.filter((n) => n.stage === 'notice_2').length;
    const stage3Count = notices.filter((n) => n.stage === 'formal_warning').length;
    const pendingCount = notices.filter((n) => n.status === 'pending').length;
    const sentCount = notices.filter((n) => n.status === 'sent').length;
    const justifiedCount = notices.filter((n) => n.status === 'justified').length;

    return {
      total: notices.length,
      stage1Count,
      stage2Count,
      stage3Count,
      pendingCount,
      sentCount,
      justifiedCount,
      newEligibleCount: pendingEvaluationList.length,
    };
  }, [notices, pendingEvaluationList]);

  // Filtered Notices List
  const filteredNotices = useMemo(() => {
    return notices.filter((n) => {
      if (stageFilter !== 'all' && n.stage !== stageFilter) return false;
      if (statusFilter !== 'all' && n.status !== statusFilter) return false;
      if (selectedGrade !== 'all' && n.grade !== selectedGrade) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchName = n.studentName.toLowerCase().includes(q);
        const matchPhone = n.guardianPhone.includes(q);
        const matchRef = n.referenceNumber.toLowerCase().includes(q);
        const matchClass = n.classroom.toLowerCase().includes(q);
        return matchName || matchPhone || matchRef || matchClass;
      }

      return true;
    });
  }, [notices, stageFilter, statusFilter, selectedGrade, searchQuery]);

  // Automatically create pending notices discovered by the engine
  const handleAutoGenerateNotices = () => {
    if (pendingEvaluationList.length === 0) {
      showToast('جميع الإشعارات محدثة ولا توجد إشعارات مستحقة جديدة حالياً');
      return;
    }

    const created: AbsenceNotice[] = [];
    pendingEvaluationList.forEach((item, idx) => {
      if (item.eligibleStage) {
        const newN = createNewNotice(
          item.student,
          item.eligibleStage,
          item.currentAbsenceDays,
          settings,
          notices.length + idx
        );
        created.push(newN);
        onSaveNotice(newN);
      }
    });

    if (onBulkSaveNotices && created.length > 1) {
      onBulkSaveNotices(created);
    }

    showToast(`تم إنشاء ${created.length} إشعار جديد بنجاح وفقاً لنظام الغياب`);
  };

  // Quick Action: Send via WhatsApp
  const handleSendWhatsApp = (notice: AbsenceNotice) => {
    const text = generateNoticeWhatsAppText(notice, settings);
    const formattedPhone = formatToAlgerianWhatsApp(notice.guardianPhone);
    const url = `https://wa.me/${formattedPhone}?text=${encodeURIComponent(text)}`;

    // Update status to 'sent'
    const updated: AbsenceNotice = {
      ...notice,
      status: 'sent',
      channel: 'whatsapp',
      sentDate: todayStr,
      updatedAt: new Date().toISOString(),
    };
    onSaveNotice(updated);

    // Open WhatsApp
    window.open(url, '_blank');
    showToast(`تم فتح تطبيق WhatsApp لتوجيه الإشعار للولي ${notice.guardianName}`);
  };

  // Quick Action: Send via SMS
  const handleSendSms = (notice: AbsenceNotice) => {
    const text = generateNoticeSmsText(notice, settings);
    const smsUri = getSingleSmsUri(notice.guardianPhone, text);

    const updated: AbsenceNotice = {
      ...notice,
      status: 'sent',
      channel: 'sms',
      sentDate: todayStr,
      updatedAt: new Date().toISOString(),
    };
    onSaveNotice(updated);

    window.location.href = smsUri;
    showToast(`تم فتح تطبيق الرسائل SMS لتوجيه الإشعار إلى ${notice.guardianPhone}`);
  };

  // Mark as Sent manually (e.g. Registered mail or hand delivery)
  const handleMarkAsSent = (notice: AbsenceNotice, channel: NoticeDeliveryChannel = 'hand_delivered') => {
    const updated: AbsenceNotice = {
      ...notice,
      status: 'sent',
      channel,
      sentDate: todayStr,
      notes: `${notice.notes || ''} (تم التبليغ يدوياً بمقر المؤسسة في ${todayStr})`,
      updatedAt: new Date().toISOString(),
    };
    onSaveNotice(updated);
    showToast('تم تحديث حالة الإشعار إلى: تم الإرسال والتبليغ');
  };

  // Submit Excuse / Justification
  const handleConfirmJustification = () => {
    if (!justifyingNotice) return;

    const updated: AbsenceNotice = {
      ...justifyingNotice,
      status: 'justified',
      excuseDate: todayStr,
      excuseReason: excuseText,
      notes: `تمت تسوية وتبرير الغياب بموجب: ${excuseText}`,
      updatedAt: new Date().toISOString(),
    };

    onSaveNotice(updated);
    setJustifyingNotice(null);
    showToast('تم تسجيل التبرير وتسوية وضعية التلميذ بنجاح');
  };

  // Simulation: Add Demo Absence to trigger stages
  const handleSimulateStage = (stage: AbsenceNoticeStage) => {
    const candidate = students.find(
      (s) => !notices.some((n) => n.studentId === s.id && n.stage === stage)
    ) || students[0];

    if (!candidate) return;

    if (onAddTestAbsenceRecord) {
      const days = stage === 'notice_1' ? 4 : stage === 'notice_2' ? 7 : 15;
      onAddTestAbsenceRecord(candidate.id, days, stage);
    }

    const daysCount = stage === 'notice_1' ? 4 : stage === 'notice_2' ? 7 : 15;
    const newNotice = createNewNotice(candidate, stage, daysCount, settings, notices.length);
    onSaveNotice(newNotice);

    showToast(`تمت محاكاة ${STAGE_CONFIG[stage].title} للتلميذ ${candidate.lastName} ${candidate.firstName}`);
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-slate-950 text-white px-5 py-3 rounded-2xl shadow-xl flex items-center gap-2.5 text-xs font-bold animate-fade-in border border-slate-700">
          <CheckCircle2 className="w-4 h-4 text-slate-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Header Card */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4 no-print">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-linear-to-br from-amber-600 to-slate-700 text-white flex items-center justify-center shadow-xs">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-slate-900">
                منظومة إشعارات وإعذارات الغياب المتدرجة
              </h2>
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-50 text-amber-900 border border-amber-200">
                النظام الرسمي المعتمد
              </span>
            </div>
            <p className="text-xs text-slate-500">
              المرحلة 1: إشعار اليوم الرابع ➔ المرحلة 2: إشعار 2 بعد أسبوع ➔ المرحلة 3: إعذار رسمي بعد 15 يوماً من أول يوم غياب
            </p>
          </div>
        </div>

        {/* Global Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Auto Scan & Generate */}
          {pendingEvaluationList.length > 0 && (
            <button
              type="button"
              onClick={handleAutoGenerateNotices}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-amber-950 bg-amber-100 hover:bg-amber-200 border border-amber-300 rounded-xl transition-all cursor-pointer shadow-xs animate-pulse"
              title="توليد الإشعارات المستحقة آلياً حسب سجلات الغياب"
            >
              <Sparkles className="w-4 h-4 text-amber-700" />
              <span>توليد {pendingEvaluationList.length} إشعار مستحق</span>
            </button>
          )}

          {/* Export to Excel */}
          <button
            type="button"
            onClick={() => exportAbsenceNoticesToExcel({ notices, settings })}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-slate-800 bg-slate-50 hover:bg-slate-100 border border-slate-300 rounded-xl transition-all cursor-pointer shadow-2xs"
            title="تصدير سجل الإشعارات كاملاً إلى Excel"
          >
            <FileSpreadsheet className="w-4 h-4 text-slate-700" />
            <span>تصدير Excel</span>
          </button>
        </div>
      </div>

      {/* Staged Disciplinary Rules Visual Ladder */}
      <div className="bg-linear-to-r from-amber-50 via-orange-50 to-slate-50 border border-orange-200 p-5 rounded-2xl shadow-xs space-y-3 no-print">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
            <Clock className="w-4 h-4 text-orange-600" />
            <span>مراحل التدرج القانوني لإشعارات وإعذارات الغياب (التشريع المدرسي):</span>
          </div>
          <span className="text-[11px] font-semibold text-slate-500">
            سريان الإجراءات حسب الأيام المنقضية
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* Step 1 */}
          <div className="bg-white/90 backdrop-blur-xs p-3.5 rounded-xl border border-amber-200 shadow-2xs space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-900 font-bold text-[11px]">
                المرحلة 1: اليوم الرابع (04)
              </span>
              <span className="text-xs font-mono-numbers font-bold text-amber-700">
                {stats.stage1Count} إشعار
              </span>
            </div>
            <h4 className="font-bold text-xs text-slate-900">الإشعار الأول بالغياب</h4>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              يرسل للولي فور بلوغ اليوم الرابع من الغياب غير المبرر لدعوته العاجلة إلى مصلحة الاستشارة التربوية.
            </p>
          </div>

          {/* Step 2 */}
          <div className="bg-white/90 backdrop-blur-xs p-3.5 rounded-xl border border-orange-200 shadow-2xs space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="px-2 py-0.5 rounded bg-orange-100 text-orange-900 font-bold text-[11px]">
                المرحلة 2: إشعار 2 (بعد أسبوع)
              </span>
              <span className="text-xs font-mono-numbers font-bold text-orange-700">
                {stats.stage2Count} إشعار 2
              </span>
            </div>
            <h4 className="font-bold text-xs text-slate-900">إشعار 2 بالغياب (الإشعار الثاني)</h4>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              المرحلة الثانية تعتبر إشعار 2 بالغياب، ترسل بعد مرور أسبوع كامل (7 أيام) على الإشعار الأول في حال استمرار الغياب دون تقديم تبرير مقبول.
            </p>
          </div>

          {/* Step 3 */}
          <div className="bg-white/90 backdrop-blur-xs p-3.5 rounded-xl border border-slate-200 shadow-2xs space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-900 font-bold text-[11px]">
                المرحلة 3: 15 يوماً من أول يوم غياب
              </span>
              <span className="text-xs font-mono-numbers font-bold text-slate-700">
                {stats.stage3Count} إعذار
              </span>
            </div>
            <h4 className="font-bold text-xs text-slate-900">الإعذار الرسمي النهائي</h4>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              إعذار رسمي موجه للولي عند بلوغ 15 يوماً من تاريخ أول يوم غياب يمنح 48 ساعة قبل الشطب النهائي من السجلات.
            </p>
          </div>
        </div>

        {/* Quick Simulator Buttons */}
        <div className="pt-2 border-t border-orange-200/80 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-1.5 text-slate-600 font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            <span>تجربة ومحاكاة دورة الغياب:</span>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => handleSimulateStage('notice_1')}
              className="px-2.5 py-1 text-[11px] font-bold bg-amber-100 hover:bg-amber-200 text-amber-900 rounded-lg transition-colors cursor-pointer"
            >
              + تجربة اليوم 4 (إشعار 1)
            </button>
            <button
              type="button"
              onClick={() => handleSimulateStage('notice_2')}
              className="px-2.5 py-1 text-[11px] font-bold bg-orange-100 hover:bg-orange-200 text-orange-900 rounded-lg transition-colors cursor-pointer"
            >
              + تجربة بعد أسبوع (إشعار 2)
            </button>
            <button
              type="button"
              onClick={() => handleSimulateStage('formal_warning')}
              className="px-2.5 py-1 text-[11px] font-bold bg-slate-100 hover:bg-slate-200 text-slate-900 rounded-lg transition-colors cursor-pointer"
            >
              + تجربة بعد 15 يوماً من أول غياب (إعذار رسمي)
            </button>
          </div>
        </div>
      </div>


      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4 no-print">
        {/* Total Notices */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-500 font-semibold">إجمالي الإشعارات المسجلة</p>
            <h3 className="text-2xl font-black text-slate-900 mt-1 font-mono-numbers">
              {stats.total}
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">في كافة المراحل</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center">
            <FileText className="w-5 h-5" />
          </div>
        </div>

        {/* Pending Notices */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs text-amber-800 font-semibold">بانتظار الإرسال والتبليغ</p>
            <h3 className="text-2xl font-black text-amber-600 mt-1 font-mono-numbers">
              {stats.pendingCount}
            </h3>
            <p className="text-[11px] text-amber-800 mt-0.5 font-semibold">تحتاج إجراء الولي</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center border border-amber-200">
            <Bell className="w-5 h-5" />
          </div>
        </div>

        {/* Sent Notices */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs text-blue-800 font-semibold">تم التبليغ والإرسال</p>
            <h3 className="text-2xl font-black text-blue-600 mt-1 font-mono-numbers">
              {stats.sentCount}
            </h3>
            <p className="text-[11px] text-blue-800 mt-0.5">واتساب / SMS / بريد</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center border border-blue-200">
            <Send className="w-5 h-5" />
          </div>
        </div>

        {/* Justified / Resolved */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-800 font-semibold">تمت التسوية والتبرير</p>
            <h3 className="text-2xl font-black text-slate-600 mt-1 font-mono-numbers">
              {stats.justifiedCount}
            </h3>
            <p className="text-[11px] text-slate-800 mt-0.5 font-semibold">مبررات مقبولة</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-slate-50 text-slate-600 flex items-center justify-center border border-slate-200">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Filter and Navigation Tabs */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3 no-print">
        <div className="flex flex-wrap items-center gap-1.5 text-xs font-bold">
          {/* Stage Tabs */}
          <button
            type="button"
            onClick={() => setStageFilter('all')}
            className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
              stageFilter === 'all'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            الكل ({notices.length})
          </button>
          <button
            type="button"
            onClick={() => setStageFilter('notice_1')}
            className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
              stageFilter === 'notice_1'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-amber-50 text-amber-900 hover:bg-amber-100 border border-amber-200'
            }`}
          >
            إشعار اليوم الرابع ({stats.stage1Count})
          </button>
          <button
            type="button"
            onClick={() => setStageFilter('notice_2')}
            className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
              stageFilter === 'notice_2'
                ? 'bg-orange-600 text-white shadow-xs'
                : 'bg-orange-50 text-orange-900 hover:bg-orange-100 border border-orange-200'
            }`}
          >
            المرحلة 2: إشعار 2 ({stats.stage2Count})
          </button>

          <button
            type="button"
            onClick={() => setStageFilter('formal_warning')}
            className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
              stageFilter === 'formal_warning'
                ? 'bg-slate-700 text-white shadow-xs'
                : 'bg-slate-50 text-slate-900 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            الإعذار الرسمي (+15 يوماً) ({stats.stage3Count})
          </button>
        </div>

        {/* Secondary filters: Status and Search */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="px-3 py-1.5 border border-slate-300 rounded-lg text-slate-700 bg-white"
          >
            <option value="all">كافة الحالات</option>
            <option value="pending">قيد الانتظار</option>
            <option value="sent">تم التبليغ والإرسال</option>
            <option value="justified">تمت التسوية والتبرير</option>
          </select>

          <select
            value={selectedGrade}
            onChange={(e) => setSelectedGrade(e.target.value)}
            className="px-3 py-1.5 border border-slate-300 rounded-lg text-slate-700 bg-white"
          >
            <option value="all">كافة المستويات</option>
            <option value="1AM">الأولى متوسط</option>
            <option value="2AM">الثانية متوسط</option>
            <option value="3AM">الثالثة متوسط</option>
            <option value="4AM">الرابعة متوسط</option>
          </select>

          <div className="relative w-48">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="بحث بالاسم أو الهاتف..."
              className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500"
            />
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
          </div>
        </div>
      </div>

      {/* Notices Roster Table & Cards */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-xs text-slate-800">
              سجل المتابعة الفردية للإشعارات والإعذارات القانونية
            </h3>
            <span className="text-[11px] text-slate-500">
              ({filteredNotices.length} إشعار مسجل)
            </span>
          </div>
        </div>

        {filteredNotices.length === 0 ? (
          <div className="p-12 text-center text-slate-400 text-xs space-y-2">
            <CheckCircle2 className="w-8 h-8 mx-auto text-slate-500" />
            <p className="font-bold text-slate-700">لا توجد إشعارات مطابقة للمحددات الحالية</p>
            <p className="text-[11px]">
              يمكنك النقر على زر "توليد إشعارات جديدة" أو استخدام أزرار المحاكاة أعلاه لتجربة المراحل الثلاث.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {filteredNotices.map((notice) => {
              const cfg = STAGE_CONFIG[notice.stage];

              return (
                <div
                  key={notice.id}
                  className="p-4 hover:bg-slate-50/80 transition-colors flex flex-col lg:flex-row lg:items-center justify-between gap-4"
                >
                  {/* Left: Student Identity & Notice Stage Badge */}
                  <div className="flex items-start gap-3.5">
                    <div
                      className={`w-11 h-11 rounded-2xl flex items-center justify-center text-white shrink-0 shadow-xs font-black ${
                        notice.stage === 'notice_1'
                          ? 'bg-amber-500'
                          : notice.stage === 'notice_2'
                          ? 'bg-orange-600'
                          : 'bg-slate-600'
                      }`}
                    >
                      {cfg.stageNumber}
                    </div>

                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h4 className="font-bold text-sm text-slate-900">
                          {notice.studentName}
                        </h4>
                        <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-slate-100 text-slate-700">
                          قسم {notice.classroom} ({notice.grade})
                        </span>
                        <span
                          className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${cfg.badgeBg}`}
                        >
                          {cfg.title}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500">
                        <span>الولي: <strong className="text-slate-800">{notice.guardianName}</strong></span>
                        <span>·</span>
                        <span className="flex items-center gap-1 font-mono-numbers">
                          <Phone className="w-3 h-3 text-slate-400" />
                          <span>{notice.guardianPhone}</span>
                        </span>
                        <span>·</span>
                        <span className="font-mono-numbers text-slate-700 font-bold">
                          الغياب: {notice.absenceDaysCount} أيام
                        </span>
                        <span>·</span>
                        <span className="text-slate-400 font-mono-numbers">
                          المرجع: {notice.referenceNumber}
                        </span>
                      </div>

                      {notice.notes && (
                        <p className="text-[11px] text-slate-500 bg-slate-50 px-2 py-1 rounded-md border border-slate-200 inline-block">
                          {notice.notes}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Right: Status & Actions */}
                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    {/* Status Badge */}
                    <div className="pl-2">
                      {notice.status === 'pending' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200">
                          <Clock className="w-3 h-3" />
                          <span>قيد الانتظار</span>
                        </span>
                      )}
                      {notice.status === 'sent' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold bg-blue-50 text-blue-800 border border-blue-200">
                          <CheckCircle2 className="w-3 h-3 text-blue-600" />
                          <span>تم التبليغ ({notice.sentDate || 'الآن'})</span>
                        </span>
                      )}
                      {notice.status === 'justified' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold bg-slate-50 text-slate-800 border border-slate-200">
                          <UserCheck className="w-3 h-3 text-slate-600" />
                          <span>تمت التسوية (مبرر)</span>
                        </span>
                      )}
                    </div>

                    {/* WhatsApp Action */}
                    <button
                      type="button"
                      onClick={() => handleSendWhatsApp(notice)}
                      className="flex items-center gap-1 px-3 py-1.5 text-xs font-bold text-white bg-slate-600 hover:bg-slate-700 active:scale-95 rounded-xl transition-all cursor-pointer shadow-2xs"
                      title="إرسال نص الإشعار الرسمي فوراً عبر WhatsApp"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>واتساب</span>
                    </button>

                    {/* SMS Action */}
                    <button
                      type="button"
                      onClick={() => handleSendSms(notice)}
                      className="flex items-center gap-1 px-3 py-1.5 text-xs font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-xl transition-all cursor-pointer shadow-2xs"
                      title="إرسال رسالة SMS عبر تطبيق الرسائل"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>SMS</span>
                    </button>

                    {/* Print Official Letter Action */}
                    <button
                      type="button"
                      onClick={() => setActivePrintNotice(notice)}
                      className="flex items-center gap-1 px-3 py-1.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-all cursor-pointer"
                      title="طباعة الاستمارة الرسمية للإشعار / الإعذار"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>طباعة</span>
                    </button>

                    {/* Mark as Justified / Excuse */}
                    {notice.status !== 'justified' && (
                      <button
                        type="button"
                        onClick={() => setJustifyingNotice(notice)}
                        className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-bold text-slate-800 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl transition-all cursor-pointer"
                        title="تسوية وتبرير الغياب بشهادة طبية أو حضور الولي"
                      >
                        <FileCheck className="w-3.5 h-3.5" />
                        <span>تسوية</span>
                      </button>
                    )}

                    {/* Hand delivered / Mark sent */}
                    {notice.status === 'pending' && (
                      <button
                        type="button"
                        onClick={() => handleMarkAsSent(notice, 'hand_delivered')}
                        className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 cursor-pointer transition-colors"
                        title="تسجيل كتسليم يدوي بالاستدعاء"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* MODAL 1: Official Printable Document (استمارة الإشعار / الإعذار الرسمية) */}
      {activePrintNotice && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-8 shadow-2xl space-y-6 relative border border-slate-200 my-8">
            {/* Top Toolbar (No print) */}
            <div className="flex items-center justify-between border-b pb-4 no-print">
              <div className="flex items-center gap-2">
                <Printer className="w-5 h-5 text-slate-700" />
                <h3 className="font-bold text-slate-900 text-sm">
                  معاينة وطباعة الوثيقة الإدارية الرسمية
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-4 py-2 bg-slate-700 hover:bg-slate-800 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Printer className="w-4 h-4" />
                  <span>طباعة الآن (A4)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActivePrintNotice(null)}
                  className="p-2 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* A4 Printable Official Form */}
            <div className="p-6 border-2 border-slate-900 rounded-2xl space-y-6 text-slate-900 leading-relaxed font-sans">
              {/* Official Algerian Republic Header */}
              <div className="text-center space-y-1 text-xs font-bold border-b-2 border-slate-900 pb-4">
                <p className="text-sm font-black">الجمهورية الجزائرية الديمقراطية الشعبية</p>
                <p>وزارة التربية الوطنية</p>
                <div className="flex justify-between items-center px-4 pt-1 text-[11px] font-semibold text-slate-700">
                  <span>مديرية التربية لولاية {settings.wilaya || 'عنابة'}</span>
                  <span className="font-bold text-slate-900">{settings.schoolName || 'متوسطة سعدون عاشور'}</span>
                  <span>السنة الدراسية: {settings.academicYear || '2026-2027'}</span>
                </div>
              </div>

              {/* Document Title & Reference */}
              <div className="flex items-center justify-between text-xs">
                <div>
                  <p><strong>مصلحة:</strong> الاستشارة التربوية</p>
                  <p><strong>رقم المرجع:</strong> {activePrintNotice.referenceNumber}</p>
                </div>
                <div className="text-left">
                  <p><strong>عنابة في:</strong> {activePrintNotice.dueDate}</p>
                  <p><strong>الدرجة:</strong> {STAGE_CONFIG[activePrintNotice.stage].daysRule}</p>
                </div>
              </div>

              {/* Title Box */}
              <div className="text-center py-2 border-2 border-slate-900 rounded-xl bg-slate-50">
                <h2 className="text-base font-black tracking-wide">
                  {STAGE_CONFIG[activePrintNotice.stage].title}
                </h2>
                <p className="text-xs font-bold text-slate-700">
                  {activePrintNotice.stage === 'formal_warning'
                    ? 'إعذار قانوني نهائي قبل الشطب من سجلات المؤسسة'
                    : 'بشأن الانقطاع عن مواظبة مقاعد الدراسة'}
                </p>
              </div>

              {/* Guardian & Student Info */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-300 text-xs space-y-2">
                <p>
                  إلى السيد(ة) ولي أمر التلميذ(ة): <strong>{activePrintNotice.guardianName}</strong>
                </p>
                <p>
                  المقيم بـ: <strong>حي وادي فرشة، عنابة</strong> · هاتف: <strong className="font-mono-numbers">{activePrintNotice.guardianPhone}</strong>
                </p>
                <p>
                  المسؤول عن التلميذ(ة): <strong className="text-sm">{activePrintNotice.studentName}</strong> | القسم: <strong>{activePrintNotice.classroom}</strong> ({activePrintNotice.grade})
                </p>
                <p>
                  رقم التعريف المدرسي الوطني: <strong className="font-mono-numbers">{activePrintNotice.nationalId || '-'}</strong>
                </p>
              </div>

              {/* Body Text */}
              <div className="text-xs text-justify space-y-3 leading-relaxed">
                {activePrintNotice.stage === 'notice_1' && (
                  <>
                    <p>
                      نحيطكم علماً بأن ابنكم (ابنتكم) المسجل بمؤسستنا قد انقطع عن متابعة الدروس لمدة <strong>أربعة (04) أيام متتالية</strong>، ابتداءً من تاريخ {activePrintNotice.startDate} إلى غاية يومنا هذا دون تقديم أي مبرر شرعي أو تقرير طبي.
                    </p>
                    <p>
                      وعملاً بمقتضيات النظام الداخلي لمؤسسات التعليم المتوسط وقرارات وزارة التربية الوطنية المتعلقة بالمواظبة المدرسية، فإننا نلزمكم بالحضور فوراً إلى مقر المتوسطة (مكتب مستشارة التربية) لتوضيح أسباب هذا الغياب وتسوية وضعية التلميذ تفادياً لاتخاذ الإجراءات التأديبية المنصوص عليها قانوناً.
                    </p>
                  </>
                )}

                {activePrintNotice.stage === 'notice_2' && (
                  <>
                    <p>
                      نظراً لعدم استجابتكم للإشعار الأول الصادر بتاريخ {activePrintNotice.startDate}، وتواصل غياب التلميذ لمدة <strong>أسبوع كامل (07 أيام)</strong> دون تقديم أي عذر مقبول يبرر هذا الغياب المستمر، نوجه إليكم هذا <strong>الإشعار الثاني (إشعار 2 بالغياب)</strong>.
                    </p>
                    <p>
                      إن استمرار هذا الانقطاع يمس بمسار التلميذ الدراسي بصورة بالغة، ونحملكم كامل المسؤولية التربوية والقانونية المترتبة على ذلك، ونطالبكم بإلزام التلميذ بالالتحاق الفوري بمقاعد الدراسة مصحوباً بولي أمره خلال 48 ساعة من تاريخ استلامكم هذا الإشعار.
                    </p>
                  </>
                )}


                {activePrintNotice.stage === 'formal_warning' && (
                  <>
                    <p className="font-bold text-slate-950">
                      بناءً على الإشعار الأول وإشعار 2 بالغياب، ونظراً لانقضاء مهلة <strong>خمسة عشر (15) يوماً كاملة من تاريخ أول يوم غياب</strong> للتلميذ دون أي استجابة أو استئناف للدراسة:
                    </p>
                    <p>
                      نوجه إليكم هذا <strong>الإعذار الرسمي الأخير</strong>.
                      وفي حال عدم التحاق التلميذ بمقاعد الدراسة داخل أجل أقصاه <strong>ثمان وأربعون (48) ساعة</strong> من تاريخ تبليغ هذا الإعذار، ستضطر إدارة المؤسسة إلى <strong>شطبه بصفة نهائية</strong> من سجلات التمدرس بمتوسطة {settings.schoolName || 'سعدون عاشور'}، واعتباره متخلياً عن الدراسة وفقاً للتشريع والتنظيم التربوي الجاري به العمل.
                    </p>
                  </>
                )}
              </div>

              {/* Signatures and Stamps */}
              <div className="pt-6 border-t border-slate-300 grid grid-cols-2 text-center text-xs font-bold">
                <div className="space-y-12">
                  <p>مستشارة التربية الرئيسية</p>
                  <p className="font-extrabold text-sm">{settings.counselorName || 'حليلو صليحة'}</p>
                </div>
                <div className="space-y-12">
                  <p>مديرة المتوسطة (الختم والتوقيع)</p>
                  <p className="font-extrabold text-sm">{settings.principalName || 'بويمة ليلى بن تروش'}</p>
                </div>
              </div>

              {/* Return Slip (وصل استلام الإشعار من طرف الولي) */}
              <div className="pt-4 border-t-2 border-dashed border-slate-400 text-[11px] space-y-2">
                <p className="font-bold text-center underline">
                  وصل استلام إشعار / إعذار الغياب (يعاد إلى إدارة المؤسسة)
                </p>
                <div className="flex justify-between">
                  <span>أنا الموقع أسفله ولي التلميذ: .......................................</span>
                  <span>أشهد باستلام {activePrintNotice.stage === 'notice_2' ? 'إشعار 2 بالغياب' : activePrintNotice.stage === 'notice_1' ? 'الإشعار الأول' : 'الإعذار الرسمي'} رقم ({activePrintNotice.referenceNumber})</span>
                </div>
                <div className="flex justify-between pt-1">
                  <span>بتاريخ: ..... / ..... / 2026</span>
                  <span>توقيع الولي: ....................................</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: Justification / Excuse Modal */}
      {justifyingNotice && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4 border border-slate-200 animate-scale-up">
            <div className="flex items-center justify-between border-b pb-3">
              <div className="flex items-center gap-2">
                <FileCheck className="w-5 h-5 text-slate-600" />
                <h3 className="font-bold text-sm text-slate-900">تسوية وتبرير الغياب</h3>
              </div>
              <button
                type="button"
                onClick={() => setJustifyingNotice(null)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="text-xs space-y-2">
              <p className="text-slate-600">
                تسجيل التبرير القانوني للتلميذ:{' '}
                <strong className="text-slate-900">{justifyingNotice.studentName}</strong> (
                {justifyingNotice.classroom})
              </p>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  طبيعة المبرر المقدم من الولي:
                </label>
                <textarea
                  rows={3}
                  value={excuseText}
                  onChange={(e) => setExcuseText(e.target.value)}
                  className="w-full p-2.5 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-slate-500"
                  placeholder="مثال: شهادة طبية معتمدة، عذر عائلي قاهر، حضور الولي والتعهد بالمواظبة..."
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t">
              <button
                type="button"
                onClick={() => setJustifyingNotice(null)}
                className="px-4 py-2 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={handleConfirmJustification}
                className="px-4 py-2 text-xs font-bold text-white bg-slate-700 hover:bg-slate-800 rounded-xl cursor-pointer shadow-xs"
              >
                تأكيد التسوية
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
