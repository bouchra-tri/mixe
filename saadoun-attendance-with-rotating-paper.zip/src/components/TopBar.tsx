import React, { useState, useEffect, useRef } from 'react';
import { SchoolSettings, PeriodId } from '../types';
import {
  Menu,
  Clock,
  Sun,
  Moon,
  RefreshCw,
  ChevronDown,
  Check,
  Database,
  User,
  LogOut,
  Scan,
  ClipboardCheck,
  Users,
  BookOpen,
  UserCheck,
  Calendar,
  ShieldAlert,
  BarChart3,
  Settings,
} from 'lucide-react';
import { getSettingsPeriods, getPeriodById } from '../utils/periodHelper';
import { AppUser } from '../types';
import { ViewType } from './Sidebar';

import { ThemeQuickMenu } from './ThemeQuickMenu';
import { useTheme } from '../context/ThemeContext';

interface TopBarProps {
  currentView: ViewType;
  settings: SchoolSettings;
  currentSession: 'morning' | 'afternoon';
  onToggleSession: () => void;
  currentPeriodId?: string;
  onChangePeriod?: (periodId: PeriodId) => void;
  syncStatus?: 'connected' | 'reconnecting' | 'offline';
  isSyncing?: boolean;
  onManualSync?: () => void;
  lastSyncTime?: string;
  onOpenDataPersistence?: () => void;
  currentUser?: AppUser | null;
  onOpenLoginModal?: () => void;
  onLogout?: () => void;
  onToggleMobileNav: () => void;
  onThemeSavedToSettings?: (color: any, customHex?: string, mode?: any) => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  currentView,
  settings,
  currentSession,
  onToggleSession,
  currentPeriodId = 'm1',
  onChangePeriod,
  syncStatus = 'connected',
  isSyncing = false,
  onManualSync,
  lastSyncTime,
  onOpenDataPersistence,
  currentUser,
  onOpenLoginModal,
  onLogout,
  onToggleMobileNav,
  onThemeSavedToSettings,
}) => {
  const { palette } = useTheme();
  const [timeStr, setTimeStr] = useState<string>('');
  const [isPeriodMenuOpen, setIsPeriodMenuOpen] = useState(false);
  const periodMenuRef = useRef<HTMLDivElement | null>(null);

  const periods = getSettingsPeriods(settings);
  const activePeriod = getPeriodById(settings, currentPeriodId);

  useEffect(() => {
    const update = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString('ar-DZ', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: false,
        })
      );
    };
    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (periodMenuRef.current && !periodMenuRef.current.contains(event.target as Node)) {
        setIsPeriodMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const morningPeriods = periods.filter((p) => p.type === 'morning');
  const afternoonPeriods = periods.filter((p) => p.type === 'afternoon');

  // Title and icon lookup based on currentView
  const viewInfo: Record<
    ViewType,
    { title: string; subtitle: string; icon: React.ComponentType<{ className?: string }> }
  > = {
    scanner: {
      title: 'بوابة الدخول السريع',
      subtitle: 'مسح واستدعاء الباركود وتسجيل الحضور الفوري',
      icon: Scan,
    },
    attendance: {
      title: 'سجل الحضور اليومي',
      subtitle: 'متابعة وتدقيق وإثبات حضور وتأخر التلاميذ',
      icon: ClipboardCheck,
    },
    students: {
      title: 'شؤون وقاعدة بيانات التلاميذ',
      subtitle: 'إدارة السجلات والبطاقات وتحديث قوائم الأقسام',
      icon: Users,
    },
    rotating_paper: {
      title: 'الورقة الدوارة',
      subtitle: 'ورقة الحضور وتأشيرات الأساتذة وجداول FET والطباعة',
      icon: ClipboardCheck,
    },
    timetable: {
      title: 'جداول التوقيت والمواد',
      subtitle: 'برامج الحصص الأسبوعية وتوزيع القاعات والأساتذة',
      icon: BookOpen,
    },
    teacher_sessions: {
      title: 'متابعة تسجيلات حضور الأساتذة',
      subtitle: 'مراجعة واعتماد الجلسات المسجلة من هواتف الأساتذة',
      icon: UserCheck,
    },
    monthly: {
      title: 'التقارير وسجلات الحضور الشهرية',
      subtitle: 'كشوف الحضور والغياب الرسمية والطباعة لوزارة التربية',
      icon: Calendar,
    },
    notices: {
      title: 'إشعارات ومراحل الغياب المتكرر',
      subtitle: 'المتابعة القانونية (إشعار 1، إشعار 2، الإعذار النهائي)',
      icon: ShieldAlert,
    },
    reports: {
      title: 'الإحصائيات والتحليلات البيانية',
      subtitle: 'مؤشرات المواظبة والنسب المئوية ونسب الحضور',
      icon: BarChart3,
    },
    settings: {
      title: 'إعدادات المؤسسة والنظام',
      subtitle: 'ضبط التوقيت، الحصص، النسخ الاحتياطي وإدارة البيانات',
      icon: Settings,
    },
  };

  const currentInfo = viewInfo[currentView] || viewInfo.scanner;
  const ViewIcon = currentInfo.icon;

  return (
    <header className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 sticky top-0 z-30 shadow-2xs transition-colors duration-150">
      <div className="w-full px-4 sm:px-6">
        <div className="flex items-center justify-between h-16 gap-3">
          {/* Left / Right Zone in RTL: Hamburger & Breadcrumbs */}
          <div className="flex items-center gap-3 min-w-0">
            {/* Hamburger Button for Mobile / Small Screens */}
            <button
              type="button"
              onClick={onToggleMobileNav}
              className="lg:hidden p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer border border-slate-200 dark:border-slate-700"
              title="فتح القائمة الجانبية"
            >
              <Menu className="w-5 h-5 text-current" />
            </button>

            {/* Current View Title & Subtitle */}
            <div className="flex items-center gap-2.5 min-w-0">
              <div
                className="hidden sm:flex w-9 h-9 rounded-xl items-center justify-center shrink-0 border transition-colors"
                style={{
                  backgroundColor: palette.light,
                  color: palette.primary,
                  borderColor: palette.border,
                }}
              >
                <ViewIcon className="w-4 h-4 text-current" />
              </div>
              <div className="min-w-0">
                <h2 className="font-extrabold text-slate-900 dark:text-slate-100 text-sm sm:text-base leading-tight truncate">
                  {currentInfo.title}
                </h2>
                <p className="text-[11px] text-slate-400 dark:text-slate-500 hidden md:block truncate">
                  {currentInfo.subtitle}
                </p>
              </div>
            </div>
          </div>

          {/* Controls Zone: Theme Quick Switcher, Sync, Period Dropdown, Clock, Persistence, User Profile */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Quick Theme Switcher */}
            <ThemeQuickMenu onThemeSavedToSettings={onThemeSavedToSettings} />

            {/* Quick Data Save Button */}
            {onOpenDataPersistence && (
              <button
                type="button"
                onClick={onOpenDataPersistence}
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl shadow-xs transition-all cursor-pointer active:scale-95"
                style={{
                  backgroundColor: palette.primary,
                  color: palette.foreground,
                }}
                title="فتح مركز حفظ وإدارة قاعدة البيانات"
              >
                <Database className="w-3.5 h-3.5 text-current" />
                <span>حفظ البيانات</span>
              </button>
            )}

            {/* Live Server Sync Status */}
            <div
              className={`flex items-center gap-1.5 px-2.5 py-1 text-[11px] rounded-lg border transition-all ${
                syncStatus === 'connected'
                  ? 'bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 border-slate-200 dark:border-slate-700'
                  : syncStatus === 'reconnecting'
                  ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-300 border-amber-200 dark:border-amber-800'
                  : 'bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 border-slate-200 dark:border-slate-700'
              }`}
              title={
                syncStatus === 'connected'
                  ? `متصل بالخادم المركزي - آخر مزامنة: ${lastSyncTime || 'الآن'}`
                  : 'جاري محاولة إعادة الاتصال بالخادم...'
              }
            >
              <span className="relative flex h-2 w-2">
                {syncStatus === 'connected' && (
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-slate-400 opacity-75"></span>
                )}
                <span
                  className={`relative inline-flex rounded-full h-2 w-2 ${
                    syncStatus === 'connected'
                      ? 'bg-slate-600'
                      : syncStatus === 'reconnecting'
                      ? 'bg-amber-500'
                      : 'bg-slate-500'
                  }`}
                ></span>
              </span>

              <span className="font-semibold hidden xl:inline">
                {syncStatus === 'connected'
                  ? 'مزامنة حية'
                  : syncStatus === 'reconnecting'
                  ? 'إعادة اتصال'
                  : 'غير متصل'}
              </span>

              {onManualSync && (
                <button
                  type="button"
                  onClick={onManualSync}
                  className="p-0.5 text-slate-500 hover:text-slate-900 cursor-pointer rounded transition-colors"
                  title="مزامنة التحديثات فوراً من الخادم"
                >
                  <RefreshCw
                    className={`w-3 h-3 ${isSyncing ? 'animate-spin text-slate-600' : ''}`}
                  />
                </button>
              )}
            </div>

            {/* Period Dropdown */}
            <div className="relative" ref={periodMenuRef}>
              <button
                type="button"
                onClick={() => setIsPeriodMenuOpen((prev) => !prev)}
                className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-bold rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors cursor-pointer text-slate-800 dark:text-slate-200 shadow-2xs whitespace-nowrap"
                title="تحديد فترة دخول الفوج"
              >
                {activePeriod.type === 'morning' ? (
                  <Sun className="w-3.5 h-3.5 text-amber-500" />
                ) : (
                  <Moon className="w-3.5 h-3.5 text-indigo-400" />
                )}
                <span className="hidden sm:inline">{activePeriod.shortName || activePeriod.name}</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {isPeriodMenuOpen && (
                <div className="absolute left-0 mt-1.5 w-72 bg-white dark:bg-slate-900 rounded-xl shadow-xl border border-slate-200 dark:border-slate-800 p-2 z-50 animate-scale-up text-right">
                  <div className="px-2 py-1.5 text-[11px] font-bold text-slate-400 dark:text-slate-500 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <span>فترات دخول الأفواج</span>
                    <span className="text-[10px] text-slate-500">6 فترات زمنية</span>
                  </div>

                  <div className="py-1">
                    <div className="px-2 py-1 text-[10px] font-bold text-amber-800 dark:text-amber-300 bg-amber-50/70 dark:bg-amber-950/40 rounded mb-1 flex items-center gap-1">
                      <Sun className="w-3 h-3" />
                      <span>الفترات الصباحية (3 أفواج)</span>
                    </div>
                    <div className="space-y-0.5">
                      {morningPeriods.map((p) => {
                        const isSelected = p.id === currentPeriodId;
                        return (
                          <button
                            key={p.id}
                            type="button"
                            onClick={() => {
                              onChangePeriod?.(p.id);
                              setIsPeriodMenuOpen(false);
                            }}
                            className={`w-full text-right px-2.5 py-1.5 text-xs rounded-lg flex items-center justify-between transition-colors cursor-pointer ${
                              isSelected
                                ? 'font-bold'
                                : 'hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
                            }`}
                            style={
                              isSelected
                                ? {
                                    backgroundColor: palette.light,
                                    color: palette.primary,
                                    border: `1px solid ${palette.border}`,
                                  }
                                : undefined
                            }
                          >
                            <span className="truncate">{p.name}</span>
                            {isSelected && <Check className="w-3.5 h-3.5 shrink-0" style={{ color: palette.primary }} />}
                          </button>
                        );
                      })}
                    </div>

                    <div className="px-2 py-1 text-[10px] font-bold text-indigo-800 dark:text-indigo-300 bg-indigo-50/70 dark:bg-indigo-950/40 rounded my-1 flex items-center gap-1">
                      <Moon className="w-3 h-3" />
                      <span>الفترات المسائية (3 أفواج)</span>
                    </div>
                    <div className="space-y-0.5">
                      {afternoonPeriods.map((p) => {
                        const isSelected = p.id === currentPeriodId;
                        return (
                          <button
                            key={p.id}
                            type="button"
                            onClick={() => {
                              onChangePeriod?.(p.id);
                              setIsPeriodMenuOpen(false);
                            }}
                            className={`w-full text-right px-2.5 py-1.5 text-xs rounded-lg flex items-center justify-between transition-colors cursor-pointer ${
                              isSelected
                                ? 'font-bold'
                                : 'hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
                            }`}
                            style={
                              isSelected
                                ? {
                                    backgroundColor: palette.light,
                                    color: palette.primary,
                                    border: `1px solid ${palette.border}`,
                                  }
                                : undefined
                            }
                          >
                            <span className="truncate">{p.name}</span>
                            {isSelected && <Check className="w-3.5 h-3.5 shrink-0" style={{ color: palette.primary }} />}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Live Clock */}
            <div className="hidden md:flex items-center gap-1.5 text-xs font-mono-numbers font-bold text-slate-800 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700">
              <Clock className="w-3.5 h-3.5 text-slate-500" />
              <span>{timeStr || '--:--:--'}</span>
            </div>

            {/* Current User in TopBar (Compact) */}
            {currentUser ? (
              <div className="flex items-center gap-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-2 py-1 rounded-xl">
                <div
                  className="w-6 h-6 rounded-lg flex items-center justify-center text-xs font-bold shrink-0 shadow-2xs"
                  style={{ backgroundColor: palette.primary, color: palette.foreground }}
                >
                  <User className="w-3.5 h-3.5 text-current" />
                </div>
                <span className="hidden sm:inline text-xs font-bold text-slate-800 dark:text-slate-200 truncate max-w-[100px]">
                  {currentUser.name}
                </span>
                {onLogout && (
                  <button
                    type="button"
                    onClick={onLogout}
                    className="p-1 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 rounded-md cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700"
                    title="تسجيل الخروج"
                  >
                    <LogOut className="w-3 h-3 text-current" />
                  </button>
                )}
              </div>
            ) : (
              onOpenLoginModal && (
                <button
                  type="button"
                  onClick={onOpenLoginModal}
                  className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-bold text-slate-900 dark:text-slate-100 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-all cursor-pointer shadow-2xs"
                >
                  <User className="w-3.5 h-3.5 text-current" />
                  <span className="hidden sm:inline">دخول الأساتذة</span>
                </button>
              )
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
