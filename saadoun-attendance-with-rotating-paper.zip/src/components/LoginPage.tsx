import React, { useState } from 'react';
import { AppUser, SchoolSettings } from '../types';
import { apiLogin } from '../services/api';
import {
  School,
  Scan,
  ClipboardCheck,
  BookOpen,
  ShieldAlert,
  User,
  KeyRound,
  LogIn,
  AlertTriangle,
  Eye,
  EyeOff,
  HelpCircle,
  Lock,
  Sparkles,
} from 'lucide-react';

interface LoginPageProps {
  settings: SchoolSettings;
  onLoginSuccess: (user: AppUser, token: string) => void;
  onOpenSetupModal?: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  settings,
  onLoginSuccess,
  onOpenSetupModal,
}) => {
  const [username, setUsername] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [showForgotPasswordModal, setShowForgotPasswordModal] = useState<boolean>(false);

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) {
      setError('يرجى إدخال اسم المستخدم');
      return;
    }
    if (!password) {
      setError('يرجى إدخال كلمة المرور');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const res = await apiLogin(username.trim(), password);
      if (res && res.user && res.token) {
        onLoginSuccess(res.user, res.token);
      } else {
        setError('فشل تسجيل الدخول: تأكد من صحة اسم المستخدم وكلمة المرور');
      }
    } catch (err: any) {
      setError(err.message || 'اسم المستخدم أو كلمة المرور غير صحيحة');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex flex-col lg:flex-row bg-[#25101E] select-none" dir="rtl">
      {/* ========================================================================= */}
      {/* RIGHT SIDE (Desktop) / BOTTOM (Mobile) — Platform Introduction (عنابي داكن مع ذهبي ووردي) */}
      {/* ========================================================================= */}
      <div className="lg:flex-1 bg-[#25101E] text-[#F4E8C1] p-6 sm:p-10 lg:p-14 flex flex-col justify-between relative overflow-hidden order-2 lg:order-1 border-t lg:border-t-0 lg:border-l border-[#54203C]">
        {/* Subtle geometric background pattern overlay */}
        <div className="absolute inset-0 opacity-5 pointer-events-none bg-[radial-gradient(#AD965B_1px,transparent_1px)] [background-size:24px_24px]"></div>
        <div className="absolute -right-20 -top-20 w-80 h-80 rounded-full bg-[#590B35]/30 blur-3xl pointer-events-none"></div>

        {/* Top Brand Header */}
        <div className="relative z-10 flex items-center gap-3.5">
          <div
            className="w-12 h-12 rounded-2xl flex items-center justify-center shadow-md ring-2 ring-[#AD965B]/40"
            style={{ backgroundColor: '#590B35', color: '#F4E8C1' }}
          >
            <School className="w-6 h-6" style={{ color: '#AD965B' }} />
          </div>
          <div>
            <span className="text-[11px] font-extrabold uppercase tracking-widest block" style={{ color: '#EF58B5' }}>
              وزارة التربية الوطنية — ولاية عنابة
            </span>
            <h1 className="text-base sm:text-lg font-black tracking-tight" style={{ color: '#F4E8C1' }}>
              {settings.schoolName || 'متوسطة سعدون عاشور — البوني'}
            </h1>
          </div>
        </div>

        {/* Center Main Hero Copy */}
        <div className="relative z-10 my-10 lg:my-0 space-y-5 max-w-xl">
          <div
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-bold border"
            style={{ backgroundColor: '#321323', color: '#EF58B5', borderColor: '#54203C' }}
          >
            <Sparkles className="w-3.5 h-3.5" style={{ color: '#AD965B' }} />
            <span>منصة محلية آمنة وموثوقة لتسيير المؤسسة</span>
          </div>

          <h2 className="text-2xl sm:text-4xl lg:text-5xl font-black leading-tight tracking-tight" style={{ color: '#F4E8C1' }}>
            الحضور والغياب والتوقيت… في منصة واحدة.
          </h2>

          <p className="text-sm sm:text-base leading-relaxed font-medium" style={{ color: '#BCAF91' }}>
            منصة متكاملة لتسجيل دخول التلاميذ، ومتابعة غيابات الحصص، وتحديد مواد وتواقيت الأساتذة، والتواصل الإداري الفعال.
          </p>

          {/* Feature Bullets with Icons */}
          <div className="space-y-3.5 pt-4">
            <div
              className="flex items-center gap-3 rounded-2xl p-3.5 border backdrop-blur-xs transition-transform hover:translate-x-1 duration-200"
              style={{ backgroundColor: '#321323', borderColor: '#54203C' }}
            >
              <div
                className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
                style={{ backgroundColor: 'rgba(89, 11, 53, 0.5)', color: '#AD965B' }}
              >
                <Scan className="w-4 h-4" />
              </div>
              <div className="text-xs sm:text-sm font-bold" style={{ color: '#F4E8C1' }}>
                تسجيل دخول التلاميذ بالباركود والبطاقات المدرسية
              </div>
            </div>

            <div
              className="flex items-center gap-3 rounded-2xl p-3.5 border backdrop-blur-xs transition-transform hover:translate-x-1 duration-200"
              style={{ backgroundColor: '#321323', borderColor: '#54203C' }}
            >
              <div
                className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
                style={{ backgroundColor: 'rgba(89, 11, 53, 0.5)', color: '#AD965B' }}
              >
                <ClipboardCheck className="w-4 h-4" />
              </div>
              <div className="text-xs sm:text-sm font-bold" style={{ color: '#F4E8C1' }}>
                تسجيل الغياب أثناء الحصة مباشرة من هاتف الأستاذ
              </div>
            </div>

            <div
              className="flex items-center gap-3 rounded-2xl p-3.5 border backdrop-blur-xs transition-transform hover:translate-x-1 duration-200"
              style={{ backgroundColor: '#321323', borderColor: '#54203C' }}
            >
              <div
                className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
                style={{ backgroundColor: 'rgba(89, 11, 53, 0.5)', color: '#AD965B' }}
              >
                <BookOpen className="w-4 h-4" />
              </div>
              <div className="text-xs sm:text-sm font-bold" style={{ color: '#F4E8C1' }}>
                جداول توقيت دقيقة للأساتذة والأقسام وتحديد مادة التلميذ الغائب
              </div>
            </div>

            <div
              className="flex items-center gap-3 rounded-2xl p-3.5 border backdrop-blur-xs transition-transform hover:translate-x-1 duration-200"
              style={{ backgroundColor: '#321323', borderColor: '#54203C' }}
            >
              <div
                className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
                style={{ backgroundColor: 'rgba(89, 11, 53, 0.5)', color: '#AD965B' }}
              >
                <ShieldAlert className="w-4 h-4" />
              </div>
              <div className="text-xs sm:text-sm font-bold" style={{ color: '#F4E8C1' }}>
                متابعة الغيابات المتكررة وإصدار التقارير والإعذارات الإدارية
              </div>
            </div>
          </div>
        </div>

        {/* Footer info */}
        <div className="relative z-10 pt-8 border-t border-[#54203C] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs" style={{ color: '#BCAF91' }}>
          <div>كل البيانات تبقى على جهاز المؤسسة وفي قاعدة البيانات المؤمنة.</div>
          <div className="font-semibold" style={{ color: '#AD965B' }}>صممت المنصة تحت إشراف السيدة : ليلى بن تروش</div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* LEFT SIDE (Desktop) / TOP (Mobile) — Login Form (خلفية بيضاء مع عنابي وذهبي) */}
      {/* ========================================================================= */}
      <div className="w-full lg:w-[480px] xl:w-[520px] bg-white p-6 sm:p-10 lg:p-12 flex flex-col justify-between order-1 lg:order-2 shadow-2xl z-20">
        {/* Top Mobile Header */}
        <div className="lg:hidden mb-6 pb-6 border-b border-slate-100 flex items-center gap-3">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center shadow-xs"
            style={{ backgroundColor: '#590B35', color: '#F4E8C1' }}
          >
            <School className="w-5 h-5" />
          </div>
          <div>
            <h1 className="font-black text-sm text-[#590B35]">متوسطة سعدون عاشور</h1>
            <span className="text-[10px] text-slate-500">منصة تسيير الحضور والغياب</span>
          </div>
        </div>

        {/* Form Header */}
        <div className="space-y-2 mb-8">
          <div
            className="w-12 h-12 rounded-2xl border flex items-center justify-center mb-4"
            style={{ backgroundColor: '#fdf2f8', color: '#590B35', borderColor: '#fbcfe8' }}
          >
            <Lock className="w-6 h-6" style={{ color: '#590B35' }} />
          </div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight" style={{ color: '#590B35' }}>
            تسجيل الدخول
          </h2>
          <p className="text-xs text-slate-500 leading-relaxed">
            أدخل بيانات حسابك للوصول إلى المساحة المخصصة لك (مدير المؤسسة أو أستاذ المادة).
          </p>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="mb-6 p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-900 text-xs font-bold flex items-center gap-2.5 animate-fade-in">
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Main Login Form */}
        <form onSubmit={handleLoginSubmit} className="space-y-4" noValidate>
          <div>
            <label className="block text-xs font-bold mb-1.5" style={{ color: '#590B35' }} htmlFor="username">
              اسم المستخدم
            </label>
            <div className="relative">
              <User className="w-4 h-4 absolute right-3.5 top-3 text-slate-400 pointer-events-none" />
              <input
                id="username"
                type="text"
                required
                autoComplete="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="أدخل اسم المستخدم الخاص بك"
                className="w-full text-xs sm:text-sm font-bold bg-slate-50 border border-slate-300 rounded-xl pr-10 pl-4 py-3 text-slate-900 focus:bg-white focus:border-[#590B35] focus:ring-2 focus:ring-[#590B35]/20 outline-none transition-all font-mono"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-bold" style={{ color: '#590B35' }} htmlFor="password">
                كلمة المرور
              </label>
              <button
                type="button"
                onClick={() => setShowForgotPasswordModal(true)}
                className="text-[11px] font-bold underline cursor-pointer"
                style={{ color: '#590B35' }}
              >
                نسيت كلمة المرور؟
              </button>
            </div>
            <div className="relative">
              <KeyRound className="w-4 h-4 absolute right-3.5 top-3 text-slate-400 pointer-events-none" />
              <input
                id="password"
                type={showPassword ? 'text' : 'password'}
                required
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full text-xs sm:text-sm font-bold bg-slate-50 border border-slate-300 rounded-xl pr-10 pl-10 py-3 text-slate-900 focus:bg-white focus:border-[#590B35] focus:ring-2 focus:ring-[#590B35]/20 outline-none transition-all font-mono"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute left-3 top-3 text-slate-400 hover:text-slate-600 p-0.5 cursor-pointer"
                title={showPassword ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer shadow-md flex items-center justify-center gap-2 mt-4 disabled:opacity-50"
            style={{
              backgroundColor: '#590B35',
              color: '#F4E8C1',
            }}
          >
            {isLoading ? (
              <span className="flex items-center gap-2">
                <span className="w-4 h-4 border-2 border-[#F4E8C1] border-t-transparent rounded-full animate-spin"></span>
                <span>جاري التحقق والدخول...</span>
              </span>
            ) : (
              <>
                <LogIn className="w-4 h-4" style={{ color: '#AD965B' }} />
                <span>دخول إلى المنصة</span>
              </>
            )}
          </button>
        </form>

        {/* Footer info */}
        <div className="mt-10 pt-6 border-t border-slate-100 text-center text-xs text-slate-400">
          متوسطة سعدون عاشور — البوني - عنابة
        </div>
      </div>

      {/* Forgot Password Modal */}
      {showForgotPasswordModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/65 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 text-right space-y-4 animate-scale-up">
            <div className="flex items-center gap-3">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{ backgroundColor: '#fdf2f8', color: '#590B35' }}
              >
                <HelpCircle className="w-5 h-5" style={{ color: '#590B35' }} />
              </div>
              <h3 className="font-black text-base text-slate-900">استعادة كلمة المرور</h3>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              إذا نسيت كلمة المرور الخاصة بحسابك، يرجى التقدم إلى الإدارة العامة للمؤسسة (مستشارة التربية أو أمانة المديرية) ليتم إعادة ضبط كلمة المرور بشكل آمن ورسمي.
            </p>

            <div className="pt-3 border-t border-slate-100 flex justify-end">
              <button
                type="button"
                onClick={() => setShowForgotPasswordModal(false)}
                className="px-5 py-2.5 rounded-xl text-xs font-bold cursor-pointer transition-colors"
                style={{ backgroundColor: '#590B35', color: '#F4E8C1' }}
              >
                حسناً، فهمت
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
