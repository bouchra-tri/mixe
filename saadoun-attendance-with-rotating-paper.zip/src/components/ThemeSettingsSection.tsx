import React, { useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { THEME_PRESETS, DEFAULT_THEME_COLOR } from '../utils/themeManager';
import { ThemeColorId, ThemeMode } from '../types/theme';
import {
  Palette,
  Sun,
  Moon,
  Laptop,
  Check,
  RotateCcw,
  Sparkles,
  Sliders,
  CheckCircle2,
  Eye,
} from 'lucide-react';

interface ThemeSettingsSectionProps {
  onSettingsThemeChange?: (color: ThemeColorId, customHex?: string, mode?: ThemeMode) => void;
  compact?: boolean;
}

export const ThemeSettingsSection: React.FC<ThemeSettingsSectionProps> = ({
  onSettingsThemeChange,
  compact = false,
}) => {
  const { config, palette, isDark, setColor, setMode, resetDefault } = useTheme();
  const [customInputHex, setCustomInputHex] = useState(
    config.customHex || (config.color === 'custom' ? palette.primary : '#0284c7')
  );
  const [copiedNotification, setCopiedNotification] = useState(false);

  const handleSelectPreset = (id: ThemeColorId) => {
    setColor(id);
    onSettingsThemeChange?.(id, config.customHex, config.mode);
  };

  const handleApplyCustomHex = (hex: string) => {
    const formatted = hex.startsWith('#') ? hex : `#${hex}`;
    setCustomInputHex(formatted);
    if (/^#[0-9A-Fa-f]{6}$/.test(formatted)) {
      setColor('custom', formatted);
      onSettingsThemeChange?.('custom', formatted, config.mode);
    }
  };

  const handleSelectMode = (newMode: ThemeMode) => {
    setMode(newMode);
    onSettingsThemeChange?.(config.color, config.customHex, newMode);
  };

  const handleReset = () => {
    resetDefault();
    setCustomInputHex('#059669');
    onSettingsThemeChange?.(DEFAULT_THEME_COLOR, undefined, 'light');
    setCopiedNotification(true);
    setTimeout(() => setCopiedNotification(false), 2500);
  };

  const presetList = Object.values(THEME_PRESETS);

  return (
    <div
      className={`rounded-2xl border transition-all ${
        compact
          ? 'p-3 bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
          : 'p-6 bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-xs space-y-6'
      }`}
    >
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-2.5">
          <div
            className="w-8 h-8 rounded-xl flex items-center justify-center text-white shadow-2xs transition-colors"
            style={{ backgroundColor: palette.primary }}
          >
            <Palette className="w-4 h-4 text-white" />
          </div>
          <div>
            <h4 className="font-bold text-slate-900 dark:text-slate-100 text-xs sm:text-sm">
              المظهر والألوان وتخصيص هوية المنصة
            </h4>
            {!compact && (
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                اختر لون وهوية متوسطة سعدون عاشور الموحدة ليتم تطبيقها فوراً على كافة صفحات ومستخدمي المنصة
              </p>
            )}
          </div>
        </div>

        <button
          type="button"
          onClick={handleReset}
          className="flex items-center gap-1.5 px-3 py-1.5 text-[11px] font-semibold text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
          title="استعادة المظهر الافتراضي للمؤسسة"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>استعادة المظهر الافتراضي</span>
        </button>
      </div>

      {copiedNotification && (
        <div className="p-2.5 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 rounded-xl text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>تمت استعادة الثيم الافتراضي للون الزمردي بنجاح</span>
        </div>
      )}

      {/* 1. Theme Color Palette Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
            لوحات الألوان المعتمدة (8 ألوان متكاملة + تخصيص حر):
          </span>
          <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
            اللون الحالي:{' '}
            <strong className="text-slate-900 dark:text-slate-100">
              {config.color === 'custom' ? `مخصص (${palette.primary})` : palette.nameAr}
            </strong>
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {presetList.map((preset) => {
            const isSelected = config.color === preset.id;
            return (
              <button
                key={preset.id}
                type="button"
                onClick={() => handleSelectPreset(preset.id)}
                className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-right transition-all cursor-pointer group ${
                  isSelected
                    ? 'border-slate-900 dark:border-white ring-2 bg-slate-50 dark:bg-slate-800/80 shadow-xs'
                    : 'border-slate-200 dark:border-slate-700/80 hover:border-slate-300 dark:hover:border-slate-600 bg-white dark:bg-slate-800/40 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                }`}
                style={isSelected ? { outlineColor: preset.primary } : undefined}
              >
                {/* Color Swatch Circle with Check */}
                <span
                  className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 shadow-2xs transition-transform group-hover:scale-105"
                  style={{
                    backgroundColor: preset.primary,
                    color: preset.foreground,
                  }}
                >
                  {isSelected && <Check className="w-4 h-4 stroke-[3]" />}
                </span>

                <div className="min-w-0 flex-1">
                  <span className="block text-xs font-bold text-slate-900 dark:text-slate-100 truncate">
                    {preset.nameAr}
                  </span>
                  <span className="block text-[10px] text-slate-400 font-mono font-medium">
                    {preset.primary}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Custom Color Picker Option */}
        <div
          className={`p-3 rounded-xl border transition-all ${
            config.color === 'custom'
              ? 'border-slate-900 dark:border-white ring-2 bg-slate-50 dark:bg-slate-800/80 shadow-xs'
              : 'border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/40'
          }`}
        >
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <label
                className="relative w-8 h-8 rounded-lg shadow-2xs border border-black/10 overflow-hidden cursor-pointer shrink-0 group flex items-center justify-center"
                style={{ backgroundColor: palette.primary }}
                title="انقر لفتح منتقي الألوان"
              >
                <input
                  type="color"
                  value={palette.primary}
                  onChange={(e) => handleApplyCustomHex(e.target.value)}
                  className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                />
                {config.color === 'custom' && (
                  <Check
                    className="w-4 h-4 stroke-[3]"
                    style={{ color: palette.foreground }}
                  />
                )}
              </label>

              <div>
                <span className="text-xs font-bold text-slate-900 dark:text-slate-100 block">
                  لون مخصص (Custom HEX)
                </span>
                <span className="text-[10px] text-slate-500 dark:text-slate-400">
                  اختر أي تدرج لوني عبر منتقي الألوان أو اكتب كود الـ HEX مباشرة
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <div className="relative flex-1 sm:w-36">
                <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-mono text-slate-400">
                  #
                </span>
                <input
                  type="text"
                  maxLength={7}
                  value={customInputHex.replace('#', '')}
                  onChange={(e) => handleApplyCustomHex(`#${e.target.value}`)}
                  placeholder="0284c7"
                  className="w-full pl-6 pr-2.5 py-1.5 text-xs font-mono font-bold uppercase rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100"
                />
              </div>

              <button
                type="button"
                onClick={() => handleApplyCustomHex(customInputHex)}
                className="px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer whitespace-nowrap shadow-2xs"
                style={{
                  backgroundColor: palette.primary,
                  color: palette.foreground,
                }}
              >
                تطبيق
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Light / Dark Mode Controls */}
      <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
        <label className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
          نمط الإضاءة والعرض (مستقل عن لون الثيم):
        </label>

        <div className="grid grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() => handleSelectMode('light')}
            className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
              config.mode === 'light'
                ? 'border-slate-900 dark:border-white bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
                : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/40 text-slate-600 dark:text-slate-300 hover:bg-slate-50'
            }`}
          >
            <Sun className="w-4 h-4 text-amber-500" />
            <span>وضع النهار (فاتح)</span>
          </button>

          <button
            type="button"
            onClick={() => handleSelectMode('dark')}
            className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
              config.mode === 'dark'
                ? 'border-slate-900 dark:border-white bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
                : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/40 text-slate-600 dark:text-slate-300 hover:bg-slate-50'
            }`}
          >
            <Moon className="w-4 h-4 text-indigo-400" />
            <span>وضع الليل (داكن)</span>
          </button>

          <button
            type="button"
            onClick={() => handleSelectMode('system')}
            className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
              config.mode === 'system'
                ? 'border-slate-900 dark:border-white bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
                : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/40 text-slate-600 dark:text-slate-300 hover:bg-slate-50'
            }`}
          >
            <Laptop className="w-4 h-4 text-slate-500" />
            <span>تلقائي (حسب النظام)</span>
          </button>
        </div>
      </div>

      {/* 3. Live Preview Card (Visual Assurance) */}
      {!compact && (
        <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-slate-300">
            <Eye className="w-3.5 h-3.5" />
            <span>معاينة حية للمظهر والتباين البصري:</span>
          </div>

          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/40 flex flex-wrap items-center gap-3">
            {/* Primary Action Button */}
            <button
              type="button"
              className="px-4 py-2 text-xs font-bold rounded-xl shadow-xs transition-all pointer-events-none flex items-center gap-1.5"
              style={{
                backgroundColor: palette.primary,
                color: palette.foreground,
              }}
            >
              <Check className="w-3.5 h-3.5" />
              <span>زر أساسي (Primary)</span>
            </button>

            {/* Secondary / Soft Button */}
            <button
              type="button"
              className="px-3.5 py-2 text-xs font-bold rounded-xl transition-all pointer-events-none flex items-center gap-1.5"
              style={{
                backgroundColor: palette.light,
                color: palette.primary,
                border: `1px solid ${palette.border}`,
              }}
            >
              <span>زر ثانوي (Secondary)</span>
            </button>

            {/* Badge */}
            <span
              className="px-2.5 py-1 text-xs font-bold rounded-lg"
              style={{
                backgroundColor: palette.light,
                color: palette.primary,
                border: `1px solid ${palette.border}`,
              }}
            >
              شارة نشطة
            </span>

            {/* Simulated Active Navigation Indicator */}
            <div
              className="px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2"
              style={{
                backgroundColor: palette.primary,
                color: palette.foreground,
              }}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>عنصر القائمة النشط</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
