import {
  Student,
  AttendanceRecord,
  SchoolSettings,
  GradeLevel,
  AbsenceNotice,
  AppUser,
  TeacherAttendanceSession,
  TeacherStudentStatusRecord,
  TimetableSession,
  TimetableMetadata,
} from '../types';

export interface SyncResponse {
  version: number;
  lastUpdated: string;
  students: Student[];
  records: AttendanceRecord[];
  settings: SchoolSettings;
  notices?: AbsenceNotice[];
  sessions?: TeacherAttendanceSession[];
  users?: AppUser[];
  timetableSessions?: TimetableSession[];
  activeTimetableMeta?: TimetableMetadata | null;
  timetableHistory?: TimetableMetadata[];
}

export interface LiveEventPayload {
  type: string;
  action?: string;
  version: number;
  lastUpdated: string;
  detail?: any;
}

// -------------------------------------------------------------
// Auth Token Handling
// -------------------------------------------------------------
const AUTH_TOKEN_KEY = 'saadoun_auth_token_v1';
const CURRENT_USER_KEY = 'saadoun_current_user_v1';

export function getStoredAuthToken(): string | null {
  try {
    return localStorage.getItem(AUTH_TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setStoredAuthToken(token: string): void {
  try {
    localStorage.setItem(AUTH_TOKEN_KEY, token);
  } catch (e) {
    console.warn('Failed to store auth token', e);
  }
}

export function getStoredCurrentUser(): AppUser | null {
  try {
    const raw = localStorage.getItem(CURRENT_USER_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function setStoredCurrentUser(user: AppUser | null): void {
  try {
    if (user) {
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(CURRENT_USER_KEY);
    }
  } catch (e) {
    console.warn('Failed to store current user', e);
  }
}

export function clearStoredAuth(): void {
  try {
    localStorage.removeItem(AUTH_TOKEN_KEY);
    localStorage.removeItem(CURRENT_USER_KEY);
  } catch (e) {
    console.warn('Failed to clear stored auth', e);
  }
}

function getAuthHeaders(): HeadersInit {
  const token = getStoredAuthToken();
  const currentUser = getStoredCurrentUser();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  if (currentUser?.id) {
    headers['x-user-id'] = currentUser.id;
  }
  return headers;
}

// -------------------------------------------------------------
// Authentication Endpoints
// -------------------------------------------------------------
export async function apiLogin(
  username: string,
  password: string
): Promise<{ success: boolean; user: AppUser; token: string; message: string }> {
  const res = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password }),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'فشل تسجيل الدخول');
  }
  setStoredAuthToken(data.token);
  setStoredCurrentUser(data.user);
  return data;
}

export async function apiGetMe(): Promise<{ authenticated: boolean; user: AppUser | null }> {
  const res = await fetch('/api/auth/me', {
    headers: getAuthHeaders(),
  });
  if (!res.ok) return { authenticated: false, user: null };
  return res.json();
}

export async function apiGetAuthStatus(): Promise<{
  adminExists: boolean;
  isCustomAdminConfigured: boolean;
  adminUsername: string;
  adminName: string;
  authenticated: boolean;
  currentUser: AppUser | null;
}> {
  try {
    const res = await fetch('/api/auth/status', {
      headers: getAuthHeaders(),
    });
    if (!res.ok) throw new Error('Failed to fetch auth status');
    return await res.json();
  } catch {
    return {
      adminExists: true,
      isCustomAdminConfigured: false,
      adminUsername: 'admin',
      adminName: 'مدير المؤسسة',
      authenticated: false,
      currentUser: null,
    };
  }
}

export async function apiSetupAdmin(params: {
  username: string;
  password: string;
  name: string;
  phone?: string;
  email?: string;
  currentPassword?: string;
}): Promise<{ success: boolean; user: AppUser; token: string; message: string }> {
  const res = await fetch('/api/auth/setup-admin', {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify(params),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'فشل إعداد حساب المدير');
  }
  if (data.token) {
    setStoredAuthToken(data.token);
  }
  if (data.user) {
    setStoredCurrentUser(data.user);
  }
  return data;
}

export async function apiLogout(): Promise<void> {
  try {
    await fetch('/api/auth/logout', {
      method: 'POST',
      headers: getAuthHeaders(),
    });
  } catch (e) {
    console.warn('Logout request failed:', e);
  } finally {
    clearStoredAuth();
  }
}

// -------------------------------------------------------------
// Users & Teachers Directory & Management
// -------------------------------------------------------------
export async function apiGetUsers(): Promise<AppUser[]> {
  const res = await fetch('/api/users', {
    headers: getAuthHeaders(),
  });
  if (!res.ok) throw new Error('فشل جلب قائمة المستخدمين');
  const data = await res.json();
  return data.users || [];
}

export async function apiCreateUser(user: Partial<AppUser>): Promise<AppUser> {
  const res = await fetch('/api/users', {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify(user),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'فشل إنشاء حساب الأستاذ');
  return data.user;
}

export async function apiUpdateUser(user: AppUser): Promise<AppUser> {
  const res = await fetch(`/api/users/${encodeURIComponent(user.id)}`, {
    method: 'PUT',
    headers: getAuthHeaders(),
    body: JSON.stringify(user),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'فشل تحديث بيانات المستخدم');
  return data.user;
}

export async function apiDeleteUser(userId: string): Promise<void> {
  const res = await fetch(`/api/users/${encodeURIComponent(userId)}`, {
    method: 'DELETE',
    headers: getAuthHeaders(),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'فشل حذف المستخدم');
}

// -------------------------------------------------------------
// Teacher Attendance Sessions Endpoints
// -------------------------------------------------------------
export async function apiGetTeacherSessions(filters?: {
  date?: string;
  classroom?: string;
  teacherId?: string;
  status?: string;
}): Promise<TeacherAttendanceSession[]> {
  const query = new URLSearchParams();
  if (filters?.date) query.set('date', filters.date);
  if (filters?.classroom) query.set('classroom', filters.classroom);
  if (filters?.teacherId) query.set('teacherId', filters.teacherId);
  if (filters?.status) query.set('status', filters.status);

  const url = `/api/attendance/sessions${query.toString() ? `?${query.toString()}` : ''}`;
  const res = await fetch(url, {
    headers: getAuthHeaders(),
  });
  if (!res.ok) throw new Error('فشل جلب سجلات حضور الأساتذة');
  const data = await res.json();
  return data.sessions || [];
}

export async function apiGetTeacherSession(id: string): Promise<TeacherAttendanceSession> {
  const res = await fetch(`/api/attendance/sessions/${encodeURIComponent(id)}`, {
    headers: getAuthHeaders(),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'فشل جلب جلسة الحضور');
  return data.session;
}

export async function apiSaveTeacherSession(
  session: TeacherAttendanceSession,
  expectedUpdatedAt?: string
): Promise<{ success: boolean; session: TeacherAttendanceSession; message: string }> {
  const res = await fetch('/api/attendance/sessions', {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify({ ...session, expectedUpdatedAt }),
  });
  const data = await res.json();
  if (!res.ok) {
    const errorMsg = data.error || 'فشل حفظ جلسة تسجيل الحضور';
    const err = new Error(errorMsg);
    (err as any).status = res.status;
    (err as any).data = data;
    throw err;
  }
  return data;
}

export async function apiSessionAction(
  sessionId: string,
  action: 'approve' | 'lock' | 'unlock'
): Promise<TeacherAttendanceSession> {
  const res = await fetch(`/api/attendance/sessions/${encodeURIComponent(sessionId)}/action`, {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify({ action }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'فشل تنفيذ الإجراء على السجل');
  return data.session;
}

export async function apiCorrectStudentSession(
  sessionId: string,
  studentId: string,
  newStatus: string,
  justification: string
): Promise<TeacherAttendanceSession> {
  const res = await fetch(`/api/attendance/sessions/${encodeURIComponent(sessionId)}/correct`, {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify({ studentId, newStatus, justification }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'فشل تصحيح حالة التلميذ');
  return data.session;
}

export async function apiGetAttendanceMonitoring(date?: string): Promise<{
  targetDate: string;
  sessions: TeacherAttendanceSession[];
  unrecordedSlots: Array<{ classroom: string; periodId: string }>;
  metrics: {
    totalRecordedSessions: number;
    totalPresent: number;
    totalAbsent: number;
    totalLate: number;
  };
}> {
  const url = `/api/attendance/monitoring${date ? `?date=${encodeURIComponent(date)}` : ''}`;
  const res = await fetch(url, {
    headers: getAuthHeaders(),
  });
  if (!res.ok) throw new Error('فشل جلب بيانات متابعة الحضور');
  return res.json();
}

// -------------------------------------------------------------
// Database Sync & Version Check
// -------------------------------------------------------------
export async function fetchDatabaseSync(): Promise<SyncResponse> {
  const res = await fetch('/api/sync', {
    headers: getAuthHeaders(),
  });
  if (!res.ok) {
    throw new Error(`Sync failed with HTTP ${res.status}`);
  }
  return res.json();
}

export async function fetchDatabaseVersion(): Promise<{
  version: number;
  lastUpdated: string;
  studentsCount: number;
  recordsCount: number;
  sessionsCount?: number;
  connectedClients: number;
}> {
  const res = await fetch('/api/version');
  if (!res.ok) {
    throw new Error(`Version check failed: ${res.status}`);
  }
  return res.json();
}

// -------------------------------------------------------------
// Students Management API
// -------------------------------------------------------------
export async function apiSaveStudent(student: Student): Promise<void> {
  const res = await fetch('/api/students', {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify(student),
  });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || 'فشل حفظ بيانات التلميذ على الخادم');
  }
}

export async function apiUpdateStudent(student: Student): Promise<void> {
  const res = await fetch(`/api/students/${encodeURIComponent(student.id)}`, {
    method: 'PUT',
    headers: getAuthHeaders(),
    body: JSON.stringify(student),
  });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || 'فشل تحديث بيانات التلميذ على الخادم');
  }
}

export async function apiDeleteStudent(studentId: string): Promise<void> {
  const res = await fetch(`/api/students/${encodeURIComponent(studentId)}`, {
    method: 'DELETE',
    headers: getAuthHeaders(),
  });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || 'فشل حذف التلميذ من الخادم');
  }
}

export async function apiBulkDeleteStudents(ids: string[]): Promise<void> {
  const res = await fetch('/api/students/bulk-delete', {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify({ ids }),
  });
  if (!res.ok) throw new Error('Failed to bulk delete students on server');
}

export async function apiClearAllStudents(): Promise<void> {
  const res = await fetch('/api/students/clear-all', {
    method: 'POST',
    headers: getAuthHeaders(),
  });
  if (!res.ok) throw new Error('Failed to clear students on server');
}

export async function apiBulkImportStudents(
  students: Student[],
  mode: 'upsert' | 'append' | 'replace'
): Promise<void> {
  const res = await fetch('/api/students/bulk-import', {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify({ students, mode }),
  });
  if (!res.ok) throw new Error('Failed to import students to server');
}

export async function apiBulkTransferStudents(
  studentIds: string[],
  newClassroom: string,
  newGrade?: GradeLevel
): Promise<void> {
  const res = await fetch('/api/students/bulk-transfer', {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify({ studentIds, newClassroom, newGrade }),
  });
  if (!res.ok) throw new Error('Failed to transfer classrooms on server');
}

// -------------------------------------------------------------
// General Attendance Records API
// -------------------------------------------------------------
export async function apiSaveAttendanceRecord(record: AttendanceRecord): Promise<void> {
  const res = await fetch('/api/records', {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify(record),
  });
  if (!res.ok) throw new Error('Failed to save attendance record to server');
}

export async function apiResetRecords(scope: 'today' | 'all'): Promise<void> {
  const res = await fetch('/api/records/reset', {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify({ scope }),
  });
  if (!res.ok) throw new Error('Failed to reset attendance records on server');
}

// -------------------------------------------------------------
// Settings API
// -------------------------------------------------------------
export async function apiSaveSettings(settings: SchoolSettings): Promise<void> {
  const res = await fetch('/api/settings', {
    method: 'PUT',
    headers: getAuthHeaders(),
    body: JSON.stringify(settings),
  });
  if (!res.ok) throw new Error('Failed to save settings on server');
}

// -------------------------------------------------------------
// Database Backup & Reset
// -------------------------------------------------------------
export async function apiResetDefaults(): Promise<void> {
  const res = await fetch('/api/database/reset-defaults', {
    method: 'POST',
    headers: getAuthHeaders(),
  });
  if (!res.ok) throw new Error('Failed to reset database on server');
}

export async function apiImportFullBackup(backupData: any): Promise<void> {
  const res = await fetch('/api/database/import-full', {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify(backupData),
  });
  if (!res.ok) throw new Error('Failed to import full backup on server');
}

export async function apiSaveDatabaseNow(): Promise<{
  success: boolean;
  version: number;
  lastUpdated: string;
  counts: { students: number; records: number; notices: number; sessions?: number };
  message: string;
}> {
  const res = await fetch('/api/database/save-now', {
    method: 'POST',
    headers: getAuthHeaders(),
  });
  if (!res.ok) throw new Error('Failed to trigger database save on server');
  return res.json();
}

// -------------------------------------------------------------
// Absence Notices
// -------------------------------------------------------------
export async function apiSaveNotice(notice: AbsenceNotice): Promise<void> {
  const res = await fetch('/api/notices', {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify(notice),
  });
  if (!res.ok) throw new Error('Failed to save absence notice on server');
}

export async function apiBulkSaveNotices(notices: AbsenceNotice[]): Promise<void> {
  const res = await fetch('/api/notices/bulk-save', {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify({ notices }),
  });
  if (!res.ok) throw new Error('Failed to bulk save absence notices on server');
}

export async function apiDeleteNotice(noticeId: string): Promise<void> {
  const res = await fetch(`/api/notices/${encodeURIComponent(noticeId)}`, {
    method: 'DELETE',
    headers: getAuthHeaders(),
  });
  if (!res.ok) throw new Error('Failed to delete absence notice on server');
}

// -------------------------------------------------------------
// Live SSE Sync
// -------------------------------------------------------------
export function initLiveSync(
  onUpdate: (data: LiveEventPayload) => void,
  onStatusChange?: (status: 'connected' | 'reconnecting' | 'offline') => void
): () => void {
  let eventSource: EventSource | null = null;
  let isClosed = false;
  let reconnectTimeout: any = null;

  function connect() {
    if (isClosed) return;

    try {
      eventSource = new EventSource('/api/events');

      eventSource.onopen = () => {
        onStatusChange?.('connected');
      };

      eventSource.onmessage = (event) => {
        if (!event.data) return;
        try {
          const parsed: LiveEventPayload = JSON.parse(event.data);
          onUpdate(parsed);
        } catch (e) {
          console.warn('Failed to parse SSE payload', e);
        }
      };

      eventSource.onerror = () => {
        onStatusChange?.('reconnecting');
        if (eventSource) {
          eventSource.close();
          eventSource = null;
        }
        if (!isClosed) {
          reconnectTimeout = setTimeout(connect, 3000);
        }
      };
    } catch {
      onStatusChange?.('offline');
      if (!isClosed) {
        reconnectTimeout = setTimeout(connect, 5000);
      }
    }
  }

  connect();

  return () => {
    isClosed = true;
    if (reconnectTimeout) clearTimeout(reconnectTimeout);
    if (eventSource) eventSource.close();
  };
}

// -------------------------------------------------------------
// Timetable & Weekly Schedule Endpoints
// -------------------------------------------------------------
export async function apiGetTimetable(): Promise<{
  sessions: TimetableSession[];
  activeMeta: TimetableMetadata | null;
  history: TimetableMetadata[];
}> {
  const res = await fetch('/api/timetable', {
    headers: getAuthHeaders(),
  });
  if (!res.ok) throw new Error('فشل جلب جدول التوقيت من الخادم');
  return res.json();
}

export async function apiImportTimetable(params: {
  sessions: TimetableSession[];
  meta?: Partial<TimetableMetadata>;
  updateSchoolSettings?: boolean;
  updateSettings?: any;
}): Promise<{
  success: boolean;
  message: string;
  meta: TimetableMetadata;
  version: number;
  history?: TimetableMetadata[];
}> {
  const res = await fetch('/api/timetable/import', {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify(params),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'فشل حفظ واستيراد التوقيت');
  return data;
}

export async function apiSwitchTimetable(timetableId: string): Promise<{
  success: boolean;
  message: string;
  meta: TimetableMetadata;
  activeTimetableMeta?: TimetableMetadata;
  timetableSessions?: TimetableSession[];
  sessionsCount: number;
  sessions?: TimetableSession[];
}> {
  const res = await fetch('/api/timetable/switch', {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify({ timetableId }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'فشل التبديل إلى التوقيت المختار');
  return {
    ...data,
    activeTimetableMeta: data.meta,
    timetableSessions: data.sessions,
  };
}

export async function apiSaveTimetableSession(session: TimetableSession): Promise<void> {
  const res = await fetch('/api/timetable/session', {
    method: 'PUT',
    headers: getAuthHeaders(),
    body: JSON.stringify(session),
  });
  if (!res.ok) throw new Error('فشل حفظ الحصة في الخادم');
}

export async function apiDeleteTimetableSession(sessionId: string): Promise<void> {
  const res = await fetch(`/api/timetable/session/${encodeURIComponent(sessionId)}`, {
    method: 'DELETE',
    headers: getAuthHeaders(),
  });
  if (!res.ok) throw new Error('فشل حذف الحصة من الخادم');
}

