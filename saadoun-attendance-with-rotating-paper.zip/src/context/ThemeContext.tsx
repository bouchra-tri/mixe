import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { ThemeConfig, ThemeColorId, ThemeMode, ThemePalette } from '../types/theme';
import {
  getStoredThemeConfig,
  saveStoredThemeConfig,
  applyThemeToDOM,
  getPalette,
  DEFAULT_THEME_COLOR,
  DEFAULT_THEME_MODE,
} from '../utils/themeManager';

interface ThemeContextType {
  config: ThemeConfig;
  palette: ThemePalette;
  isDark: boolean;
  setColor: (color: ThemeColorId, customHex?: string) => void;
  setMode: (mode: ThemeMode) => void;
  resetDefault: () => void;
  updateFromExternal: (color?: ThemeColorId, customHex?: string, mode?: ThemeMode) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [config, setConfig] = useState<ThemeConfig>(() => getStoredThemeConfig());

  // Listen to system dark mode changes if mode is 'system'
  useEffect(() => {
    applyThemeToDOM(config);
    saveStoredThemeConfig(config);

    if (config.mode === 'system') {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      const handleChange = () => {
        applyThemeToDOM(config);
      };
      mediaQuery.addEventListener('change', handleChange);
      return () => mediaQuery.removeEventListener('change', handleChange);
    }
  }, [config]);

  // Listen to external theme changes (like another tab or live broadcast)
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'saadoun_theme_config_v2' && e.newValue) {
        try {
          const newConfig = JSON.parse(e.newValue);
          setConfig(newConfig);
          applyThemeToDOM(newConfig);
        } catch {}
      }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  const setColor = useCallback((color: ThemeColorId, customHex?: string) => {
    setConfig((prev) => {
      const next: ThemeConfig = {
        ...prev,
        color,
        customHex: color === 'custom' ? (customHex || prev.customHex || '#059669') : prev.customHex,
      };
      applyThemeToDOM(next);
      saveStoredThemeConfig(next);
      return next;
    });
  }, []);

  const setMode = useCallback((mode: ThemeMode) => {
    setConfig((prev) => {
      const next: ThemeConfig = { ...prev, mode };
      applyThemeToDOM(next);
      saveStoredThemeConfig(next);
      return next;
    });
  }, []);

  const resetDefault = useCallback(() => {
    const next: ThemeConfig = {
      color: DEFAULT_THEME_COLOR,
      mode: DEFAULT_THEME_MODE,
    };
    setConfig(next);
    applyThemeToDOM(next);
    saveStoredThemeConfig(next);
  }, []);

  const updateFromExternal = useCallback(
    (color?: ThemeColorId, customHex?: string, mode?: ThemeMode) => {
      if (!color && !mode) return;
      setConfig((prev) => {
        const next: ThemeConfig = {
          color: color || prev.color,
          customHex: customHex !== undefined ? customHex : prev.customHex,
          mode: mode || prev.mode,
        };
        applyThemeToDOM(next);
        saveStoredThemeConfig(next);
        return next;
      });
    },
    []
  );

  const palette = getPalette(config.color, config.customHex);
  const isDark =
    config.mode === 'dark' ||
    (config.mode === 'system' &&
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-color-scheme: dark)').matches);

  return (
    <ThemeContext.Provider
      value={{
        config,
        palette,
        isDark,
        setColor,
        setMode,
        resetDefault,
        updateFromExternal,
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
};

export function useTheme(): ThemeContextType {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
}
