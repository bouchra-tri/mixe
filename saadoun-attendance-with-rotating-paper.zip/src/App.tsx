import React, { useState, useEffect } from 'react';
import {
  Student,
  AttendanceRecord,
  SchoolSettings,
  GradeLevel,
  PeriodId,
  AbsenceNotice,
  AbsenceNoticeStage,
  TimetableSession,
} from './types';
import { INITIAL_STUDENTS, DEFAULT_SETTINGS, INITIAL_NOTICES } from './data/initialStudents';
import { INITIAL_TIMETABLE_SESSIONS } from './data/timetableData';
import { matchStudentByBarcode } from './utils/barcodeNormalizer';
import { getAutoDetectedPeriod, getPeriodSessionType } from './utils/periodHelper';
import { Sidebar, ViewType } from './components/Sidebar';
import { TopBar } from './components/TopBar';
import { ScannerGate } from './components/ScannerGate';
import { DailyAttendance } from './components/DailyAttendance';
import { StudentManagement } from './components/StudentManagement';
import { RotatingPaperPanel } from './components/RotatingPaperPanel';
import { TimetableManager } from './components/TimetableManager';
import { MonthlyReports } from './components/MonthlyReports';
import { AbsenceNoticesManager } from './components/AbsenceNoticesManager';
import { AnalyticsReports } from './components/AnalyticsReports';
import { SettingsModal } from './components/SettingsModal';
import { LateTicketModal } from './components/LateTicketModal';
import { StudentCardModal } from './components/StudentCardModal';
import { DataPersistenceModal } from './components/DataPersistenceModal';
import { LoginPage } from './components/LoginPage';
import { TeacherPortal } from './components/TeacherPortal';
import { TeacherSessionsManager } from './components/TeacherSessionsManager';
import { LoginModal } from './components/LoginModal';
import { AppUser } from './types';
import { School, ShieldCheck, RefreshCw, CheckCircle2 } from 'lucide-react';
import {
  fetchDatabaseSync,
  fetchDatabaseVersion,
  apiSaveStudent,
  apiUpdateStudent,
  apiDeleteStudent,
  apiBulkDeleteStudents,
  apiClearAllStudents,
  apiBulkImportStudents,
  apiBulkTransferStudents,
  apiSaveAttendanceRecord,
  apiResetRecords,
  apiSaveSettings,
  apiResetDefaults,
  apiImportFullBackup,
  apiSaveNotice,
  apiBulkSaveNotices,
  apiDeleteNotice,
  initLiveSync,
  getStoredCurrentUser,
  setStoredCurrentUser,
  clearStoredAuth,
  apiLogout,
} from './services/api';
import { useTheme } from './context/ThemeContext';

const STORAGE_KEYS = {
  STUDENTS: 'saadoun_achour_students_v1',
  RECORDS: 'saadoun_achour_records_v1',
  SETTINGS: 'saadoun_achour_settings_v1',
  NOTICES: 'saadoun_achour_notices_v1',
};

// Generate realistic initial check-ins for demo experience
function getInitialRecords(): AttendanceRecord[] {
  const dates = [
    '2026-10-18',
    '2026-10-19',
    '2026-10-20',
    '2026-10-21',
    '2026-10-22',
    '2026-10-25',
    '2026-10-26',
  ];

  const generated: AttendanceRecord[] = [];

  dates.forEach((dateStr, dayIdx) => {
    INITIAL_STUDENTS.forEach((student, sIdx) => {
      // 1. Amin Bouaziz (SA-2026-103) is absent starting Oct 21 (4 days of absence -> Stage 1)
      if (student.id === 'SA-2026-103' && dayIdx >= 3) {
        return; // Absent
      }
      // 2. Nour El Houda Guerfi (SA-2026-201) is absent the whole period (14 days -> Stage 2)
      if (student.id === 'SA-2026-201') {
        return; // Absent
      }
      // 3. Yacine Benmoubarak (SA-2026-301) is absent long term (29 days -> Stage 3)
      if (student.id === 'SA-2026-301') {
        return; // Absent
      }

      // Excused medical leave on Oct 20
      if (student.id === 'SA-2026-203' && dateStr === '2026-10-20') {
        generated.push({
          id: `ATT-${dateStr}-${student.id}`,
          studentId: student.id,
          barcode: student.barcode,
          studentName: `${student.lastName} ${student.firstName}`,
          grade: student.grade,
          classroom: student.classroom,
          date: dateStr,
          timestamp: '08:00:00',
          fullDateTime: `${dateStr}T08:00:00`,
          session: 'm1',
          periodId: 'm1',
          status: 'excused',
          lateMinutes: 0,
          device: 'manual',
          excuseReason: 'شهادة طبية مبررة من طبيب الصحة المدرسية',
        });
        return;
      }

      // Check-in times
      const isLate = (sIdx + dayIdx) % 7 === 0;
      const minute = isLate ? 8 + ((sIdx + dayIdx) % 15) : 46 + (sIdx % 12);
      const hour = isLate ? 8 : (minute >= 60 ? 8 : 7);
      const normalizedMin = minute >= 60 ? minute - 60 : minute;
      const timeStr = `0${hour}:${normalizedMin < 10 ? '0' : ''}${normalizedMin}:15`;
      const lateMinutes = isLate ? normalizedMin : 0;

      generated.push({
        id: `ATT-${dateStr}-${student.id}`,
        studentId: student.id,
        barcode: student.barcode,
        studentName: `${student.lastName} ${student.firstName}`,
        grade: student.grade,
        classroom: student.classroom,
        date: dateStr,
        timestamp: timeStr,
        fullDateTime: `${dateStr}T${timeStr}`,
        session: 'm1',
        periodId: 'm1',
        status: isLate ? 'late' : 'present',
        lateMinutes,
        device: sIdx % 2 === 0 ? 'scanner_gun' : 'camera',
      });
    });
  });

  return generated;
}

export default function App() {
  const { palette, updateFromExternal } = useTheme();

  // Navigation view
  const [currentView, setCurrentView] = useState<ViewType>('scanner');

  // Detect cohort period (m1, m2, m3, a1, a2, a3) and session
  const [currentPeriodId, setCurrentPeriodId] = useState<PeriodId>(() => {
    return getAutoDetectedPeriod();
  });

  const [currentSession, setCurrentSession] = useState<'morning' | 'afternoon'>(() => {
    return getPeriodSessionType(getAutoDetectedPeriod());
  });

  const handlePeriodChange = (periodId: PeriodId) => {
    setCurrentPeriodId(periodId);
    setCurrentSession(getPeriodSessionType(periodId));
  };

  // Load state from localStorage or use defaults
  const [students, setStudents] = useState<Student[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.STUDENTS);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
      return INITIAL_STUDENTS;
    } catch {
      return INITIAL_STUDENTS;
    }
  });

  const [records, setRecords] = useState<AttendanceRecord[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.RECORDS);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
      return getInitialRecords();
    } catch {
      return getInitialRecords();
    }
  });

  const [settings, setSettings] = useState<SchoolSettings>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed.principalName === 'أحمد بن عمار' || !parsed.principalName) {
          parsed.principalName = 'بويمة ليلى بن تروش';
        }
        if (parsed.counselorName === 'كريم قندوز' || !parsed.counselorName) {
          parsed.counselorName = 'حليلو صليحة';
        }
        if (parsed.academicYear === '2025-2026' || !parsed.academicYear) {
          parsed.academicYear = '2026-2027';
        }
        if (parsed.wilaya === 'المسيلة' || !parsed.wilaya) {
          parsed.wilaya = 'عنابة';
        }
        return { ...DEFAULT_SETTINGS, ...parsed };
      }
      return DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  });

  // Staged Absence Notices State
  const [notices, setNotices] = useState<AbsenceNotice[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.NOTICES);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
      return INITIAL_NOTICES;
    } catch {
      return INITIAL_NOTICES;
    }
  });

  // Timetable Sessions State
  const [timetableSessions, setTimetableSessions] = useState<TimetableSession[]>(() => {
    try {
      const stored = localStorage.getItem('saadoun_achour_timetable_v1');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
      return INITIAL_TIMETABLE_SESSIONS;
    } catch {
      return INITIAL_TIMETABLE_SESSIONS;
    }
  });

  const handleUpdateTimetableSessions = (updated: TimetableSession[]) => {
    setTimetableSessions(updated);
    try {
      localStorage.setItem('saadoun_achour_timetable_v1', JSON.stringify(updated));
    } catch (e) {
      console.warn('Failed to save timetable sessions:', e);
    }
  };

  // User Authentication State
  const [currentUser, setCurrentUser] = useState<AppUser | null>(() => {
    return getStoredCurrentUser() || null;
  });
  // Sidebar state
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  // Data Persistence Modal state
  const [isDataPersistenceOpen, setIsDataPersistenceOpen] = useState(false);

  // Modals
  const [activeLateTicket, setActiveLateTicket] = useState<{
    record: AttendanceRecord;
    student: Student;
  } | null>(null);

  const [activeStudentCard, setActiveStudentCard] = useState<Student | null>(null);
  const [studentToEdit, setStudentToEdit] = useState<Student | null>(null);

  // Database version & last updated tracker
  const [dbLastUpdated, setDbLastUpdated] = useState<string>(() => {
    try {
      return localStorage.getItem('saadoun_achour_db_updated_at') || new Date().toISOString();
    } catch {
      return new Date().toISOString();
    }
  });

  // Real-time synchronization state across all users and devices
  const [syncStatus, setSyncStatus] = useState<'connected' | 'reconnecting' | 'offline'>('connected');
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [lastSyncTime, setLastSyncTime] = useState<string>('');
  const [liveBannerAlert, setLiveBannerAlert] = useState<string | null>(null);
  const serverVersionRef = React.useRef<number>(0);
  const isSyncingRef = React.useRef<boolean>(false);

  const markDbUpdated = () => {
    const now = new Date().toISOString();
    setDbLastUpdated(now);
    try {
      localStorage.setItem('saadoun_achour_db_updated_at', now);
      window.dispatchEvent(new CustomEvent('saadoun_db_synced', { detail: { timestamp: now } }));
    } catch (e) {
      console.warn('Failed to save db timestamp', e);
    }
  };

  // Pull latest database state from server
  const pullServerSync = React.useCallback(async (silent = false) => {
    if (isSyncingRef.current) return;
    try {
      isSyncingRef.current = true;
      if (!silent) setIsSyncing(true);

      const data = await fetchDatabaseSync();
      if (data && Array.isArray(data.students)) {
        if (data.students.length > 0) {
          setStudents(data.students);
          localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(data.students));
        }
        if (data.records && data.records.length > 0) {
          setRecords(data.records);
          localStorage.setItem(STORAGE_KEYS.RECORDS, JSON.stringify(data.records));
        }
        if (data.settings) {
          setSettings(data.settings);
          localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(data.settings));
          if (data.settings.themeColor || data.settings.themeMode) {
            updateFromExternal(data.settings.themeColor, data.settings.customHexColor, data.settings.themeMode);
          }
        }
        if (data.notices && data.notices.length > 0) {
          setNotices(data.notices);
          localStorage.setItem(STORAGE_KEYS.NOTICES, JSON.stringify(data.notices));
        }
        setDbLastUpdated(data.lastUpdated);
        serverVersionRef.current = data.version;

        const timeStr = new Date().toLocaleTimeString('ar-DZ', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        });
        setLastSyncTime(timeStr);
        setSyncStatus('connected');
      }
    } catch (err) {
      console.warn('Initial server sync failed (running in local offline mode):', err);
      setSyncStatus('offline');
    } finally {
      isSyncingRef.current = false;
      setIsSyncing(false);
    }
  }, []);

  // Initialize live real-time sync with server
  useEffect(() => {
    pullServerSync(true);

    const cleanupSSE = initLiveSync(
      (payload) => {
        if (payload.version && payload.version > serverVersionRef.current) {
          serverVersionRef.current = payload.version;
          pullServerSync(true);

          if (payload.action === 'student_added') {
            setLiveBannerAlert(`تم تسجيل تلميذ جديد: ${payload.detail?.name || ''}`);
            setTimeout(() => setLiveBannerAlert(null), 4000);
          } else if (payload.action === 'record_saved') {
            setLiveBannerAlert(`تسجيل دخول فوري: ${payload.detail?.studentName || ''}`);
            setTimeout(() => setLiveBannerAlert(null), 3000);
          } else if (payload.action === 'teacher_session_saved') {
            setLiveBannerAlert(`تسجيل حضور من طرف ${payload.detail?.teacherName || 'الأستاذ'} (قسم ${payload.detail?.classroom || ''})`);
            setTimeout(() => setLiveBannerAlert(null), 4000);
          } else if (payload.action === 'teacher_session_status_changed') {
            setLiveBannerAlert(`تم تحديث حالة جلسة الحضور إلى (${payload.detail?.newStatus || ''})`);
            setTimeout(() => setLiveBannerAlert(null), 3500);
          } else if (payload.action === 'database_saved_manually') {
            setLiveBannerAlert(`تم حفظ قاعدة البيانات بالكامل على الخادم بنجاح`);
            setTimeout(() => setLiveBannerAlert(null), 3000);
          }
        }
      },
      (newStatus) => {
        setSyncStatus(newStatus);
      }
    );

    return () => {
      cleanupSSE();
    };
  }, [pullServerSync]);

  const handleLoginSuccess = (user: AppUser, token: string) => {
    setCurrentUser(user);
    setStoredCurrentUser(user);
    setIsLoginModalOpen(false);
    pullServerSync(true);
  };

  const handleLogout = async () => {
    try {
      await apiLogout();
    } catch (e) {
      // ignore
    }
    clearStoredAuth();
    setCurrentUser(null);
    setIsLoginModalOpen(false);
  };

  // Count pending notices that require action
  const pendingNoticesCount = notices.filter((n) => n.status === 'pending').length;

  // Handlers for Students
  const handleAddStudent = (newStudent: Student) => {
    setStudents((prev) => {
      const updated = [newStudent, ...prev];
      localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(updated));
      return updated;
    });
    markDbUpdated();
    apiSaveStudent(newStudent).catch((err) => console.warn('Server save student error:', err));
  };

  const handleUpdateStudent = (updatedStudent: Student) => {
    setStudents((prev) => {
      const updated = prev.map((s) => (s.id === updatedStudent.id ? updatedStudent : s));
      localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(updated));
      return updated;
    });

    setRecords((prev) => {
      const updated = prev.map((r) => {
        if (r.studentId === updatedStudent.id) {
          return {
            ...r,
            studentName: `${updatedStudent.lastName} ${updatedStudent.firstName}`,
            grade: updatedStudent.grade,
            classroom: updatedStudent.classroom,
            barcode: updatedStudent.barcode,
          };
        }
        return r;
      });
      localStorage.setItem(STORAGE_KEYS.RECORDS, JSON.stringify(updated));
      return updated;
    });

    markDbUpdated();
    apiUpdateStudent(updatedStudent).catch((err) => console.warn('Server update student error:', err));
  };

  const handleDeleteStudent = (studentId: string) => {
    setStudents((prev) => {
      const updated = prev.filter((s) => s.id !== studentId);
      localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(updated));
      return updated;
    });
    setRecords((prev) => {
      const updated = prev.filter((r) => r.studentId !== studentId);
      localStorage.setItem(STORAGE_KEYS.RECORDS, JSON.stringify(updated));
      return updated;
    });
    setNotices((prev) => {
      const updated = prev.filter((n) => n.studentId !== studentId);
      localStorage.setItem(STORAGE_KEYS.NOTICES, JSON.stringify(updated));
      return updated;
    });
    markDbUpdated();
    apiDeleteStudent(studentId).catch((err) => console.warn('Server delete student error:', err));
  };

  const handleDeleteMultipleStudents = (ids: string[]) => {
    const idSet = new Set(ids);
    setStudents((prev) => {
      const updated = prev.filter((s) => !idSet.has(s.id));
      localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(updated));
      return updated;
    });
    setRecords((prev) => {
      const updated = prev.filter((r) => !idSet.has(r.studentId));
      localStorage.setItem(STORAGE_KEYS.RECORDS, JSON.stringify(updated));
      return updated;
    });
    setNotices((prev) => {
      const updated = prev.filter((n) => !idSet.has(n.studentId));
      localStorage.setItem(STORAGE_KEYS.NOTICES, JSON.stringify(updated));
      return updated;
    });
    markDbUpdated();
    apiBulkDeleteStudents(ids).catch((err) => console.warn('Server bulk delete error:', err));
  };

  const handleClearAllStudents = () => {
    setStudents([]);
    setRecords([]);
    setNotices([]);
    localStorage.removeItem(STORAGE_KEYS.STUDENTS);
    localStorage.removeItem(STORAGE_KEYS.RECORDS);
    localStorage.removeItem(STORAGE_KEYS.NOTICES);
    markDbUpdated();
    apiClearAllStudents().catch((err) => console.warn('Server clear all error:', err));
  };

  const handleBulkTransferStudents = (
    studentIds: string[],
    newClassroom: string,
    newGrade?: GradeLevel
  ) => {
    const idSet = new Set(studentIds);
    setStudents((prev) => {
      const updated = prev.map((s) => {
        if (idSet.has(s.id)) {
          return {
            ...s,
            classroom: newClassroom,
            grade: newGrade || s.grade,
          };
        }
        return s;
      });
      localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(updated));
      return updated;
    });
    markDbUpdated();
    apiBulkTransferStudents(studentIds, newClassroom, newGrade).catch((err) =>
      console.warn('Server bulk transfer error:', err)
    );
  };

  // Handlers for Attendance Records
  const handleAddRecord = (newRecord: AttendanceRecord) => {
    setRecords((prev) => {
      const updated = [newRecord, ...prev];
      localStorage.setItem(STORAGE_KEYS.RECORDS, JSON.stringify(updated));
      return updated;
    });
    markDbUpdated();
    apiSaveAttendanceRecord(newRecord).catch((err) => console.warn('Server save record error:', err));
  };

  const handleUpdateRecord = (updatedRecord: AttendanceRecord) => {
    setRecords((prev) => {
      const updated = prev.map((r) => (r.id === updatedRecord.id ? updatedRecord : r));
      localStorage.setItem(STORAGE_KEYS.RECORDS, JSON.stringify(updated));
      return updated;
    });
    markDbUpdated();
    apiSaveAttendanceRecord(updatedRecord).catch((err) => console.warn('Server update record error:', err));
  };

  // Handlers for Absence Notices
  const handleSaveNotice = (notice: AbsenceNotice) => {
    setNotices((prev) => {
      const idx = prev.findIndex((n) => n.id === notice.id);
      let updated: AbsenceNotice[];
      if (idx >= 0) {
        updated = [...prev];
        updated[idx] = notice;
      } else {
        updated = [notice, ...prev];
      }
      localStorage.setItem(STORAGE_KEYS.NOTICES, JSON.stringify(updated));
      return updated;
    });
    markDbUpdated();
    apiSaveNotice(notice).catch((err) => console.warn('Server save notice error:', err));
  };

  const handleBulkSaveNotices = (newNotices: AbsenceNotice[]) => {
    setNotices((prev) => {
      const map = new Map<string, AbsenceNotice>();
      prev.forEach((n) => map.set(n.id, n));
      newNotices.forEach((n) => map.set(n.id, n));
      const merged = Array.from(map.values());
      localStorage.setItem(STORAGE_KEYS.NOTICES, JSON.stringify(merged));
      return merged;
    });
    markDbUpdated();
    apiBulkSaveNotices(newNotices).catch((err) => console.warn('Server bulk save notices error:', err));
  };

  const handleDeleteNotice = (id: string) => {
    setNotices((prev) => {
      const updated = prev.filter((n) => n.id !== id);
      localStorage.setItem(STORAGE_KEYS.NOTICES, JSON.stringify(updated));
      return updated;
    });
    markDbUpdated();
    apiDeleteNotice(id).catch((err) => console.warn('Server delete notice error:', err));
  };

  // Handlers for Settings & Reset
  const handleSaveSettings = (newSettings: SchoolSettings) => {
    setSettings(newSettings);
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(newSettings));
    markDbUpdated();
    apiSaveSettings(newSettings).catch((err) => console.warn('Server save settings error:', err));
  };

  const handleResetToday = () => {
    const today = new Date().toISOString().split('T')[0];
    setRecords((prev) => {
      const updated = prev.filter((r) => r.date !== today);
      localStorage.setItem(STORAGE_KEYS.RECORDS, JSON.stringify(updated));
      return updated;
    });
    markDbUpdated();
    apiResetRecords('today').catch((err) => console.warn('Reset records error:', err));
  };

  const handleResetDefaultData = () => {
    setStudents(INITIAL_STUDENTS);
    setRecords(getInitialRecords());
    setSettings(DEFAULT_SETTINGS);
    setNotices(INITIAL_NOTICES);

    localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(INITIAL_STUDENTS));
    localStorage.setItem(STORAGE_KEYS.RECORDS, JSON.stringify(getInitialRecords()));
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(DEFAULT_SETTINGS));
    localStorage.setItem(STORAGE_KEYS.NOTICES, JSON.stringify(INITIAL_NOTICES));

    markDbUpdated();
    apiResetDefaults()
      .then(() => pullServerSync(false))
      .catch((err) => console.warn('Reset defaults error:', err));
  };

  const handleImportData = (backup: {
    students: Student[];
    records: AttendanceRecord[];
    settings?: SchoolSettings;
    notices?: AbsenceNotice[];
  }) => {
    setStudents(backup.students);
    setRecords(backup.records || []);
    if (backup.settings) setSettings(backup.settings);
    if (backup.notices) setNotices(backup.notices);

    localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(backup.students));
    localStorage.setItem(STORAGE_KEYS.RECORDS, JSON.stringify(backup.records || []));
    if (backup.settings) localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(backup.settings));
    if (backup.notices) localStorage.setItem(STORAGE_KEYS.NOTICES, JSON.stringify(backup.notices));

    markDbUpdated();
    apiImportFullBackup(backup).catch((err) => console.warn('Import data error:', err));
  };

  // Barcode quick scan from card modal
  const handleScanBarcodeFromModal = (barcode: string) => {
    setCurrentView('scanner');
    const match = matchStudentByBarcode(students, barcode);
    const student = match.student;
    if (student) {
      const today = new Date().toISOString().split('T')[0];
      const now = new Date();
      const timeStr = now.toTimeString().split(' ')[0];
      const existing = records.find(
        (r) => r.studentId === student.id && r.date === today && r.session === currentSession
      );

      const newRec: AttendanceRecord = {
        id: existing ? existing.id : `ATT-${Date.now()}`,
        studentId: student.id,
        barcode: student.barcode,
        studentName: `${student.lastName} ${student.firstName}`,
        grade: student.grade,
        classroom: student.classroom,
        date: today,
        timestamp: timeStr,
        fullDateTime: now.toISOString(),
        session: currentSession,
        status: 'present',
        lateMinutes: 0,
        device: 'manual',
      };

      if (existing) {
        handleUpdateRecord(newRec);
      } else {
        handleAddRecord(newRec);
      }
    }
  };

  // Excel Bulk Import handler
  const handleImportExcelStudents = (
    importedStudents: Student[],
    mode: 'upsert' | 'append' | 'replace'
  ) => {
    if (mode === 'replace') {
      setStudents(importedStudents);
    } else if (mode === 'upsert') {
      setStudents((prev) => {
        const studentMap = new Map<string, Student>();
        const byBarcode = new Map<string, Student>();
        const byNationalId = new Map<string, Student>();
        const byName = new Map<string, Student>();

        prev.forEach((s) => {
          if (s.barcode) byBarcode.set(s.barcode, s);
          if (s.nationalId) byNationalId.set(s.nationalId, s);
          const fullName = `${s.lastName.trim()} ${s.firstName.trim()}`.toLowerCase();
          byName.set(fullName, s);
          studentMap.set(s.id, s);
        });

        importedStudents.forEach((imp) => {
          const fullName = `${imp.lastName.trim()} ${imp.firstName.trim()}`.toLowerCase();
          const existing =
            (imp.barcode ? byBarcode.get(imp.barcode) : undefined) ||
            (imp.nationalId ? byNationalId.get(imp.nationalId) : undefined) ||
            studentMap.get(imp.id) ||
            byName.get(fullName);

          if (existing) {
            const updated: Student = {
              ...existing,
              ...imp,
              id: existing.id,
              barcode: imp.barcode || existing.barcode,
            };
            studentMap.set(existing.id, updated);
          } else {
            studentMap.set(imp.id, imp);
          }
        });

        return Array.from(studentMap.values());
      });
    } else {
      setStudents((prev) => {
        const existingBarcodes = new Set(prev.map((s) => s.barcode));
        const existingNationalIds = new Set(prev.map((s) => s.nationalId).filter(Boolean));
        const newUnique = importedStudents.filter(
          (s) => !existingBarcodes.has(s.barcode) && !existingNationalIds.has(s.nationalId)
        );
        return [...prev, ...newUnique];
      });
    }
    markDbUpdated();
    apiBulkImportStudents(importedStudents, mode).catch((err) =>
      console.warn('Failed to sync Excel students with server:', err)
    );
  };

  // If not logged in, render the professional full-screen landing login page
  if (!currentUser) {
    return (
      <LoginPage
        settings={settings}
        onLoginSuccess={handleLoginSuccess}
      />
    );
  }

  // If active user is a Teacher, render dedicated Teacher Portal
  if (currentUser && currentUser.role === 'teacher') {
    return (
      <>
        <TeacherPortal
          user={currentUser}
          allStudents={students}
          settings={settings}
          onLogout={handleLogout}
          onRefreshData={() => pullServerSync(true)}
        />
        {isLoginModalOpen && (
          <LoginModal
            isOpen={isLoginModalOpen}
            currentUser={currentUser}
            onClose={() => setIsLoginModalOpen(false)}
            onLoginSuccess={handleLoginSuccess}
          />
        )}
      </>
    );
  }

  return (
    <div className="min-h-screen bg-[var(--app-bg,#f8fafc)] flex flex-row font-sans text-[var(--app-text,#0f172a)] transition-colors duration-150" dir="rtl">
      {/* Lateral Navigation Sidebar */}
      <Sidebar
        currentView={currentView}
        onChangeView={(view) => {
          setCurrentView(view);
          setIsMobileNavOpen(false);
        }}
        settings={settings}
        pendingNoticesCount={pendingNoticesCount}
        onOpenDataPersistence={() => setIsDataPersistenceOpen(true)}
        currentUser={currentUser}
        onOpenLoginModal={() => setIsLoginModalOpen(true)}
        onLogout={handleLogout}
        isMobileOpen={isMobileNavOpen}
        onCloseMobile={() => setIsMobileNavOpen(false)}
        isCollapsed={isSidebarCollapsed}
        onToggleCollapse={() => setIsSidebarCollapsed((prev) => !prev)}
      />

      {/* Main Content Column */}
      <div className="flex-1 min-w-0 flex flex-col min-h-screen overflow-x-hidden">
        {/* TopBar with breadcrumbs, period cohort switcher, clock, sync status, and mobile drawer toggle */}
        <TopBar
          currentView={currentView}
          settings={settings}
          currentSession={currentSession}
          onToggleSession={() => {
            const nextSession = currentSession === 'morning' ? 'afternoon' : 'morning';
            setCurrentSession(nextSession);
            setCurrentPeriodId(nextSession === 'morning' ? 'm1' : 'a1');
          }}
          currentPeriodId={currentPeriodId}
          onChangePeriod={handlePeriodChange}
          syncStatus={syncStatus}
          isSyncing={isSyncing}
          onManualSync={() => pullServerSync(false)}
          lastSyncTime={lastSyncTime}
          onOpenDataPersistence={() => setIsDataPersistenceOpen(true)}
          currentUser={currentUser}
          onOpenLoginModal={() => setIsLoginModalOpen(true)}
          onLogout={handleLogout}
          onToggleMobileNav={() => setIsMobileNavOpen((prev) => !prev)}
          onThemeSavedToSettings={(color, customHex, mode) => {
            handleSaveSettings({
              ...settings,
              themeColor: color,
              customHexColor: customHex,
              themeMode: mode,
            });
          }}
        />

        {/* Real-time remote update notification alert */}
        {liveBannerAlert && (
          <div
            className="text-xs px-4 py-2 text-center font-semibold shadow-xs animate-in slide-in-from-top duration-200 flex items-center justify-center gap-2 no-print"
            style={{
              backgroundColor: palette.primary,
              color: palette.foreground,
            }}
          >
            <CheckCircle2 className="w-3.5 h-3.5 text-current" />
            <span>{liveBannerAlert}</span>
          </div>
        )}

        {/* Main Content Area */}
        <main className={currentView === 'rotating_paper' ? 'flex-1 w-full min-w-0 p-2 sm:p-3' : 'flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 py-6'}>
        {currentView === 'rotating_paper' && <RotatingPaperPanel settings={settings} />}
        {currentView === 'scanner' && (
          <ScannerGate
            students={students}
            records={records}
            settings={settings}
            currentSession={currentSession}
            currentPeriodId={currentPeriodId}
            onChangePeriod={handlePeriodChange}
            onAddRecord={handleAddRecord}
            onUpdateRecord={handleUpdateRecord}
            onOpenLateTicket={(rec, st) => setActiveLateTicket({ record: rec, student: st })}
            onViewStudentCard={(st) => setActiveStudentCard(st)}
          />
        )}

        {currentView === 'attendance' && (
          <DailyAttendance
            students={students}
            records={records}
            settings={settings}
            currentSession={currentSession}
            currentPeriodId={currentPeriodId}
            onChangePeriod={handlePeriodChange}
            onAddRecord={handleAddRecord}
            onUpdateRecord={handleUpdateRecord}
            onOpenLateTicket={(rec, st) => setActiveLateTicket({ record: rec, student: st })}
            onViewStudentCard={(st) => setActiveStudentCard(st)}
          />
        )}

        {currentView === 'students' && (
          <StudentManagement
            students={students}
            settings={settings}
            onAddStudent={handleAddStudent}
            onUpdateStudent={handleUpdateStudent}
            onDeleteStudent={handleDeleteStudent}
            onDeleteMultipleStudents={handleDeleteMultipleStudents}
            onViewStudentCard={(st) => setActiveStudentCard(st)}
            onImportExcelStudents={handleImportExcelStudents}
            onBulkTransferStudents={handleBulkTransferStudents}
            dbLastUpdated={dbLastUpdated}
            onForceSyncDatabase={markDbUpdated}
            studentToEdit={studentToEdit}
            onClearStudentToEdit={() => setStudentToEdit(null)}
          />
        )}

        {currentView === 'timetable' && (
          <TimetableManager
            students={students}
            records={records}
            settings={settings}
            currentSession={currentSession}
            currentPeriodId={currentPeriodId}
            onViewStudentCard={(st) => setActiveStudentCard(st)}
            timetableSessions={timetableSessions}
            onUpdateTimetableSessions={handleUpdateTimetableSessions}
          />
        )}

        {currentView === 'teacher_sessions' && (
          <TeacherSessionsManager
            settings={settings}
            students={students}
            onRefreshData={() => pullServerSync(true)}
          />
        )}

        {currentView === 'monthly' && (
          <MonthlyReports
            students={students}
            records={records}
            settings={settings}
            onOpenNotice={(st) => {
              setCurrentView('notices');
            }}
          />
        )}

        {currentView === 'notices' && (
          <AbsenceNoticesManager
            students={students}
            records={records}
            settings={settings}
            notices={notices}
            onSaveNotice={handleSaveNotice}
            onBulkSaveNotices={handleBulkSaveNotices}
            onDeleteNotice={handleDeleteNotice}
          />
        )}

        {currentView === 'reports' && (
          <AnalyticsReports
            students={students}
            records={records}
            settings={settings}
            currentSession={currentSession}
            currentPeriodId={currentPeriodId}
            onChangePeriod={handlePeriodChange}
          />
        )}

        {currentView === 'settings' && (
          <SettingsModal
            settings={settings}
            students={students}
            records={records}
            onSaveSettings={handleSaveSettings}
            onResetToday={handleResetToday}
            onResetDefaultData={handleResetDefaultData}
            onImportData={(st, rec) => handleImportData({ students: st, records: rec })}
            onImportExcelStudents={handleImportExcelStudents}
            onClearAllStudents={handleClearAllStudents}
          />
        )}
      </main>

      {/* Institutional Footer */}
      <footer className="bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 py-4 mt-auto no-print transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-2">
            <School className="w-4 h-4 text-current" style={{ color: palette.primary }} />
            <span className="font-semibold text-slate-800 dark:text-slate-200">{settings.schoolName}</span>
            <span aria-hidden="true">·</span>
            <span>مديرية التربية لولاية {settings.wilaya}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono-numbers">{settings.academicYear}</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-slate-600" />
              نظام رقمنة الحضور والمواظبة المدرسية
            </span>
            <span aria-hidden="true">·</span>
            <span>الجمهورية الجزائرية الديمقراطية الشعبية</span>
          </div>
        </div>
      </footer>
      </div>

      {/* Late Ticket Modal */}
      {activeLateTicket && (
        <LateTicketModal
          record={activeLateTicket.record}
          student={activeLateTicket.student}
          settings={settings}
          onClose={() => setActiveLateTicket(null)}
        />
      )}

      {/* Student Card / Badge Modal */}
      {activeStudentCard && (
        <StudentCardModal
          student={activeStudentCard}
          settings={settings}
          onClose={() => setActiveStudentCard(null)}
          onScanThisStudent={handleScanBarcodeFromModal}
          onEditStudent={(st) => {
            setActiveStudentCard(null);
            setStudentToEdit(st);
            setCurrentView('students');
          }}
        />
      )}

      {/* Data Persistence & Storage Hub Modal */}
      {isDataPersistenceOpen && (
        <DataPersistenceModal
          students={students}
          records={records}
          settings={settings}
          notices={notices}
          lastSavedTime={dbLastUpdated}
          onClose={() => setIsDataPersistenceOpen(false)}
          onManualSaveSuccess={(savedTime) => {
            markDbUpdated();
          }}
          onImportFullData={handleImportData}
          onResetDefaults={handleResetDefaultData}
        />
      )}


      {/* Unified Login & Account Switcher Modal */}
      {isLoginModalOpen && (
        <LoginModal
          isOpen={isLoginModalOpen}
          currentUser={currentUser}
          onClose={() => setIsLoginModalOpen(false)}
          onLoginSuccess={handleLoginSuccess}
        />
      )}
    </div>
  );
}
