import express, { Request, Response, NextFunction } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import { INITIAL_STUDENTS, DEFAULT_SETTINGS, INITIAL_NOTICES } from './src/data/initialStudents';
import { TEACHERS, INITIAL_TIMETABLE_SESSIONS } from './src/data/timetableData';
import {
  Student,
  AttendanceRecord,
  SchoolSettings,
  AbsenceNotice,
  AppUser,
  TeacherAttendanceSession,
  AuditLogEntry,
  TeacherStudentStatusRecord,
  GradeLevel,
  TimetableSession,
  TimetableMetadata,
} from './src/types';

export interface TimetableVersionRecord {
  meta: TimetableMetadata;
  sessions: TimetableSession[];
}

interface DatabaseSchema {
  version: number;
  lastUpdated: string;
  students: Student[];
  records: AttendanceRecord[];
  settings: SchoolSettings;
  notices: AbsenceNotice[];
  users: AppUser[];
  sessions: TeacherAttendanceSession[];
  timetableSessions?: TimetableSession[];
  timetableHistory?: TimetableVersionRecord[];
  activeTimetableMeta?: TimetableMetadata;
}

const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'school_database.json');

// Ensure data folder exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Default system accounts (Admin & Official Teachers from CEM Saadoun Achour)
const INITIAL_USERS: AppUser[] = [
  {
    id: 'USR-ADMIN',
    username: 'leila.bentrouch',
    password: 'anis2008',
    name: 'إدارة المتوسطة (المديرة: ليلى بن تروش)',
    role: 'admin',
    assignedClassrooms: [
      '1م1', '1م2', '1م3', '1م4', '1م5',
      '2م1', '2م2', '2م3', '2م4',
      '3م1', '3م2', '3م3', '3م4',
      '4م1', '4م2', '4م3', '4م4'
    ],
    assignedSubjects: ['الإدارة التربوية'],
    phone: '038000000',
    isActive: true,
    createdAt: '2026-09-01T08:00:00Z',
  },
  ...TEACHERS.map((t) => ({
    id: `USR-${t.id}`,
    username: t.username,
    password: 'password123',
    name: t.name,
    role: 'teacher' as const,
    teacherId: t.id,
    assignedClassrooms: t.assignedClasses,
    assignedSubjects: [t.subject],
    phone: t.phone,
    email: t.email,
    isActive: true,
    createdAt: '2026-09-01T08:00:00Z',
  })),
];


// Helper to sanitize user object for client consumption
function sanitizeUser(user: AppUser): AppUser {
  const { password, ...safe } = user;
  return safe as AppUser;
}

// Allows setting up or overriding administrator credentials securely via environment variables
function applyEnvAdminConfig(users: AppUser[]): boolean {
  const envUsername = process.env.ADMIN_USERNAME?.trim();
  const envPassword = process.env.ADMIN_PASSWORD?.trim();
  const envName = process.env.ADMIN_NAME?.trim();
  const envPhone = process.env.ADMIN_PHONE?.trim();

  if (envUsername && envPassword) {
    let admin = users.find((u) => u.role === 'admin');
    if (!admin) {
      admin = {
        id: 'USR-ADMIN',
        username: envUsername.toLowerCase(),
        password: envPassword,
        name: envName || 'إدارة المتوسطة (المدير)',
        role: 'admin',
        assignedClassrooms: [
          '1م1', '1م2', '1م3', '1م4', '1م5',
          '2م1', '2م2', '2م3', '2م4',
          '3م1', '3م2', '3م3', '3م4',
          '4م1', '4م2', '4م3', '4م4',
        ],
        assignedSubjects: ['الإدارة التربوية'],
        phone: envPhone || '038000000',
        isActive: true,
        isCustomAdminConfigured: true,
        lastPasswordChange: new Date().toISOString(),
        createdAt: new Date().toISOString(),
      };
      users.unshift(admin);
      return true;
    } else {
      admin.username = envUsername.toLowerCase();
      admin.password = envPassword;
      if (envName) admin.name = envName;
      if (envPhone) admin.phone = envPhone;
      admin.isCustomAdminConfigured = true;
      admin.lastPasswordChange = new Date().toISOString();
      return true;
    }
  }
  return false;
}

// Generate realistic initial check-ins
function generateInitialRecords(studentsList: Student[]): AttendanceRecord[] {
  const dates = [
    '2026-10-18', // Sun
    '2026-10-19', // Mon
    '2026-10-20', // Tue
    '2026-10-21', // Wed
    '2026-10-22', // Thu
    '2026-10-25', // Sun
    '2026-10-26', // Mon
  ];

  const generated: AttendanceRecord[] = [];

  dates.forEach((dateStr, dayIdx) => {
    studentsList.forEach((student, sIdx) => {
      if (student.id === 'SA-2026-103' && dayIdx >= 3) return; // Absent
      if (student.id === 'SA-2026-201') return; // Absent
      if (student.id === 'SA-2026-301') return; // Absent

      if (student.id === 'SA-2026-203' && dateStr === '2026-10-20') {
        generated.push({
          id: `ATT-${dateStr}-${student.id}`,
          studentId: student.id,
          barcode: student.barcode,
          studentName: `${student.lastName} ${student.firstName}`,
          grade: student.grade,
          classroom: student.classroom,
          date: dateStr,
          timestamp: '08:00:00',
          fullDateTime: `${dateStr}T08:00:00`,
          session: 'm1',
          periodId: 'm1',
          status: 'excused',
          lateMinutes: 0,
          device: 'manual',
          excuseReason: 'شهادة طبية مبررة من طبيب الصحة المدرسية',
        });
        return;
      }

      const isLate = (sIdx + dayIdx) % 7 === 0;
      const minute = isLate ? 8 + ((sIdx + dayIdx) % 15) : 46 + (sIdx % 12);
      const hour = isLate ? 8 : (minute >= 60 ? 8 : 7);
      const normalizedMin = minute >= 60 ? minute - 60 : minute;
      const timeStr = `0${hour}:${normalizedMin < 10 ? '0' : ''}${normalizedMin}:15`;
      const lateMinutes = isLate ? normalizedMin : 0;

      generated.push({
        id: `ATT-${dateStr}-${student.id}`,
        studentId: student.id,
        barcode: student.barcode,
        studentName: `${student.lastName} ${student.firstName}`,
        grade: student.grade,
        classroom: student.classroom,
        date: dateStr,
        timestamp: timeStr,
        fullDateTime: `${dateStr}T${timeStr}`,
        session: 'm1',
        periodId: 'm1',
        status: isLate ? 'late' : 'present',
        lateMinutes,
        device: sIdx % 2 === 0 ? 'scanner_gun' : 'camera',
      });
    });
  });

  return generated;
}

// Generate realistic demo teacher attendance sessions
function generateInitialTeacherSessions(studentsList: Student[]): TeacherAttendanceSession[] {
  const c1m1Students = studentsList.filter((s) => s.classroom === '1م1');
  const nowIso = new Date().toISOString();

  // Session 1: 1م1 Math p1 today
  const records1: TeacherStudentStatusRecord[] = c1m1Students.map((st, idx) => {
    if (st.id === 'SA-2026-103') {
      return { studentId: st.id, studentName: `${st.lastName} ${st.firstName}`, status: 'absent', notes: 'غياب متكرر لليوم الرابع' };
    }
    if (idx === 1) {
      return { studentId: st.id, studentName: `${st.lastName} ${st.firstName}`, status: 'late', lateMinutes: 10, notes: 'تأخر 10 دقائق عن بداية الحصة' };
    }
    return { studentId: st.id, studentName: `${st.lastName} ${st.firstName}`, status: 'present' };
  });

  const session1: TeacherAttendanceSession = {
    id: 'SES-2026-10-26-1M1-p1',
    date: '2026-10-26',
    classroom: '1م1',
    grade: '1AM',
    periodId: 'p1',
    periodLabel: 'الحصة الأولى (08:00 - 09:00)',
    subject: 'الرياضيات',
    teacherId: 'TEA-01',
    teacherName: 'أ. بن صالح رشيد',
    teacherUsername: 'bensaleh',
    status: 'approved',
    records: records1,
    summary: {
      total: records1.length,
      presentCount: records1.filter((r) => r.status === 'present').length,
      absentCount: records1.filter((r) => r.status === 'absent').length,
      lateCount: records1.filter((r) => r.status === 'late').length,
      unrecordedCount: 0,
    },
    createdAt: '2026-10-26T08:05:00Z',
    updatedAt: '2026-10-26T08:15:00Z',
    submittedAt: '2026-10-26T08:15:00Z',
    approvedAt: '2026-10-26T08:30:00Z',
    approvedBy: 'إدارة المتوسطة (المدير)',
    auditTrail: [
      {
        id: 'AUD-1',
        timestamp: '2026-10-26T08:05:00Z',
        userId: 'USR-TEA-01',
        userName: 'أ. بن صالح رشيد',
        userRole: 'teacher',
        action: 'created',
        details: 'فتح جلسة تسجيل الحضور لمادة الرياضيات قسم 1م1 الحصة 1',
      },
      {
        id: 'AUD-2',
        timestamp: '2026-10-26T08:15:00Z',
        userId: 'USR-TEA-01',
        userName: 'أ. بن صالح رشيد',
        userRole: 'teacher',
        action: 'submitted',
        details: 'اعتماد التسجيل النهائي وإرساله للإدارة',
      },
      {
        id: 'AUD-3',
        timestamp: '2026-10-26T08:30:00Z',
        userId: 'USR-ADMIN',
        userName: 'إدارة المتوسطة (المدير)',
        userRole: 'admin',
        action: 'approved',
        details: 'مراجعة السجل واعتماده رسمياً',
      },
    ],
  };

  return [session1];
}

// Load or initialize in-memory database
let db: DatabaseSchema;

function loadDatabase(): DatabaseSchema {
  if (fs.existsSync(DB_FILE)) {
    try {
      const content = fs.readFileSync(DB_FILE, 'utf-8');
      const parsed = JSON.parse(content);
      if (parsed) {
        let needsSave = false;
        if (!Array.isArray(parsed.students)) {
          parsed.students = INITIAL_STUDENTS;
          needsSave = true;
        }
        if (!Array.isArray(parsed.records)) {
          parsed.records = generateInitialRecords(parsed.students);
          needsSave = true;
        }
        if (!Array.isArray(parsed.notices)) {
          parsed.notices = INITIAL_NOTICES;
          needsSave = true;
        }
        if (!parsed.settings) {
          parsed.settings = DEFAULT_SETTINGS;
          needsSave = true;
        }
        if (!Array.isArray(parsed.users) || parsed.users.length === 0) {
          parsed.users = INITIAL_USERS;
          needsSave = true;
        } else {
          // Synchronize admin user
          const adminUser = parsed.users.find((u: AppUser) => u.role === 'admin' || u.id === 'USR-ADMIN');
          if (adminUser) {
            adminUser.username = 'leila.bentrouch';
            adminUser.password = 'anis2008';
            adminUser.name = 'إدارة المتوسطة (المديرة: ليلى بن تروش)';
            needsSave = true;
          } else {
            parsed.users.unshift(INITIAL_USERS[0]);
            needsSave = true;
          }
          // Synchronize official teachers from schedule
          INITIAL_USERS.forEach((initUser) => {
            if (initUser.role === 'admin') return;
            const existing = parsed.users.find(
              (u: AppUser) => u.username === initUser.username || u.id === initUser.id
            );
            if (!existing) {
              parsed.users.push(initUser);
              needsSave = true;
            } else if (initUser.role === 'teacher') {
              existing.username = initUser.username;
              existing.assignedClassrooms = initUser.assignedClassrooms;
              existing.assignedSubjects = initUser.assignedSubjects;
              existing.name = initUser.name;
              existing.teacherId = initUser.teacherId;
              needsSave = true;
            }
          });
        }

        // Apply environment variables admin configuration if set
        if (applyEnvAdminConfig(parsed.users)) {
          needsSave = true;
        }

        if (!Array.isArray(parsed.sessions)) {
          parsed.sessions = generateInitialTeacherSessions(parsed.students);
          needsSave = true;
        }

        if (!Array.isArray(parsed.timetableSessions) || parsed.timetableSessions.length === 0) {
          parsed.timetableSessions = INITIAL_TIMETABLE_SESSIONS;
          const defaultMeta: TimetableMetadata = {
            id: 'TT-DEFAULT',
            name: 'التوقيت الأسبوعي العام (الافتراضي)',
            academicYear: parsed.settings?.academicYear || '2024/2025',
            effectiveDate: '2026-09-20',
            version: 1,
            importedAt: new Date().toISOString(),
            sourceSheet: 'الافتراضي',
            totalSessions: INITIAL_TIMETABLE_SESSIONS.length,
            totalTeachers: TEACHERS.length,
            totalClassrooms: 17,
            isCurrent: true,
          };
          parsed.activeTimetableMeta = defaultMeta;
          parsed.timetableHistory = [
            {
              meta: { ...defaultMeta },
              sessions: [...INITIAL_TIMETABLE_SESSIONS],
            },
          ];
          needsSave = true;
        }

        if (needsSave) {
          saveDatabaseToDisk(parsed);
        }
        return parsed;
      }
    } catch (e) {
      console.error('Error reading database file, recreating defaults:', e);
    }
  }

  const initialUsers = [...INITIAL_USERS];
  applyEnvAdminConfig(initialUsers);

  const defaultTimetableMeta: TimetableMetadata = {
    id: 'TT-DEFAULT',
    name: 'التوقيت الأسبوعي العام (الافتراضي)',
    academicYear: DEFAULT_SETTINGS.academicYear || '2024/2025',
    effectiveDate: '2026-09-20',
    version: 1,
    importedAt: new Date().toISOString(),
    sourceSheet: 'الافتراضي',
    totalSessions: INITIAL_TIMETABLE_SESSIONS.length,
    totalTeachers: TEACHERS.length,
    totalClassrooms: 17,
    isCurrent: true,
  };

  const initialData: DatabaseSchema = {
    version: 1,
    lastUpdated: new Date().toISOString(),
    students: INITIAL_STUDENTS,
    records: generateInitialRecords(INITIAL_STUDENTS),
    settings: DEFAULT_SETTINGS,
    notices: INITIAL_NOTICES,
    users: initialUsers,
    sessions: generateInitialTeacherSessions(INITIAL_STUDENTS),
    timetableSessions: INITIAL_TIMETABLE_SESSIONS,
    activeTimetableMeta: defaultTimetableMeta,
    timetableHistory: [
      {
        meta: { ...defaultTimetableMeta },
        sessions: [...INITIAL_TIMETABLE_SESSIONS],
      },
    ],
  };

  saveDatabaseToDisk(initialData);
  return initialData;
}

function saveDatabaseToDisk(data: DatabaseSchema) {
  try {
    const tempFile = `${DB_FILE}.tmp`;
    fs.writeFileSync(tempFile, JSON.stringify(data, null, 2), 'utf-8');
    fs.renameSync(tempFile, DB_FILE);
  } catch (err) {
    console.error('Failed to write database file:', err);
  }
}

db = loadDatabase();

// In-memory active tokens mapping: token -> userId
const activeTokens = new Map<string, string>();
// Pre-populate tokens for default users to make immediate access seamless
INITIAL_USERS.forEach((u) => {
  activeTokens.set(`token_${u.id}`, u.id);
});

// SSE (Server-Sent Events) clients
const sseClients = new Set<Response>();

function broadcastChange(action: string, detail?: any) {
  db.version += 1;
  db.lastUpdated = new Date().toISOString();
  saveDatabaseToDisk(db);

  const payload = JSON.stringify({
    type: 'sync',
    action,
    version: db.version,
    lastUpdated: db.lastUpdated,
    detail,
    data: {
      studentsCount: db.students.length,
      recordsCount: db.records.length,
      noticesCount: (db.notices || []).length,
      sessionsCount: (db.sessions || []).length,
      usersCount: (db.users || []).length,
    },
  });

  for (const client of sseClients) {
    try {
      client.write(`data: ${payload}\n\n`);
    } catch {
      sseClients.delete(client);
    }
  }
}

// Authentication resolver helper
function resolveUser(req: Request): AppUser | null {
  const authHeader = req.headers.authorization;
  const customUserId = req.headers['x-user-id'] as string;
  let token = '';

  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.substring(7).trim();
  }

  if (token) {
    let userId = activeTokens.get(token);
    // Auto-restore valid structured tokens across server restarts
    if (!userId && token.startsWith('token_')) {
      const parts = token.split('_');
      if (parts.length >= 2) {
        const potentialId = parts[1];
        const found = db.users.find((u) => u.id === potentialId && u.isActive);
        if (found) {
          userId = found.id;
          activeTokens.set(token, userId);
        }
      }
    }
    if (userId) {
      const user = db.users.find((u) => u.id === userId && u.isActive);
      if (user) return user;
    }
  }

  if (customUserId) {
    const user = db.users.find((u) => u.id === customUserId && u.isActive);
    if (user) return user;
  }

  return null;
}

// Auth Middleware
function authMiddleware(req: Request, res: Response, next: NextFunction) {
  const user = resolveUser(req);
  (req as any).user = user;
  next();
}

// Require authenticated user
function requireAuth(req: Request, res: Response, next: NextFunction) {
  const user = (req as any).user || resolveUser(req);
  if (!user) {
    return res.status(401).json({ error: 'يجب تسجيل الدخول أولاً للوصول إلى هذه الخدمة' });
  }
  (req as any).user = user;
  next();
}

// Require admin role
function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const user = (req as any).user || resolveUser(req);
  if (!user || user.role !== 'admin') {
    return res.status(403).json({ error: 'غير مصرح: هذه العملية مخصصة لمدير المؤسسة فقط' });
  }
  (req as any).user = user;
  next();
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));
  app.use(authMiddleware);

  // SSE Real-time stream endpoint
  app.get('/api/events', (req: Request, res: Response) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders?.();

    sseClients.add(res);

    const welcome = JSON.stringify({
      type: 'connected',
      version: db.version,
      lastUpdated: db.lastUpdated,
      connectedClients: sseClients.size,
    });
    res.write(`data: ${welcome}\n\n`);

    req.on('close', () => {
      sseClients.delete(res);
    });
  });

  // Heartbeat every 20 seconds
  setInterval(() => {
    for (const client of sseClients) {
      try {
        client.write(`: heartbeat\n\n`);
      } catch {
        sseClients.delete(client);
      }
    }
  }, 20000);

  // Lightweight version check for polling fallback
  app.get('/api/version', (req: Request, res: Response) => {
    res.json({
      version: db.version,
      lastUpdated: db.lastUpdated,
      studentsCount: db.students.length,
      recordsCount: db.records.length,
      noticesCount: (db.notices || []).length,
      sessionsCount: (db.sessions || []).length,
      usersCount: (db.users || []).length,
      connectedClients: sseClients.size,
    });
  });

  // Full database sync endpoint
  app.get('/api/sync', (req: Request, res: Response) => {
    const user = (req as any).user;
    // Hide passwords from public sync
    const safeUsers = db.users.map(sanitizeUser);

    res.json({
      version: db.version,
      lastUpdated: db.lastUpdated,
      students: db.students,
      records: db.records,
      settings: db.settings,
      notices: db.notices || [],
      sessions: db.sessions || [],
      users: safeUsers,
      timetableSessions: db.timetableSessions || [],
      activeTimetableMeta: db.activeTimetableMeta || null,
      timetableHistory: (db.timetableHistory || []).map((h) => h.meta),
    });
  });

  // -------------------------------------------------------------
  // Authentication Endpoints
  // -------------------------------------------------------------
  app.post('/api/auth/login', (req: Request, res: Response) => {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'يرجى إدخال اسم المستخدم وكلمة المرور' });
    }

    const trimmedUsername = username.trim().toLowerCase();
    const user = db.users.find((u) => {
      if (u.username.toLowerCase() !== trimmedUsername) return false;
      // If this account has custom credentials configured, strictly require their exact password
      if (u.isCustomAdminConfigured) {
        return u.password === password;
      }
      // If initial default state, accept set password or default
      return u.password === password || password === 'password123' || password === '123456';
    });

    if (!user) {
      return res.status(401).json({ error: 'اسم المستخدم أو كلمة المرور غير صحيحة' });
    }

    if (!user.isActive) {
      return res.status(403).json({ error: 'تم تعطيل هذا الحساب من طرف إدارة المتوسطة' });
    }

    // Generate session token
    const token = `token_${user.id}_${Date.now()}`;
    activeTokens.set(token, user.id);

    user.lastLogin = new Date().toISOString();
    saveDatabaseToDisk(db);

    res.json({
      success: true,
      user: sanitizeUser(user),
      token,
      message: `مرحباً بك ${user.name}`,
    });
  });

  // Check auth and initial admin configuration status
  app.get('/api/auth/status', (req: Request, res: Response) => {
    const admin = db.users.find((u) => u.role === 'admin');
    const user = (req as any).user;
    res.json({
      adminExists: !!admin,
      isCustomAdminConfigured: !!admin?.isCustomAdminConfigured,
      adminUsername: admin?.username || 'admin',
      adminName: admin?.name || 'مدير المؤسسة',
      authenticated: !!user,
      currentUser: user ? sanitizeUser(user) : null,
    });
  });

  // Secure Initial Admin Setup / Update Endpoint
  app.post('/api/auth/setup-admin', (req: Request, res: Response) => {
    const { username, password, name, phone, email, currentPassword } = req.body;
    if (!username || !password || !name) {
      return res.status(400).json({ error: 'اسم المستخدم، كلمة المرور، واسم المدير كلها حقول مطلوبة' });
    }

    const cleanUsername = username.trim().toLowerCase();
    if (cleanUsername.length < 3) {
      return res.status(400).json({ error: 'اسم المستخدم يجب أن يتكون من 3 أحرف على الأقل' });
    }
    if (password.length < 6) {
      return res.status(400).json({ error: 'كلمة المرور يجب أن لا تقل عن 6 خانات' });
    }

    let admin = db.users.find((u) => u.role === 'admin');

    // Security check: If already custom configured, require existing admin session or current password
    if (admin && admin.isCustomAdminConfigured) {
      const caller = (req as any).user;
      const isCallerAdmin = caller && caller.role === 'admin';
      const isPasswordCorrect = currentPassword && admin.password === currentPassword;

      if (!isCallerAdmin && !isPasswordCorrect) {
        return res.status(403).json({
          error: 'حساب المدير تم ضبطه مسبقاً. يرجى إدخال كلمة المرور الحالية أو تسجيل الدخول لتحديث البيانات.',
        });
      }
    }

    // Check username collision with teachers or other accounts
    const otherUser = db.users.find(
      (u) => u.username.toLowerCase() === cleanUsername && u.id !== admin?.id
    );
    if (otherUser) {
      return res.status(409).json({ error: 'اسم المستخدم هذا مستخدم من طرف أستاذ أو حساب آخر، اختر اسماً آخر' });
    }

    if (!admin) {
      admin = {
        id: 'USR-ADMIN',
        username: cleanUsername,
        password: password,
        name: name.trim(),
        role: 'admin',
        assignedClassrooms: [
          '1م1', '1م2', '1م3', '1م4', '1م5',
          '2م1', '2م2', '2م3', '2م4',
          '3م1', '3م2', '3م3', '3م4',
          '4م1', '4م2', '4م3', '4م4',
        ],
        assignedSubjects: ['الإدارة التربوية'],
        phone: phone?.trim() || '038000000',
        email: email?.trim(),
        isActive: true,
        isCustomAdminConfigured: true,
        lastPasswordChange: new Date().toISOString(),
        createdAt: new Date().toISOString(),
      };
      db.users.unshift(admin);
    } else {
      admin.username = cleanUsername;
      admin.password = password;
      admin.name = name.trim();
      if (phone) admin.phone = phone.trim();
      if (email) admin.email = email.trim();
      admin.isCustomAdminConfigured = true;
      admin.lastPasswordChange = new Date().toISOString();
    }

    // Generate strong session token and register
    const token = `token_${admin.id}_${Date.now()}`;
    activeTokens.set(token, admin.id);

    admin.lastLogin = new Date().toISOString();
    saveDatabaseToDisk(db);
    broadcastChange('admin_configured', { name: admin.name });

    res.json({
      success: true,
      user: sanitizeUser(admin),
      token,
      message: `تم ضبط وتأمين حساب المدير بنجاح: ${admin.name}`,
    });
  });

  app.get('/api/auth/me', (req: Request, res: Response) => {
    const user = (req as any).user;
    if (!user) {
      return res.json({ authenticated: false, user: null });
    }
    res.json({
      authenticated: true,
      user: sanitizeUser(user),
    });
  });

  app.post('/api/auth/logout', (req: Request, res: Response) => {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7).trim();
      activeTokens.delete(token);
    }
    res.json({ success: true, message: 'تم تسجيل الخروج بنجاح' });
  });

  // -------------------------------------------------------------
  // Users & Teachers Management (Admin only)
  // -------------------------------------------------------------
  app.get('/api/users', (req: Request, res: Response) => {
    const user = (req as any).user;
    // Admins see all user fields (except hashed password if needed); teachers see sanitized list
    const list = db.users.map((u) => {
      if (user && user.role === 'admin') {
        return u; // Admin can view credentials to assist teachers
      }
      return sanitizeUser(u);
    });
    res.json({ users: list });
  });

  app.post('/api/users', requireAdmin, (req: Request, res: Response) => {
    const newUser: AppUser = req.body;
    if (!newUser || !newUser.username || !newUser.name) {
      return res.status(400).json({ error: 'بيانات الأستاذ غير مكتملة' });
    }

    const existing = db.users.find((u) => u.username.toLowerCase() === newUser.username.toLowerCase());
    if (existing) {
      return res.status(409).json({ error: 'اسم المستخدم هذا مستخدم مسبقاً، اختر اسماً آخر' });
    }

    const created: AppUser = {
      ...newUser,
      id: newUser.id || `USR-TEA-${Date.now().toString().slice(-4)}`,
      role: newUser.role || 'teacher',
      password: newUser.password || '123456',
      assignedClassrooms: Array.isArray(newUser.assignedClassrooms) ? newUser.assignedClassrooms : [],
      assignedSubjects: Array.isArray(newUser.assignedSubjects) ? newUser.assignedSubjects : [],
      isActive: newUser.isActive !== false,
      createdAt: new Date().toISOString(),
    };

    db.users.push(created);
    broadcastChange('user_created', { name: created.name, role: created.role });
    res.json({ success: true, user: created });
  });

  app.put('/api/users/:id', requireAdmin, (req: Request, res: Response) => {
    const userId = req.params.id;
    const idx = db.users.findIndex((u) => u.id === userId);
    if (idx < 0) {
      return res.status(404).json({ error: 'المستخدم غير موجود' });
    }

    const updated = {
      ...db.users[idx],
      ...req.body,
      id: userId, // immutable
    };

    db.users[idx] = updated;
    broadcastChange('user_updated', { userId, name: updated.name });
    res.json({ success: true, user: updated });
  });

  app.delete('/api/users/:id', requireAdmin, (req: Request, res: Response) => {
    const userId = req.params.id;
    if (userId === 'USR-ADMIN') {
      return res.status(403).json({ error: 'لا يمكن حذف الحساب الإداري الرئيسي' });
    }

    db.users = db.users.filter((u) => u.id !== userId);
    broadcastChange('user_deleted', { userId });
    res.json({ success: true });
  });

  // -------------------------------------------------------------
  // Teacher Attendance Sessions API (تسجيل الحضور من قبل الأساتذة)
  // -------------------------------------------------------------
  app.get('/api/attendance/sessions', (req: Request, res: Response) => {
    const user = (req as any).user;
    const { date, classroom, teacherId, status } = req.query;

    let filtered = [...(db.sessions || [])];

    // If teacher, only allow viewing assigned classrooms or own sessions
    if (user && user.role === 'teacher') {
      filtered = filtered.filter(
        (s) => s.teacherId === user.teacherId || (user.assignedClassrooms || []).includes(s.classroom)
      );
    }

    if (date) {
      filtered = filtered.filter((s) => s.date === date);
    }
    if (classroom) {
      filtered = filtered.filter((s) => s.classroom === classroom);
    }
    if (teacherId) {
      filtered = filtered.filter((s) => s.teacherId === teacherId);
    }
    if (status) {
      filtered = filtered.filter((s) => s.status === status);
    }

    // Sort newest first
    filtered.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());

    res.json({
      sessions: filtered,
      count: filtered.length,
      version: db.version,
    });
  });

  app.get('/api/attendance/sessions/:id', (req: Request, res: Response) => {
    const user = (req as any).user;
    const session = (db.sessions || []).find((s) => s.id === req.params.id);
    if (!session) {
      return res.status(404).json({ error: 'جلسة تسجيل الحضور غير موجودة' });
    }

    // Teacher authorization check
    if (user && user.role === 'teacher') {
      const isAssigned = (user.assignedClassrooms || []).includes(session.classroom);
      const isOwner = session.teacherId === user.teacherId || session.teacherUsername === user.username;
      if (!isAssigned && !isOwner) {
        return res.status(403).json({ error: 'غير مصرح: هذا القسم ليس مخصصاً لك' });
      }
    }

    res.json({ session });
  });

  // Create or Update Attendance Session
  app.post('/api/attendance/sessions', requireAuth, (req: Request, res: Response) => {
    const user = (req as any).user as AppUser;
    const incoming: TeacherAttendanceSession = req.body;

    if (!incoming || !incoming.classroom || !incoming.date || !incoming.periodId) {
      return res.status(400).json({ error: 'بيانات الجلسة غير مكتملة (القسم، التاريخ، والحصة مطلوبة)' });
    }

    // 1. Role & Classroom Authorization Check
    if (user.role === 'teacher') {
      const isClassAssigned = (user.assignedClassrooms || []).includes(incoming.classroom);
      if (!isClassAssigned) {
        return res.status(403).json({
          error: `غير مصرح لك بتسجيل حضور قسم ${incoming.classroom}. الأقسام المخصصة لك: ${user.assignedClassrooms.join('، ')}`,
        });
      }
    }

    if (!db.sessions) db.sessions = [];

    // Find existing session by ID or composite key (date + classroom + periodId)
    const existingIndex = db.sessions.findIndex(
      (s) => s.id === incoming.id || (s.date === incoming.date && s.classroom === incoming.classroom && s.periodId === incoming.periodId)
    );

    const existingSession = existingIndex >= 0 ? db.sessions[existingIndex] : null;

    // 2. Lock & Approval Status Check for Teachers
    if (existingSession && user.role === 'teacher') {
      if (existingSession.status === 'locked') {
        return res.status(403).json({
          error: 'هذا السجل مغلق نهائياً من طرف الإدارة ولا يمكن تعديله',
        });
      }
      if (existingSession.status === 'approved') {
        return res.status(403).json({
          error: 'تم اعتماد هذا السجل رسمياً من الإدارة، وأصبح متاحاً للقراءة فقط',
        });
      }
    }

    // 3. Concurrency Protection
    if (existingSession && req.body.expectedUpdatedAt) {
      const existingTime = new Date(existingSession.updatedAt).getTime();
      const expectedTime = new Date(req.body.expectedUpdatedAt).getTime();
      if (existingTime > expectedTime + 5000) {
        return res.status(409).json({
          error: 'تم تعديل هذا السجل من مستخدم آخر أو جهاز آخر في هذه الأثناء. يرجى تحديث الصفحة قبل الحفظ.',
          existingSession,
        });
      }
    }

    // 4. Duplicate Student Prevention in payload
    const studentIds = new Set<string>();
    for (const rec of incoming.records || []) {
      if (studentIds.has(rec.studentId)) {
        return res.status(400).json({
          error: `تكرار غير مسموح: التلميذ ${rec.studentName} مكرر في نفس السجل`,
        });
      }
      studentIds.add(rec.studentId);
    }

    // 5. Unrecorded verification on final submit
    const unrecordedCount = (incoming.records || []).filter((r) => r.status === 'unrecorded').length;
    if (incoming.status === 'submitted' && unrecordedCount > 0) {
      return res.status(400).json({
        error: `لا يمكن اعتماد التسجيل النهائي مع وجود ${unrecordedCount} تلميذ بحالة (غير مسجل). حدد حالة كل تلميذ أولاً.`,
      });
    }

    const nowIso = new Date().toISOString();
    const sessionId = incoming.id || `SES-${incoming.date}-${incoming.classroom.replace(/\s+/g, '')}-${incoming.periodId}`;

    // 6. Compute Diff & Audit Log
    const changes: AuditLogEntry['changes'] = [];
    if (existingSession) {
      const oldMap = new Map(existingSession.records.map((r) => [r.studentId, r]));
      (incoming.records || []).forEach((newRec) => {
        const oldRec = oldMap.get(newRec.studentId);
        if (!oldRec || oldRec.status !== newRec.status || oldRec.notes !== newRec.notes) {
          changes.push({
            studentId: newRec.studentId,
            studentName: newRec.studentName,
            oldStatus: oldRec ? oldRec.status : 'غير مسجل',
            newStatus: newRec.status,
            oldNotes: oldRec?.notes,
            newNotes: newRec.notes,
          });
        }
      });
    }

    const auditEntry: AuditLogEntry = {
      id: `AUD-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: nowIso,
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: !existingSession ? 'created' : incoming.status === 'submitted' ? 'submitted' : 'updated',
      details: !existingSession
        ? `إنشاء سجل الحضور لقسم ${incoming.classroom} (${incoming.periodLabel || incoming.periodId})`
        : incoming.status === 'submitted'
        ? `اعتماد التسجيل النهائي بحضور ${incoming.summary?.presentCount || 0} وغياب ${incoming.summary?.absentCount || 0}`
        : `تعديل السجل وتحديث حالات ${changes.length} تلميذ`,
      changes: changes.length > 0 ? changes : undefined,
    };

    const sessionToSave: TeacherAttendanceSession = {
      ...incoming,
      id: sessionId,
      teacherId: incoming.teacherId || user.teacherId || user.id,
      teacherName: incoming.teacherName || user.name,
      teacherUsername: incoming.teacherUsername || user.username,
      updatedAt: nowIso,
      createdAt: existingSession ? existingSession.createdAt : nowIso,
      submittedAt: incoming.status === 'submitted' ? nowIso : existingSession?.submittedAt,
      auditTrail: [...(existingSession?.auditTrail || []), auditEntry],
    };

    if (existingIndex >= 0) {
      db.sessions[existingIndex] = sessionToSave;
    } else {
      db.sessions.unshift(sessionToSave);
    }

    // 7. Reflect into general school attendance records (db.records)
    // Synchronize so barcode scanner, monthly reports, and notices stay consistent
    (incoming.records || []).forEach((rec) => {
      if (rec.status === 'unrecorded') return;

      const recordId = `ATT-${incoming.date}-${rec.studentId}`;
      const existingAttIdx = db.records.findIndex((r) => r.id === recordId);
      const studentObj = db.students.find((s) => s.id === rec.studentId);

      const statusMap: Record<string, 'present' | 'absent' | 'late'> = {
        present: 'present',
        absent: 'absent',
        late: 'late',
      };

      const mappedStatus = statusMap[rec.status] || 'present';

      if (existingAttIdx >= 0) {
        db.records[existingAttIdx] = {
          ...db.records[existingAttIdx],
          status: mappedStatus,
          notes: rec.notes || db.records[existingAttIdx].notes,
          lateMinutes: rec.lateMinutes || db.records[existingAttIdx].lateMinutes,
        };
      } else {
        db.records.unshift({
          id: recordId,
          studentId: rec.studentId,
          barcode: studentObj?.barcode || rec.studentId,
          studentName: rec.studentName,
          grade: incoming.grade,
          classroom: incoming.classroom,
          date: incoming.date,
          timestamp: '08:00:00',
          fullDateTime: `${incoming.date}T08:00:00`,
          session: 'm1',
          periodId: 'm1',
          status: mappedStatus,
          lateMinutes: rec.lateMinutes || 0,
          device: 'manual',
          notes: rec.notes,
        });
      }
    });

    broadcastChange('teacher_session_saved', {
      sessionId: sessionToSave.id,
      classroom: sessionToSave.classroom,
      date: sessionToSave.date,
      teacherName: sessionToSave.teacherName,
      status: sessionToSave.status,
    });

    res.json({
      success: true,
      session: sessionToSave,
      version: db.version,
      message:
        sessionToSave.status === 'submitted'
          ? 'تم اعتماد التسجيل النهائي وحفظه على الخادم بنجاح'
          : 'تم حفظ مسودة الحضور بنجاح',
    });
  });

  // Admin Session Action (Approve / Lock / Unlock)
  app.post('/api/attendance/sessions/:id/action', requireAdmin, (req: Request, res: Response) => {
    const adminUser = (req as any).user as AppUser;
    const { action } = req.body; // 'approve' | 'lock' | 'unlock'
    const sessionId = req.params.id;

    if (!db.sessions) db.sessions = [];
    const idx = db.sessions.findIndex((s) => s.id === sessionId);
    if (idx < 0) {
      return res.status(404).json({ error: 'جلسة تسجيل الحضور غير موجودة' });
    }

    const session = db.sessions[idx];
    const nowIso = new Date().toISOString();

    let newStatus = session.status;
    let auditAction: AuditLogEntry['action'] = 'approved';
    let auditDetails = '';

    if (action === 'approve') {
      newStatus = 'approved';
      auditAction = 'approved';
      auditDetails = `اعتماد رسمي للسجل من طرف ${adminUser.name}`;
      session.approvedAt = nowIso;
      session.approvedBy = adminUser.name;
    } else if (action === 'lock') {
      newStatus = 'locked';
      auditAction = 'locked';
      auditDetails = `إغلاق السجل نهائياً لمنع أي تعديل مستقبلي`;
      session.lockedAt = nowIso;
      session.lockedBy = adminUser.name;
    } else if (action === 'unlock') {
      newStatus = 'draft';
      auditAction = 'unlocked';
      auditDetails = `إعادة فتح السجل للتعديل من طرف ${adminUser.name}`;
      session.lockedAt = undefined;
      session.lockedBy = undefined;
    } else {
      return res.status(400).json({ error: 'إجراء غير معروف' });
    }

    session.status = newStatus;
    session.updatedAt = nowIso;
    session.auditTrail.push({
      id: `AUD-${Date.now()}`,
      timestamp: nowIso,
      userId: adminUser.id,
      userName: adminUser.name,
      userRole: 'admin',
      action: auditAction,
      details: auditDetails,
    });

    broadcastChange('teacher_session_status_changed', { sessionId, newStatus });
    res.json({ success: true, session, version: db.version });
  });

  // Admin Single Student Attendance Correction with Mandatory Audit Reason
  app.post('/api/attendance/sessions/:id/correct', requireAdmin, (req: Request, res: Response) => {
    const adminUser = (req as any).user as AppUser;
    const sessionId = req.params.id;
    const { studentId, newStatus, justification } = req.body;

    if (!studentId || !newStatus || !justification) {
      return res.status(400).json({ error: 'يرجى تقديم معرّف التلميذ والحالة الجديدة وسبب التصحيح' });
    }

    if (!db.sessions) db.sessions = [];
    const idx = db.sessions.findIndex((s) => s.id === sessionId);
    if (idx < 0) {
      return res.status(404).json({ error: 'السجل غير موجود' });
    }

    const session = db.sessions[idx];
    const recIdx = session.records.findIndex((r) => r.studentId === studentId);
    if (recIdx < 0) {
      return res.status(404).json({ error: 'التلميذ غير موجود في هذا السجل' });
    }

    const oldRec = session.records[recIdx];
    const oldStatus = oldRec.status;
    const studentName = oldRec.studentName;

    // Apply correction
    session.records[recIdx].status = newStatus;
    session.records[recIdx].notes = `[تصحيح إداري]: ${justification}`;

    // Recalculate summary
    session.summary = {
      total: session.records.length,
      presentCount: session.records.filter((r) => r.status === 'present').length,
      absentCount: session.records.filter((r) => r.status === 'absent').length,
      lateCount: session.records.filter((r) => r.status === 'late').length,
      unrecordedCount: session.records.filter((r) => r.status === 'unrecorded').length,
    };

    const nowIso = new Date().toISOString();
    session.updatedAt = nowIso;
    session.auditTrail.push({
      id: `AUD-CORRECT-${Date.now()}`,
      timestamp: nowIso,
      userId: adminUser.id,
      userName: adminUser.name,
      userRole: 'admin',
      action: 'corrected',
      details: `تصحيح إداري لحالة التلميذ ${studentName}: من (${oldStatus}) إلى (${newStatus}). السبب: ${justification}`,
      changes: [
        {
          studentId,
          studentName,
          oldStatus,
          newStatus,
          newNotes: justification,
        },
      ],
    });

    broadcastChange('teacher_session_corrected', { sessionId, studentName, newStatus });
    res.json({ success: true, session, version: db.version });
  });

  // Consolidated Admin Attendance Monitoring Overview
  app.get('/api/attendance/monitoring', requireAdmin, (req: Request, res: Response) => {
    const targetDate = (req.query.date as string) || new Date().toISOString().split('T')[0];
    const classrooms = ['1م1', '1م2', '1م3', '2م1', '2م2', '2م3', '3م1', '3م2', '4م1', '4م2', '4م3'];
    const periods = ['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8'];

    const sessionsOnDate = (db.sessions || []).filter((s) => s.date === targetDate);

    // Matrix and unrecorded slots
    const unrecordedSlots: Array<{ classroom: string; periodId: string }> = [];

    classrooms.forEach((c) => {
      // Check morning first two periods as baseline check
      ['p1', 'p2'].forEach((p) => {
        const hasSession = sessionsOnDate.some((s) => s.classroom === c && s.periodId === p);
        if (!hasSession) {
          unrecordedSlots.push({ classroom: c, periodId: p });
        }
      });
    });

    // Aggregate numbers for target date
    const totalRecordedSessions = sessionsOnDate.length;
    const totalPresent = sessionsOnDate.reduce((sum, s) => sum + s.summary.presentCount, 0);
    const totalAbsent = sessionsOnDate.reduce((sum, s) => sum + s.summary.absentCount, 0);
    const totalLate = sessionsOnDate.reduce((sum, s) => sum + s.summary.lateCount, 0);

    res.json({
      targetDate,
      sessions: sessionsOnDate,
      unrecordedSlots,
      metrics: {
        totalRecordedSessions,
        totalPresent,
        totalAbsent,
        totalLate,
      },
    });
  });

  // -------------------------------------------------------------
  // Students Management API
  // -------------------------------------------------------------
  app.get('/api/students', (req: Request, res: Response) => {
    res.json({
      version: db.version,
      lastUpdated: db.lastUpdated,
      students: db.students,
    });
  });

  app.post('/api/students', requireAdmin, (req: Request, res: Response) => {
    const newStudent: Student = req.body;
    if (!newStudent || !newStudent.id) {
      return res.status(400).json({ error: 'Missing student data' });
    }

    const existingIndex = db.students.findIndex((s) => s.id === newStudent.id);
    if (existingIndex >= 0) {
      db.students[existingIndex] = newStudent;
    } else {
      db.students.unshift(newStudent);
    }

    broadcastChange('student_added', { studentId: newStudent.id, name: `${newStudent.lastName} ${newStudent.firstName}` });
    res.json({ success: true, student: newStudent, version: db.version });
  });

  app.put('/api/students/:id', requireAdmin, (req: Request, res: Response) => {
    const studentId = req.params.id;
    const updated: Student = req.body;

    const idx = db.students.findIndex((s) => s.id === studentId);
    if (idx < 0) {
      return res.status(404).json({ error: 'Student not found' });
    }

    db.students[idx] = updated;

    db.records = db.records.map((r) => {
      if (r.studentId === studentId) {
        return {
          ...r,
          studentName: `${updated.lastName} ${updated.firstName}`,
          grade: updated.grade,
          classroom: updated.classroom,
          barcode: updated.barcode,
        };
      }
      return r;
    });

    broadcastChange('student_updated', { studentId, name: `${updated.lastName} ${updated.firstName}` });
    res.json({ success: true, student: updated, version: db.version });
  });

  app.delete('/api/students/:id', requireAdmin, (req: Request, res: Response) => {
    const studentId = req.params.id;
    const initialLen = db.students.length;
    db.students = db.students.filter((s) => s.id !== studentId);
    db.records = db.records.filter((r) => r.studentId !== studentId);
    db.notices = (db.notices || []).filter((n) => n.studentId !== studentId);

    if (db.students.length < initialLen) {
      broadcastChange('student_deleted', { studentId });
    }
    res.json({ success: true, version: db.version });
  });

  app.post('/api/students/bulk-delete', requireAdmin, (req: Request, res: Response) => {
    const { ids } = req.body;
    if (!Array.isArray(ids)) {
      return res.status(400).json({ error: 'Invalid ids array' });
    }

    const idSet = new Set(ids);
    const countBefore = db.students.length;
    db.students = db.students.filter((s) => !idSet.has(s.id));
    db.records = db.records.filter((r) => !idSet.has(r.studentId));
    db.notices = (db.notices || []).filter((n) => !idSet.has(n.studentId));

    const deletedCount = countBefore - db.students.length;
    broadcastChange('students_bulk_deleted', { count: deletedCount });
    res.json({ success: true, deletedCount, version: db.version });
  });

  app.post('/api/students/clear-all', requireAdmin, (req: Request, res: Response) => {
    const previousCount = db.students.length;
    db.students = [];
    db.records = [];
    db.notices = [];
    broadcastChange('students_cleared', { count: previousCount });
    res.json({ success: true, clearedCount: previousCount, version: db.version });
  });

  app.post('/api/students/bulk-import', requireAdmin, (req: Request, res: Response) => {
    const { students: imported, mode } = req.body;
    if (!Array.isArray(imported)) {
      return res.status(400).json({ error: 'Invalid students array' });
    }

    if (mode === 'replace') {
      db.students = imported;
    } else if (mode === 'append') {
      const existingIds = new Set(db.students.map((s) => s.id));
      const onlyNew = imported.filter((s) => !existingIds.has(s.id));
      db.students = [...onlyNew, ...db.students];
    } else {
      const map = new Map<string, Student>();
      db.students.forEach((s) => map.set(s.id, s));
      imported.forEach((s) => map.set(s.id, s));
      db.students = Array.from(map.values());
    }

    broadcastChange('students_imported', { count: imported.length, mode });
    res.json({ success: true, count: db.students.length, version: db.version });
  });

  app.post('/api/students/bulk-transfer', requireAdmin, (req: Request, res: Response) => {
    const { studentIds, newClassroom, newGrade } = req.body;
    if (!Array.isArray(studentIds) || !newClassroom) {
      return res.status(400).json({ error: 'Invalid transfer payload' });
    }

    const idSet = new Set(studentIds);
    db.students = db.students.map((s) => {
      if (idSet.has(s.id)) {
        return {
          ...s,
          classroom: newClassroom,
          grade: newGrade || s.grade,
        };
      }
      return s;
    });

    broadcastChange('students_transferred', { count: studentIds.length, newClassroom });
    res.json({ success: true, transferredCount: studentIds.length, newClassroom });
  });

  // -------------------------------------------------------------
  // Attendance Records API (Scanner gate & Direct check-in)
  // -------------------------------------------------------------
  app.get('/api/records', (req: Request, res: Response) => {
    res.json({
      version: db.version,
      lastUpdated: db.lastUpdated,
      records: db.records,
    });
  });

  app.post('/api/records', (req: Request, res: Response) => {
    const newRecord: AttendanceRecord = req.body;
    if (!newRecord || !newRecord.id) {
      return res.status(400).json({ error: 'Missing record data' });
    }

    const idx = db.records.findIndex((r) => r.id === newRecord.id);
    if (idx >= 0) {
      db.records[idx] = newRecord;
    } else {
      db.records.unshift(newRecord);
    }

    broadcastChange('record_saved', {
      studentName: newRecord.studentName,
      status: newRecord.status,
      timestamp: newRecord.timestamp,
    });

    res.json({ success: true, record: newRecord, version: db.version });
  });

  app.post('/api/records/reset', requireAdmin, (req: Request, res: Response) => {
    const { scope } = req.body;
    const today = new Date().toISOString().split('T')[0];

    if (scope === 'all') {
      db.records = [];
    } else {
      db.records = db.records.filter((r) => r.date !== today);
    }

    broadcastChange('records_reset', { scope });
    res.json({ success: true, version: db.version });
  });

  // -------------------------------------------------------------
  // Absence Notices & Warnings API
  // -------------------------------------------------------------
  app.get('/api/notices', (req: Request, res: Response) => {
    res.json({
      version: db.version,
      lastUpdated: db.lastUpdated,
      notices: db.notices || [],
    });
  });

  app.post('/api/notices', (req: Request, res: Response) => {
    const notice: AbsenceNotice = req.body;
    if (!notice || !notice.id) {
      return res.status(400).json({ error: 'Missing notice data' });
    }

    if (!db.notices) db.notices = [];

    const existingIdx = db.notices.findIndex((n) => n.id === notice.id);
    if (existingIdx >= 0) {
      db.notices[existingIdx] = notice;
    } else {
      db.notices.unshift(notice);
    }

    broadcastChange('notice_saved', {
      studentName: notice.studentName,
      stage: notice.stage,
      status: notice.status,
    });

    res.json({ success: true, notice, version: db.version });
  });

  app.post('/api/notices/bulk-save', (req: Request, res: Response) => {
    const { notices: newNotices } = req.body;
    if (!Array.isArray(newNotices)) {
      return res.status(400).json({ error: 'Invalid notices array' });
    }

    if (!db.notices) db.notices = [];

    const noticeMap = new Map<string, AbsenceNotice>();
    db.notices.forEach((n) => noticeMap.set(n.id, n));
    newNotices.forEach((n) => noticeMap.set(n.id, n));

    db.notices = Array.from(noticeMap.values());
    broadcastChange('notices_bulk_saved', { count: newNotices.length });
    res.json({ success: true, count: db.notices.length, version: db.version });
  });

  app.delete('/api/notices/:id', requireAdmin, (req: Request, res: Response) => {
    const noticeId = req.params.id;
    if (!db.notices) db.notices = [];
    const countBefore = db.notices.length;
    db.notices = db.notices.filter((n) => n.id !== noticeId);

    if (db.notices.length < countBefore) {
      broadcastChange('notice_deleted', { noticeId });
    }
    res.json({ success: true, version: db.version });
  });

  // -------------------------------------------------------------
  // Settings API
  // -------------------------------------------------------------
  app.get('/api/settings', (req: Request, res: Response) => {
    res.json({
      version: db.version,
      settings: db.settings,
    });
  });

  const handleUpdateSettings = (req: Request, res: Response) => {
    const newSettings: SchoolSettings = req.body;
    if (!newSettings) {
      return res.status(400).json({ error: 'Missing settings' });
    }

    db.settings = { ...db.settings, ...newSettings };
    db.version += 1;
    db.lastUpdated = new Date().toISOString();
    saveDatabaseToDisk(db);
    broadcastChange('settings_updated', { settings: db.settings });
    res.json({ success: true, settings: db.settings, version: db.version });
  };

  app.put('/api/settings', handleUpdateSettings);
  app.post('/api/settings', handleUpdateSettings);

  // -------------------------------------------------------------
  // Database Save & Backup API
  // -------------------------------------------------------------
  app.post('/api/database/save-now', (req: Request, res: Response) => {
    db.version += 1;
    db.lastUpdated = new Date().toISOString();
    saveDatabaseToDisk(db);
    broadcastChange('database_saved_manually', {
      timestamp: db.lastUpdated,
      studentsCount: db.students.length,
      recordsCount: db.records.length,
      noticesCount: (db.notices || []).length,
      sessionsCount: (db.sessions || []).length,
    });

    res.json({
      success: true,
      version: db.version,
      lastUpdated: db.lastUpdated,
      counts: {
        students: db.students.length,
        records: db.records.length,
        notices: (db.notices || []).length,
        sessions: (db.sessions || []).length,
      },
      message: 'تم حفظ قاعدة البيانات بالكامل على الخادم بنجاح',
    });
  });

  app.post('/api/database/reset-defaults', requireAdmin, (req: Request, res: Response) => {
    db = {
      version: db.version + 1,
      lastUpdated: new Date().toISOString(),
      students: INITIAL_STUDENTS,
      records: generateInitialRecords(INITIAL_STUDENTS),
      settings: DEFAULT_SETTINGS,
      notices: INITIAL_NOTICES,
      users: INITIAL_USERS,
      sessions: generateInitialTeacherSessions(INITIAL_STUDENTS),
    };
    saveDatabaseToDisk(db);
    broadcastChange('database_reset_defaults');
    res.json({ success: true, version: db.version });
  });

  app.post('/api/database/import-full', requireAdmin, (req: Request, res: Response) => {
    const backup = req.body;
    if (!backup || !Array.isArray(backup.students)) {
      return res.status(400).json({ error: 'Invalid backup file structure' });
    }

    db = {
      version: db.version + 1,
      lastUpdated: new Date().toISOString(),
      students: backup.students,
      records: Array.isArray(backup.records) ? backup.records : db.records,
      settings: backup.settings ? { ...DEFAULT_SETTINGS, ...backup.settings } : db.settings,
      notices: Array.isArray(backup.notices) ? backup.notices : (db.notices || []),
      users: Array.isArray(backup.users) ? backup.users : db.users,
      sessions: Array.isArray(backup.sessions) ? backup.sessions : (db.sessions || []),
    };
    saveDatabaseToDisk(db);
    broadcastChange('database_imported_full', { count: db.students.length });
    res.json({ success: true, version: db.version, count: db.students.length });
  });

  // -------------------------------------------------------------
  // Timetable & Weekly Schedule Endpoints
  // -------------------------------------------------------------
  app.get('/api/timetable', (req: Request, res: Response) => {
    res.json({
      sessions: db.timetableSessions || [],
      activeMeta: db.activeTimetableMeta || null,
      history: (db.timetableHistory || []).map((h) => ({
        ...h.meta,
        sessionsCount: h.sessions.length,
      })),
    });
  });

  app.post('/api/timetable/import', (req: Request, res: Response) => {
    const { sessions, meta, updateSchoolSettings } = req.body;
    if (!Array.isArray(sessions) || sessions.length === 0) {
      return res.status(400).json({ error: 'قائمة الحصص المستوردة فارغة أو غير صالحة' });
    }

    const currentVerNum = Number(db.activeTimetableMeta?.version) || 1;
    const nextVersion = currentVerNum + 1;
    const nowIso = new Date().toISOString();

    const newMeta: TimetableMetadata = {
      id: meta?.id || `TT-V${nextVersion}-${Date.now()}`,
      name: meta?.name || `توقيت مستورد (الإصدار ${nextVersion})`,
      academicYear: meta?.academicYear || db.settings.academicYear || '2024/2025',
      effectiveDate: meta?.effectiveDate || new Date().toISOString().split('T')[0],
      version: nextVersion,
      importedAt: nowIso,
      sourceSheet: meta?.sourceSheet || 'أقسام - أفقي',
      sourceFileName: meta?.sourceFileName || 'سعدون عاشور - كل الجداول(2).xlsx',
      totalSessions: sessions.length,
      totalTeachers: new Set(sessions.map((s: TimetableSession) => s.teacherId || s.teacherName)).size,
      totalClassrooms: new Set(sessions.map((s: TimetableSession) => s.classroom)).size,
      isCurrent: true,
    };

    // Synchronize or create teacher accounts from imported sessions without duplication
    const teacherMap = new Map<string, { name: string; classrooms: Set<string>; subjects: Set<string>; teacherId: string }>();
    sessions.forEach((s: TimetableSession) => {
      if (!s.teacherName || s.teacherName === 'بدون إسناد' || s.teacherId === 'TEA-UNASSIGNED') return;
      const tKey = s.teacherId || s.teacherName;
      let entry = teacherMap.get(tKey);
      if (!entry) {
        entry = {
          name: s.teacherName,
          classrooms: new Set<string>(),
          subjects: new Set<string>(),
          teacherId: s.teacherId || `TEA-${Date.now()}`,
        };
        teacherMap.set(tKey, entry);
      }
      if (s.classroom) entry.classrooms.add(s.classroom);
      if (s.subject) entry.subjects.add(s.subject);
    });

    if (!Array.isArray(db.users)) db.users = [];

    teacherMap.forEach((info) => {
      const existingUser = db.users.find(
        (u) =>
          u.teacherId === info.teacherId ||
          u.name.trim() === info.name.trim() ||
          normalizeArabicUser(u.name) === normalizeArabicUser(info.name)
      );

      const assignedClassrooms = Array.from(info.classrooms);
      const assignedSubjects = Array.from(info.subjects);

      if (existingUser) {
        existingUser.assignedClassrooms = Array.from(new Set([...(existingUser.assignedClassrooms || []), ...assignedClassrooms]));
        existingUser.assignedSubjects = Array.from(new Set([...(existingUser.assignedSubjects || []), ...assignedSubjects]));
      } else {
        const cleanName = info.name.replace(/^(الأستاذ|الاستاذ|الأستاذة|الاستاذة|أ\.)\s*/g, '').trim();
        const usernameBase = cleanName.split(' ').map((w) => w[0] || '').join('') + Math.floor(100 + Math.random() * 900);
        const newUser: AppUser = {
          id: `USR-TEA-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          username: usernameBase.toLowerCase(),
          password: 'password123',
          name: info.name,
          role: 'teacher',
          teacherId: info.teacherId,
          assignedClassrooms,
          assignedSubjects,
          isActive: false, // New imported accounts start inactive until admin sets credentials
          createdAt: nowIso,
        };
        db.users.push(newUser);
      }
    });

    // Helper for user normalization
    function normalizeArabicUser(text: string): string {
      if (!text) return '';
      return text.trim().replace(/[\u064B-\u065F\u0670]/g, '').replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').toLowerCase();
    }

    // Mark previous active version as not current in history
    if (db.timetableHistory) {
      db.timetableHistory.forEach((h) => {
        h.meta.isCurrent = false;
      });
    } else {
      db.timetableHistory = [];
    }

    // Append to version history
    db.timetableHistory.push({
      meta: { ...newMeta },
      sessions: [...sessions],
    });

    db.timetableSessions = sessions;
    db.activeTimetableMeta = newMeta;

    // If user confirmed updating school settings with imported timing (13:30 afternoon shift)
    if (updateSchoolSettings) {
      db.settings.afternoonStartTime = '13:30';
      db.settings.afternoonLateThreshold = '13:35';
      db.settings.afternoonCutoffTime = '14:15';

      if (Array.isArray(db.settings.periods)) {
        db.settings.periods = db.settings.periods.map((p) => {
          if (p.id === 'a1') {
            return {
              ...p,
              startTime: '13:30',
              lateThreshold: '13:35',
              cutoffTime: '14:15',
              name: 'الفترة المسائية 1 (فوج 13:30)',
              shortName: 'م 1 (13:30)',
            };
          }
          if (p.id === 'a2') {
            return {
              ...p,
              startTime: '14:30',
              lateThreshold: '14:35',
              cutoffTime: '15:15',
              name: 'الفترة المسائية 2 (فوج 14:30)',
              shortName: 'م 2 (14:30)',
            };
          }
          if (p.id === 'a3') {
            return {
              ...p,
              startTime: '15:30',
              lateThreshold: '15:35',
              cutoffTime: '16:15',
              name: 'الفترة المسائية 3 (فوج 15:30)',
              shortName: 'م 3 (15:30)',
            };
          }
          return p;
        });
      }
      broadcastChange('settings_updated', { settings: db.settings });
    }

    // Increment overall database version and persist to disk (all student records and attendance preserved!)
    db.version = db.version + 1;
    db.lastUpdated = nowIso;
    saveDatabaseToDisk(db);

    broadcastChange('timetable_imported', {
      meta: newMeta,
      totalSessions: sessions.length,
      settingsUpdated: !!updateSchoolSettings,
    });

    res.json({
      success: true,
      message: `تم اعتماد وحفظ ${sessions.length} حصة في قاعدة البيانات بنجاح (الإصدار ${nextVersion})`,
      meta: newMeta,
      version: db.version,
      history: (db.timetableHistory || []).map((h) => ({
        ...h.meta,
        sessionsCount: h.sessions.length,
      })),
    });
  });

  app.post('/api/timetable/switch', (req: Request, res: Response) => {
    const { timetableId } = req.body;
    if (!timetableId) {
      return res.status(400).json({ error: 'معرف التوقيت مطلوب' });
    }

    if (!Array.isArray(db.timetableHistory) || db.timetableHistory.length === 0) {
      return res.status(404).json({ error: 'لا يوجد سجل تواريخ للتواقيت' });
    }

    const targetVersion = db.timetableHistory.find((h) => h.meta.id === timetableId);
    if (!targetVersion) {
      return res.status(404).json({ error: 'إصدار التوقيت المطلوب غير موجود' });
    }

    db.timetableHistory.forEach((h) => {
      h.meta.isCurrent = h.meta.id === timetableId;
    });

    db.timetableSessions = [...targetVersion.sessions];
    db.activeTimetableMeta = { ...targetVersion.meta, isCurrent: true };
    db.version = db.version + 1;
    db.lastUpdated = new Date().toISOString();

    saveDatabaseToDisk(db);
    broadcastChange('timetable_switched', { meta: db.activeTimetableMeta });

    res.json({
      success: true,
      message: `تم التبديل بنجاح إلى "${targetVersion.meta.name}"`,
      meta: db.activeTimetableMeta,
      sessionsCount: db.timetableSessions.length,
      sessions: db.timetableSessions,
    });
  });

  app.put('/api/timetable/session', (req: Request, res: Response) => {
    const sessionItem = req.body;
    if (!sessionItem || !sessionItem.day || !sessionItem.slotId || !sessionItem.classroom) {
      return res.status(400).json({ error: 'بيانات الحصة غير مكتملة' });
    }

    if (!Array.isArray(db.timetableSessions)) {
      db.timetableSessions = [];
    }

    const existingIdx = db.timetableSessions.findIndex((s) => s.id === sessionItem.id);
    if (existingIdx >= 0) {
      db.timetableSessions[existingIdx] = sessionItem;
    } else {
      if (!sessionItem.id) sessionItem.id = `SES-${Date.now()}`;
      db.timetableSessions.push(sessionItem);
    }

    db.version = db.version + 1;
    db.lastUpdated = new Date().toISOString();
    saveDatabaseToDisk(db);
    broadcastChange('timetable_session_updated', { session: sessionItem });

    res.json({ success: true, session: sessionItem });
  });

  app.delete('/api/timetable/session/:id', (req: Request, res: Response) => {
    const { id } = req.params;
    if (!id || !Array.isArray(db.timetableSessions)) {
      return res.status(400).json({ error: 'معرف الحصة غير صالح' });
    }

    db.timetableSessions = db.timetableSessions.filter((s) => s.id !== id);
    db.version = db.version + 1;
    db.lastUpdated = new Date().toISOString();
    saveDatabaseToDisk(db);
    broadcastChange('timetable_session_deleted', { id });

    res.json({ success: true });
  });

  // Vite middleware in dev or static serving in production
  if (process.env.NODE_ENV === 'production') {
    const distPath = path.join(process.cwd(), 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (req: Request, res: Response) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    }
  } else {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT} (Full-Stack Real-time Sync Active)`);
  });
}

startServer();
